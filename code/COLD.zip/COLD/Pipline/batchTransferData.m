%% Clean the stack data for the tiles that have been processed with COLD
dir_pipline = fileparts(mfilename('fullpath'));

%% Add paths
restoredefaultpath;
addpath(genpath(fileparts(dir_pipline)));

%% landsat tiles
[~, tiles] = readTileList;

dir_src_landsat = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/LandsatARDC2/';
dir_des_landsat = '/shared/cn449/Shi/LandsatCONUSARDC2/';

for i = 1: length(tiles)
    %% Obtain the tile name of Landsat data
    tile = tiles{i};
    %% Check the cold results, and if 100% done, just skip to submitt the job
    records_finished = checkTSFitLine(sprintf(globalsets.FolderpathCOLD, tile));
    %% Check the stack dataset
    [prct, err, images_err] = checkStack(tile);

    if records_finished == 100 || prct == 100
        fprintf('100 percent done for %s\r\n', tile);
        fprintf('Start to tranfer Landsat images %s\r\n', tile);

        images = dir(fullfile(dir_src_landsat, tile, '*'));
        if isempty(images)
            fprintf('No Landsat images left\r\n');
        end
        for im = 1: length(images)
            image = images(im);
            if isequal(image.name, '.') || isequal(image.name, '..')
                continue;
            end
            copyfile(fullfile(dir_src_landsat, tile, image.name), fullfile(dir_des_landsat, tile, sprintf('%s.part', image.name)));
            % in case the file is broken during transfering
            movefile(fullfile(dir_des_landsat, tile, sprintf('%s.part', image.name)), fullfile(dir_des_landsat, tile, sprintf('%s', image.name)));
            if isfolder(fullfile(dir_src_landsat, tile, image.name))
                rmdir(fullfile(dir_src_landsat, tile, image.name), 's');
            else
                delete(fullfile(dir_src_landsat, tile, image.name));
            end

            fprintf('%s\n', image.name); 
        end
    end
end
