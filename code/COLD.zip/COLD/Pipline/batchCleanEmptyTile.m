%% Clean the stack data for the tiles that have been processed with COLD
dir_pipline = fileparts(mfilename('fullpath'));

%% Add paths
restoredefaultpath;
addpath(genpath(fileparts(dir_pipline)));

%% landsat tiles
dir_src_landsat = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/LandsatARDC2/';
tiles = dir(fullfile(dir_src_landsat, 'h*'));

for i = 1: length(tiles)
    tile = tiles(i).name;

    dir_tile = fullfile(dir_src_landsat, tile);

    if length(dir(fullfile(dir_tile))) == 2
        rmdir(dir_tile);
    end


end