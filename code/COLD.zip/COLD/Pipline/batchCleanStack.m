%% Clean the stack data for the tiles that have been processed with COLD
dir_pipline = fileparts(mfilename('fullpath'));

%% Add paths
restoredefaultpath;
addpath(genpath(fileparts(dir_pipline)));

%% landsat tiles
% [~, tiles] = readTileList;

tiles = dir(fullfile('/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Detection', 'h*'));

for i = 1: length(tiles)
    %% Obtain the tile name of Landsat data
    tile = tiles(i).name;
    %% Check the cold results, and if 100% done, just skip to submitt the job
    records_finished = checkTSFitLine(sprintf(globalsets.FolderpathCOLD, tile));
    if records_finished ==100
        fprintf('100 percent done for %s\r\n', tile);
        folderpath_stack = fullfile(sprintf(globalsets.FolderpathCOLD, tile), 'StackData');
        if isfolder(folderpath_stack)% to delete all the files, rather than the folder, since we do not wanna this affect the parallel-computing
            stackfolders = dir(fullfile(folderpath_stack, 'R*'));
            for ifolder = 1: length(stackfolders)
                rmdir(fullfile(stackfolders(ifolder).folder, stackfolders(ifolder).name), 's');
            end
            rmdir(folderpath_stack); % remove the folders
            fprintf('Finished deleting the stack dataset at %s\r\n', folderpath_stack); 
        else
            fprintf('No the stack dataset at %s\r\n', folderpath_stack); 
        end
    end
end


