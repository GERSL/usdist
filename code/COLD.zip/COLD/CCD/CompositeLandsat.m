function [sdate, line_t] = CompositeLandsat(sdate, line_t, nbands)
    anomly = true; % exclude the "anomly" period of Landsat 5 and 7 as to single satellite period
    sticks_overtime = construct_composite_interval(max(sdate), anomly);

    for pix_id = 1:  nbands: size(line_t, 2)
        data_sr_composite = composite_adaptive(sdate, line_t(:, pix_id: pix_id + nbands -1), sticks_overtime);
    end
end

function sticks_overtime = construct_composite_interval(datenum_last, anomly)
    
    datenum_start  = datenum(datetime(1982, 1, 1)); % landsat data start from 1982 data data
    % datenum_last   = datenum(datetime(yyyymmdd));
    
    % define the datetime of each of sensor, which will be used to define the single or double satellite(s) period
    % when the images started to be acuqired rather than the lunch time

    % On November 18, 2011, image acquisitions were suspended for a period of 90 days, due to fluctuations in the performance of a critical amplifier in the satellite's transmission system.
    % Search by USGS Earth Explorer, the last image was acquired on May 5, 2012, but since November 18, 2011, there were very limited images acquired.
    landsat5_last   = datenum(datetime(2011,11,18));
    landsat7_first  = datenum(datetime(1999,6,30));
    landsat7_last   = datenum(datetime(2019, 12, 31)); % due to the orbit drift
    landsat8_first  = datenum(datetime(2013,3,18));
    landsat9_first  = datenum(datetime(2021,10,31));
    
    datenum_single = [datenum_start: landsat7_first - 1, ... % before landsat 7
        landsat5_last + 1: landsat8_first-1, ... % between end of landsat 5 and start of landsat 8, only Landsat 7
        landsat7_last + 1: landsat9_first - 1 ... % between end of landsat 7 and start of landsat 9, only Landsat 8
        ];
    if anomly
        landsat5_anomly = [datenum(datetime(2002,3,1)): datenum(datetime(2002,4,27)),... % bumper mode
            datenum(datetime(2005,11,27)): datenum(datetime(2006,1,8)),... % issue on back-up solar array drive
            datenum(datetime(2007,10,6)): datenum(datetime(2008,2,15)),... % issue with onboard batteries
            datenum(datetime(2009,12,19)): datenum(datetime(2010,1,6))]; % ther techinical difficulties
        landsat7_anomly = [datenum(datetime(2003,6,1)): datenum(datetime(2003,7,14))]; % because of the SLC-off, Landsat 7 did not collect data for one month
        datenum_single = [datenum_single, ... % before landsat 7
            landsat5_anomly, ... % during landsat 5 issue, only Landsat 7
            landsat7_anomly % during landsat 7 issue, only Landsat 5
            ];
    end
    % create adaptive intervals over time
    interval1_length = 16; % 1: single satellite
    interval2_length = 32; % 2: bi-satellites
    intervals1_overtime = datenum_start:interval1_length: datenum_last + interval1_length;


    % datenum_single = unique(datenum_single);

    % overlap the datenum list of single landsat with the 16-day intervals
    sticks_overtime = datenum_start;
    skip_next = false;
    for i = 1:length(intervals1_overtime)-1
        if skip_next
            skip_next = false; % turn off
            continue;
        end
        datenum_interval = intervals1_overtime(i):intervals1_overtime(i+1)-1;
        if sum(ismember(datenum_interval, datenum_single)) == length(datenum_interval)
            % all the days fall in the single landsat period, we make the
            % composite by each 16 days
            sticks_overtime = [sticks_overtime, intervals1_overtime(i) + interval1_length];
        else % otherwise, some days experienced two landsats, we used 32 days to composite 
            sticks_overtime = [sticks_overtime, intervals1_overtime(i) + interval2_length];
            skip_next = true; % skip next one of 16 days
        end
    end
    % remaining days as the last interval
    if sticks_overtime(end) < datenum_last
        sticks_overtime = [sticks_overtime, datenum_last];
    
    end
    sticks_overtime = sticks_overtime';
end

function data_sr_composite = composite_adaptive(datenum_obs, data_sr_point, sticks_overtime)
    rng(42);
    data_sr_composite = [];


    max_rnb = double(data_sr_point(:,4))./double(data_sr_point(:,3));

    selected_array = zeros(size(max_rnb), 'logical');
    for i_v = 1:length(sticks_overtime)-1
        interval = sticks_overtime(i_v):sticks_overtime(i_v+1)-1;
        idx = find(ismember(datenum_obs,interval));
        if ~isempty(idx)
            [~, id_idx] = max(max_rnb(idx));
            % data_sr_inverval = data_sr_point(idx,:);
            selected_array(idx(id_idx)) = 1; % here we just select the first one instead
        end
    end

    data_sr_point = data_sr_point(selected_array,:);
    % randomly select 12 observations if 
    year_obs = year(datenum_obs);
    for yr = unique(year_obs)'
        data_sr_year = data_sr_point(year_obs==yr,:);
        if height(data_sr_year) > 12
            data_sr_year = data_sr_year(randperm(height(data_sr_year), 12),:);
        end
        data_sr_composite = [data_sr_composite; data_sr_year];
    end

end
