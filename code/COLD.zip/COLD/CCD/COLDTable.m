function COLDTable(task,ntasks)
    addpath(fullfile(fileparts(fileparts(mfilename('fullpath')))));
    if ~exist('task', 'var')
        task = 1;
    end
    if ~exist('ntasks', 'var')
        ntasks = 1; % In total, 1000 csv files and 1000 samples per csv
    end


    tic
    %% Parameter setting.
    % Test the sensor's impact 
%     testSensor = 7;

    %% Constants:
    % Bands for detection change

    % If using linear model to conduct cross sensor adjustment
    sensorAdjust = 0;
    isOverWrite = false;
    recordSR = 1; % Record the surface reflectance bands
    alpha = 0.1; % p value of the significance
    binaryThresholdOfVegetated = 0.1;
    B_detect = 2:6;
    nbands = 8;
    % Treshold of noisercg_new
    Tmax_cg = 1-1e-5;
    composite = false;
    if composite 
        T_cg = 0.975;
        conse = 5;
    else
        T_cg = 0.99;
        conse = 6;
    end
    % Interested IDs
    ROIIDs = [];
    
    %% Locate to the working folder, in which all outputing data can be found

    
    folderpath_tsf = '/gpfs/sharedfs1/zhulab/Shi/ProjectTestDroughtEffectLegacy/Landsat/gordon_10m_agc_topographic/';
    folderpath_chg = '/gpfs/sharedfs1/zhulab/Shi/ProjectTestDroughtEffectLegacy/gordon_10m_agc_topographic_points/cold';
    
    if ~exist(folderpath_chg, 'dir')
       mkdir(folderpath_chg)
    end
    

    %% Check the sample CSV files
    sampleFiles = dir(fullfile(folderpath_tsf,'*.csv'));
    sampleFiles = {sampleFiles.name}';
    numSampleFiles = length(sampleFiles);
 
    %% HPC Process
    tasks_per = ceil(numSampleFiles/ntasks);
    start_i = (task-1)*tasks_per + 1;
    end_i = min(task*tasks_per, numSampleFiles);    

    tic
    fprintf('%d CSV wait for process in this task\n',end_i-start_i+1);
    %% Locate to a certain task, one task for one row folder
    for i_task = start_i:end_i
        sampleName = sampleFiles{i_task};
        %% Load the observations
        fprintf('Calculate greeening for -> %s (%d/%d with %d mins)\n',sampleName,i_task,end_i,round(toc/60));         
        filepath_rcg = fullfile(folderpath_chg, replace(sampleName,{'plot','.csv'},{'rec_cg','.mat'})); % r: row
        if isfile(filepath_rcg)&& ~isOverWrite
            fprintf('Skip\n');
            load(filepath_rcg);
        else
            % Run COLD and Trend analysis
            % Adjust based on robust regression
            samples = readtable(fullfile(folderpath_tsf,sampleName));
            
%             % Filter the low-quality observations
            srValues = table2array(samples(:,{'blue','green','red','nir','swir1','swir2'})); 
            idxRemoval = max(srValues,[],2)>1 | min(srValues,[],2)<0;
            samples = samples(~idxRemoval,:);
    

            % sdates from year and doy
            years = unique(samples.year); % used for the table-based COLD
            sdate = datenum(samples.year,1,samples.doy);
            % Landsat observations and QA
            line_t = table2array(samples(:,{'blue','green','red','nir','swir1','swir2','temp','qa_pixel'})); 
            line_t(:,1:6) = round(line_t(:,1:6)*10000); % between 0 and 10000
            line_t(:,7) = round(line_t(:,7)*10);        % in X10 K
            line_t(:,end) = convertQA2Fmask(line_t(:,end));
            % Samples to process
            proc_cols = samples.plotid;
            sensors = char(samples.sensor);
            sensors = str2num(sensors(:,end));
            
            % Path info in case single orbit processing is needed
            path_t_all = []; % samples(:,3);
            path_r = [];
            ncols = 0; % To keep same as the line-based COLD
            nrows = 1; % To keep same as the line-based COLD
            maxc = 8; % To keep same as the line-based COLD
            
            %% Run COLD
            rec_cg = TrendSeasonalFit_COLDTable(sdate, line_t, sensors,path_t_all, path_r, ...
                ncols, nrows, proc_cols, T_cg,Tmax_cg,conse,maxc,nbands,years,B_detect,composite,recordSR);
    
            fprintf(' -> Break detection %d min\n',round(toc/60));
            

            %% Append lat/lon information
            if isfield(samples, 'plotid') && isfield(samples, 'lon') && isfield(samples, 'lat')
                sampleInfo = samples(:,{'plotid','lon','lat'});
                sampleInfo = unique(sampleInfo);
                plotIDs = [rec_cg.pos]';
                [~,idxLoc] = ismember(plotIDs,sampleInfo.plotid);
                lats = num2cell(sampleInfo.lat(idxLoc));
                lons = num2cell(sampleInfo.lon(idxLoc));
                [rec_cg(:).lat] = lats{:};
                [rec_cg(:).lon] = lons{:};
            end
    
            
            %% save record of time series segments
            
            save([filepath_rcg, '.part'] ,'rec_cg'); % save as .part
            movefile([filepath_rcg, '.part'], filepath_rcg);  % and then rename it as normal format
            fprintf('Export -> %s (%d mins)\n',filepath_rcg,round(toc/60));
        end
%         %% Export the annual green trend as well
% %         selectVI = char(randsample(greeningsets.vegetationIndices,1)); 
%         for i_v = 1:length(greeningsets.vegetationIndices)
%             selectVI = greeningsets.vegetationIndices{i_v};
%             pathGreenTrendIndex = fullfile(pathGreenTrend,selectVI);
%             if ~exist(pathGreenTrendIndex,'dir')
%                 mkdir(pathGreenTrendIndex);
%             end
% 
%             filepath_trend = fullfile(pathGreenTrendIndex,replace(sampleName,{'Obs','.csv'},{'trend','.mat'}));
%             if isfile(filepath_trend)
%                 fprintf('Skip %s\n',filepath_trend);
%             else
%                 annualTrend = exportAnnualGreeningTrend(rec_cg,selectVI);    
%                 save([filepath_trend, '.part'] ,'annualTrend'); % save as .part
%                 clear rec_cg annualTrend;
%                 movefile([filepath_trend, '.part'], filepath_trend);  % and then rename it as normal format
%                 close all;
%                 fprintf('Export -> %s (%d mins)\n',filepath_trend,round(toc/60));
%             end
%         end
    end
end

function cfmask = convertQA2Fmask(qa)
    cfmask = qa;
    cfmask(bitget(qa,1) == 1) = 255; % Filled
    cfmask(bitget(qa,7) == 1) = 0; % Clear Land and Water [No Cloud & No Dialted Cloud]
    cfmask(bitget(qa,8) == 1) = 1; % Water
    cfmask(bitget(qa,5) == 1) = 2; % Cloud Shadow
    cfmask(bitget(qa,6) == 1) = 3; % Snow
    cfmask(bitget(qa,2) == 1) = 4; % Dilated Cloud
    cfmask(bitget(qa,4) == 1) = 4; % Cloud
end
