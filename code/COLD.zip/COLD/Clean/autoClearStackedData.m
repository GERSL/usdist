% set directory of the COLD results
path_coldresult = globalsets.PathCOLD;
name_rst = globalsets.FolderTSFit;

hvs = dir(fullfile(path_coldresult, 'h*'));
for i_hv = 1 : length(hvs)
    hv = hvs(i_hv);
% %     if ismember(hv.name,{'h003v010', 'h007v003', 'h015v009', 'h029v005', 'h021v015'})
% %         continue; % keep them
% %     end
    % if having 5000 .mat files, just skip it and go to process next
    lines_done = length(dir(fullfile(hv.folder, hv.name, name_rst, 'record_change*.mat')));
    if lines_done < 5000
        stackfolders = dir(fullfile(hv.folder, hv.name, 'L*'));
        fprintf('Did not finish COLD for %s with %d lines done, total %d images\r', ...
            hv.name, lines_done, length(stackfolders));
        continue;
    end
    counterReg = 5000;
    %% Check COLD results according to readable char
    % counterReg = 0;
    % for i = 1:5000
    %     % Check whether record_change already exist for row == i
    %     try
    %         % if successfully loaded => skip
    %         load((fullfile( hv.folder, hv.name, name_rst, ['record_change',sprintf('%d',i),'.mat'])))
    %         counterReg = counterReg + 1;
    %     catch
    %         % if file error occurs, just delete it
    %         delete((fullfile( hv.folder, hv.name, name_rst, ['record_change',sprintf('%d',i),'.mat'])))
    %         fprintf('%s: Errors in %d th record\r', hv.name, i);
    %         break;
    %         % not exist or corrupt
    %     end
    % end
    
%     fprintf('%s: Finished %0.00f Percent\r', hv.name, counterReg./50);
    %% Delete the stacked data/ folder if finished
    if counterReg == 5000
        % start to delete the stacked folder, but remain one that may be
        % used in the future to get image inforamtion
        stackfolders = dir(fullfile(hv.folder, hv.name, 'L*'));
        for ifolder = 1: length(stackfolders)
            rmdir(fullfile(hv.folder, hv.name, stackfolders(ifolder).name), 's');
        end
        fprintf('%s: %d lines done. Finished deleting %d stacked images\r', hv.name, counterReg , length(stackfolders));
    end
end

close all;