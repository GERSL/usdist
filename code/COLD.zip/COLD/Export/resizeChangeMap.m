%% Resize the change map into coaser resolution
function resizeChangeMap(folderpath_cold, years, varargin)
% This is to export the change map with corsers resoltuion based on the
% existing 30m change maps
%
% INPUT:
%
%   folderpath_cold:        Locate to COLD working folder, in which the
%                           change folder <TSFitLine> is necessery, and
%                           this folder was created by <COLD.m>.
%
%   out (optional):         Folder path of outputing.
%
%   years:                  [Array] The years of change map. 
%
%   resolution:             [Number] in meter. The spatial resolution of the pixel,  e.g., 1500 m
%
%   types (optional):       [1,2,3] The types defined by COLD
%
%
% OUTPUT:
%
% changemap_yyyy.tif in folder <ChangeMap> (yyyy means the year)
% uint16
% pixel value: xdoy (x indicates the type of change, and doy indicates DOY) 
% x's range is between 1 to 3
% 1 => regrowth break
% 2 => aforestation break
% 3 => land disturbance
% 
% AUTHOR(s): Zhe Zhu and Shi Qiu
% DATE: Feb. 7, 2021
% COPYRIGHT @ GERSLab
%
% Also see labelDisturbanceType.m
addpath(fileparts(fileparts(mfilename('fullpath'))));

% optional
p = inputParser;
addParameter(p,'types', [1,2,3]); % label the type of change
addParameter(p,'resolution', 1500); % not to display info
addParameter(p,'minarea', 0); % mini area
addParameter(p,'out', fullfile(folderpath_cold, 'ChangeMap')); % output folder
parse(p,varargin{:});
resolution = p.Results.resolution;
types = p.Results.types;
minarea = p.Results.minarea;
out = p.Results.out;

change_pixel_value = 255; % for display

[~, tilename] = fileparts(folderpath_cold);

fprintf('Start to resize change maps for %s\r\n', tilename);

if ~isfolder(out)
    mkdir(out);
end

%% exist check
for i_yr = 1: length(years)
    yr = years(i_yr);
    filename_changemap = ['changemap_typedoy_',num2str(yr),'.tif'];
    filename_changemap_resized = sprintf('%s_changemap_%d_%04d.tif', tilename, yr, resolution);
    
    % check resourcing change map
    filepath_map_src = fullfile(folderpath_cold, 'ChangeMap', filename_changemap); 
    if ~isfile(filepath_map_src)
        fprintf('Lack of %s\n', filepath_map_src);
        continue;
    end
    
    % check destination change map resized
    filepath_map_des = fullfile(out, filename_changemap_resized);
    % % if isfile(filepath_map_des)
    % %     try % load image to examine it
    % %         readgeoraster(filepath_map_des);
    % %         fprintf('Exist %s\n', filepath_map_des);
    % %         continue;
    % %     catch
    % %     end
    % % end
    
    % start to resize and save the map
    [image, R] = readgeoraster(filepath_map_src);
    info = geotiffinfo(filepath_map_src);
    image_out = image;
    % selec the types defined by cold
    image_out = zeros(size(image_out), 'uint8');
    for ig = 1: length(types)
        image_out(fix(image./1000)==types(ig)) = 1;
    end
    
    if minarea > 0
        image_out = bwareaopen(image_out, minarea); % remove tiny objects with fewer than 4 pixels
    end

    [image_scaled, R_scaled] = aggregateImage(image_out, R, R.CellExtentInWorldX/resolution, 'sum');

    image_scaled(image_scaled > 0) = change_pixel_value;
    geotiffwrite(filepath_map_des, image_scaled, R_scaled,'GeoKeyDirectoryTag',info.GeoTIFFTags.GeoKeyDirectoryTag);
    fprintf('Finish processing %s\n', filepath_map_des);
end
end


function [image_scaled, R_scaled] = aggregateImage(image, R, scale, method)
    [~, R_scaled] = mapresize(image, R, scale);
    switch method
        case 'sum'
            fun_block = @(block) sum(sum(block.data));
    end
    image_scaled = blockproc(image, [1/scale, 1/scale], fun_block);
end