function exportChangePreModelQuality(folderpath_cold, years, varargin)
%exportChangePreModelQuality.m This function is to create the Quality of the pre-change model estimation (e.g., perennial snow pixel, cloud detection failed, the normal procedure for model fit) and how many coefficients are used for model fit. 
%
%
% INPUT:
%
%   folderpath_cold:        Locate to COLD working folder, in which the
%                           change folder <TSFitLine> is necessery, and
%                           this folder was created by <COLD.m>.
%
%   years:                  [Array] The years of change map. 
%
%   msg (optional):         [false/true] Display processing status (default
%                           value: false)
%
% OUTPUT:
%
%
% REFERENCE(S):
%
%   Zhu, Zhe, et al. "Continuous monitoring of land disturbance based on
%   Landsat time series." Remote Sensing of Environment 238 (2020): 111116.
%
% EXAMPLE OF USE:
%
%   > To export change maps between 1985 and 2019 (without labling change type).
%
%     exportChangeMap('/lustre/scratch/qiu25856/TestGERSToolbox/h029v005/',
%     [1985:2019])
% 
% AUTHOR(s): Zhe Zhu and Shi Qiu
% DATE: Feb. 7, 2021
% COPYRIGHT @ GERSLab
%
% Also see labelDisturbanceType.m

addpath(fileparts(fileparts(mfilename('fullpath'))));

% optional
p = inputParser;
addParameter(p,'outpath', []); % same as the input if empty
addParameter(p,'msg', false); % not to display info
parse(p,varargin{:});
msg = p.Results.msg;
outpath = p.Results.outpath;

[~, foldername_working] = fileparts(folderpath_cold);
if msg
   fprintf('Start to export change premodel quality maps for %s\r\n', foldername_working);
end

folderpath_tsf = fullfile(folderpath_cold, 'TSFitLine');

if isempty(outpath)
    folderpath_chgmap = fullfile(folderpath_cold, 'ChangePreModelQualityMap');
else
    folderpath_chgmap = outpath;   
end
if ~isfolder(folderpath_chgmap)
    try
        mkdir(folderpath_chgmap);
    catch
    end
end

%% exist check
existfiles = true;
for i_yr = 1: length(years)
    yr = years(i_yr);
    filenameout = ['change_premodel_qa_map_',num2str(yr),'.tif'];
    if ~isfile(fullfile(folderpath_chgmap, filenameout))
        existfiles = false; % set to false if any one not exsit
        break;
    end
end

if existfiles
    if msg
        fprintf('Exist maps at %s\n', folderpath_chgmap);
    end
    return;
end

tic

%% get metadata
load(fullfile(folderpath_cold, 'metadata.mat'));
nrows = metadata.nrows;
ncols = metadata.ncols;
% dimension and projection of the image
jiDim = [ncols,nrows];
% max number of maps
max_n = length(years);
% slope threshold

% produce disturbance map
LandDistMap = zeros(nrows,ncols,max_n, 'uint8');

% cd to the folder for storing recored structure
% cd(v_input.name_rst);
records = dir(fullfile(folderpath_tsf,'record_change*.mat')); % folder names
num_line = size(records,1);

for line = 1: num_line
    % show processing status
    if msg
        if line/num_line < 1
            fprintf('Processing %.2f percent\r',100*(line/num_line));
        else
            fprintf('Processing %.2f percent\n',100*(line/num_line));
        end
    end
    % load one line of time series models
    load(fullfile(folderpath_tsf,records(line).name)); %#ok<LOAD>
    
    % postions
    pos = [rec_cg.pos];
    
    % continue if there is no model available
    l_pos = length(pos);
    if l_pos == 0
        continue
    end
    
    % break time
    t_break = [rec_cg.t_break];
    t_start = [rec_cg.t_start];
    category = [rec_cg.category];
    % change probability
    change_prob = [rec_cg.change_prob];
    
    
    for i = 1:l_pos - 1 % -1: segment of time series will not have change record!
        % get row and col
        [I,J] = ind2sub(jiDim,pos(i));
        
        if change_prob(i) == 1 && pos(i) == pos(i+1) % same position
            break_year = datevecmx(t_break(i));
            break_year = break_year(1);
            LandDistMap(J,I,years == break_year) = category(i); %
        end
    end
end


geotif_obj = metadata.GRIDobj;
for i_yr = 1: length(years)
    yr = years(i_yr);
    geotif_obj.Z = LandDistMap(:,:,i_yr);
    filenameout = ['change_premodel_qa_map_',num2str(yr),'.tif'];
    GRIDobj2geotiff(geotif_obj, fullfile(folderpath_chgmap, filenameout));
end

if msg
    fprintf('Finished exporting change premodel QA map for %s with %0.2f mins\r\n', foldername_working, toc/60); 
end
end
