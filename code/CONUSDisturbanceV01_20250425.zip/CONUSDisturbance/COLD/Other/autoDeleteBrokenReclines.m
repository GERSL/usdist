dir_lines = '/lustre/scratch/qiu25856/COLDResults/CONUS_SpectralChangeProduct_COLD2_Version1/h009v006/TSFitLine/';

linefiles = dir(fullfile(dir_lines, 're*.mat'));

for i = 3800: length(linefiles)
    try
        load(fullfile(dir_lines, linefiles(i).name));
    catch
        fprintf('Errors in %s\n', linefiles(i).name);
    end
end