ARDTiles = textread('pendingARDTiles_Prepare.txt', '%s');

list_time1stmodel = [];
for iard = 1: length(ARDTiles)
    
    hv_name = ARDTiles{iard};
    fprintf('Loading 1st model''s time for ARD %s\n', hv_name);
    outputFolder = fullfile('/lustre/scratch/qiu25856/COLDResults/CONUS_v16', hv_name);
	n_map = 'Year1stModel';
    outputFolder = fullfile(outputFolder, n_map);
    outputFilename = ['year1stmodel_',hv_name,'.tif'];
    outputFilepath = fullfile(outputFolder, outputFilename);
    
    mask_tmp = geotiffread(outputFilepath);
    list_time1stmodel = [list_time1stmodel, mask_tmp(:)];
end

% exclude pixel with 0, which is no year data to fit 1st model
list_time1stmodel = list_time1stmodel(list_time1stmodel>0);

figure;
set(gcf,'color','w');
xlim([1982, 1992]);
hold on;
histogram(list_time1stmodel, 'Normalization', 'probability');
xlabel('Year of First Initialized Model');
ylabel('Relative Probability');
box on;