function clearLandsatData(folderpath_cold, folderpath_landsat, msg)
%CLEARLANDSATDATA Clear all the Landsat data after change detection process finished.
% INPUT:
%
%   folderpath_cold:        Locate to COLD working folder, in which the
%                           change folder <TSFitLine> is necessery, and
%                           this folder was created by <COLD.m>.
%
%   folderpath_landsat:     Locate the folder of Landsat data
%
%   msg (optional)          [false/true] Display processing status (default
%                           value: false)

% folderpath_cold = '/lustre/scratch/qiu25856/COLDResults/CONUS_SpectralChangeProduct_COLD2/h015v008';

if ~exist('msg', 'var')
    msg = false;
end


if msg
    fprintf('Start to clear the Landsat data for %s\r\n', folderpath_landsat);
end

%% check the stack folder <LandsatData>, and if no, just return
if ~isfolder(folderpath_landsat)
    if msg
        fprintf('Already no the Landsat data for %s\r\n', folderpath_landsat);
    end
    return;
end


%% Check the results in <LandsatData>
if checkTSFitLine(folderpath_cold) == 1 % may be returned by existing file, or by 100% finished
    if isfolder(folderpath_landsat)
        try
            tic
            rmdir(folderpath_landsat, 's');
            if msg
                fprintf('Finished deleting the folder <LandsatData> of %s with %0.2f mins\r\n', folderpath_landsat, toc/60); 
            end
        catch
            if msg
                fprintf('Have no permit to delete the folder <LandsatData> of %s\r\n', folderpath_landsat); 
            end
        end
    end
end