function autoClearJobRecords(jobFolder)
dotmatlab = 'home/qiu25856/.matlab';

%% Set inputs here
isDelDotMatlb = 0;

if ~exist('jobFolder', 'var')
    jobFolder = 'HPCCJobsCOLD';
    % jobFolder = 'HPCCJobsDataPrep';
end


%% Check and go
if isDelDotMatlb && isfolder(dotmatlab)
    rmdir(dotmatlab, 's');
    fprintf('Deleted .matlab folder!\r');
end

jobfiles = dir(fullfile(jobFolder,'stack*'));
fileLen1 = length(jobfiles);
for ifile  =1 : fileLen1
    % the files in the past day
    if hours(datetime(now,'ConvertFrom','datenum')-jobfiles(ifile).date) > 48
    	delete(fullfile(jobfiles(ifile).folder, jobfiles(ifile).name));
    end
end

jobfiles = dir(fullfile(jobFolder,'h*'));
fileLen2 = length(jobfiles);
for ifile  =1 : fileLen2
    if hours(datetime(now,'ConvertFrom','datenum')-jobfiles(ifile).date) > 48
    	delete(fullfile(jobfiles(ifile).folder, jobfiles(ifile).name));
    end
end

jobfiles = dir(fullfile(jobFolder,'machine*'));
fileLen3 = length(jobfiles);
for ifile  =1 : fileLen3
    if hours(datetime(now,'ConvertFrom','datenum')-jobfiles(ifile).date) > 48
    	delete(fullfile(jobfiles(ifile).folder, jobfiles(ifile).name));
    end
end

fprintf('A total of %d job files were removed!\r', fileLen1+fileLen2+fileLen3);

