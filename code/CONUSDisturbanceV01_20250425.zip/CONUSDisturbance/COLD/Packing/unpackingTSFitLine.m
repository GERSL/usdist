function unpackingTSFitLine(folderpath_cold, varargin)
%UNPACKINGTSFITLINE is to un-pack to the record of time series segment per line in
%<TSFitLine> from .tar.

    tic; % count time

    %% request user's input
    p = inputParser;
    addParameter(p,'del', false); % is to delete the TSFitLine folder
    addParameter(p,'out', []); % is to delete the TSFitLine folder
    parse(p,varargin{:});
    del = p.Results.del;
    folderpath_out = p.Results.out;

    %% determine the folder
    if isempty(folderpath_out)
        folderpath_out = folderpath_cold;
    else
        if ~isfolder(folderpath_out)
            mkdir(folderpath_out);
        end
    end

    %% TSFitLine.tar
    filepath_tar = fullfile(folderpath_cold, 'TSFitLine.tar');
    if ~isfile(filepath_tar)
        warning(sprintf('No %s\r', filepath_tar));
        return;
    end
    
    %% Untar
    fprintf('Start uncompressing %s to\r %s\r', folderpath_cold, folderpath_out);
    untar(filepath_tar, folderpath_out)
    fprintf('Finish uncompressing %s with %0.4f mins\r', folderpath_cold, toc/60);

    %% delete the .tar
end

