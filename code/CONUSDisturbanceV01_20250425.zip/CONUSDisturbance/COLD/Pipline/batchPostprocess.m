function batchPostprocess(procs, varargin)
%% This is to post-processing at parallel of Landsat ARD  or PathRow tiles
%
% 
% AUTHOR(s): Shi Qiu
% DATE: Nov. 1, 2022
% Updated on June 22, 2023
% COPYRIGHT @ GERSLab

%% optional
p = inputParser;
addParameter(p,'task', 1); % 1st task
addParameter(p,'ntasks', 1); % single task to compute
addParameter(p,'out', ''); % the outputing directory

% request user's input
parse(p,varargin{:});
task = p.Results.task;
ntasks = p.Results.ntasks;
folderpath_out = p.Results.out;

% define the components that we are processing
% procs = {'annual_change_doy_map_resize-1500'};
% procs = {'annual_change_magnitude_map', 'annual_change_doy_map'};
% procs = {'annual_change_coeff'};
% procs = {'annual_change_doy_map'};
% procs = {'annual_change_magnitude_map'};
% procs = {'annual_change_rmagnitude_map'};

if ischar(procs) || isstring(procs)
    procs = {procs};
end

% force to define the outputing directory for single folder
folderpath_out = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Classification';
folderpath_out = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Detection';
if ~isempty(folderpath_out)&&~isfolder(folderpath_out)
    mkdir(folderpath_out);
end

%% Add paths
restoredefaultpath;
addpath(genpath(fileparts(fileparts(mfilename('fullpath')))));

%% COLD 2 for global path/row
folderpath_parentwork = globalsets.FolderpathCOLD;
folderpath_parentwork = strrep(folderpath_parentwork, '/%s', ''); % remove the expression
folderpath_parentwork = strrep(folderpath_parentwork, '%s', '');

%% Landsat tiles
% [~, Tiles] = readLandsatList;
% Locate ARD tiles in the working folder, if no specifyed
if ~exist('Tiles', 'var')
    Tiles = dir(fullfile(folderpath_parentwork, 'h*'));
    if isempty(Tiles) % also support path/row data
        Tiles = dir(fullfile(folderpath_parentwork, 'p*'));
    end
    Tiles = {Tiles.name};
end
% Tiles = {'h002v002'};
%% Define the years we are studying
years = globalsets.Years;

%% Assign tasks first
objtasks = [];
for iARD = 1: length(Tiles)
    tile = Tiles{iARD};
    for ipro = 1: length(procs)
        if strcmpi(procs{ipro}, 'annual_change_coeff')
            % parallel processing each row each tile
            row_step = 100;
            for irow = 1: row_step: 5000
                objtasks = [objtasks; ...
                    struct('tile', tile, 'process', {procs{ipro}}, 'years', years, 'rows', [irow, irow - 1 + row_step])];
            end
        else
            objtasks = [objtasks; ...
                struct('tile', tile, 'process', {procs{ipro}}, 'years', years, 'rows', [])];
        end
    end
end

    
for i = task: ntasks: length(objtasks)
    tile = objtasks(i).tile;
    procs = objtasks(i).process;
    years = objtasks(i).years;
    rows = objtasks(i).rows;
    
    function_tic = tic;
    % fprintf('Task# %03d/%03d to process %s for %s in %s\n', task, ntasks, procs, tile, num2str(years));
    
    folderpath_tilecold = fullfile(folderpath_parentwork, tile);
    folderpath_map = sprintf(globalsets.FolderpathDest, tile);

    %% Examine product's status
    if ismember('check_tsfit', procs)
        checkTSFitLine(folderpath_tilecold, 'read', true, 'msg', true);
%         checkProductProcessStatus(folderpath_tilecold);
    end
    
    %% Export change maps for mutiple years
    if ismember({'annual_change_doy_map'}, {procs})
        if checkTSFitLine(folderpath_tilecold) == 100
            exportChangeMap(folderpath_tilecold, years, 'ctype', true, 'msg', true, 'out', folderpath_map);
        else
            fprintf('Lack of records\r\n');
        end
    end

    %% Resize change map to a new resolution --- corser
    procs = split(procs, '-'); % split out the parameter, i.e., resolution
    if ismember({'annual_change_doy_map_resize'}, {procs{1}})
        resolution = str2num(procs{end});
        if ~isempty(folderpath_out)
            resizeChangeMap(folderpath_tilecold, years, 'types', [1,2,3], 'resolution', resolution, 'minarea', 4, 'out', folderpath_out);
        else
            resizeChangeMap(folderpath_tilecold, years, 'types', [1,2,3], 'resolution', resolution, 'minarea', 4);
        end
    end
    
    %% Export change magnitude for mutiple years
    if ismember('annual_change_magnitude_map', procs)
        exportChangeMagnitudeMap(folderpath_tilecold, years, 'msg', true);
    end
    %% Export change rmagnitude for mutiple years
    if ismember('annual_change_rmagnitude_map', procs)
        exportChangeMagnitudeMap(folderpath_tilecold, years, 'msg', true, 'relative', true);
    end
    
    %% Export change duration for mutiple years
    if ismember('annual_change_duration_map', procs)
        exportChangeDurationMap(folderpath_tilecold, years, 'msg', true);
    end
    
    %% Export change premodel QA for mutiple years
    if ismember('annual_change_premodel_qa_map', procs)
        exportChangePreModelQuality(folderpath_tilecold, years, 'msg', true);
    end
    
    %% Export change coeffs for mutiple years, that were developed for extracting the inputs of ODACA
    if ismember('annual_change_coeff', procs)
       exportChangeCoeffs(folderpath_tilecold, years, 'outpath', folderpath_map, 'rows', rows, 'msg', true);
    end
    
    %% Accumulate changes to display the most recent changes
    if ismember('accumulated_change_map', procs)
%         accumulateChangeMap(folderpath_tilecold, years, 'type', 'all', 'orbit', 'all', 'msg', true);
        accumulateChangeMap(folderpath_tilecold, years, 'type', 'regrowth', 'orbit', 'single', 'msg', true);
    end
    
    %% Create change frequency maps to display the number of (spectral) changes
    if ismember('change_frequency', procs)
        createChangeFrequencyMap(folderpath_tilecold, years, 'ctype', 'all', 'msg', true);
    end
    
    %% Create observation count map according to the rec_cg
    if ismember('observation_count', procs)
        exportObservationCount(fullfile(folderpath_parentout, tile), 'msg', true);
    end
    
    %% Create single row layer, according to the recorded number of clear-sky observations of rec_cg
    if ismember('single_row_layer', procs)
        createSingleRowLayer(folderpath_tilecold);
    end
    
    %% Create synthetic image
    if ismember('synthetic_image', procs)
        for iyr = min(years): years_step: max(years)
            createSyntheticImage(folderpath_tilecold, 2001, 7, 1, 'msg', true, 'compress', false);
        end
    end
    
    %% Packing the TSFitLine
    if ismember('packing_tsfit', procs)
        packingTSFitLine(folderpath_tilecold, 'del', true);
    end
    
    %% Unpacking the TSFitLine
    if ismember('unpacking_tsfit', procs)
        unpackingTSFitLine(folderpath_tilecold, 'out', folderpath_map);
    end

    %% Clean all the stack datset once change detection done
    if ismember('clear_stack', procs)
        clearStackData(folderpath_tilecold);
    end
    
    %% Clean all the Landsat dat once change detection done
    if ismember('clear_landsat', procs)
        clearLandsatData(folderpath_tilecold, sprintf(globalsets.FolderpathLandsat, tile), true);
    end

    % fprintf('Task# %03d/%03d finished with %0.2f mins\n', task, ntasks, toc(function_tic)/60);
end


%% History records

%% COLD 2 generated by qiu25856
% folderpath_parentwork = '/lustre/scratch/qiu25856/ProjectCONUSChange/CONUS_SpectralChangeProduct_COLD2_Version1/';

%% COLD 2 generated by zhu40264
% folderpath_parentwork = '/lustre/scratch/qiu25856/COLDResults/CONUS_SpectralChangeProduct_COLD2_Z/';

%% COLD 2 generated by qiu25856
% folderpath_parentwork = '/lustre/scratch/qiu25856/COLDResults/CONUS_SpectralChangeProduct_COLD2_Version1/';

%% Sets for distance agent classification
% folderpath_parentout = '/lustre/scratch/qiu25856/CONUSDisturbanceAgent/CONUS_DisturbanceAgent_Version1/';


%% Test sites for improving land cover classifications
% folderpath_parentwork = '/lustre/scratch/qiu25856/DataImprovingCoverClassification/TestData/'; 
% folderpath_parentwork = '/lustre/scratch/qiu25856/DataImprovingCoverClassification/ChangeCOLD2Paths/';
% ARDTiles = {'h003v010',...
%             'h007v003',...
%             'h015v009',...
%             'h021v015',...
%             'h029v005};
% folderpath_parentout = '/lustre/scratch/qiu25856/ProjectCONUSDisturbanceAgent/CONUSDisturbanceAgentC100/';
% folderpath_parentout = '/lustre/scratch/qiu25856/ProjectCONUSDisturbanceAgent/product/v101/magnitude/';
% folderpath_parentout = '/scratch/shq19004/GlobalAgentProductTest/';
% folderpath_parentwork = folderpath_parentout;

