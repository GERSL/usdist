
parpool(12);

restoredefaultpath;
addpath(genpath(fileparts(fileparts(mfilename('fullpath')))));


parfor i = 1: 12
    stackLandsatARDC2Bands2Line('h011v002', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h011v003', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h011v004', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h011v005', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h011v006', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h011v007', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h011v008', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h011v009', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h011v010', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h011v011', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h011v012', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h011v013', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h011v014', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h011v015', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h011v016', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h011v017', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h012v002', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h012v003', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h012v004', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h012v005', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h012v006', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h012v007', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h012v008', 'task', i, 'ntasks', 12);
    stackLandsatARDC2Bands2Line('h012v009', 'task', i, 'ntasks', 12);

    % piplineFromStackToCOLD('h001v005', 'task', i, 'ntasks', 1);
    % piplineFromStackToCOLD('h001v006', 'task', i, 'ntasks', 1);
    % stackLandsatARDC2Bands2Line('h001v007', 'task', i, 'ntasks', 30);
    % stackLandsatARDC2Bands2Line('h001v008', 'task', i, 'ntasks', 30);
    % piplineFromStackToCOLD('h001v009', 'task', i, 'ntasks', 1);
    % stackLandsatARDC2Bands2Line('h001v010', 'task', i, 'ntasks', 30);
    % stackLandsatARDC2Bands2Line('h002v001', 'task', i, 'ntasks', 30);
    % piplineFromStackToCOLD('h007v001', 'task', i, 'ntasks', 1);
    % stackLandsatARDC2Bands2Line('h002v003', 'task', i, 'ntasks', 30);
    % stackLandsatARDC2Bands2Line('h002v004', 'task', i, 'ntasks', 30);
    % stackLandsatARDC2Bands2Line('h002v005', 'task', i, 'ntasks', 30);
    
end