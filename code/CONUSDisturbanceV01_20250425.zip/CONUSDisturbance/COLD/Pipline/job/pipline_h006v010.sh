#!/bin/bash
#SBATCH -J h006v010 # jobname
#SBATCH --partition=general
#SBATCH --nodes 1 
#SBATCH --ntasks 1
#SBATCH --array 1-69
#SBATCH --mem-per-cpu=10G
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err

echo $SLURMD_NODENAME # display the node name
cd ../

module load matlab
matlab -nojvm -nodisplay -nosplash -singleCompThread -r piplineFromStackToCOLD\(\'h006v010\',\'task\',$SLURM_ARRAY_TASK_ID,\'ntasks\',$SLURM_ARRAY_TASK_MAX\); exit

exit

#SBATCH --partition=general

#SBATCH --partition=priority
#SBATCH --account=zhz18039

#SBATCH --partition=osg
#SBATCH --account=osgusers

