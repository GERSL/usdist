#!/bin/bash
#SBATCH -J post # jobname
#SBATCH --partition=priority
#SBATCH --account=zhz18039
#SBATCH --nodes 1 
#SBATCH --ntasks 1
#SBATCH --array 1-100
#SBATCH --mem-per-cpu=40G
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err

echo $SLURMD_NODENAME # display the node name
cd ../

module load matlab
# matlab -nojvm -nodisplay -nosplash -singleCompThread -r batchPostprocess\(\'annual_change_doy_map\',\'task\',$SLURM_ARRAY_TASK_ID,\'ntasks\',$SLURM_ARRAY_TASK_MAX\); exit
# matlab -nojvm -nodisplay -nosplash -singleCompThread -r batchPostprocess\(\'annual_change_coeff\',\'task\',$SLURM_ARRAY_TASK_ID,\'ntasks\',$SLURM_ARRAY_TASK_MAX\); exit
# matlab -nojvm -nodisplay -nosplash -singleCompThread -r batchPostprocess\(\'annual_change_magnitude_map\',\'task\',$SLURM_ARRAY_TASK_ID,\'ntasks\',$SLURM_ARRAY_TASK_MAX\); exit
# matlab -nojvm -nodisplay -nosplash -singleCompThread -r batchPostprocess\(\'annual_change_premodel_qa_map\',\'task\',$SLURM_ARRAY_TASK_ID,\'ntasks\',$SLURM_ARRAY_TASK_MAX\); exit
matlab -nojvm -nodisplay -nosplash -singleCompThread -r batchPostprocess\(\'annual_change_rmagnitude_map\',\'task\',$SLURM_ARRAY_TASK_ID,\'ntasks\',$SLURM_ARRAY_TASK_MAX\); exit

exit

#SBATCH --partition=general

#SBATCH --partition=priority
#SBATCH --account=zhz18039

#SBATCH --partition=osg
#SBATCH --account=osgusers

