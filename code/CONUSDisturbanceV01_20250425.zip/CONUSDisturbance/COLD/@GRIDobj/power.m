function OUT = power(varargin)

funname = 'power';
narginchk(2,2)
OUT = builtincaller(funname,varargin{:});