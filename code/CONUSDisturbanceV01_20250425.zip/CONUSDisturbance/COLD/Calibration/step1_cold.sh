#!/bin/bash
#SBATCH -J cold
#SBATCH --partition=priority			# specify partition
#SBATCH --account=zhz18039			# specify the priority account 
#SBATCH --constraint='epyc128' 
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --array 1-100
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err
#SBATCH --mem-per-cpu=20G


echo $SLURMD_NODENAME # display the node name
echo $SLURM_ARRAY_TASK_ID
echo $SLURM_ARRAY_TASK_MAX

module load matlab

matlab -nojvm -nodisplay -nosplash -singleCompThread -r step1_cold\($SLURM_ARRAY_TASK_ID,$SLURM_ARRAY_TASK_MAX,1\) # COMPOSITE
# matlab -nojvm -nodisplay -nosplash -singleCompThread -r step1_cold\($SLURM_ARRAY_TASK_ID,$SLURM_ARRAY_TASK_MAX,0\) # NON-COMPOSITE


exit


#SBATCH --partition=priority			# specify partition
#SBATCH --account=zhz18039			# specify the priority account 


#SBATCH --partition=general