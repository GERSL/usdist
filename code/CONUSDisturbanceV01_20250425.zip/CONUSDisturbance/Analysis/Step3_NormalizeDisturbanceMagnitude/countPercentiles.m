function countPercentiles(jobid, jobnum)
% This function goes to compute the individual disturbance pixel for each
% agent, including magnitude

tic

%% Add code paths
pathpackage = fileparts(fileparts(fileparts(mfilename('fullpath')))); 
addpath(pathpackage); % add ODACA's parent folder
addpath(fullfile(pathpackage, 'ODACA'));

%% Pre-setted paras
if isempty(odacasets.refineSampleCollection)
    product_version = 0; % indicate the maps using open-source data
else
    product_version = odacasets.refineSampleCollection + 1; % following the sample collection's #
end
dir_map = fullfile(odacasets.pathResultMaps, sprintf('V%02dPostRelease', product_version));
dir_map_ana = fullfile(odacasets.pathResultAnalysis, sprintf('V%02dPostRelease', product_version));
dir_terri = fullfile(odacasets.pathResultAnalysis, 'state_regions');

if ~exist('jobid', 'var') || ~exist('jobnum', 'var')
    jobid = 1; jobnum = 1;
end

agent = 'target';

agent_code_full = [1,2,3,4,5,6,7];
switch  agent
    case 'all'
        agent_codes = agent_code_full;
    case 'target'
        agent_codes = [1,2,3,4,5,6];
    otherwise
        agent_codes = [getfield(odacasets.agents, agent)];
end

% e.g., getfield(agents, 'stress') will return 4.
% e.g., fieldnames(agents) will return the agent names
agent_names = fieldnames(odacasets.agents_release);

% path_shapefile = fullfile(pathpackage, 'Analysis', 'Shapefile', shapefile_name, sprintf('%s.shp', shapefile_name));
% grid_shapefile = shaperead(path_shapefile);

dir_ana_grid_rec = fullfile(dir_map_ana, 'conus_disturbance_pixel_magnitude', agent);
if ~isfolder(dir_ana_grid_rec)
    mkdir(dir_ana_grid_rec);
end

conus_tiles = odacasets.ARDTiles;
years = 1987:2022;

for ic = jobid: jobnum: length(agent_codes)
    agentname = agent_names{agent_codes(ic)};
    fprintf('Processing %s\n', agentname);

    % Merge all .csv files that are available
    pix_mags_agent = [];
    for iy = 1: length(years)
        yr = years(iy);
        fprintf('Loading data in %d\n', yr);
        for it = 1: length(conus_tiles)
            tile = conus_tiles{it};
            filepath_rec = fullfile(dir_ana_grid_rec, sprintf('%s_%d_%s_pixel_magnitude.csv', tile, yr, agentname));
            if isfile(filepath_rec)
                pix_mags = readtable(filepath_rec);
                pix_mags.agent = repmat({agentname}, size(pix_mags,1), 1);
                pix_mags_agent = [pix_mags_agent; pix_mags];
            end
        end
    end
    mag_prcts = prctile([pix_mags_agent.magnitude], [0, 25, 50, 75, 100]);
    mag_prcts
end

end

function entire_map_terri = load_entire_terri_map(dir_map, h_min, h_max, v_min, v_max)
    tile_size = 5000;
    hs = h_min:h_max;
    vs = v_min:v_max;
    entire_map_terri = zeros(tile_size.*length(hs), tile_size.*length(vs));
    for iv = 1: length(vs)
        for ih = 1: length(hs)
            filepath_map = fullfile(dir_map, sprintf('h%03dv%03d_terri_state.tif', hs(ih), vs(iv)));
            if isfile(filepath_map)
                entire_map_terri((iv -1)*tile_size + 1 : iv*tile_size, (ih-1)*tile_size + 1: ih*tile_size)= imread(filepath_map);
            end
        end
    end
end

function entire_map_disturb = load_entire_disturbance_map(dir_map, yr, key, h_min, h_max, v_min, v_max, version)
    tile_size = 5000;
    hs = h_min:h_max;
    vs = v_min:v_max;
    entire_map_disturb = zeros(tile_size.*length(hs), tile_size.*length(vs));
    for iv = 1: length(vs)
        for ih = 1: length(hs)
            mapname = sprintf('CD_%03d%03d_%04d_%s', hs(ih), vs(iv), yr, version);
            filepath_map = fullfile(dir_map, sprintf('h%03dv%03d', hs(ih), vs(iv)), mapname, sprintf('%s_%s.tif', mapname, key));
            if isfile(filepath_map)
                entire_map_disturb((iv -1)*tile_size + 1 : iv*tile_size, (ih-1)*tile_size + 1: ih*tile_size)= imread(filepath_map);
            end
        end
    end
end