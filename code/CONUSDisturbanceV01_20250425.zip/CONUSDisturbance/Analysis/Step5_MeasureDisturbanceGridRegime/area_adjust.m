function area = area_adjust(agent_name, area)
    switch agent_name
        case 'all'
            adjust_factor_area = get_area_adjust_factor('Disturbance', 0);
        case 'anthropogenic'
            adjust_factor_area = get_area_adjust_factor('Anthropogenic', 1);
        case 'natural'
            adjust_factor_area = get_area_adjust_factor('Natural', 1);
        case 'mixed'
            adjust_factor_area = get_area_adjust_factor('Mixed', 1);
        case 'forest_management'
            adjust_factor_area = get_area_adjust_factor('Logging', 2);
        case 'construction'
            adjust_factor_area = get_area_adjust_factor('Construction', 2);
        case 'agriculture_activity'
            adjust_factor_area = get_area_adjust_factor('Agricultural change', 2);
        case 'stress'
            adjust_factor_area = get_area_adjust_factor('Stress', 2);
        case 'natural_hazard'
            adjust_factor_area = get_area_adjust_factor('Wind and geohazard', 2);
        case 'water_dynamic'
            adjust_factor_area = get_area_adjust_factor('Water dynamic', 2);
        case 'fire'
            adjust_factor_area = get_area_adjust_factor('Fire', 2);
    end
    area = area*adjust_factor_area;
end

function [adjust_factor_area, adjust_factor_area_std] = get_area_adjust_factor(agent_name, level)
    % Calculates the area adjustment factor and its standard error for a given agent.
    % Parameters:
    % agent_name (string): The name of the agent.
    % level (int): The level of the agent (0, 1, or 2).
    % Returns:
    % adjust_factor_area (double): The area adjustment factor.
    % adjust_factor_area_std (double): The standard error of the adjustment factor.

    if nargin < 2
        level = 2; % Default level
    end

    % The mapped pixel area for each agent, including other as last element
    level2_agents = {'Logging', 'Construction', 'Agricultural change', 'Stress', ...
                     'Wind and geohazard', 'Water dynamic', 'Fire', 'Other'};
    level1_agents = {'Anthropogenic', 'Natural', 'Mixed', 'Other'};
    level0_agents = {'Disturbance', 'Other'};
    
    % 1988-2022 data
    level2_maparea = [818023180, 162535245, 686167559, 237669529, 22437757, ...
                      211722125, 200739895, 300364635120];
    level1_maparea = [level2_maparea(strcmp(level2_agents, 'Logging')) + ...
                      level2_maparea(strcmp(level2_agents, 'Construction')) + ...
                      level2_maparea(strcmp(level2_agents, 'Agricultural change')), ...
                      level2_maparea(strcmp(level2_agents, 'Stress')) + ...
                      level2_maparea(strcmp(level2_agents, 'Wind and geohazard')), ...
                      level2_maparea(strcmp(level2_agents, 'Water dynamic')) + ...
                      level2_maparea(strcmp(level2_agents, 'Fire')), ...
                      level2_maparea(strcmp(level2_agents, 'Other'))];
                  
    level0_maparea = [sum(level1_maparea(1:3)), level1_maparea(4)];
    
    if level == 2
        adj_area_proportion = [0.00216005821062309000, 0.00050396254166034600, ...
                               0.00157825625023407000, 0.00089483793835486900, ...
                               0.00009555742299355500, 0.00075376301384972800, ...
                               0.00056516499689410200, 0.9934484];
        adj_area_std_error_proportion = [0.00011520499018179600, 0.00003728556756761910, ...
                                         0.00010878890963850200, 0.00005856756890541120, ...
                                         0.00003820341415181740, 0.00005124719521030140, ...
                                         0.00002382153709892140, 0.000145195];
        map_proportion = level2_maparea / sum(level2_maparea);
        i = find(strcmp(level2_agents, agent_name));
        
    elseif level == 1
        adj_area_proportion = [0.00453765769747212000, 0.00080448415043756300, ...
                               0.00134860797977440000, 0.99330925017231600000];
        adj_area_std_error_proportion = [0.00013044567654391100, 0.00005639054845699630, ...
                                         0.00005485193876488860, 0.00012044567440190500];
        map_proportion = level1_maparea / sum(level1_maparea);
        i = find(strcmp(level1_agents, agent_name));
        
    elseif level == 0
        adj_area_proportion = [0.00689999798185498000, 0.99310000201814500000];
        adj_area_std_error_proportion = [0.00009040677948448250, 0.00009040677948448260];
        map_proportion = level0_maparea / sum(level0_maparea);
        i = find(strcmp(level0_agents, agent_name));
        
    else
        error('Invalid level. Level must be 0, 1, or 2.');
    end
    
    % Calculate the adjustment factor area and its standard error
    adjust_factor_area = adj_area_proportion(i) / map_proportion(i);
    adjust_factor_area_std = adj_area_std_error_proportion(i) / map_proportion(i);
end

% function area = area_adjust(agent_code, area)
%     % agent code, 1, 2, 3, 4, 5, 6, 7, 8 which is same as to the defination
%     % in the ODACA setup class
% 
%     % adjust the area according to the good practice and samples
%     pixe_map = [818023180.0, 162535245.0, 237669529.0, 22437757.0, 211722125.0, 200739895.0, 686167559.0, 300364635120.0]; % pixel
%     area_map = pixe_map/sum(pixe_map); % convert to porption
% 
%     % sample-based estimation
%     area_true = [0.00216005821062309000,	0.00050396254166034600,	0.00089483793835486900,	0.00009555742299355500,	0.00075376301384972800,	0.00056516499689410200, 0.00157825625023407000,	0.9934484];
% 
%     area = area*area_true(agent_code)/area_map(agent_code);
% end