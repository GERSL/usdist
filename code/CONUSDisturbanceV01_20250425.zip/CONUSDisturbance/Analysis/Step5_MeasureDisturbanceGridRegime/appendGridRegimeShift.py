import os
import geopandas as gpd
import shutil
import numpy as np
import pandas as pd
import h5py

# Add paths (Python doesn't require explicit path adding in most cases)
pathpackage = os.path.abspath(os.path.join(os.path.dirname(__file__), '../..'))

# Pre-set parameters

years = list(range(1988, 2023))
product_version = 8
pathResultAnalysis = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Analysis/'
shapefile_name = 'hexagon_grid_50km'
dir_map_ana = os.path.join(pathResultAnalysis, f'V{product_version:02d}PostRelease')

dir_ana_grid_rec = os.path.join(dir_map_ana, f'{shapefile_name}_dist_regime_shift_patch_1988_2022')
dir_ana_grid_shp = os.path.join(dir_map_ana, f'{shapefile_name}_dist_regime_shift_patch_{years[0]}_{years[-1]}_shapefile')


# create the directory if it does not exist
if not os.path.exists(dir_ana_grid_shp):
    os.makedirs(dir_ana_grid_shp)

agents_name = ['all', 'anthropogenic', 'natural', 'mixed', 'forest_management',
                'construction', 'agriculture_activity', 'stress', 'natural_hazard',
                'water_dynamic', 'fire']

measurements = ['dist_frequency', 'dist_size','dist_size_median', 'dist_size_prct75', 'dist_size_prct99', 'dist_size_max', 'dist_severity', 'dist_grid_area_adjust']

measurements = ['dist_frequency', 'dist_size','dist_severity']
measurements = ['dist_size_median', 'dist_size_prct75', 'dist_size_prct99', 'dist_size_max', 'dist_grid_area_adjust']

valueformats = ['mean']

# load all .csv files into dataframe
rec_files = [f for f in os.listdir(dir_ana_grid_rec) if f.endswith('.csv')]
dist_grid_data = pd.concat([pd.read_csv(os.path.join(dir_ana_grid_rec, f)) for f in rec_files])

# load shapfile

path_shapefile = os.path.join(pathpackage, 'Analysis', 'Shapefile', shapefile_name, f'{shapefile_name}.shp')
grid_shapefile = gpd.read_file(path_shapefile)
# Specifically process the layers
if shapefile_name == 'eco_regions_l3':
    # Convert NA_L3CODE to numeric ID
    grid_shapefile['Id'] = grid_shapefile['NA_L3CODE'].str.replace('.', '').astype(float)

# give the geo data to the dist_grid_data
dist_grid_data_shape = dist_grid_data.merge(grid_shapefile, left_on='Id', right_on='Id', how='left')    
# to geo data frame
dist_grid_data_shape = gpd.GeoDataFrame(dist_grid_data_shape)

# select the grids which occured disturbance when the frequency of all disturbances is larger than 0
grid_freqs = dist_grid_data_shape[dist_grid_data_shape['measurement'] == 'dist_frequency']
grid_ids = grid_freqs[grid_freqs['MeanY8822'] > 0]['Id'].unique()
dist_grid_data_shape = dist_grid_data_shape[dist_grid_data_shape['Id'].isin(grid_ids)]


# label the significant acceleration and deceleration
dist_grid_data_shape['sig_celeration'] = 255 # filled with 255
# trend is significant
# celeration is significant
# when the trend is significant, but the celeration is not significant, we label it as 0
dist_grid_data_shape['sig_celeration'][(dist_grid_data_shape['TrhY8822'] == 1)] = 0
# when trend is positive, and celeration is positive, we label it as 1, which means accelerated increasing.
dist_grid_data_shape['sig_celeration'][(dist_grid_data_shape['TrhY8822'] == 1) & (dist_grid_data_shape['TrsY8822'] > 0) & (dist_grid_data_shape['CTrhY8822'] == 1) & (dist_grid_data_shape['CTrsY8822'] > 0)] = 1
# when trend is positive, and celeration is negetive, we label it as -1, which means decelerated increasing.
dist_grid_data_shape['sig_celeration'][(dist_grid_data_shape['TrhY8822'] == 1) & (dist_grid_data_shape['TrsY8822'] > 0) & (dist_grid_data_shape['CTrhY8822'] == 1) & (dist_grid_data_shape['CTrsY8822'] < 0)] = -1
# when trend is negetive, and celeration is positive, we label it as 1, which means accelerated decreasing.
dist_grid_data_shape['sig_celeration'][(dist_grid_data_shape['TrhY8822'] == 1) & (dist_grid_data_shape['TrsY8822'] < 0) & (dist_grid_data_shape['CTrhY8822'] == 1) & (dist_grid_data_shape['CTrsY8822'] < 0)] = 1
# when trend is negetive, and celeration is negetive, we label it as 1, which means decelerated decreasing.
dist_grid_data_shape['sig_celeration'][(dist_grid_data_shape['TrhY8822'] == 1) & (dist_grid_data_shape['TrsY8822'] < 0) & (dist_grid_data_shape['CTrhY8822'] == 1) & (dist_grid_data_shape['CTrsY8822'] > 0)] = -1


# process the data by agent and measurement, one by one
agents = dist_grid_data_shape['agent'].unique()
measurements = dist_grid_data_shape['measurement'].unique()
for agent in agents:
    for measurement in measurements:
        print(f'Processing {agent} {measurement}')
        shapefile_name = f'{agent}_{measurement}_mean_{years[0]}_{years[-1]}'
        # select the data by agent and measurement
        data_selected = dist_grid_data_shape[(dist_grid_data_shape['agent'] == agent) & (dist_grid_data_shape['measurement'] == measurement)]

        # step 1: save the data to shapefile
        # save the data to shapefile
        # save as shapefile
        data_selected.to_file(os.path.join(dir_ana_grid_shp, f'{shapefile_name}.shp'))
        # Copy projection-related files
        for ext in ['.prj', '.cpg', '.sbn']:
            shutil.copyfile(path_shapefile.replace('.shp', ext), os.path.join(dir_ana_grid_shp, f'{shapefile_name}.shp').replace('.shp', ext))
        # msg
        print(f'{shapefile_name} saved')

        # step 2: convert the polygon to point
        # convert data_selected with polygon to point, with central point
        data_selected['geometry'] = data_selected['geometry'].centroid
        data_selected = gpd.GeoDataFrame(data_selected)
        # save as shapefile
        data_selected.to_file(os.path.join(dir_ana_grid_shp, f'{shapefile_name}_point.shp'))
        # Copy projection-related files
        for ext in ['.prj', '.cpg', '.sbn']:
            shutil.copyfile(path_shapefile.replace('.shp', ext), os.path.join(dir_ana_grid_shp, f'{shapefile_name}_point.shp').replace('.shp', ext))