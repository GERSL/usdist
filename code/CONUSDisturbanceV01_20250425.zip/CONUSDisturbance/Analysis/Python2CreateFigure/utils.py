import numpy as np

def get_area_adjust_factor(agent_name, level = 2):
    """
    Calculates the area adjustment factor and its standard error for a given agent.
    Parameters:
    agent_name (str): The name of the agent.
    Returns:
    tuple: A tuple containing the area adjustment factor and its standard error.
    Raises:
    None
    Example:
    >>> get_area_adjust_factor('Logging')
    (0.00216005821062309, 0.000115204990181796)
    """

    
    # the mapped pixel area for each agent, including other as last element
    level2_agents = ['Logging',  'Construction', 'Agricultural disturbance','Stress', 'Wind/geohazard', 'Water disturbance', 'Fire', 'Other']
    level1_agents = ['Human-directed', 'Wild', 'Mixed', 'Other']
    level0_agents = ['Disturbance', 'Other']
    # 1988-2022
    level2_maparea = [818023180,
                162535245,
                686167559,
                237669529,
                22437757,
                211722125,
                200739895,
                300364635120]
    level1_maparea = [level2_maparea[level2_agents.index('Logging')]+level2_maparea[level2_agents.index('Construction')]+level2_maparea[level2_agents.index('Agricultural disturbance')],
                level2_maparea[level2_agents.index('Stress')]+level2_maparea[level2_agents.index('Wind/geohazard')],
                level2_maparea[level2_agents.index('Water disturbance')]+level2_maparea[level2_agents.index('Fire')],
                level2_maparea[level2_agents.index('Other')],
                ]
    level0_maparea = [level1_maparea[level1_agents.index('Human-directed')]+level1_maparea[level1_agents.index('Wild')]+level1_maparea[level1_agents.index('Mixed')],
                level1_maparea[level1_agents.index('Other')]
                ]
    if level == 2:
        # sorted by level2_order, that is the order of the agent, i.e., ['Logging',  'Construction', 'Agricultural disturbance','Stress', 'Wind/geohazard', 'Water disturbance', 'Fire', 'Other']
        adj_area_proportion = [0.00216005821062309000,	0.00050396254166034600,	0.00157825625023407000,	0.00089483793835486900,	0.00009555742299355500,	0.00075376301384972800,	0.00056516499689410200,	0.9934484]
        adj_area_std_error_proportion = [0.00011520499018179600,0.00003728556756761910,0.00010878890963850200,0.00005856756890541120,0.00003820341415181740,0.00005124719521030140,0.00002382153709892140,0.000145195]
        
        # calculate the proportion of the mapped pixel area for each agent
        map_proportion = np.asarray(level2_maparea)/np.sum(level2_maparea)
        
        # the index of the agent in the list
        i = level2_agents.index(agent_name)
    elif level == 1:
        # adj_area_proportion = [0.00453765769747212000,	0.00080448415043756300,	0.00134860797977440000,	0.99330925017231600000]
        # adj_area_std_error_proportion = [0.00013044567654391100,	0.00005639054845699630,	0.00005485193876488860,	0.00012044567440190500]
        # stephen's methods
        adj_area_proportion = [0.004249,	0.001558,	0.000755,	0.993437]
        adj_area_std_error_proportion = [0.000155, 0.000072027,	0.000051334,	0.000145]
        
        # calculate the proportion of the mapped pixel area for each agent
        map_proportion = np.asarray(level1_maparea)/np.sum(level1_maparea)
        
        # the index of the agent in the list
        i = level1_agents.index(agent_name)
    elif level == 0:
        # stephen's methods
        adj_area_proportion = [0.006563,	0.993437]
        adj_area_std_error_proportion = [0.000145,	0.000145]
        
        # calculate the proportion of the mapped pixel area for each agent
        map_proportion = np.asarray(level0_maparea)/np.sum(level0_maparea)
        
        # the index of the agent in the list
        i = level0_agents.index(agent_name)
    
    
    adjust_factor_area = adj_area_proportion[i]/map_proportion[i]
    adjust_factor_area_std = adj_area_std_error_proportion[i]/map_proportion[i]
    
    return adjust_factor_area, adjust_factor_area_std