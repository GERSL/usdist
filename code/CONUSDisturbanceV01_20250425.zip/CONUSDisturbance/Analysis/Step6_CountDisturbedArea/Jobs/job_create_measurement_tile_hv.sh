#!/bin/bash
#SBATCH -J hv_area
#SBATCH --partition=general
#SBATCH --constraint='epyc128' 
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --array 1-100
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err
#SBATCH --mem-per-cpu=20G


echo $SLURMD_NODENAME # display the node name
echo $SLURM_ARRAY_TASK_ID
echo $SLURM_ARRAY_TASK_MAX

cd ../

module load matlab

matlab -nojvm -nodisplay -nosplash -singleCompThread -r countTileDisturbanceVerticalHorizontal\($SLURM_ARRAY_TASK_ID,$SLURM_ARRAY_TASK_MAX,15000\)
matlab -nojvm -nodisplay -nosplash -singleCompThread -r countTileDisturbanceVerticalHorizontal\($SLURM_ARRAY_TASK_ID,$SLURM_ARRAY_TASK_MAX,1500\)
matlab -nojvm -nodisplay -nosplash -singleCompThread -r countTileDisturbanceVerticalHorizontal\($SLURM_ARRAY_TASK_ID,$SLURM_ARRAY_TASK_MAX,3000\)
matlab -nojvm -nodisplay -nosplash -singleCompThread -r countTileDisturbanceVerticalHorizontal\($SLURM_ARRAY_TASK_ID,$SLURM_ARRAY_TASK_MAX,6000\)


exit


#SBATCH --partition=priority			# specify partition
#SBATCH --account=zhz18039			# specify the priority account 


#SBATCH --partition=general