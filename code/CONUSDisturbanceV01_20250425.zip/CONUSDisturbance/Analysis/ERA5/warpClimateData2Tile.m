function warpClimateData2Tile(jobid, jobnum)
    %% Add code paths
    pathpackage = fileparts(fileparts(fileparts(mfilename('fullpath')))); 
    addpath(pathpackage); % add ODACA's parent folder
    addpath(fullfile(pathpackage, 'ODACA')); % add the <Shared>
    addpath(fullfile(pathpackage, 'ODACA', 'Shared')); % add the <Shared>

    if ~exist('jobid', 'var') || ~exist('jobnum', 'var')
        jobid = 1; jobnum = 1;
    end

    conus_tiles = odacasets.ARDTiles;
    
    dir_era5 = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/ERA5/Monthly';

    layers = {'total_precipitation', '2m_temperature'};
    lyers_

    years = 1988:2022; % the study years

    for i = 1: length(years)
        yr = years(i);
        for j = 1: length(layers)
            layer = layers{j};
            filepath_layer = fullfile(dir_era5, layer, sprintf('%s_%d.nc', layer, yr));
            filepath_layer_tif = fullfile(dir_era5, layer, sprintf('%s_%d.tif', layer, yr));

                % if we have no file here, then we will create this.
            finfo = ncinfo(filepath_layer);
            layer_shortname = finfo.Variables(end).Name;
            WV = ncread(filepath_layer, layer_shortname);
            
            finfo = finfo.Attributes;
            LatitudeResolution = finfo(strcmp({finfo.Name}, 'LatitudeResolution')).Value;
            LatitudeResolution = str2num(LatitudeResolution);
            LongitudeResolution = finfo(strcmp({finfo.Name}, 'LongitudeResolution')).Value;
            LongitudeResolution = str2num(LongitudeResolution);
            
            % Limits in latitude/longitude of the geographic quadrangle bounding the georeferenced raster. 
            LatitudeLimits = ncread(nc4_file,'lat');
            LatitudeLimits = [min(LatitudeLimits(:))-LatitudeResolution/2, max(LatitudeLimits(:))+LatitudeResolution/2];
            LongitudeLimits = ncread(nc4_file,'lon');
            LongitudeLimits = [min(LongitudeLimits(:))-LongitudeResolution/2, max(LongitudeLimits(:))+LongitudeResolution/2];

            WV = rot90(fliplr(WV));
            % Write the .grd data into geotiff
            R = georasterref('RasterSize',size(WV),'LatitudeLimits',LatitudeLimits,........
            'LongitudeLimits',LongitudeLimits);
        
            % save it locally
            % default 'CoordRefSysCode', 4326
            geotiffwrite(tiffile,WV,R);
            
            wv_gridobj = GRIDobj(filepath_layer_tif);
            WV = imread(filepath_layer_tif);
            wv_gridobj.Z = WV(:,:,hour);
            wv_gridobj.size(end) = [];
        end
    end


end

