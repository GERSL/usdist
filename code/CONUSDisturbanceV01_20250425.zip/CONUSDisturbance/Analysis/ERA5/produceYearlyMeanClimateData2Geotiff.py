'''to preprocess the ERA5 data to geotiff files with yearly mean values'''
import os
import datetime
import time
import rasterio
import pyproj
import numpy as np
from pathlib import Path
import click
import glob
from shapely.geometry import box
import geopandas as gpd
import pandas as pd
import xarray as xr
import rioxarray as rio

@click.command()
@click.option("--ci",          "-i", default=1, type=int, help="The core's id")
@click.option("--cn",          "-n", default=1, type=int, help="The number of cores")
@click.option("--source", "-l", default="/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/ERA5/Monthly", type=str, help="The filepath of the data's location")
@click.option("--destination", "-o", default="/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/ERA5/Yearly", type=str, help="The filepath of the output location")
def main(ci, cn, source, destination):
    # print the input parameters
    print("source: ", source)
    print("destination: ", destination)
    print("ci: ", ci)
    print("cn: ", cn)
    
    layers = ['total_precipitation', '2m_temperature']
    layers_shortname = ['tp', 't2m'] # respond to the layers
    years = range(1985, 2023)
    for iyr in range(ci-1, len(years), cn):
        # print the year
        print("processing ", years[iyr])
        yr = years[iyr]
        for i, layer in enumerate(layers):
            # create the destination folder if it does not exist
            Path(os.path.join(destination, layer)).mkdir(parents=True, exist_ok=True)
            # layer of the data
            layer_shortname = layers_shortname[i]
            
            # open it
            ncfile = xr.open_dataset(os.path.join(source, layer, '{}_{}.nc'.format(layer, yr)))
            
            #Extract the variable
            pr = ncfile[layer_shortname]
            
            # get ignoring-nan average of the data along with the time axis, that is 12 months
            pr = pr.mean(dim='valid_time', skipna=True)

            #Define lat/long 
            pr = pr.rio.set_spatial_dims('longitude', 'latitude')

            #Check for the CRS
            pr.rio.crs

            #(Optional) If your CRS is not discovered, you should be able to add it like so:
            pr.rio.set_crs("epsg:4326")

            #Saving the file
            pr.rio.to_raster(os.path.join(destination, layer, '{}_{}.tif'.format(layer, yr)))

 # /gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/LandsatARDC2/CONUS_C2_ARD_grid/
# Main function
if __name__ == "__main__":
    main()