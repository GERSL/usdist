function countPixLevelClearObsNum(folderpath_ard, folderpath_save, varargin)
%% Add code paths
addpath(genpath(fileparts(fileparts(mfilename('fullpath')))));

% directory of Landsat ARd
folderpath_ard = '/shared/cn449/DataLandsatARDCONUSTemp';
folderpath_save = '/scratch/shq19004/Temp';
% optional
p = inputParser;
addParameter(p,'orbitpath', 'single'); % to create single path layer
addParameter(p,'task', 1); % 1st task
addParameter(p,'ntasks', 1); % single task to compute
addParameter(p,'errorpass', false);
parse(p,varargin{:});
task = p.Results.task;
ntasks = p.Results.ntasks;
errorpass = p.Results.errorpass;

% char will be better understood for users
switch lower(p.Results.orbitpath)
    case 'single'
        singlepath = true;
    case 'all'
        singlepath = false;
end


tiles = dir(fullfile(folderpath_ard, 'h*'));

for i = task: ntasks: length(tiles)
    tile = tiles(i).name;
    
    % search the images at the tile
    imfs_all = dir(fullfile(folderpath_ard, tile, 'L*BT.tar'));
%     imfs = regexpi({imfs_all.name}, 'L(T05|T04|E07|C08|C09)(\w*)', 'match'); % no expand name
    sensors = {'LT04', 'LT05', 'LE07', 'LC08'};
    for s = 1: length(sensors)
        sensor = sensors{s};
        imfs = regexpi({imfs_all.name}, [sensor, '(\w*)'], 'match'); % no expand name
        imfs = [imfs{:}];
        imfs = vertcat(imfs{:});
        imfs(:, end-2:end) = []; 
        % sort according to yeardoy, and this ensure each core would have same
        % image list if parallel.
        yyyymmdd = str2num(imfs(:, 16:23)); % should change for different sets
        [~, sort_order] = sort(yyyymmdd);
        imfs = imfs(sort_order, :);
        folderpath_tile_save = fullfile(folderpath_save, tile);
        if ~isfolder(folderpath_tile_save)
            mkdir(folderpath_tile_save);
        end
        path_ard = [];
        year_pre = 0;
        for im = 1: size(imfs, 1)
            imf = imfs(im, :);
            year_imf = str2num(imf(16:19));
            if isfile(fullfile(folderpath_tile_save, sprintf('%s_clear_observation_number_%d.tif', sensor, year_imf)))
                continue;
            end
            try
                % uncompress the image BT.tar
                filepath_imf = fullfile(folderpath_ard, tile, [imf, '_BT.tar']);
                files_uncompress = untar(filepath_imf, folderpath_tile_save);
            catch
                continue;
            end
    
            % convert pixel QA to fmask values
            pix_qa = GRIDobj(fullfile(folderpath_tile_save, [imf, '_PIXELQA.tif']));
            pix_qa.Z = uint16(pix_qa.Z);
            cfmask = zeros(pix_qa.size, 'uint8');
            cfmask(bitget(pix_qa.Z,1) == 1) = 255;
            cfmask(bitget(pix_qa.Z,2) == 1) = 0;
            cfmask(bitget(pix_qa.Z,3) == 1) = 1;
            cfmask(bitget(pix_qa.Z,4) == 1) = 2;
            cfmask(bitget(pix_qa.Z,5) == 1) = 3;
            cfmask(bitget(pix_qa.Z,6) == 1) = 4;
    
            % single path layer
            if singlepath
                if isempty(path_ard)
                    if isfile(fullfile(folderpath_tile_save, 'singlepath_landsat.tif'))
                        path_ard = GRIDobj(fullfile(folderpath_tile_save, 'singlepath_landsat.tif'));
                    else
                        singlepathlayer = GRIDobj(fullfile( fileparts(mfilename('fullpath')), 'singlepath_landsat_conus.tif'));  % at parent code's folder
                        path_ard = reproject2utm(singlepathlayer, pix_qa, 'method', 'nearest');
                        path_ard.Z = uint8(path_ard.Z);
                        GRIDobj2geotiff(path_ard, fullfile(folderpath_tile_save, 'singlepath_landsat.tif'));
     
                    end
                end
                % Find the collection 1's path from .xml, and rename stack name with end of path
                filepath_xml = fullfile(folderpath_tile_save, [imf, '.xml']);
                fid_in=fopen(filepath_xml,'r');
                xml_str=strread(fscanf(fid_in,'%c',inf)','%s');
                path_char=char(xml_str(strmatch('path=',xml_str))); % path=
                path = str2double(path_char(1,7:end-1)); % only 1 item
                cfmask(path_ard.Z ~= path) = 255; % single path
            end
    
            % sum of the number of clear obs
            if year_imf~= year_pre % when we come to a different year, we will initlize the mask of recording clear observations' number
                mask_clr_num = pix_qa;
                mask_clr_num.Z = zeros(pix_qa.size, 'uint16'); % initilaze the mask of clear observation's number
                year_pre = year_imf;
            end
            mask_clr_num.Z = mask_clr_num.Z + uint16(cfmask <= 1);
            
            % save if next year will be different or the last image
            if im == size(imfs, 1) || str2num(imfs(im+1, 16:19)) ~= year_pre
                GRIDobj2geotiff(mask_clr_num, fullfile(folderpath_tile_save, sprintf('%s_clear_observation_number_%d.tif', sensor, year_imf)));
            end
            for idel = 1: length(files_uncompress)
                delete(files_uncompress{idel});
            end
            fprintf('Updated %s %s in %d\n', tile, sensor, year_imf);
        end
    end
end