#!/bin/bash
#SBATCH -J orgmap
#SBATCH --partition=general
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --array 1-20
#SBATCH --exclude=cn[244,245,246,252,254,255,268,269,270,271,285,286,287,289,290,291,293,331,390,394]
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err


echo $SLURMD_NODENAME # display the node name
echo $SLURM_ARRAY_TASK_ID
echo $SLURM_ARRAY_TASK_MAX

cd ../

module load matlab

matlab -nojvm -nodisplay -nosplash -singleCompThread -r organizeMaps\($SLURM_ARRAY_TASK_ID,$SLURM_ARRAY_TASK_MAX\)



exit


#SBATCH --partition=priority			# specify partition
#SBATCH --account=zhz18039			# specify the priority account 


#SBATCH --partition=general