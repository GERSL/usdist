#!/bin/bash
#SBATCH -J gridindex
#SBATCH --partition=general
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --array 1-500
#SBATCH --exclude=cn[244,245,246,252,254,255,268,269,270,271,285,286,287,289,290,291,293,331,341,355,390,394,535,546]
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err
#SBATCH --mem-per-cpu=10G


echo $SLURMD_NODENAME # display the node name
echo $SLURM_ARRAY_TASK_ID
echo $SLURM_ARRAY_TASK_MAX

cd ../

module load matlab

matlab -nojvm -nodisplay -nosplash -singleCompThread -r measureGridDisturbance\($SLURM_ARRAY_TASK_ID,$SLURM_ARRAY_TASK_MAX\,\'forest_management\'\)
matlab -nojvm -nodisplay -nosplash -singleCompThread -r measureGridDisturbance\($SLURM_ARRAY_TASK_ID,$SLURM_ARRAY_TASK_MAX\,\'agriculture_activity\'\)
matlab -nojvm -nodisplay -nosplash -singleCompThread -r measureGridDisturbance\($SLURM_ARRAY_TASK_ID,$SLURM_ARRAY_TASK_MAX\,\'construction\'\)
matlab -nojvm -nodisplay -nosplash -singleCompThread -r measureGridDisturbance\($SLURM_ARRAY_TASK_ID,$SLURM_ARRAY_TASK_MAX\,\'stress\'\)
matlab -nojvm -nodisplay -nosplash -singleCompThread -r measureGridDisturbance\($SLURM_ARRAY_TASK_ID,$SLURM_ARRAY_TASK_MAX\,\'debris\'\)
matlab -nojvm -nodisplay -nosplash -singleCompThread -r measureGridDisturbance\($SLURM_ARRAY_TASK_ID,$SLURM_ARRAY_TASK_MAX\,\'water_dynamic\'\)
matlab -nojvm -nodisplay -nosplash -singleCompThread -r measureGridDisturbance\($SLURM_ARRAY_TASK_ID,$SLURM_ARRAY_TASK_MAX\,\'fire\'\)
matlab -nojvm -nodisplay -nosplash -singleCompThread -r measureGridDisturbance\($SLURM_ARRAY_TASK_ID,$SLURM_ARRAY_TASK_MAX\,\'other\'\)
matlab -nojvm -nodisplay -nosplash -singleCompThread -r measureGridDisturbance\($SLURM_ARRAY_TASK_ID,$SLURM_ARRAY_TASK_MAX\,\'noother\'\)
matlab -nojvm -nodisplay -nosplash -singleCompThread -r measureGridDisturbance\($SLURM_ARRAY_TASK_ID,$SLURM_ARRAY_TASK_MAX\,\'all\'\)


exit


#SBATCH --partition=priority			# specify partition
#SBATCH --account=zhz18039			# specify the priority account 


#SBATCH --partition=general