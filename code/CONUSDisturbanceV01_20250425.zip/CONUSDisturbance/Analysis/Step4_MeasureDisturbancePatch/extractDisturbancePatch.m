function extractDisturbancePatch(jobid, jobnum)
% This function goes to compute the individual disturbance patches for each
% agent, including size and magnitude

tic

%% Add code paths
pathpackage = fileparts(fileparts(fileparts(mfilename('fullpath')))); 
addpath(pathpackage); % add ODACA's parent folder
addpath(fullfile(pathpackage, 'ODACA'));

%% Pre-setted paras
if isempty(odacasets.refineSampleCollection)
    product_version = 0; % indicate the maps using open-source data
else
    product_version = odacasets.refineSampleCollection + 1; % following the sample collection's #
end

dir_map = fullfile(odacasets.pathResultMaps, sprintf('V%02dPostRelease', product_version));
dir_map_ana = fullfile(odacasets.pathResultAnalysis, sprintf('V%02dPostRelease', product_version));
dir_terri = fullfile(odacasets.pathResultAnalysis, 'state_regions');

if ~exist('jobid', 'var') || ~exist('jobnum', 'var')
    jobid = 55; jobnum = 100;
end

% agent = 'forest_management';
agent_code_full = [1,2,3,4,5,6,7,8];
agent_name_full = fieldnames(odacasets.agents);
agent = 'target';

switch  agent
    case 'all'
        agent_codes = agent_code_full;
    case 'target'
        agent_codes = [1,2,3,4,5,6,7];
    otherwise
        agent_codes = [getfield(odacasets.agents, agent)];
end

%        agents = struct('forest_management',    1, ...
%                        'agriculture_activity', 2, ...
%                        'construction',         3, ...
%                        'stress',               4, ...
%                        'debris',               5, ...
%                        'water_dynamic',        6, ...
%                        'fire',                 7, ...
%                        'other',                8);
% e.g., getfield(agents, 'stress') will return 4.
% e.g., fieldnames(agents) will return the agent names

% path_shapefile = fullfile(pathpackage, 'Analysis', 'Shapefile', shapefile_name, sprintf('%s.shp', shapefile_name));
% grid_shapefile = shaperead(path_shapefile);

conus_tiles = odacasets.ARDTiles;
years = odacasets.years;

dir_ana_grid_rec = fullfile(dir_map_ana, 'conus_disturbance_patch');
if ~isfolder(dir_ana_grid_rec)
    mkdir(dir_ana_grid_rec);
end


version = sprintf('V%02d', product_version);

for ijob = jobid: jobnum: length(conus_tiles)
    tile = conus_tiles{ijob};

    % check the file exists or not
    existing_all = true;
    for iy = 1: length(years)
        yr = years(iy);
        for ic = 1: length(agent_codes)
            agent_code = agent_codes(ic);
            filepath_rec = fullfile(dir_ana_grid_rec, tile, sprintf('%s_dist_patch_%d_%d.csv', tile, yr, agent_code));
            filepath_rec_empty = fullfile(dir_ana_grid_rec, tile, sprintf('%s_dist_patch_%d_%d.ept', tile, yr, agent_code));
            if isfile(filepath_rec) || isfile(filepath_rec_empty)
                continue;
            else
                existing_all = false;
                break;
            end
        end
    end
    % % if existing_all
    % %     fprintf('All records exist for %s\n', tile);
    % %     continue;
    % % end

    % start to process normally
    tile_h = str2num(tile(2:4));
    tile_v = str2num(tile(6:8));
    % extend one ard tile to create disturbance objects
    ard_buf = 1;
    h_min = min([tile_h])-ard_buf;
    v_min = min([tile_v])-ard_buf;
    h_max = max([tile_h])+ard_buf;
    v_max = max([tile_v])+ard_buf;
    % avoid negative values
%     h_min = max(0, h_min);
%     v_min = max(0, v_min);
    entire_map_terri = load_entire_terri_map(dir_terri, h_min, h_max, v_min, v_max);
    entire_map_terri = entire_map_terri > 0;
    map_center_tile = zeros(size(entire_map_terri), 'logical');
    map_center_tile(5001:10000, 5001:10000) = 1;
    % at each year, we calculate the measurements
    % record_disturbance_patch= [];
    for iy = 1: length(years)
        yr = years(iy);

        % fprintf('Processing %s %d\n', tile, yr);

        % define the white entire map
        entire_map_disturb_agent                    = load_entire_disturbance_map(dir_map, yr, 'AGENT', h_min, h_max, v_min, v_max, version);
        % entire_map_disturb_agent(~entire_map_terri) = 0; % exclude non-terri
        entire_map_disturb_mag                      = load_entire_disturbance_map(dir_map, yr, 'MAG', h_min, h_max, v_min, v_max, version);
        entire_map_disturb_mag                      = entire_map_disturb_mag./10000; % back to 0-1
        % remain disturbed pixels
        for ic = 1: length(agent_codes)
            agent_code = agent_codes(ic);

            filepath_rec = fullfile(dir_ana_grid_rec, tile, sprintf('%s_dist_patch_%d_%d.csv', tile, yr, agent_code));
            filepath_rec_empty = fullfile(dir_ana_grid_rec, tile, sprintf('%s_dist_patch_%d_%d.ept', tile, yr, agent_code));
            % % if isfile(filepath_rec) || isfile(filepath_rec_empty)
            % %     fprintf('Exist %s\n', filepath_rec);
            % %     continue;
            % % end

            % create the folder if it does not exist
            if ~isfolder(fullfile(dir_ana_grid_rec, tile))
                mkdir(fullfile(dir_ana_grid_rec, tile));
            end


            switch agent_name_full{agent_codes(ic)}
                case 'forest_management'
                    severity_quarter = odacasets.severity_quarter_forest_management; % i.e., [lower, median, higher]
                case 'construction'
                    severity_quarter = odacasets.severity_quarter_construction;
                case 'agriculture_activity'
                    severity_quarter = odacasets.severity_quarter_agriculture_activity;
                case 'stress'
                    severity_quarter = odacasets.severity_quarter_stress;
                case 'natural_hazard'
                    severity_quarter = odacasets.severity_quarter_debris;
                case 'water_dynamic'
                    severity_quarter = odacasets.severity_quarter_water_dynamic;
                case 'fire'
                    severity_quarter = odacasets.severity_quarter_fire;
            end


            patches = regionprops(bwconncomp(entire_map_disturb_agent == agent_codes(ic)), 'Area', 'PixelIdxList');
            for io = 1: length(patches)
                num_central_tile = sum(map_center_tile(patches(io).PixelIdxList)) ;
                if num_central_tile > 0 % only collect any pixels at the central title
                    if num_central_tile < patches(io).Area
                        across = true;
                    else
                        across = false;
                    end
                    pix_mag = entire_map_disturb_mag(patches(io).PixelIdxList);

                    % Code of segmenting the severity at pixel level
                    pix_agent = entire_map_disturb_agent(patches(io).PixelIdxList) == agent_code; % this is not necessery
                    % convert to severity, 1, 2, 3, 4
                    pix_severity = zeros(size(pix_mag));

                    pix_severity(pix_agent & pix_mag <= severity_quarter(1)) = 1;  % low: <= 25th percentile
                    pix_severity(pix_agent & pix_mag > severity_quarter(1) & pix_mag <= severity_quarter(2)) = 2; % moderate: % 25th < and <= 50th
                    pix_severity(pix_agent & pix_mag > severity_quarter(2) & pix_mag <= severity_quarter(3)) = 3; % high % 50th < and <= 75th
                    pix_severity(pix_agent & pix_mag > severity_quarter(3)) = 4; % very high < 75th percentile  

                    patches(io).year                   = yr;
                    patches(io).agent                  = agent_codes(ic);
                    patches(io).across_tile            = across;
                    patches(io).area                   = patches(io).Area*0.09;
                    patches(io).pixel_severity_mean    = mean(pix_severity);
                    patches(io).pixel_severity_median  = median(pix_severity);
                    patches(io).patch_magnitude_mean   = mean(pix_mag);
                    patches(io).patch_magnitude_median = median(pix_mag);

                    % record_disturbance_patch = [record_disturbance_patch, ...
                    %     struct('year', yr, 'agent', agent_codes(ic), 'across_tile', across,'area', patches(io).Area*0.09, 'severity', mean(pix_severity), 'magnitude', mean(pix_mag))];
                else
                    patches(io).area = 0;
                end
            end
            % stand by empty file to help to recognize we have procssed or
            % not
            if ~isempty(patches)
                patches = patches([patches.area] > 0);
                if ~isempty(patches)
                    patches = rmfield(patches, 'PixelIdxList'); % reduce the file size
                    writetable(struct2table(patches), filepath_rec);
                else
                    emptyStruct = struct;
                    save(filepath_rec_empty,'-struct','emptyStruct');
                end
            else
                emptyStruct = struct;
                save(filepath_rec_empty,'-struct','emptyStruct');
            end
        end
    end
end

end

function entire_map_terri = load_entire_terri_map(dir_map, h_min, h_max, v_min, v_max)
    tile_size = 5000;
    hs = h_min:h_max;
    vs = v_min:v_max;
    entire_map_terri = zeros(tile_size.*length(hs), tile_size.*length(vs));
    for iv = 1: length(vs)
        for ih = 1: length(hs)
            filepath_map = fullfile(dir_map, sprintf('h%03dv%03d_terri_state.tif', hs(ih), vs(iv)));
            if isfile(filepath_map)
                entire_map_terri((iv -1)*tile_size + 1 : iv*tile_size, (ih-1)*tile_size + 1: ih*tile_size)= imread(filepath_map);
            end
        end
    end
end

function entire_map_disturb = load_entire_disturbance_map(dir_map, yr, key, h_min, h_max, v_min, v_max, version)
    tile_size = 5000;
    hs = h_min:h_max;
    vs = v_min:v_max;
    entire_map_disturb = zeros(tile_size.*length(hs), tile_size.*length(vs));
    for iv = 1: length(vs)
        for ih = 1: length(hs)
            mapname = sprintf('CD_%03d%03d_%04d_%s', hs(ih), vs(iv), yr, version);
            filepath_map = fullfile(dir_map, sprintf('h%03dv%03d', hs(ih), vs(iv)), mapname, sprintf('%s_%s.tif', mapname, key));
            if isfile(filepath_map)
                entire_map_disturb((iv -1)*tile_size + 1 : iv*tile_size, (ih-1)*tile_size + 1: ih*tile_size)= imread(filepath_map);
            end
        end
    end
end