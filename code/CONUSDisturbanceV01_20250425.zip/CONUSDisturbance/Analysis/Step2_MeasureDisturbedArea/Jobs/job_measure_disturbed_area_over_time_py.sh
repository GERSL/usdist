#!/bin/bash
#SBATCH -J distarea
#SBATCH --partition=priority			# specify partition
#SBATCH --account=zhz18039			# specify the priority account 
#SBATCH --constraint='epyc128' 
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --array 1-20
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err
#SBATCH --mem-per-cpu=20G


echo $SLURMD_NODENAME # display the node name
echo $SLURM_ARRAY_TASK_ID
echo $SLURM_ARRAY_TASK_MAX

. "/home/shq19004/miniconda3/etc/profile.d/conda.sh"  # startup conda
conda activate dist 

cd ../

python measureTiledisturbance.py --ci=$SLURM_ARRAY_TASK_ID --cn=$SLURM_ARRAY_TASK_MAX

exit


#SBATCH --partition=priority			# specify partition
#SBATCH --account=zhz18039			# specify the priority account 


#SBATCH --partition=general