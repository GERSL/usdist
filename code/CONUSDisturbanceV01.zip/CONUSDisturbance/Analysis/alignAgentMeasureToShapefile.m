
    
% Add code paths
pathpackage = fileparts(fileparts(mfilename('fullpath'))); 
addpath(pathpackage); % add ODACA's parent folder
addpath(fullfile(pathpackage, 'Shared')); % add the <Shared>

agents_name = {'forest_management', 'agriculture_activity', 'construction', 'stress', 'debris', 'water_dynamic', 'fire', 'other'};
agents_name = {'forest_management', 'agriculture_activity', 'construction', 'stress', 'debris', 'water_dynamic', 'fire'};

years   = odacasets.years;

shapefile_name = 'hexagon_grid_50km';
path_shapefile = fullfile(pathpackage, 'Analysis', 'Shapefile', shapefile_name, sprintf('%s.shp', shapefile_name));
grid_shapefile = shaperead(path_shapefile);


dir_map = odacasets.pathResultMaps;
dir_map_ana = [dir_map, 'Ana'];

dir_ana_grid_rec = fullfile(dir_map_ana, [shapefile_name, '_disturbance_agent_measurment']);
dir_ana_grid_shp = [dir_ana_grid_rec, '_shapefile'];
if ~isfolder(dir_ana_grid_shp)
    mkdir(dir_ana_grid_shp);
end

for ig = 1: length(grid_shapefile)

    grid_id = grid_shapefile(ig).Id;
    
    fprintf('(%04d/%04d)Collecting disturbance agent grid# %05d\r', ig, length(grid_shapefile), grid_id);

    filepath_rec = fullfile(dir_ana_grid_rec, sprintf('grid_%05d.csv', grid_id));

    if ~isfile(filepath_rec)
        continue;
    end

    % load the regimes
    record_grid = readtable(filepath_rec,'PreserveVariableNames',true);
    record_grid = table2struct(record_grid);

    st_year = min(years); ed_year = max(years);
    grid_shapefile = agent_years(grid_shapefile, ig, record_grid, agents_name, st_year, ed_year);
    grid_shapefile = agent_years(grid_shapefile, ig, record_grid, agents_name, 2000, 2020);
    grid_shapefile = agent_years(grid_shapefile, ig, record_grid, agents_name, 2000, 2004);
    grid_shapefile = agent_years(grid_shapefile, ig, record_grid, agents_name, 2005, 2009);
    grid_shapefile = agent_years(grid_shapefile, ig, record_grid, agents_name, 2010, 2015);
    grid_shapefile = agent_years(grid_shapefile, ig, record_grid, agents_name, 2016, 2020);

    for yr = years
        grid_shapefile = agent_years(grid_shapefile, ig, record_grid, agents_name, yr, yr);
    end
end

% exclude the grids that we do not have data at all
ids_remain = [];
for ig = 1: length(grid_shapefile)
    if ~isempty(grid_shapefile(ig).('Y2020'))
        ids_remain = [ids_remain; ig];
    end

end
grid_shapefile = grid_shapefile(ids_remain);

% exclude Y 2012
for ig = 1: length(grid_shapefile)
    grid_shapefile(ig).('Y2012') = 'No';
end


shapewrite(grid_shapefile, fullfile(dir_ana_grid_shp, sprintf('major_agent_selected_by_absarea_%d_%d.shp', min(years), max(years))));

function grid_shapefile = agent_years(grid_shapefile, ig, record_grid, agents_name, st_year, ed_year)
    % st_year = min(years); ed_year = max(years);
    years_exclude = [2012];
    record_grid = record_grid(~ismember([record_grid.year], years_exclude));  %we exclude the 2012 because of the single Landsat satellite

    year_ids = ismember([record_grid.year], st_year:ed_year); %

    record_grid = record_grid(year_ids);
    if st_year == ed_year
        fieldname = sprintf('Y%04d', st_year);
    else
        fieldname = sprintf('Y%02d%02d', mod(st_year, 100), mod(ed_year, 100));
    end
    grid_shapefile(ig).(fieldname) = 'No';
    default_area = 0;
    for iag = 1: length(agents_name)
        new_area = sum([record_grid.(agents_name{iag})])/height(record_grid);
        if new_area > default_area
            grid_shapefile(ig).(fieldname) = agents_name{iag};
            default_area = new_area;
        end
    end
end