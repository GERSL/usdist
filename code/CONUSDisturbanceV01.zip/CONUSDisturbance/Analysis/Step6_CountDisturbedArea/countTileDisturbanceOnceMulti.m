% count the disturbed area at least once

function countTileDisturbanceOnceMulti(jobid, jobnum)
    tic
    %% Add code paths
    pathpackage = fileparts(fileparts(fileparts(mfilename('fullpath')))); 
    addpath(pathpackage); % add ODACA's parent folder
    addpath(fullfile(pathpackage, 'ODACA')); % add the <Shared>
    addpath(fullfile(pathpackage, 'ODACA', 'Shared')); % add the <Shared>
    
    if ~exist('jobid', 'var') || ~exist('jobnum', 'var')
        jobid = 1; jobnum = 1; 
    end
    
    %% Pre-setted paras
    if isempty(odacasets.refineSampleCollection)
        product_version = 0; % indicate the maps using open-source data
    else
        product_version = odacasets.refineSampleCollection + 1; % following the sample collection's #
    end
    dir_map = fullfile(odacasets.pathResultMaps, sprintf('V%02dPostRelease', product_version));
    dir_map_ana = fullfile(odacasets.pathResultAnalysis, sprintf('V%02dPostRelease', product_version));
    % adjusted lcmap present land cover type on the first day of the year
    
    dir_ana_grid_rec = fullfile(dir_map_ana, 'conus_disturbance_once_muti_area');
    if ~isfolder(dir_ana_grid_rec)
        mkdir(dir_ana_grid_rec);
    end
    
    conus_tiles = odacasets.ARDTiles;
    
    years_agent_all = 1988:2022; % product version 1.3


    version = sprintf('V%02d', product_version);
    
    for ijob = jobid: jobnum: length(conus_tiles)
        tile = conus_tiles{ijob};
        if ismember({tile}, {'h022v003', 'h024v004', 'h024v005', 'h025v006', 'h026v005'})
            fprintf('Skipping water tile %s\n', tile);
            continue;
        end
        path_tile = fullfile(dir_ana_grid_rec, sprintf('%s_disturbance_once_area.csv', tile));
        if isfile(path_tile)
            fprintf('Existing area at %s\r', tile);
            continue;
        end
        %% Obtain base layer, which is the ROI which experienced at once disturbance
        [agent_cube, map_terr] = load_disturbance_agent_cube(dir_map, tile, years_agent_all, version); 
        % disturbance frequency among the six types
        once_map_disturbed = sum(agent_cube < 8, 3) > 0; % including all the disturbance types
        muti_map_disturbed = sum(agent_cube < 8, 3) > 2; % including all the disturbance types

        %% Process the area
        fprintf('Processing area at %s\r', tile);
        record_tile = [];

        record = struct('tile',  tile, ...
            'oncedistarea',  0.09*sum(once_map_disturbed(:)), ... % ha
            'mutidistarea',  0.09*sum(muti_map_disturbed(:)), ... % ha
            'totalarea', 0.09*sum(map_terr(:)), ... % ha
            'startyear',  years_agent_all(1), ...
            'endyear',  years_agent_all(end)); %#ok<GFLD> 
        record_tile = [record_tile, record];

        writetable(struct2table(record_tile), path_tile);
        fprintf('Finish saving the disturbance agent measurements: area at %s with %0.2f mins\r', tile, toc/60);
    
    end
end

function [disturb_agent_cube, map_terr] = load_disturbance_agent_cube(dir_map, tile, years_disturbance, version)
    % get the distance maps
    key = 'AGENT';
    disturb_agent_cube = [];
    map_terr = [];
    for dy = 1: length(years_disturbance)
        yr = years_disturbance(dy);
        mapname = sprintf('CD_%s%s_%04d_%s', tile(2:4), tile(6:8), yr, version);
        filepath_map = fullfile(dir_map, tile, mapname, sprintf('%s_%s.tif', mapname, key));
        disturb_agent = imread(filepath_map);
        % when the terr is not available, we use the disturb_agent as terr
        if isempty(map_terr)
            map_terr = disturb_agent < 255; % terr
        end
        disturb_agent(disturb_agent ==0 ) = 8; % merge non disturbance as other as well
        disturb_agent(disturb_agent ==255 ) = 8; % merge non disturbance as other as well
        if isempty(disturb_agent_cube)
            % expand the dimension
            disturb_agent_cube = zeros([size(disturb_agent), length(years_disturbance)], 'uint8');
        end
        disturb_agent_cube(:,:,dy) = disturb_agent;
    end
end