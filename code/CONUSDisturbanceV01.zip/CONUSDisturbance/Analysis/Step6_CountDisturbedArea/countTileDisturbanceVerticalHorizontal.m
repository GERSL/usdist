% count the disturbed area for each ARD tile along vertical and horizontal directions

function countTileDisturbanceVerticalHorizontal(jobid, jobnum, resolution)
tic
%% Add code paths
pathpackage = fileparts(fileparts(fileparts(mfilename('fullpath')))); 
addpath(pathpackage); % add ODACA's parent folder
addpath(fullfile(pathpackage, 'ODACA')); % add the <Shared>
addpath(fullfile(pathpackage, 'ODACA', 'Shared')); % add the <Shared>

if ~exist('jobid', 'var') || ~exist('jobnum', 'var')
    jobid = 1; jobnum = 1; resolution = 3000;
end

%% Pre-setted paras
if isempty(odacasets.refineSampleCollection)
    product_version = 0; % indicate the maps using open-source data
else
    product_version = odacasets.refineSampleCollection + 1; % following the sample collection's #
end
dir_map = fullfile(odacasets.pathResultMaps, sprintf('V%02dPostRelease', product_version));
dir_map_ana = fullfile(odacasets.pathResultAnalysis, sprintf('V%02dPostRelease', product_version));


dir_ana_grid_rec = fullfile(dir_map_ana, 'conus_hv_disturbed_area');
if ~isfolder(dir_ana_grid_rec)
    mkdir(dir_ana_grid_rec);
end

conus_tiles = odacasets.ARDTiles;

years = 1985:2022;

% resolutions_meter = [300, 600, 1500, 3000, 30000]; % in meters  
resolutions_meter = [resolution]; % in meters  
resolutions_pixel = resolutions_meter./30; % divided by the landsat resolution 30 meters

agents = odacasets.agents;
agent_name_full = fieldnames(agents);
version = sprintf('V%02d', product_version);

for ijob = jobid: jobnum: length(conus_tiles)
    tile = conus_tiles{ijob};
    path_tile = fullfile(dir_ana_grid_rec, sprintf('%s_agent_area_%d.csv', tile, resolutions_meter(1)));
    if isfile(path_tile)
        fprintf('Existing area at %s\r', tile);
        continue;
    end
    fprintf('Processing area at %s\r', tile);
    key = 'AGENT';
    record_tile = [];
    tile_horizontal=str2num(tile(2:4));
    tile_vertical=str2num(tile(6:8));
    for iy = 1: length(years)
        yr = years(iy);
        mapname = sprintf('CD_%s%s_%04d_%s', tile(2:4), tile(6:8), yr, version);
        filepath_map = fullfile(dir_map, tile, mapname, sprintf('%s_%s.tif', mapname, key));
        disturb_agent = imread(filepath_map);
        
        for ic = 1: length(agent_name_full)
            map_agent_year = disturb_agent == getfield(agents, agent_name_full{ic});
            map_terr = disturb_agent < 255; % terr
            
            for ir = 1: length(resolutions_pixel) % for each resolution
                res_pix = resolutions_pixel(ir);
                res_meter = resolutions_meter(ir);

                % along vertical which is row
                id = 1;
                for irow = 1: res_pix: size(map_agent_year, 1)
                    record = struct('tile',  tile, ...
                                    'agent', agent_name_full{ic}, ...
                                    'area',  0.09*sum(sum(map_agent_year(irow: irow+res_pix - 1,:))), ... % ha
                                    'terrarea', 0.09*sum(sum(map_terr(irow: irow+res_pix - 1,:))), ... % ha
                                    'year',  yr, ...
                                    'tile_horizontal',  tile_horizontal, ...
                                    'tile_vertical',  tile_vertical, ...
                                    'cell_horizontal', 0, ...
                                    'cell_vertical', id, ...
                                    'resolution', res_meter ...
                                    ); %#ok<GFLD> 
                    record_tile = [record_tile, record];
                    id = id + 1;
                end

                % along horizontal which is column
                id = 1;
                for icol = 1: res_pix: size(map_agent_year, 2)
                    record = struct('tile',  tile, ...
                                    'agent', agent_name_full{ic}, ...
                                    'area',  0.09*sum(sum(map_agent_year(:, icol: icol+res_pix - 1))), ... % ha
                                    'terrarea', 0.09*sum(sum(map_terr(:, icol: icol+res_pix - 1))), ... % ha
                                    'year',  yr, ...
                                    'tile_horizontal',  tile_horizontal, ...
                                    'tile_vertical',  tile_vertical, ...
                                    'cell_horizontal', id, ...
                                    'cell_vertical', 0, ...
                                    'resolution', res_meter...
                                    ); %#ok<GFLD> 
                    record_tile = [record_tile, record];
                    id = id + 1;
                end
            end
        end
    end
    writetable(struct2table(record_tile), path_tile);
    fprintf('Finish saving the disturbance agent measurements: area at %s with %0.2f mins\r', tile, toc/60);

end