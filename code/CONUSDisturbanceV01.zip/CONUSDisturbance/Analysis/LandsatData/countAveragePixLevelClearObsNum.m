function countAveragePixLevelClearObsNum(varargin)
%% Add code paths
addpath(genpath(fileparts(fileparts(fileparts(mfilename('fullpath'))))));

% directory of Landsat ARd
folderpath_save = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSLandDisturbanceV041Ana/conus_clear_observation_pixel_level';
dir_terri = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSLandDisturbanceV041Ana/state_regions';

% optional
p = inputParser;
addParameter(p,'orbitpath', 'single'); % to create single path layer
addParameter(p,'task', 1); % 1st task
addParameter(p,'ntasks', 1); % single task to compute
addParameter(p,'errorpass', false);
parse(p,varargin{:});
task = p.Results.task;
ntasks = p.Results.ntasks;

years = 1982:2021;
sensors = {'LT04', 'LT05', 'LE07', 'LC08'};

tiles = dir(fullfile(folderpath_save, 'h*'));

for i = task: ntasks: length(years)
    yr = years(i);
    num_conus_clr_obs = zeros([length(sensors), 1]);
    num_conus_pix = zeros([length(sensors), 1]);
    for it = 1: length(tiles)
        % load the number of clear observations
        map_terri = [];
        for s = 1: length(sensors)
            sensor = sensors{s};
            filepath_tile_year = fullfile(folderpath_save, tiles(it).name, sprintf('%s_clear_observation_number_%d.tif', sensor, yr));
            if isfile(filepath_tile_year)
                map_clr_obs = imread(filepath_tile_year);
                % exclude non-terri
                if isempty(map_terri)
                    filepath_map = fullfile(dir_terri, sprintf('%s_terri_state.tif', tiles(it).name));
                    map_terri = imread(filepath_map) > 0;
                end
                num_conus_clr_obs(s) = num_conus_clr_obs(s) + sum(map_clr_obs(map_terri)); % sum the number of clear observaitons
                num_conus_pix(s) = num_conus_pix(s) + sum(map_terri(:)); % sum the number of the terri pixels
            end
        end
%         filepath_tile_year = fullfile(folderpath_save, tiles(it).name, sprintf('clear_observation_number_%d.tif', yr));
%         if isfile(filepath_tile_year)
%             map_clr_obs = imread(filepath_tile_year);
%             % exclude non-terri
%             filepath_map = fullfile(dir_terri, sprintf('%s_terri_state.tif', tiles(it).name));
%             map_terri = imread(filepath_map) > 0;
%             num_conus_clr_obs = num_conus_clr_obs + sum(map_clr_obs(map_terri)); % sum the number of clear observaitons
%             num_conus_pix = num_conus_pix + sum(map_terri(:)); % sum the number of the terri pixels
%         end
    end
    average_num = num_conus_clr_obs./num_conus_pix;
    
    record_num = struct('year', yr, sensors{1}, average_num(1), sensors{2}, average_num(2), sensors{3}, average_num(3), sensors{4}, average_num(4));

    filepath_rec = fullfile(folderpath_save, sprintf('conus_average_clear_observation_sensor_%d.csv', yr));
    writetable(struct2table(record_num), filepath_rec);
end