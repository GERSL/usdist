function measureTileDisturbance(jobid, jobnum)
tic
%% Add code paths
pathpackage = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(genpath(fullfile(pathpackage, 'ODACA'))); % add ODACA's parent folder

if ~exist('jobid', 'var') || ~exist('jobnum', 'var')
    jobid = 1; jobnum = 1;
end

key = 'AGENT'; % based on which layer?
% key = 'TIME';


%% Pre-setted paras
if isempty(odacasets.refineSampleCollection)
    product_version = 0; % indicate the maps using open-source data
else
    product_version = odacasets.refineSampleCollection + 1; % following the sample collection's #
end

dir_map = fullfile(odacasets.pathResultMaps, sprintf('V%02dPostRelease', product_version));

dir_map_ana = fullfile(odacasets.pathResultAnalysis, sprintf('V%02dPostRelease', product_version));

dir_ana_grid_rec = fullfile(dir_map_ana, 'tile_disturbance_measurement');
if ~isfolder(dir_ana_grid_rec)
    mkdir(dir_ana_grid_rec);
end

% shared shapefile
shapefile_name   = 'state';
path_shapefile = fullfile(pathpackage, 'Analysis', 'Shapefile', shapefile_name, sprintf('%s.shp', shapefile_name) );
shp_state = shaperead(path_shapefile);

state_ids = unique({shp_state.STFIPS});
nca_ids = unique([shp_state.NCACode]);

conus_tiles = odacasets.ARDTiles;

years = odacasets.years;

agents_default = odacasets.agents;
agents = odacasets.agents;
agent_name_full = fieldnames(agents);
version = sprintf('V%02d', product_version);

for ijob = jobid: jobnum: length(conus_tiles)
    tile = conus_tiles{ijob};
    path_tile = fullfile(dir_ana_grid_rec, sprintf('%s_agent_area.csv', tile));
    if isfile(path_tile)
        continue;
    end

    mask_state = imread(fullfile(fileparts(dir_map_ana), 'state_regions',  sprintf('%s_%s_state.tif', tile, 'terri') ));
    mask_nca = imread(fullfile(fileparts(dir_map_ana), 'nca_regions',  sprintf('%s_%s_nca.tif', tile, 'terri')));
    record_tile = [];
    for iy = 1: length(years)
        yr = years(iy);
        mapname = sprintf('CD_%s%s_%04d_%s', tile(2:4), tile(6:8), yr, version);
        filepath_map = fullfile(dir_map, tile, mapname, sprintf('%s_%s.tif', mapname, key));
        disturb_agent = imread(filepath_map);
        
        % when we use TIME (DOY) layer, we only record all breaks
        if strcmpi(key, "TIME")
            agent_name_full = {'unclassified'};
            agents = struct('unclassified', 9);
            disturb_agent(disturb_agent>0 & disturb_agent< 65535) = 9;
        end
        for ic = 1: length(agent_name_full)
            agent_code = getfield(agents_default, agent_name_full{ic});
            map_agent_year = disturb_agent == agent_code;
            % other includes no disturbance in our analysis
            if strcmpi(agent_name_full{ic}, 'other')
                map_agent_year(disturb_agent==0) = 1; % where 0 is no disturbance 255 is out of CONUS
            end

            record = struct('tile',  tile, ...
                            'agent', agent_name_full{ic}, ...
                            'area',  0.09*sum(sum(map_agent_year(:))), ... % ha
                            'year',  yr...
                            ); %#ok<GFLD> 
            
            for is = 1: length(state_ids)
                state_id = str2num(state_ids{is});
                record.(sprintf('state%02d', state_id)) = 0.09*sum(sum(map_agent_year & mask_state == state_id)); % ha
            end

            for is = 1: length(nca_ids)
                nca_id = nca_ids(is);
                record.(sprintf('nca%d', nca_id)) = 0.09*sum(sum(map_agent_year & mask_nca == nca_id)); % ha
            end

            record_tile = [record_tile, record];
        end
    end

    writetable(struct2table(record_tile), path_tile);
    fprintf('Finish saving the disturbance agent measurements: area at %s with %0.2f mins\r', tile, toc/60);

end
