function extractPixelDisturbanceMagnitude(jobid, jobnum)
% This function goes to compute the individual disturbance pixel for each
% agent, including magnitude

tic

%% Add code paths
pathpackage = fileparts(fileparts(fileparts(mfilename('fullpath')))); 
addpath(pathpackage); % add ODACA's parent folder
addpath(fullfile(pathpackage, 'ODACA'));

%% Pre-setted paras
if isempty(odacasets.refineSampleCollection)
    product_version = 0; % indicate the maps using open-source data
else
    product_version = odacasets.refineSampleCollection + 1; % following the sample collection's #
end

dir_map = fullfile(odacasets.pathResultMaps, sprintf('V%02dPostRelease', product_version));
dir_map_ana = fullfile(odacasets.pathResultAnalysis, sprintf('V%02dPostRelease', product_version));

dir_terri = fullfile(odacasets.pathResultAnalysis, 'state_regions');

if ~exist('jobid', 'var') || ~exist('jobnum', 'var')
    jobid = 1; jobnum = 1;
end

agent = 'target';
relative = false; % true means relative magnitude, false means absolute magnitude
process = 'merge'; % 'merge': merge all .csv files per tile; 'generation': create the .csv file per tile per year per agent
switch  agent
    case 'all'
        agent_codes = [1,2,3,4,5,6,7];
    case 'target'
        agent_codes = [1,2,3,4,5,6,7];
    otherwise
        agent_codes = [getfield(odacasets.agents, agent)];
end

% e.g., getfield(agents, 'stress') will return 4.
% e.g., fieldnames(agents) will return the agent names
agent_names = fieldnames(odacasets.agents);

% path_shapefile = fullfile(pathpackage, 'Analysis', 'Shapefile', shapefile_name, sprintf('%s.shp', shapefile_name));
% grid_shapefile = shaperead(path_shapefile);
if relative % the folder name would be varied _r or none
    dir_ana_grid_rec = fullfile(dir_map_ana, 'conus_disturbance_pixel_rmagnitude', agent); 
else
    dir_ana_grid_rec = fullfile(dir_map_ana, 'conus_disturbance_pixel_magnitude', agent);
end

if ~isfolder(dir_ana_grid_rec)
    mkdir(dir_ana_grid_rec);
end

conus_tiles = odacasets.ARDTiles;
years = odacasets.years;
years = 1988:2022;
mapv = product_version;

for ijob = jobid: jobnum: length(conus_tiles)
    tile = conus_tiles{ijob};
    fprintf('Processing %s\n', tile);
    tile_h = str2num(tile(2:4));
    tile_v = str2num(tile(6:8));
    % extend one ard tile to create disturbance objects
    ard_buf = 0;
    h_min = min([tile_h])-ard_buf;
    v_min = min([tile_v])-ard_buf;
    h_max = max([tile_h])+ard_buf;
    v_max = max([tile_v])+ard_buf;

    switch process
        case 'generation'
            % avoid negative values
        %     h_min = max(0, h_min);
        %     v_min = max(0, v_min);
            entire_map_terri = load_entire_terri_map(dir_terri, h_min, h_max, v_min, v_max);
            entire_map_terri = entire_map_terri > 0;
            % at each year, we calculate the measurements
            for iy = 1: length(years)
                yr = years(iy);
                % define the white entire map
                entire_map_disturb_agent = load_entire_disturbance_map(dir_map, yr, 'AGENT', h_min, h_max, v_min, v_max, sprintf('V%02d', mapv));
                entire_map_disturb_agent(~entire_map_terri) = 0; % exclude non-terri
                if relative
                    entire_map_disturb_mag   = load_entire_disturbance_map(dir_map, yr, 'RMAG', h_min, h_max, v_min, v_max, sprintf('V%02d', mapv));
                else
                    entire_map_disturb_mag   = load_entire_disturbance_map(dir_map, yr, 'MAG', h_min, h_max, v_min, v_max, sprintf('V%02d', mapv));
                end
                % remain disturbed pixels
                for ic = 1: length(agent_codes)
                    pix_mag = entire_map_disturb_mag(entire_map_disturb_agent == agent_codes(ic));
                    if ~isempty(pix_mag)
                        filepath_rec = fullfile(dir_ana_grid_rec, sprintf('%s_%d_%s_pixel_magnitude.csv', tile, yr, agent_names{agent_codes(ic)}));
                        writetable(struct2table(struct('magnitude', pix_mag)), filepath_rec);
                    end
                end
            end
        case 'merge'
            % Merge all .csv files that are available
            filepath_rec_merge = fullfile(dir_ana_grid_rec, sprintf('%s_pixel_magnitude.csv', tile));
            if isfile(filepath_rec_merge)
                fprintf('Exsit %s\n', filepath_rec_merge);
            else
                pix_mags_tile = [];
                for iy = 1: length(years)
                    yr = years(iy);
                    for ic = 1: length(agent_codes)
                        agentname = agent_names{agent_codes(ic)};
                        filepath_rec = fullfile(dir_ana_grid_rec, sprintf('%s_%d_%s_pixel_magnitude.csv', tile, yr, agentname));
                        if isfile(filepath_rec)
                            pix_mags = readtable(filepath_rec);
                            pix_mags.agent = repmat({agentname}, size(pix_mags,1), 1);
                            pix_mags_tile = [pix_mags_tile; pix_mags];
                        end
                    end
                end
                if ~isempty(pix_mags_tile)
                    writetable(pix_mags_tile, filepath_rec_merge);
                    fprintf('Saved %s\n', filepath_rec_merge);
                else
                    fprintf('Empty %s\n', filepath_rec_merge);
                end
            end
    end
end

end

function entire_map_terri = load_entire_terri_map(dir_map, h_min, h_max, v_min, v_max)
    tile_size = 5000;
    hs = h_min:h_max;
    vs = v_min:v_max;
    entire_map_terri = zeros(tile_size.*length(hs), tile_size.*length(vs));
    for iv = 1: length(vs)
        for ih = 1: length(hs)
            filepath_map = fullfile(dir_map, sprintf('h%03dv%03d_terri_state.tif', hs(ih), vs(iv)));
            if isfile(filepath_map)
                entire_map_terri((iv -1)*tile_size + 1 : iv*tile_size, (ih-1)*tile_size + 1: ih*tile_size)= imread(filepath_map);
            end
        end
    end
end

function entire_map_disturb = load_entire_disturbance_map(dir_map, yr, key, h_min, h_max, v_min, v_max, version)
    tile_size = 5000;
    hs = h_min:h_max;
    vs = v_min:v_max;
    entire_map_disturb = zeros(tile_size.*length(hs), tile_size.*length(vs));
    for iv = 1: length(vs)
        for ih = 1: length(hs)
            mapname = sprintf('CD_%03d%03d_%04d_%s', hs(ih), vs(iv), yr, version);
            filepath_map = fullfile(dir_map, sprintf('h%03dv%03d', hs(ih), vs(iv)), mapname, sprintf('%s_%s.tif', mapname, key));
            if isfile(filepath_map)
                entire_map_disturb((iv -1)*tile_size + 1 : iv*tile_size, (ih-1)*tile_size + 1: ih*tile_size)= imread(filepath_map);
            end
        end
    end
end