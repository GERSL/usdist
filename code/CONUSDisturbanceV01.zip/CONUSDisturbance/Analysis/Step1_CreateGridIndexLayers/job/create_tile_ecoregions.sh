#!/bin/bash
#SBATCH -J eco # jobname
#SBATCH --partition=priority
#SBATCH --account=zhz18039
#SBATCH --constraint='epyc128'
#SBATCH --mem-per-cpu=10G
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --array 1-30
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err


echo $SLURMD_NODENAME # display the node name
cd ../

# start up conda
. "/home/shq19004/miniconda3/etc/profile.d/conda.sh"
conda activate dist

python ./createTileEcoregion.py -i $SLURM_ARRAY_TASK_ID -n $SLURM_ARRAY_TASK_MAX

exit

#SBATCH --partition=general

#SBATCH --partition=priority
#SBATCH --account=zhz18039
#SBATCH --constraint='epyc128'
#SBATCH --nodes 1 
#SBATCH --ntasks 1
#SBATCH --array 1-20
#SBATCH --mem-per-cpu=20G
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err



#SBATCH --partition=general-gpu
#SBATCH --constraint=a100
#SBATCH --mem-per-cpu=10G
#SBATCH --gres=gpu:1
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --array 1-30
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err