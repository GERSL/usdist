function createTileGridIndex(jobid, jobnum)
% create the grid index for the analyze levels based on the shapfiles,
% such as conus grid as well as the state polygons

%% Add code paths
pathpackage = fileparts(fileparts(fileparts(mfilename('fullpath')))); 
addpath(pathpackage); % add ODACA's parent folder
addpath(fullfile(pathpackage, 'Shared')); % add the <Shared>

%% Pre-setted paras
dir_map = odacasets.pathResultMaps;
dir_map_ana = [dir_map, 'Ana'];
conus_tiles = odacasets.ARDTiles;

if ~exist('jobid', 'var') || ~exist('jobnum', 'var')
    jobid = 1; jobnum = 1;
end

shapefile_name   = 'hexagon_grid_50km';

% shared shapefile
path_shapefile = fullfile(pathpackage, 'Analysis', 'Shapefile', shapefile_name, sprintf('%s.shp', shapefile_name) );

dir_ana_grid = fullfile(dir_map_ana, shapefile_name);
if ~isfolder(dir_ana_grid)
    mkdir(dir_ana_grid);
end

for ijob = jobid: jobnum: length(conus_tiles)
    tile = conus_tiles{ijob};
    path_tile_map = fullfile(dir_map_ana, 'state_regions',  sprintf('%s_%s_state.tif', tile, 'terri') );
    mask_state = imread(path_tile_map);
    path_tile_grid = fullfile(dir_ana_grid, sprintf('%s_%s.tif', tile, shapefile_name) );
    rasterizeShapfilePyGDAL(path_shapefile, path_tile_map, path_tile_grid, 'Id', 'uint16');

    % overlay the grid index mask with the terri areas
    map_grid_index = GRIDobj(path_tile_grid);
    map_grid_index.Z(mask_state==0)=intmax('uint16'); % setup as the mask
    map_grid_index.Z = uint16(map_grid_index.Z);
    GRIDobj2geotiff(map_grid_index, path_tile_grid);



%     path_tile_map = fullfile(dir_map, tile,  sprintf('NLCD_2019_%s.tif', tile));
%     path_tile_grid = fullfile(dir_ana_grid, sprintf('%s_%s.tif', tile, shapefile_name) );
%     rasterizeShapfilePyGDAL(path_shapefile, path_tile_map, path_tile_grid, 'Id', 'uint16');
%     map_grid_index = GRIDobj(path_tile_grid);
%     map_nlcd = imread(path_tile_map);
%     map_grid_index.Z(map_nlcd==0)=intmax('uint16'); % setup as the mask
%     map_grid_index.Z = uint16(map_grid_index.Z);
%     GRIDobj2geotiff(map_grid_index, path_tile_grid);

    fprintf('Created: %s\n', path_tile_grid);
end
