#!/bin/bash
#SBATCH -J distpatch
#SBATCH --partition=priority			# specify partition
#SBATCH --account=zhz18039			# specify the priority account 
#SBATCH --constraint='epyc128' 
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --array 1-427
#SBATCH --exclude=cn[474,475,476,478,479,538,523]
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err
#SBATCH --mem-per-cpu=20G


echo $SLURMD_NODENAME # display the node name
echo $SLURM_ARRAY_TASK_ID
echo $SLURM_ARRAY_TASK_MAX

cd ../

module load matlab

matlab -nojvm -nodisplay -nosplash -singleCompThread -r extractDisturbancePatch\($SLURM_ARRAY_TASK_ID,$SLURM_ARRAY_TASK_MAX\)


exit


#SBATCH --partition=priority			# specify partition
#SBATCH --account=zhz18039			# specify the priority account 


#SBATCH --partition=general