function updateDisturbancePatchSeverity(jobid, jobnum)


end

