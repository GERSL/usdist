function measureGridRegime(jobid, jobnum)
%%
% This function goes to measure grid-level disturbance regimes, 
% including size, frequency, and severity for each year
%

tic % start to record the grid regimes

%% Add code paths
pathpackage = fileparts(fileparts(fileparts(mfilename('fullpath')))); 
addpath(pathpackage); % add ODACA's parent folder
addpath(fullfile(pathpackage, 'ODACA')); % add the <Shared>
addpath(fullfile(pathpackage, 'ODACA', 'Shared')); % add the <Shared>
if ~exist('jobid', 'var') || ~exist('jobnum', 'var')
    jobid = 44; jobnum = 44;
end

%% Pre-setted paras
if isempty(odacasets.refineSampleCollection)
    product_version = 0; % indicate the maps using open-source data
else
    product_version = odacasets.refineSampleCollection + 1; % following the sample collection's #
end
version = sprintf('V%02d', product_version);

%% define the directories that are requried in this script
dir_map = fullfile(odacasets.pathResultMaps, sprintf('V%02dPostRelease', product_version));
dir_map_ana = fullfile(odacasets.pathResultAnalysis, sprintf('V%02dPostRelease', product_version));
dir_terri = fullfile(odacasets.pathResultAnalysis, 'state_regions');


%% define the tiles covered land only
conus_tiles = odacasets.ARDTiles;
conus_tiles = conus_tiles(~ismember(conus_tiles, {'h022v003', 'h024v004', 'h024v005', 'h025v006', 'h026v005'}));

%% land disturbance agent codes defination
agent_code_full = [1,2,3,4,5,6,7];
agent_name_full = fieldnames(odacasets.agents);
agent_codes = [1,2,3,4,5,6,7];

% also see odacasets.agents for the agent codes
%        agents = struct('forest_management',    1, ...
%                        'agriculture_activity', 2, ...
%                        'construction',         3, ...
%                        'stress',               4, ...
%                        'debris',               5, ...
%                        'water_dynamic',        6, ...
%                        'fire',                 7, ...
%                        'other',                8);
% e.g., getfield(agents, 'stress') will return 4.
% e.g., fieldnames(agents) will return the agent names

years = 1988:2022; % the analyzed years

%% define the base hexagon grid layer
shapefile_name = 'hexagon_grid_50km';
severity_normalization = 'patch'; % 'pixel' or 'patch'
% shapefile_name = 'eco_regions_l3';
lookup_tile_grid = load_lookup_tile_grid(odacasets.pathResultAnalysis, shapefile_name, conus_tiles);

% create folders
dir_ana_grid_rec = fullfile(dir_map_ana, [shapefile_name, '_dist_regime_patch', sprintf('_%d_%d', years(1), years(end))]);
if ~isfolder(dir_ana_grid_rec)
    mkdir(dir_ana_grid_rec);
end

% to get the unique grid id list, and process each one of them at parallel computing
rng(1);
grid_id_list = unique([lookup_tile_grid.grid_id]);
grid_id_list = grid_id_list(randperm(length(grid_id_list)));

%% start to process the grid one by one and at parallel computing
for ijob = jobid: jobnum: length(grid_id_list)
    % the grid id
    grid_id = grid_id_list(ijob);
    % setup the output file
    filepath_rec = fullfile(dir_ana_grid_rec, sprintf('grid_%05d.mat', grid_id));
    if isfile(filepath_rec)
        % fprintf('Exist the disturbance measurements at grid# %05d with %0.2f mins\r', grid_id, toc/60);
        continue;
    end

    % extend one ard tile to create disturbance objects
    ard_buf = 1;

    % to get the ARD tiles which were covering the grid
    grid_tiles = lookup_tile_grid(ismember([lookup_tile_grid.grid_id], grid_id));

    % get the grid index
    entire_map_grid_index = load_entire_grid_index_map(odacasets.pathResultAnalysis, shapefile_name, [grid_tiles.tile_h], [grid_tiles.tile_v], ard_buf, grid_id);
    % entire_map_grid_index = entire_map_grid_index == grid_id;

    area_grid = sum(entire_map_grid_index(:))*0.09; % ha  % to exclude the pixels out of boundary
    % skip the the grid with having any terri areas
    if area_grid == 0
        continue;
    end

    % at each year, we calculate the measurements
    record_grid = [];
    for iy = 1: length(years)
        % year
        yr = years(iy);

        % define the white entire maps
        entire_map_disturb_agent = load_entire_disturbance_map(dir_map, yr, 'AGENT', [grid_tiles.tile_h], [grid_tiles.tile_v], ard_buf, version);
    
        %% build disturbance objects for each agent layer
        patches_all = [];
        for ig = 1: length(agent_codes)
            agentcode  = agent_codes(ig);
            patches = regionprops(bwconncomp(entire_map_disturb_agent == agentcode), 'Area', 'PixelIdxList');
            
            % only at the grid
            id_patch_grid = [];
            for ip = 1: length(patches)
                if sum(entire_map_grid_index(patches(ip).PixelIdxList)) >  0
                    id_patch_grid = [id_patch_grid; ip];
                end
            end

            % append to the all patch list
            if ~isempty(id_patch_grid)
                % select the disturbance patches in the grid level
                patches = patches(id_patch_grid);
                [patches.AgentCode] = deal(agentcode); % recording agent's code 
                patches_all = [patches_all; patches];
            end
        end
    
        % if no data included, just skip the grid 
        if isempty(patches_all)
            % have data always since we do not want to remove the grid in
            % the shapfile
            record = struct('grid_id',          grid_id, ...
                            'grid_area',        area_grid, ...
                            'year',             yr, ...
                            'agent',            'no', ...
                            'patches',          NaN,...
                            'dist_grid_area',   0, ...      % total disturbed area within the grid, unit: ha
                            'dist_area',        0, ...      % total disturbed area, unit: ha
                            'dist_size',        0, ...      % average area of disturbance pacthes in the grid, unit: ha                                
                            'dist_size_median', 0, ... % median area of disturbance patches in the grid, unit: ha
                            'dist_size_prct75', 0, ...
                            'dist_size_prct99', 0, ...
                            'dist_size_max',    0, ...
                            'dist_frequency',   0, ...      % frequency of disturbance pacthes in the grid, unit: per ha per year
                            'dist_severity',    0, ...      % average severity of disturbance pacthes in the grid, unitless
                            'dist_number',      0, ...      % backup of the number of disturbance pactches
                            'dist_magnitude',   0 ...      % backup of the number of disturbance magnitude in Landsat spectral bands
                            );
            record_grid = [record_grid, record];
            continue;
        end

        %% adjust area according to the good practice in pixel
        % we will do this in the future when we plot out the results
        %for ip = 1: length(patches_all)
        %    agentcode = patches_all(ip).AgentCode;
        %    patches_all(ip).AdjustArea = area_adjust(agentcode, patches_all(ip).Area);
        %end

        %% start to compute the measurments for the grid
        entire_map_disturb_mag  = load_entire_disturbance_map(dir_map, yr, 'MAG',   [grid_tiles.tile_h], [grid_tiles.tile_v], ard_buf, version);
        entire_map_disturb_mag = entire_map_disturb_mag./10000; % back to 0-1
        % compute the disturbance regimes for each object, i.e., disturbance severity
        for ip = 1: length(patches_all)
            agentcode = patches_all(ip).AgentCode;
            agentname = char(agent_name_full(agent_code_full==agentcode));
            switch agentname
                case 'forest_management'
                    severity_quarter = odacasets.severity_quarter_forest_management; % i.e., [lower, median, higher]
                case 'construction'
                    severity_quarter = odacasets.severity_quarter_construction;
                case 'agriculture_activity'
                    severity_quarter = odacasets.severity_quarter_agriculture_activity;
                case 'stress'
                    severity_quarter = odacasets.severity_quarter_stress;
                case 'natural_hazard'
                    severity_quarter = odacasets.severity_quarter_debris;
                case 'water_dynamic'
                    severity_quarter = odacasets.severity_quarter_water_dynamic;
                case 'fire'
                    severity_quarter = odacasets.severity_quarter_fire;
            end
    
            % convert to severity, 1, 2, 3, 4
            pix_mag = entire_map_disturb_mag(patches_all(ip).PixelIdxList);

            switch severity_normalization
                case 'pixel'
                    pix_severity = zeros(size(pix_mag));
                    pix_severity(pix_mag <= severity_quarter(1)) = 1;  % low: <= 25th percentile
                    pix_severity(pix_mag > severity_quarter(1) & pix_mag <= severity_quarter(2)) = 2; % moderate: % 25th < and <= 50th
                    pix_severity(pix_mag > severity_quarter(2) & pix_mag <= severity_quarter(3)) = 3; % high % 50th < and <= 75th
                    pix_severity(pix_mag > severity_quarter(3)) = 4; % very high < 75th percentile
        
                    patches_all(ip).Magnitude = mean(pix_mag);
                    patches_all(ip).Severity  = mean(pix_severity);
                case 'patch'
                    patches_all(ip).Magnitude = mean(pix_mag);
                    % Assign severity at the patch level based on the mean magnitude
                    if patches_all(ip).Magnitude <= severity_quarter(1)
                        patches_all(ip).Severity = 1;  % low
                    elseif patches_all(ip).Magnitude <= severity_quarter(2)
                        patches_all(ip).Severity = 2;  % moderate
                    elseif patches_all(ip).Magnitude <= severity_quarter(3)
                        patches_all(ip).Severity = 3;  % high
                    else
                        patches_all(ip).Severity = 4;  % very high
                    end
            end
        end
        clear entire_map_disturb_mag;

        % for each of disturbance agent
        for ig = 1: length(agent_codes) + 4
            if ig == length(agent_codes) + 1 % for general land disturbance
                agentname = 'all';
                agentcode=[1,2,3,4,5,6,7];
            elseif ig == length(agent_codes) + 2% for general land disturbance
                agentname = 'anthropogenic';
                agentcode = [1,2,7]; % 7 is agri
            elseif ig == length(agent_codes) + 3 % for general land disturbance
                agentname = 'natural';
                agentcode = [3,4];
            elseif ig == length(agent_codes) + 4 % for general land disturbance
                agentname = 'mixed';
                agentcode = [5,6];
            else % for each of the land disturbance agents
                agentcode  = agent_codes(ig);
                agentname = char(agent_name_full(agent_code_full==agentcode));
                agentcode = [agentcode];
            end
            patches = patches_all(ismember([patches_all.AgentCode], agentcode));
            % append to record
            if ~isempty(patches)
                record = struct('grid_id',          grid_id, ...
                                'grid_area',        area_grid, ...
                                'year',             yr, ...
                                'agent',            agentname, ...
                                'patches',          rmfield(patches, 'PixelIdxList'),...
                                'dist_grid_area',   sum(entire_map_grid_index(cat(1, patches.PixelIdxList)) > 0)*0.09, ... % total disturbaed area within the grid, unit: ha
                                'dist_area',        sum([patches.Area])*0.09, ...     % total disturbed area, unit: ha
                                'dist_size',        mean([patches.Area])*0.09, ...   % average area of disturbance pacthes in the grid, unit: ha
                                'dist_size_median', median([patches.Area])*0.09, ... % median area of disturbance patches in the grid, unit: ha
                                'dist_size_prct75', prctile([patches.Area], 75)*0.09, ...
                                'dist_size_prct99', prctile([patches.Area], 99)*0.09, ...
                                'dist_size_max',    max([patches.Area])*0.09, ...
                                'dist_frequency',   length(patches)/area_grid, ...% frequency of disturbance pacthes in the grid, unit: per ha per year
                                'dist_severity',    mean([patches.Severity]), ...  % average severity of disturbance pacthes in the grid, unitless
                                'dist_number',      length(patches), ...            % backup of the number of disturbance pactches
                                'dist_magnitude',   mean([patches.Magnitude]) ... % backup of the number of disturbance magnitude in Landsat spectral bands
                                );
                record_grid = [record_grid, record];
            end
        end
        fprintf('Finish computing disturbance at grid# %05d for %d with %0.2f mins\r', grid_id, yr, toc/60);
    end
    save(filepath_rec, 'record_grid', "-v7.3", "-nocompression");
    % writetable(struct2table(record_grid), filepath_rec);
    fprintf('Finish saving the disturbance measurements at grid# %05d with %0.2f mins\r', grid_id, toc/60);
end

end

function entire_map_grid_index = load_entire_grid_index_map(dir_map_ana, shapefile_name, tile_h, tile_v, ard_buf, grid_id)

    % extend one ard tile to create disturbance objects
    h_min = min(tile_h)-ard_buf;
    v_min = min(tile_v)-ard_buf;
    h_max = max(tile_h)+ard_buf;
    v_max = max(tile_v)+ard_buf;

    % avoid negative values
%     h_min = max(0, h_min);
%     v_min = max(0, v_min);
    tile_size = 5000;
    hs = h_min: h_max;
    vs = v_min: v_max;
    entire_map_grid_index = false(tile_size.*length(hs), tile_size.*length(vs));
    for iv = 1: length(vs)
        for ih = 1: length(hs)
            filepath_grid_index_map = fullfile(dir_map_ana, shapefile_name, sprintf('h%03dv%03d_%s.tif', hs(ih), vs(iv), shapefile_name));
            if isfile(filepath_grid_index_map) % out of the CONUS region, there will be no map available
                entire_map_grid_index((iv -1)*tile_size + 1 : iv*tile_size, (ih-1)*tile_size + 1: ih*tile_size)= imread(filepath_grid_index_map) == grid_id;
            end
        end
    end
end

function entire_map_disturb = load_entire_disturbance_map(dir_map, yr, key, tile_h, tile_v, ard_buf, version)
    % extend one ard tile to create disturbance objects
    h_min = min(tile_h)-ard_buf;
    v_min = min(tile_v)-ard_buf;
    h_max = max(tile_h)+ard_buf;
    v_max = max(tile_v)+ard_buf;

    tile_size = 5000;
    hs = h_min:h_max;
    vs = v_min:v_max;
    entire_map_disturb = zeros(tile_size.*length(hs), tile_size.*length(vs));
    for iv = 1: length(vs)
        for ih = 1: length(hs)
            mapname = sprintf('CD_%03d%03d_%04d_%s', hs(ih), vs(iv), yr, version);
            filepath_map = fullfile(dir_map, sprintf('h%03dv%03d', hs(ih), vs(iv)), mapname, sprintf('%s_%s.tif', mapname, key));
            if isfile(filepath_map)
                entire_map_disturb((iv -1)*tile_size + 1 : iv*tile_size, (ih-1)*tile_size + 1: ih*tile_size)= imread(filepath_map);
            end
        end
    end
end

function entire_map_disturb = load_entire_cover_change_count_map(dir_map, key, tile_h, tile_v, ard_buf)
    % extend one ard tile to create disturbance objects
    h_min = min(tile_h)-ard_buf;
    v_min = min(tile_v)-ard_buf;
    h_max = max(tile_h)+ard_buf;
    v_max = max(tile_v)+ard_buf;

    tile_size = 5000;
    hs = h_min:h_max;
    vs = v_min:v_max;
    entire_map_disturb = zeros(tile_size.*length(hs), tile_size.*length(vs));
    for iv = 1: length(vs)
        for ih = 1: length(hs)
            mapname = sprintf('h%03dv%03d', hs(ih), vs(iv));
            filepath_map = fullfile(dir_map, sprintf('%s_%s.tif', mapname, key));
            if isfile(filepath_map)
                entire_map_disturb((iv -1)*tile_size + 1 : iv*tile_size, (ih-1)*tile_size + 1: ih*tile_size)= imread(filepath_map);
            end
        end
    end
end


function record_tile_grid = load_lookup_tile_grid(dir_map_ana, shapefile_name, conus_tiles)
    dir_ana_grid = fullfile(dir_map_ana, shapefile_name);
    filepath_rec = fullfile(dir_ana_grid, sprintf('lookup_tile_grid_%s.csv', shapefile_name));

    if isfile(filepath_rec)
        record_tile_grid = readtable(filepath_rec,'PreserveVariableNames',true);
        record_tile_grid = table2struct(record_tile_grid);
        return
    end
    
    record_tile_grid = [];
    for i = 1: length(conus_tiles)
        tile = conus_tiles{i};
    
        path_tile_grid = fullfile(dir_ana_grid, sprintf('%s_%s.tif', tile, shapefile_name) );
        tile_grid_index = imread(path_tile_grid);
        indexs = unique(tile_grid_index(:));
        
        for j = 1: length(indexs)
            if indexs(j) > 0 & indexs(j) < 65535
                record = struct('tile_name', tile, 'tile_h', str2num(tile(2:4)), 'tile_v', str2num(tile(6:8)), 'grid_id', indexs(j) );
                record_tile_grid = [record_tile_grid, record];
            end
        end
        fprintf('Created: %s\n', path_tile_grid);
    end
    
    
    writetable(struct2table(record_tile_grid), filepath_rec);
end