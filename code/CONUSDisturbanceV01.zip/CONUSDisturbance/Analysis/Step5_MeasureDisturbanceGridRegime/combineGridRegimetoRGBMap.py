
import sys
import os
import glob
from pathlib import Path
import click
import geopandas as gpd


# Pre-set parameters

years = list(range(1988, 2023))
product_version = 8
pathResultAnalysis = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Analysis/'
shapefile_name = 'hexagon_grid_50km'
dir_map_ana = os.path.join(pathResultAnalysis, f'V{product_version:02d}PostRelease')

dir_ana_grid_shp = os.path.join(dir_map_ana, f'{shapefile_name}_dist_regime_shift_patch_{years[0]}_{years[-1]}_shapefile')
# setup the destination folder output
destination = dir_ana_grid_shp + "_rgb"
# create the directory if it does not exist
if not os.path.exists(destination):
    os.makedirs(destination)

agents = ['all', 'forest_management', 'construction', 'agriculture_activity', 'stress', 'natural_hazard', 'water_dynamic', 'fire']

# process each of the agents
for agt in agents:
    r_channel   = gpd.read_file(os.path.join(dir_ana_grid_shp, f'{agt}_dist_frequency_mean_1988_2022.shp'))
    g_channel   = gpd.read_file(os.path.join(dir_ana_grid_shp, f'{agt}_dist_size_mean_1988_2022.shp'))
    b_channel   = gpd.read_file(os.path.join(dir_ana_grid_shp, f'{agt}_dist_severity_mean_1988_2022.shp'))
 
    a_channel = r_channel.copy() # set it up as the base
    r_channel.set_index('Id')
    g_channel.set_index('Id')
    b_channel.set_index('Id') # on index to join the shapefiles
    # join the three shapefiles
    a_channel = a_channel.join(r_channel, rsuffix="_r")
    a_channel = a_channel.join(g_channel, rsuffix="_g")
    a_channel = a_channel.join(b_channel, rsuffix="_b")
    # remove columns geometry_r, geometry_g, geometry_b because it will impact the fillna
    a_channel.drop(columns=["geometry_r", "geometry_g", "geometry_b"], inplace=True)
    # convert null to zero for all columns
    a_channel.fillna(0, inplace=True)

    # covernt to total disturbance area by multiplying the area of each hexagon
    # num_years = 35 # 2022 - 1988 + 1
    r_channel_area = a_channel["MeanY8822_r"]
    g_channel_area = a_channel["MeanY8822_g"]
    b_channel_area = a_channel["MeanY8822_b"]
    
    # get percentile 95% of the disturbance area
    r_channel_max = r_channel_area.quantile(0.95)
    g_channel_max = g_channel_area.quantile(0.95)
    b_channel_max = b_channel_area.quantile(0.95)
    print(f"r_channel_max: {r_channel_max}")
    print(f"g_channel_max: {g_channel_max}")
    print(f"b_channel_max: {b_channel_max}")
    
    # define min
    r_channel_min = 0
    g_channel_min = 0
    b_channel_min = 0
    
    # normalize the disturbance area into 0-255 according to min and max
    r_channel_area = (r_channel_area - r_channel_min) / (r_channel_max - r_channel_min) * 255
    g_channel_area = (g_channel_area - g_channel_min) / (g_channel_max - g_channel_min) * 255
    b_channel_area = (b_channel_area - b_channel_min) / (b_channel_max - b_channel_min) * 255
    
    # round of values and into uint8
    r_channel_area = r_channel_area.round().astype("uint8")
    g_channel_area = g_channel_area.round().astype("uint8")
    b_channel_area = b_channel_area.round().astype("uint8")
    
    # convert to the rgb to hex
    rgb_hex = []
    for r, g, b in zip(r_channel_area, g_channel_area, b_channel_area):
        rgb_hex.append(f"#{r:02x}{g:02x}{b:02x}")
    
    # append to the shapefile RGB
    a_channel["R"] = r_channel_area
    a_channel["G"] = g_channel_area
    a_channel["B"] = b_channel_area

    # save the hex values to the shapefile
    a_channel["HEX"] = rgb_hex
    # only keep the necessary columns, ID GRID_ID RGB_HEX geometry R G B
    a_channel = a_channel[["Id", "HEX", "geometry", "R", "G", "B"]]

    # save the shapefile with agent name
    a_channel.to_file(os.path.join(destination, f"{agt}_regime_rgb.shp"))
    