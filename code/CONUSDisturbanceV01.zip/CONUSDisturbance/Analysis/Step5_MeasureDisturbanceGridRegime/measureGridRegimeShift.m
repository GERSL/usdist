function measureGridRegimeShift(jobid, jobnum)
    %% Add code paths
    pathpackage = fileparts(fileparts(fileparts(mfilename('fullpath')))); 
    addpath(pathpackage); % add ODACA's parent folder
    addpath(fullfile(pathpackage, 'ODACA')); % add the <Shared>
    addpath(fullfile(pathpackage, 'ODACA', 'Shared')); % add the <Shared>
    
    
    %% Pre-setted paras
    if isempty(odacasets.refineSampleCollection)
        product_version = 0; % indicate the maps using open-source data
    else
        product_version = odacasets.refineSampleCollection + 1; % following the sample collection's #
    end
    
    dir_map_ana = fullfile(odacasets.pathResultAnalysis, sprintf('V%02dPostRelease', product_version));
    
    
    if ~exist('jobid', 'var') || ~exist('jobnum', 'var')
        jobid = 1; jobnum = 1;
    end
    
    shapefile_name = 'hexagon_grid_50km';
    % shapefile_name = 'eco_regions_l3';
    
    years = 1988:2022; % the analyzed years
    % years = 1988:2020; % study period, a total of 35 years
    
    % all agents: 'forest_management', 'agriculture_activity', 'construction', 'stress', 'debris', 'water_dynamic', 'fire', 'other'
    agents_name = {'all', 'anthropogenic', 'natural', 'mixed', 'forest_management','construction', 'agriculture_activity', 'stress', 'natural_hazard', 'water_dynamic', 'fire'};
    measurements = {'dist_frequency', 'dist_size','dist_size_median', 'dist_size_prct75', 'dist_size_prct99', 'dist_size_max', 'dist_severity', 'dist_grid_area_adjust'};
    valueformats = {'mean'};
    % valueformats = {'median'};

    % load the shapefile and to get the grid ID
    grid_shapefile = shaperead(fullfile(pathpackage, 'Analysis', 'Shapefile', shapefile_name, sprintf('%s.shp', shapefile_name)));
    % specifically process the layers
    switch shapefile_name
        case 'eco_regions_l3'
            % Loop through each entry and perform the conversion
            % Grid ID is 'NA_L3CODE' numeric values
            for ig = 1:height(grid_shapefile)
                current_code = grid_shapefile(ig).NA_L3CODE;  % Extract the current NA_L3CODE as a string
                cleaned_code = strrep(current_code, '.', '');  % Remove periods (.)
                grid_shapefile(ig).Id = str2double(cleaned_code);  % Convert to a numeric value
            end
    end

    % build tasks by agents_name and measurements
    % Get the lengths of each dimension
    numValueFormats = length(valueformats);
    numGrids = length(grid_shapefile);
    
    % Preallocate the tasks matrix
    numTasks = numValueFormats * numGrids;
    tasks = zeros(numTasks, 2);  % Preallocate space for all tasks
    
    % Use a counter to fill the preallocated matrix
    taskIndex = 1;
    
    for k = 1:numValueFormats
        for m = 1:numGrids
            tasks(taskIndex, :) = [k, m];
            taskIndex = taskIndex + 1;
        end
    end
    % randomize the tasks
    rng(42); % seed
    tasks = tasks(randperm(numTasks), :);

    dir_ana_grid_rec = fullfile(dir_map_ana, [shapefile_name, '_dist_regime_patch_1988_2022']);
    dir_ana_grid_shift_rec = fullfile(dir_map_ana, [shapefile_name, '_dist_regime_shift_patch', sprintf('_%d_%d', years(1), years(end))]);
    if ~isfolder(dir_ana_grid_shift_rec)
        mkdir(dir_ana_grid_shift_rec);
    end
    

    for itask = jobid: jobnum: length(tasks)
        k = tasks(itask, 1);
        m = tasks(itask, 2);
    
        valueformat = valueformats{k};
        grid_id = grid_shapefile(m).Id;
      
        
        % fprintf('(%04d/%04d)Collecting disturbance agent grid# %05d\r', ig, length(grid_shapefile), grid_id);
    
        filepath_rec = fullfile(dir_ana_grid_rec, sprintf('grid_%05d.mat', grid_id));
    
        if ~isfile(filepath_rec)
            continue;
        end
        filepath_shift_rec = fullfile(dir_ana_grid_shift_rec, sprintf('grid_%05d.csv', grid_id));
        % examine if the file exists
        if isfile(filepath_shift_rec)
            continue;
        end

        % load the regimes
        load(filepath_rec);
        record_grid_init = struct2table(record_grid);
        record_grid_all = [];
        for i = 1: length(agents_name)
            for j = 1: length(measurements)
                record_grid = record_grid_init;
                agent_name = agents_name{i};
                measurement = measurements{j};
                % adjust the area to the true according to good practice
                if strcmpi(measurement, 'dist_grid_area_adjust')
                    [record_grid.dist_grid_area_adjust] = deal(record_grid.dist_grid_area);
                    for ir = 1: height(record_grid)
                        if record_grid(ir,:).dist_grid_area_adjust > 0 % only when we have data available
                            record_grid(ir,:).dist_grid_area_adjust = area_adjust(record_grid(ir,:).agent{1}, record_grid(ir,:).dist_grid_area_adjust);
                        end
                    end
                end
                
                % add column names for the shapefile
                record_grid_shapfile = append_grid_disturbance_attri(grid_shapefile(m), record_grid, agent_name, measurement, valueformat, years(1), years(end)); % ten years
        
                % each year
                for yr = years
                    record_grid_shapfile = append_grid_disturbance_attri(record_grid_shapfile, record_grid, agent_name, measurement, valueformat, yr, yr); % if same years, name will be like Y2000'
                end

                % add record_grid to record_grid_all, with agent and measurement
                record_grid_shapfile.agent = repmat(agent_name, height(record_grid_shapfile), 1);
                record_grid_shapfile.measurement = repmat(measurement, height(record_grid_shapfile), 1);
                record_grid_all = [record_grid_all; record_grid_shapfile];
            end
        end
        % save .mat
        record_grid = record_grid_all;
        % remove the fields, Geometry, BoundingBox, X, Y, which are not needed
        record_grid = rmfield(record_grid, {'Geometry', 'BoundingBox', 'X', 'Y'});
        % covnert to table
        record_grid = struct2table(record_grid);
        % save as .csv
        writetable(record_grid, filepath_shift_rec);
        % save(filepath_shift_rec, 'record_grid', "-v7.3", "-nocompression");
        
    end
    
    end
    
    function grid_shapefile = append_grid_disturbance_attri(grid_shapefile, record_grid, agent_name, measurement, valueformat, st_year, ed_year, years_exclude)
        % st_year = min(years); ed_year = max(years);
    %     years_exclude = [2012];
        if ~exist('years_exclude', 'var')
            years_exclude = [];
        end
        if st_year == ed_year
            fieldname = sprintf('Y%04d', st_year);
            grid_shapefile.(fieldname) = NaN; % init
        else
            fieldname = sprintf('Y%02d%02d', mod(st_year, 100), mod(ed_year, 100));
            grid_shapefile.(sprintf('Mean%s', fieldname)) = NaN;
            grid_shapefile.(sprintf('Trh%s', fieldname)) = NaN;
            grid_shapefile.(sprintf('Trs%s', fieldname)) = NaN;
            grid_shapefile.(sprintf('CTrh%s', fieldname)) = NaN;
            grid_shapefile.(sprintf('CTrs%s', fieldname)) = NaN;
        end
    
        % select the recording grids, such as years, disturbances occured
        datain_years = st_year: ed_year;
        datain_years = datain_years(~ismember(datain_years, years_exclude));  %we exclude the 2012 because of the single Landsat satellite
        record_grid = record_grid(ismember([record_grid.year], datain_years), :);
    
        if ~isempty(record_grid)
            record_grid = record_grid(ismember([record_grid.agent], agent_name), :);
            if isempty(record_grid)
                return;
            end
            if st_year ~= ed_year
                % reconstruct the data, if no distubance, the value should be 0
                datain_measures = zeros(size(datain_years));
                collec_years = [record_grid.('year')];
                for iy = 1: length(datain_years)
                    id_yr = find(collec_years == datain_years(iy));
                    if ~isempty(id_yr)
                        datain_measures(iy) = record_grid(id_yr,: ).(measurement);
                    end
                end
    
                datain = [datain_years; datain_measures]';
                alpha = 0.05; % CI 95%
    
                [taub tau h sig Z S sigma sen n senplot CIlower CIupper D Dall C3 nsigma] = ktaub(datain, alpha, false);

                % acceleration rate over time with moving window of 10 years
                datain_slope = datain;
                win_size = 10;
                for iy = win_size: size(datain_slope, 1)
                    [taub_a tau_a h_a sig_a Z_a S_a sigma_a sen_a n_a senplot_a CIlower_a CIupper_a D_a Dall_a C3_a nsigma_a] = ktaub(datain(iy-win_size+ 1: iy,:), alpha, false);
                    datain_slope(iy, end) = sen_a; % slope is given
                end
                datain_slope = datain_slope(win_size:end, :);
                [taub_a tau_a h_a sig_a Z_a S_a sigma_a sen_a n_a senplot_a CIlower_a CIupper_a D_a Dall_a C3_a nsigma_a] = ktaub(datain_slope, alpha, false);

    
                switch valueformat
                    case 'mean'
                        if strcmpi('dist_size', measurement) % patch-based metric
                            % mean of the disturbance patches 1988-2022
                            tvalue = 0;
                            tnum = 0;
                            for ir = 1: height(record_grid)
                                pathes_grid = record_grid(ir, "patches").patches;
                                pathes_grid = pathes_grid{1};
                                tvalue = tvalue + sum([pathes_grid.Area]).*0.09; % to ha
                                tnum = tnum + length(pathes_grid);
                            end
                            grid_shapefile.(sprintf('Mean%s', fieldname)) = tvalue/tnum;
                        elseif strcmpi('dist_severity', measurement) % patch-basd metric
                            % mean of the disturbance patches 1988-2022
                            tvalue = 0;
                            tnum = 0;
                            for ir = 1: height(record_grid)
                                pathes_grid = record_grid(ir, "patches").patches;
                                pathes_grid = pathes_grid{1};
                                tvalue = tvalue + sum([pathes_grid.Severity]);
                                tnum = tnum + length(pathes_grid);
                            end
                            grid_shapefile.(sprintf('Mean%s', fieldname)) = tvalue/tnum;
                        else % grid-based metric
                            grid_shapefile.(sprintf('Mean%s', fieldname)) = mean(datain_measures, 'omitnan');
                        end
                        sen = 100*sen/grid_shapefile.(sprintf('Mean%s', fieldname)); % convert to percentage per year
                        sen_a = 100*sen_a/grid_shapefile.(sprintf('Mean%s', fieldname)); % convert to percentage per year
                    case 'median' % TBD
                        grid_shapefile.(sprintf('Medi%s', fieldname)) = median(datain_measures, 'omitnan');
                        sen = 100*sen/grid_shapefile.(sprintf('Medi%s', fieldname)); % convert to percentage per year
                end
                
                grid_shapefile.(sprintf('Trh%s', fieldname)) = h;
                grid_shapefile.(sprintf('Trs%s', fieldname)) = sen;
                grid_shapefile.(sprintf('CTrh%s', fieldname)) = h_a;
                grid_shapefile.(sprintf('CTrs%s', fieldname)) = sen_a;
            else
                % for single year
                grid_shapefile.(fieldname) = record_grid.(measurement);
            end
        end
    end
    