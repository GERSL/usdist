function rgb = hex2rgb(hex)
    % HEX2RGB Convert hex color code to RGB.
    % Input: 
    %   hex - A string representing the hex color code (e.g., '#FF5733' or 'FF5733')
    % Output:
    %   rgb - A 1x3 vector with normalized RGB values (in the range [0, 1])

    % Remove the '#' symbol if it's present
    if hex(1) == '#'
        hex = hex(2:end);
    end

    % Convert the hex string to numbers
    r = hex2dec(hex(1:2));
    g = hex2dec(hex(3:4));
    b = hex2dec(hex(5:6));

    % Normalize the RGB values to the range [0, 1]
    rgb = [r, g, b] / 255;
end
