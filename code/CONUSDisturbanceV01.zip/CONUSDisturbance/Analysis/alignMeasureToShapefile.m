function alignMeasureToShapefile(jobid, jobnum)

if ~exist('jobid', 'var') || ~exist('jobnum', 'var')
    jobid = 1; jobnum = 1;
end

agents = {'noother', 'forest_management', 'agriculture_activity', 'construction', 'stress', 'debris', 'water_dynamic', 'fire', 'other', 'all'};

% agents = {'agriculture_activity'};

measures = {'distarea', 'size', 'frequency', 'magnitude'};

for ijob = jobid: jobnum: length(agents)

    for ms = measures
        align2Shapfile(agents{ijob}, ms{1});
    end
end

end

function align2Shapfile(agent, measure)
    
    % Add code paths
    pathpackage = fileparts(fileparts(mfilename('fullpath'))); 
    addpath(pathpackage); % add ODACA's parent folder
    addpath(fullfile(pathpackage, 'Shared')); % add the <Shared>


    years   = odacasets.years;
    
    shapefile_name = 'hexagon_grid_50km';
    path_shapefile = fullfile(pathpackage, 'Analysis', 'Shapefile', shapefile_name, sprintf('%s.shp', shapefile_name));
    grid_shapefile = shaperead(path_shapefile);
    
    
    dir_map = odacasets.pathResultMaps;
    dir_map_ana = [dir_map, 'Ana'];
    
    dir_ana_grid_rec = fullfile(dir_map_ana, [shapefile_name, '_disturbance_measurment'], agent);
    dir_ana_grid_shp = [dir_ana_grid_rec, '_shapefile'];
    if ~isfolder(dir_ana_grid_shp)
        mkdir(dir_ana_grid_shp);
    end
    
    for ig = 1: length(grid_shapefile)
    
        grid_id = grid_shapefile(ig).Id;
        
        fprintf('Collecting disturbance %s %s at grid# %05d\r', measure, agent, grid_id);
    
        filepath_rec = fullfile(dir_ana_grid_rec, sprintf('grid_%05d.csv', grid_id));
    
        if ~isfile(filepath_rec)
            continue;
        end

        % load the regimes
        record_grid = readtable(filepath_rec,'PreserveVariableNames',true);
        record_grid = table2struct(record_grid);
        for ir = 1: length(record_grid)

            record_grid(ir).frequency = record_grid(ir).frequency./record_grid(ir).area;

            if isnan(record_grid(ir).frequency)
                record_grid(ir).frequency = 0;
            end
            if isnan(record_grid(ir).size)
                record_grid(ir).size = 0;
            end
            if isnan(record_grid(ir).magnitude)
                record_grid(ir).magnitude = 0;
            end
            record_grid(ir).magnitude = record_grid(ir).magnitude./10000; % convert to 0-1 reflectance level
        end

        st_year = min(years); ed_year = max(years);
        grid_shapefile = regime_years(grid_shapefile, ig, record_grid, measure, st_year, ed_year);
        grid_shapefile = regime_years(grid_shapefile, ig, record_grid, measure, 2000, 2020);
        grid_shapefile = regime_years(grid_shapefile, ig, record_grid, measure, 2000, 2004);
        grid_shapefile = regime_years(grid_shapefile, ig, record_grid, measure, 2005, 2009);
        grid_shapefile = regime_years(grid_shapefile, ig, record_grid, measure, 2010, 2015);
        grid_shapefile = regime_years(grid_shapefile, ig, record_grid, measure, 2016, 2020);

        for yr = years
            grid_shapefile(ig).(sprintf('Y%d', yr)) = record_grid([record_grid.year] == yr).(measure);
        end
    end

    % exclude the grids that we do not have data at all
    ids_remain = [];
    for ig = 1: length(grid_shapefile)
        if ~isempty(grid_shapefile(ig).('Y2020'))
            ids_remain = [ids_remain; ig];
        end
    end
    grid_shapefile = grid_shapefile(ids_remain);
        
%     fields = fieldnames( grid_shapefile ,'-full') ;
%     for ig = 1: length(grid_shapefile)
%         for ic =1 :length(fields)
%             if isempty(grid_shapefile(ig).(fields{ic}))
%                 grid_shapefile(ig).(fields{ic}) = -9999;
%             end
%         end
%     end
    shapewrite(grid_shapefile, fullfile(dir_ana_grid_shp, sprintf('%s_%s_%d_%d.shp', agent, measure, min(years), max(years))));
end

function grid_shapefile = regime_years(grid_shapefile, ig, record_grid, measure, st_year, ed_year)
    % st_year = min(years); ed_year = max(years);
    years_exclude = [2012];
    record_grid = record_grid(~ismember([record_grid.year], years_exclude));  %we exclude the 2012 because of the single Landsat satellite
    year_range = [st_year: ed_year];
    year_range = year_range(~ismember(year_range, years_exclude));  %we exclude the 2012 because of the single Landsat satellite
    
    year_ids = ismember([record_grid.year], st_year:ed_year); %

    measure_list = [record_grid(year_ids).(measure)];
    grid_shapefile(ig).(sprintf('Y%02d%02dMean', mod(st_year, 100), mod(ed_year, 100))) = mean(measure_list, 'omitnan');
    grid_shapefile(ig).(sprintf('Y%02d%02dMedi', mod(st_year, 100), mod(ed_year, 100))) = median(measure_list, 'omitnan');

    datain = [year_range; measure_list]';
    datain(isnan(measure_list), :) = [];
    [taub tau h sig Z S sigma sen n senplot CIlower CIupper D Dall C3 nsigma] = ktaub(datain, 0.1, false);
    grid_shapefile(ig).(sprintf('Y%02d%02dTrh', mod(st_year, 100), mod(ed_year, 100))) = h;
    grid_shapefile(ig).(sprintf('Y%02d%02dTrs', mod(st_year, 100), mod(ed_year, 100))) = sen;
end