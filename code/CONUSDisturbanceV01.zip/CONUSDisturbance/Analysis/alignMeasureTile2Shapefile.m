%% Add code paths
pathpackage = fileparts(fileparts(mfilename('fullpath'))); 
addpath(pathpackage); % add ODACA's parent folder
addpath(fullfile(pathpackage, 'Shared')); % add the <Shared>

agents_name = {'forest_management', 'agriculture_activity', 'construction', 'stress', 'debris', 'water_dynamic', 'fire', 'other'};
agents_count = {'forest_management', 'agriculture_activity', 'construction', 'stress', 'debris', 'water_dynamic', 'fire'};

years = 2000:2020;
shapefile_name = 'state';
path_shapefile = fullfile(pathpackage, 'Analysis', 'Shapefile', shapefile_name, sprintf('%s.shp', shapefile_name));
grid_shapefile = shaperead(path_shapefile);
grid_shapefile = init_shapefile_new_field(grid_shapefile, agents_name, min(years), max(years), agents_count);
for yr = years
    grid_shapefile = init_shapefile_new_field(grid_shapefile, agents_name, yr, yr, agents_count);
end


dir_map = odacasets.pathResultMaps;
dir_map_ana = [dir_map, 'Ana'];

dir_ana_grid_rec = fullfile(dir_map_ana, 'tile_disturbance_measurment');
dir_ana_grid_shp = [dir_ana_grid_rec, '_shapefile'];
if ~isfolder(dir_ana_grid_shp)
    mkdir(dir_ana_grid_shp);
end

conus_tiles = odacasets.ARDTiles;
for i = 1: length(conus_tiles)
    fprintf('Processing %s\n', conus_tiles{i});
    tile = conus_tiles{i};
    filepath_rec = fullfile(dir_ana_grid_rec, sprintf('%s_agent_area.csv', tile));

    record_tile = readtable(filepath_rec,'PreserveVariableNames',true);
    record_tile = table2struct(record_tile);
    grid_shapefile = disturbance_area_years(grid_shapefile, record_tile, agents_name, min(years), max(years), agents_count);
    for yr = years
        grid_shapefile = disturbance_area_years(grid_shapefile, record_tile, agents_name, yr, yr, agents_count);
    end
end


shapewrite(grid_shapefile, fullfile(dir_ana_grid_shp, sprintf('disturbance_area_state_%d_%d.shp', min(years), max(years))));

function grid_shapefile = init_shapefile_new_field(grid_shapefile, agents_name, st_year, ed_year, agents_count)
    if st_year == ed_year
        fieldname = sprintf('Y%04d', st_year);
    else
        fieldname = sprintf('Y%02d%02d', mod(st_year, 100), mod(ed_year, 100));
    end
    for istate = 1: length(grid_shapefile)
        if ~isempty(agents_count)
            grid_shapefile(istate).(['AL', fieldname]) = 0; % all disturbanced area
        end
       % init
        for iag = 1: length(agents_name)
            agent = agents_name{iag};
            grid_shapefile(istate).([upper(agent(1:2)), fieldname]) = 0;
        end
    end
end

function grid_shapefile = disturbance_area_years(grid_shapefile, record_tile, agents_name, st_year, ed_year, agents_count)
    % st_year = min(years); ed_year = max(years);
%     years_exclude = [2012];
%     record_grid = record_grid(~ismember([record_grid.year], years_exclude));  %we exclude the 2012 because of the single Landsat satellite

    year_ids = ismember([record_tile.year], st_year:ed_year); %
    record_tile = record_tile(year_ids);

    if st_year == ed_year
        fieldname = sprintf('Y%04d', st_year);
    else
        fieldname = sprintf('Y%02d%02d', mod(st_year, 100), mod(ed_year, 100));
    end
    for istate = 1: length(grid_shapefile)
        state_id = str2num(grid_shapefile(istate).STFIPS);
        % count total area of land disturbance except 'other'
        if ~isempty(agents_count)
            record_tile_agent = record_tile(ismember({record_tile.agent}, agents_count));
            area_tile_agent = sum([record_tile_agent.(sprintf('state%02d', state_id))]);
            field_name = ['AL', fieldname];
            grid_shapefile(istate).(field_name) = grid_shapefile(istate).(field_name) + area_tile_agent;
        end
        % sum
        for iag = 1: length(agents_name)
            agent = agents_name{iag};
            record_tile_agent = record_tile(ismember({record_tile.agent}, agent));
            area_tile_agent = sum([record_tile_agent.(sprintf('state%02d', state_id))]);
            field_name = [upper(agent(1:2)), fieldname];
            grid_shapefile(istate).(field_name) = grid_shapefile(istate).(field_name) + area_tile_agent;
        end

    end
    end













