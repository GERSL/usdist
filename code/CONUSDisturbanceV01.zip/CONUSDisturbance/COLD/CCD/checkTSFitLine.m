function  records_finished = checkTSFitLine(folderpath_cold, varargin)
%% This is function is to examine the status of product process
% July 27, 2021
% by Shi
% INPUT:
%
%   folderpath_cold:        Locate to COLD working folder, in which the
%                           change folder <TSFitLine> is necessery, and
%                           this folder was created by <COLD.m>.
%
%   read (optional)          [false/true] check the rec_cg by reading (default
%                           value: false)
%
%   msg (optional)          [false/true] Display processing status (default
%                           value: false)
% RETURN:
% records_finished:         The percentage of the records finished
% 
% folderpath_cold = '/lustre/scratch/qiu25856/COLDResults/CONUS_SpectralChangeProduct_COLD2_Version1/h008v003';% 

% request user's input
p = inputParser;
addParameter(p,'read', false); 
addParameter(p,'msg', false); 
parse(p,varargin{:});
readfit = p.Results.read;
msg = p.Results.msg;


[~, hv_name] = fileparts(folderpath_cold);

% total number of rows
try
    met = load(fullfile(folderpath_cold, 'metadata.mat'));
catch
    % fprintf('%s: No metadata\r', hv_name);
    records_finished = 0;
    return;
end
nrows = met.metadata.nrows;
clear met;

foldername_fit = 'TSFitLine';

%% exmaine all rows ready or not?

filepath_tar = fullfile(folderpath_cold, [foldername_fit, '.tar']);
if isfile(filepath_tar)
    records_finished = 100; % 100% finished, according to the .tar
else
    files_reg = dir(fullfile(folderpath_cold, foldername_fit, 'record_change*.mat'));
    files_reg([files_reg.bytes] == 0) = [];% remove the file size with 0

    if readfit % check the dataset by loading each one of them
        num_files = readcheck(files_reg, msg);
    else % just show the number of files
        num_files = length(files_reg);
    end
    
    % convert to rate
    records_finished = 100.*num_files./nrows;
end

if msg
    fprintf('%s: Finished TSF lines %0.2f Percent for CCD\r', hv_name, records_finished);
end

end

function num_files = readcheck(files_reg, msg)
    num_files = length(files_reg);
    for ir = 1: length(files_reg)
        try
            load(fullfile(files_reg(ir).folder, files_reg(ir).name)); %#ok<LOAD> 
        catch
            num_files = num_files - 1;
            if msg
                fprintf('Error in loading %s\r', fullfile(files_reg(ir).folder, files_reg(ir).name));
            end
        end
    end
end
%% Examine each of the rec_cg files
% % records = zeros([nrows, 1], 'logical');
% % for i = 1: nrows
% %     if isfile(fullfile(folderpath_cold, foldername_fit, sprintf('record_change_r%05d.mat', i)))
% %         records(i) = 1;
% %     end
% % end
% % records_finished = sum(records)./nrows;