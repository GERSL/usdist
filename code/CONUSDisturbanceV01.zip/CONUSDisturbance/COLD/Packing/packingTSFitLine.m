function status = packingTSFitLine(folderpath_cold, varargin)
%PACKINGTSFITLINE is to pack the record of time series segment per line in
%<TSFitLine>, as .tar.
% This will reduce the number of files.


    p = inputParser;
    addParameter(p,'del', true); % is to delete the TSFitLine folder
    
     % request user's input
    parse(p,varargin{:});
    del = p.Results.del;


    status = 0; 
    % 0: Not finished
    % 1: Compressed
    % 2: .tar file exsit

    %% continue it only when all rows finished
    if checkTSFitLine(folderpath_cold) == 1 % may be returned by existing file, or by 100% finished
        tic
        fprintf('Start to compress TSFitLine at %s\r', folderpath_cold);
        foldername_fit = 'TSFitLine';
        filepath_tar = fullfile(folderpath_cold, [foldername_fit, '.tar']);
        if isfile(filepath_tar) && ~isfile([filepath_tar, '.part'])&& ~isfile([filepath_tar, '.part.tar']) % the second condition is to double-confirm the success of the compression
            if del && isfolder(fullfile(folderpath_cold, foldername_fit))
                rmdir(fullfile(folderpath_cold, foldername_fit), 's'); % delete the folder of TSFitLine
            end
            status = 2; % exsit
            fprintf('Exist TSFitLine.tar at %s\r', folderpath_cold);
            return;
        end
        if isfile([filepath_tar, '.part']) % delete the broken file
            delete([filepath_tar, '.part']);
        end
        if isfile([filepath_tar, '.part.tar']) % delete the broken file
            delete([filepath_tar, '.part.tar']);
        end
        
        tar([filepath_tar, '.part'], fullfile(folderpath_cold, foldername_fit)); % compress it
        
        if isfile([filepath_tar, '.part.tar'])
            movefile([filepath_tar, '.part.tar'], filepath_tar); % rename as .tar
        else
            movefile([filepath_tar, '.part'], filepath_tar); % rename as .tar
        end
        
        % one more file process is to ensure all the above codes were
        % conducted sucessfully
        save([filepath_tar, '.part'] , 'filepath_tar');
        if isfile([filepath_tar, '.part']) % delete the broken file
            delete([filepath_tar, '.part']);
        end
        
        if del
            rmdir(fullfile(folderpath_cold, foldername_fit), 's'); % delete the folder of TSFitLine
        end
        fprintf('Finished compressing TSFitLine at %s in %0.2f mins\r', folderpath_cold, toc/60);
        status = 1; % finished compressing
    end
end

% Call Linux command to compress the data
%         commandstr = sprintf('tar czfv %s %s',filepath_tar, fullfile(folderpath_cold, foldername_fit));
%         system(commandstr);

