%% Clean the stack data for the tiles that have been processed with COLD
dir_pipline = fileparts(mfilename('fullpath'));

%%
CHECKITEMS = {'stack', 'cold'};
% CHECKITEMS = {'stack'};

%% Add paths
restoredefaultpath;
addpath(genpath(fileparts(dir_pipline)));

%% landsat tiles
% [~, tiles] = readTileList;
tiles = dir(fullfile('/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Detection', 'h*'));

for i =  1: length(tiles)
    %% Obtain the tile name of Landsat data
    tile = tiles(i).name;
    if length(tile) ~= 8
        continue;
    end
    
    %% Check the cold results, and if 100% done, just skip to submitt the job
    records_finished = checkTSFitLine(sprintf(globalsets.FolderpathCOLD, tile));

    if records_finished < 100
        [prct, err, images_err, images_lack] = checkStack(tile);
        if ismember({'stack'}, CHECKITEMS)
            fprintf('*%03.2f percent done for stacking %s\n', prct, tile);
        end
        if err > 0
            warning('Stacking error for %s \r\n', tile);
            fprintf('Re-stacking ... (if some files were deleted, please re-download the Landsat data for this tile)\r\n');
            stackLandsatARDC2Bands2Line(tile, 'imagelist', images_err, 'errordelete', true);
        elseif prct >= 80 & ~isempty(images_lack)
            fprintf('Stacking ... (A few images have not been stacked, so this function helps to stack)\r\n');
            stackLandsatARDC2Bands2Line(tile, 'imagelist', images_lack);
        end
    end
    if ismember({'cold'}, CHECKITEMS)
        fprintf('%03.2f percent done for detecting %s\n', records_finished, tile);
    end
end

