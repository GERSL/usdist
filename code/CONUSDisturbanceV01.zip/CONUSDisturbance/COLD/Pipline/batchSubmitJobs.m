%% This is to submit the job for processing Landsat ARD  or PathRow tiles
%
% 
% AUTHOR(s): Shi Qiu
% DATE: Nov. 1, 2022
% COPYRIGHT @ GERSLab

dir_pipline = fileparts(mfilename('fullpath'));

%% Add paths
restoredefaultpath;
addpath(genpath(fileparts(dir_pipline)));

%% Select landsat tiles from the .txt
[~, tiles] = readTileList;

% tiles = {'h015v014'};
% tiles = {'h005v011'};

%% Select the tiles with 100% stacked data
% tiles_dir = dir(fullfile('/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Producing', 'h*'));
% tiles = [];
% for i =  1: length(tiles_dir)
%     tile = tiles_dir(i).name;
%     if length(tile) ~= 8
%         continue;
%     end
%     [prct, err, images_err, images_lack] = checkStack(tile);
%     if prct == 100
%         tiles = [tiles; {tile}];
%     end
% end


TILECORENUMBER = 51;
MAXCORESTACKING = 1000;

num_stacking = 0;
num_submitted = 0;

[~, jobs] = system("sacct --format='JobName%50,State'");
jobs = strsplit(jobs, ' ');

for i = 1: length(tiles)
    if num_submitted >= 100
        fprintf('More than %d jobs were submitted. Please refresh this script to submit new jobs\r\n', num_submitted);
        break;
    end


    %% Obtain the tile name of Landsat data
    tile = tiles{i};

    %% Check the cold results, and if 100% done, just skip to submitt the job
    folderpath_cold = sprintf(globalsets.FolderpathCOLD, tile);
    records_finished = checkTSFitLine(folderpath_cold);
    if records_finished == 100
        fprintf('100 percent done for %s\r\n', tile);
        continue;
    end

    %% Check the running or pending jobs
    inprocess = false;

    if sum(ismember({'RUNNING', 'PENDING'}, jobs(find(ismember(jobs, tile))+1)))> 0
        fprintf('Job of %s in RUNNING or PENDING\r\n', tile);
        inprocess = true;
    end    
    if inprocess % when the tile is in process, we will check it is in stacking or not
        continue;
    end
    
    if inprocess % when the tile is in process, we will check it is in stacking or not
        [prct, err] = checkStack(tile);
        if prct < 100
            num_stacking = num_stacking + 1;
        end
        continue;
    end

    if num_stacking*TILECORENUMBER >= MAXCORESTACKING
        fprintf('%d tiles in stacking, we will wait for a while\r\n', num_stacking);
        break;
    end

    %% create .sh
    FileJobs = 'piplineJobTemplate.sh';
    filepath_job_template = fullfile(dir_pipline, FileJobs); % the template of the jobs
    fid_in = fopen(filepath_job_template,'a+');
    shfile=fscanf(fid_in,'%c',inf);

    % Target .sh files
    folderpath_job_record = fullfile(dir_pipline, 'job'); % the outputs will be stored in this directory
    if ~isfolder(folderpath_job_record)
        mkdir(folderpath_job_record);
    end
    FileJobsReady = sprintf('pipline_%s.sh', tile);
    path_job_ready = fullfile(folderpath_job_record, FileJobsReady);
    
    % create the job file and submit it.
    shfile_ready = strrep(shfile, 'TileName', tile);
    shfile_ready = strrep(shfile_ready, 'CoreNumber', num2str(TILECORENUMBER));
    shfile_ready = strrep(shfile_ready, '%', '%%'); % print %

    %open file identifier
    fid = fopen(path_job_ready,'w');
    fprintf(fid, shfile_ready);
    fclose(fid);

    %% submit job
    record_folder = pwd; % recording the current folder
    cd(folderpath_job_record);
    [~, jobid] = system(sprintf('sbatch %s', FileJobsReady));
    cd(record_folder); % go back to the code package's folder
    
    jobid= split(jobid, ' ');
    jobid = str2double(jobid{end});
    
    fprintf('Jobs for %s (ID: %d) has been submited successfully\r', tile, jobid);
    
    num_submitted = num_submitted + 1;
end % end of tile


