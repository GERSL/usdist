for i = 1: 10000
    i
    batchCleanStack
    batchSubmitJobs
    batchCheckProgress
    pause(60*30)
end