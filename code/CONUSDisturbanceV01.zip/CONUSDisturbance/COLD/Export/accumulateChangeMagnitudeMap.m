function accumulateChangeMagnitudeMap(folderpath_cold, years, varargin)
% ACCUMULATECHANGEMAP This is to create the accumulated change map based on
% the yearly change maps in the folder <ChangeMap>
%
% INPUT:
%
%   folderpath_cold:        Locate to COLD working folder, in which the
%                           change folder <TSFitLine> is necessery, and
%                           this folder was created by <COLD.m>.
%
%   years:                  [Array] The years of change map. 
%
%   type (optional):       {'all', 'regrowth', 'disturbance'} which change type?
%
%   orbit (optional):       Orbit path of Landsat ('single' or 'all').
%                           'single' means generate the single Landsat path
%                           layer with geotiff format. 'all' means not to
%                           do that. (default value: single)
%
%   minsize (optional):     Mininum size of change object in each year.(default value is 1). 
%
%   msg (optional):         [false/true] Display processing status (default
%                           value: false)
% 
%
% OUTPUT:
%
% accuchangemap_type_yyyy_yyyy.tif in folder <ChangeMap> (type means the change type and yyyy means the year)
% uint16
% pixel value: xdoy (x indicates the type of change, and doy indicates DOY) 
% x's range is between 1 to 3
% 1 => regrowth break
% 2 => aforestation break
% 3 => land disturbance
%
% i.e., 1002 means the regrowth break occured in the 2nd day
%
%
% REFERENCE(S):
%
%   Zhu, Zhe, et al. "Continuous monitoring of land disturbance based on
%   Landsat time series." Remote Sensing of Environment 238 (2020): 111116.
%
% EXAMPLE OF USE:
%
%   > To export change maps between 1985 and 2019 (without labling change type).
%
%     accumulateChangeMap('/lustre/scratch/qiu25856/TestGERSToolbox/h029v005/',
%     [1985:2019])
% 
% AUTHOR(s): Zhe Zhu and Shi Qiu
% DATE: Feb. 7, 2021
% COPYRIGHT @ GERSLab

addpath(fileparts(fileparts(mfilename('fullpath'))));
addpath(fullfile(fileparts(fileparts(mfilename('fullpath'))), 'Shared'));

% optional
p = inputParser;
addParameter(p,'minsize', 1); % all size change object
addParameter(p,'type', 'all'); % delete stack data or not
addParameter(p,'orbit', 'all'); % to create single path layer
addParameter(p,'msg', false); % not to display info
parse(p,varargin{:});
minsize = p.Results.minsize;
msg = p.Results.msg;
type = p.Results.type;
orbit = p.Results.orbit;

tic
[~, tilename] = fileparts(folderpath_cold);
if msg
    fprintf('Start to accumulate change magnitude maps with %s change between %d and %d for %s\r\n', type, min(years), max(years), tilename);
end

orbitnum = str2double(tilename(2:4));

mapfolder = fullfile(folderpath_cold, globalsets.FolderChangeMagnitudeMap);
        
if ~isfolder(globalsets.PathGeneralAccumuChangeMagnitudeMap)
    mkdir(globalsets.PathGeneralAccumuChangeMagnitudeMap);
end
accmap_outfilepath = fullfile(globalsets.PathGeneralAccumuChangeMagnitudeMap, ...
    sprintf('accu_change_magnitude_map_%s_%d_%d.tif', tilename, min(years), max(years)));

accMapGridobj = [];

%% data first
distmap_name = 'change_magnitude_map';
yearlymaps = dir(fullfile(mapfolder, 'change_magnitude_map_*.tif')); % this has all values


%% Check files are ready
if isempty(yearlymaps)
    fprintf('No yearly change magnitude maps at %s!\r\n', mapfolder);
    return;
else
    years_nomap = [];
    for imap = 1: length(years)
        yr = years(imap);
        yearlymap_filepath = fullfile(mapfolder, [distmap_name, '_', num2str(yr),'.tif']);
        if ~isfile(yearlymap_filepath)
            years_nomap = [years_nomap; yr];
        end
    end
    if ~isempty(years_nomap)
        fprintf('No yearly change magnitude maps for Years %d!\r', years_nomap);
        return;
    end
end

%% Calculate the accumulated map

for imap = 1: length(years)
    yr = years(imap);
    if msg
        fprintf('Accumulating the change magnitude map for year %d\r', yr);
    end
    yearlymap_filepath = fullfile(mapfolder, [distmap_name, '_', num2str(yr),'.tif']);
    if isempty(accMapGridobj)
        accMapGridobj = GRIDobj(yearlymap_filepath); % first map gives to trget map
        if strcmpi(orbit, 'single')
            singlepathlayer = loadSinglePathLayer(folderpath_cold, accMapGridobj);
        end
        mask_changmap = accMapGridobj.Z ~=0;
            
        if minsize > 1
            mask_changmap = mask_changmap & bwareaopen(mask_changmap, minsize, 8); % remove small objects with 8-conn
        end
        accMapGridobj.Z(~mask_changmap) = 9999; % label as 9999 for the removed pixels. 
        clear yearlymap_filepath mask_changmap;
        continue;
    end
    yearlymap = GRIDobj(yearlymap_filepath);
    mask_changmap = accMapGridobj.Z ~=0;
            
    if minsize > 1
        mask_changmap = mask_changmap & bwareaopen(mask_changmap, minsize, 8);  % remove small objects with 8-conn
    end
    accMapGridobj.Z(mask_changmap) = accMapGridobj.Z(mask_changmap);
    clear yearlymap yearlymap_filepath mask_changmap;
end
accMapGridobj.Z = uint16(accMapGridobj.Z);

if exist('singlepathlayer', 'var')
    accMapGridobj.Z(singlepathlayer ~= orbitnum) = 9999; % only single orbit remained here
end
% save out
GRIDobj2geotiff(accMapGridobj, accmap_outfilepath);
% % % save out as a folder
% % if ~isempty(outputfolder)
% %     copyfile(accmap_outfilepath, outputfolder);
% % end

if msg
    fprintf('Finished accumluting change maps for %s with %0.2f mins\r\n', tilename, toc/60); 
end



