fprintf('** Check Multiple Same Data by Python Download Function for %s\n', hv_name);
% Filter for Landsat folders get num of total folders start with "L"
imfs = dir(fullfile(dir_cur,'L*SR.tar'));
% filter for Landsat folders
% espa data
%imf = regexpi({imf.name}, 'L(T05|T04|E07|C08)(\w*)\-(\w*)', 'match'); 
imfs = regexpi({imfs.name}, 'L(T05|T04|E07|C08)(\w*)', 'match'); % no expand name
%imf = regexpi({imf.name}, 'L(T05|T04|E07|C08).*', 'match');
imfs = [imfs{:}];
if isempty(imfs)
    warning('No images for %s!', hv_name);
    continue;
end
imfs = vertcat(imfs{:});
% sort according to yeardoy
yyyymmdd = str2num(imfs(:, 16:23)); % should change for different sets
yyyymmdd_uniq = unique(yyyymmdd,'rows') ;
% when they have same number, just return...
if length(yyyymmdd_uniq)== length(yyyymmdd)
    continue;
end

for i_yyyymmdd  =1: length(yyyymmdd_uniq)
    yyyymmdd_tmp = yyyymmdd_uniq(i_yyyymmdd);
    imfs_unq = dir(fullfile(dir_cur,['L*_CU_',hv_hhhvvv,'_',num2str(yyyymmdd_tmp),'_*SR.tar']));
    if length(imfs_unq) > 1
        % try to delete the old data
        for i_multp = 1: length(imfs_unq)-1
            imfs_unq_name = imfs_unq(1).name;
            imfs_del = dir(fullfile(dir_cur,[imfs_unq_name(1:end-6), '*.tar']));
            for idel = 1: length(imfs_del)
                filepath_tmp = fullfile(dir_cur,imfs_del(idel).name);
                delete(filepath_tmp);
                fprintf('Deleted %s\r', filepath_tmp);
            end
        end
    end
end
fprintf('A total of %d images are remained for %s...\n',length(yyyymmdd_uniq), hv_name);