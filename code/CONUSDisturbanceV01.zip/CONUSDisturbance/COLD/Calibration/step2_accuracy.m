function step2_accuracy(icore, ncore, composite)
    %% Add Pacakge Paths
    restoredefaultpath;
    addpath(genpath(fileparts(fileparts(mfilename('fullpath')))));

    %% Setup default parallel assignment
    if ~exist('icore', 'var')
        icore = 1;
    end
    if ~exist('ncore', 'var')
        ncore = 1;
    end
    if ~exist('composite', 'var')
        composite = 1;
    end

    % where the outputing will sad
    DIR_REC = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/CalibrationCOLD/NAFD_COLD';
    FILEPATH_NAFD1 = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/CalibrationCOLD/NAFD/nafd1_10102018.csv';
    FILEPATH_NAFD2 = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/CalibrationCOLD/NAFD/nafd2_10102018.csv';
    ts_seg = loadReferences({FILEPATH_NAFD1, FILEPATH_NAFD2});

    if composite
        DIR_REC = [DIR_REC, '_COMPOSITE'];
    else
        DIR_REC = [DIR_REC, '_ALLDATA'];
    end
    
    %% Test model parameters
    CONS = [3:1:8];
    CHANGE_PROB = [0.8, 0.85, 0.9, 0.95, 0.99, 0.999];
    MODEL_UPDATE = [0];
    REGROWTH = [50, 100, 150, 200, 250, 300, 350, 400, 450, 500];


    %% Test model updating rate
    CONS = [6];
    CHANGE_PROB = [0.95]; % reducing to 0.95, and then we will classify further.
    MODEL_UPDATE = [0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08];
    REGROWTH = [200];
    
    %% create task list
    tasks = [];
    for con = CONS
        for prob = CHANGE_PROB
            for uprate = MODEL_UPDATE
                for reg = REGROWTH
                    task = [];
                    task.con = con;
                    task.prob = prob;
                    task.reg = reg;
                    task.uprate = uprate;
                    tasks = [tasks; task];
                end
            end
        end
    end

    for i = icore: ncore: length(tasks)
        con = tasks(i).con;
        prob = tasks(i).prob;
        uprate = tasks(i).uprate;
        reg = tasks(i).reg;
        
        % Record the accuracy
        Conse = [];
        Threshold = [];
        UpdateRate = [];
        F1Score = [];
        Commission = [];
        Omission = [];

        % con = 3;
        % prob = 0.95;
        % th_disturb_min = -200; % MINimum THreshold for extracting DISTURBance
        th_disturb_min = 0 - reg;
        subfoldername = sprintf('%02d_%05d_%03d', con, prob*10000, uprate*100);
        rec_cg = loadCOLDResults(fullfile(DIR_REC, subfoldername)); % 
        subfoldername = sprintf('%02d_%05d_%03d_%04d', con, prob*10000, uprate*100, reg); % change to the outcome
    
        windsize = 96;
    
        all_ids = unique(ts_seg(:,1)); % all pixel ids with change agent
        n_ids = length(all_ids); % number of pixels need CCDC process
        
        tst_ids = all_ids;
        fprintf('A total of %d reference plots\r', length(tst_ids));
        confsm = zeros(1,3);
        all_yrs = [1984,2012]; % the reference bettwen 1984 and 2012 (very few in 2013, so we excluded 2013)

        for i = 1:length(tst_ids) % n_ids
            sel_ids = ts_seg(:,1) == tst_ids(i);%all_ids(i);
            ts_final = ts_seg(sel_ids,:);
            
            % get CCDC models for a pixel
            tst = rec_cg(:, [rec_cg.pos]== tst_ids(i));
            pos = [tst.pos];
            
            if ~isempty(pos)
                % record start year of matched disturbance
                rec_match = 0; rec_i = 0;
                for j = 1:size(tst,2)
                    % detect decline
                    if tst(j).change_prob == 1
                        [break_type,break_year,break_doy] = label_dist_type(tst(j).coefs,tst(j).t_break,...
                            th_disturb_min,tst(j).magnitude,tst(j+1).coefs);
        
                        % BL to record agreed disturbances between ccd and reference samples
                        BL = 0;
                        break_type(break_type == 2) = 3; % planting as disturbance
                        % only record start of distrubance % timesync cannot record distrubance occurred in the first year
                        if break_type == 3 && break_year >= all_yrs(1)+1 && break_year <= all_yrs(end)-1 && BL == 0
                            for ij = 1:size(ts_final,1)
                                if ts_final(ij,end) > 2 && break_year <= ts_final(ij,3) && break_year >= ts_final(ij,2)
                                    confsm(1) = confsm(1) + 1; % change matched
                                    BL = 1;
        
                                    % record change start year
                                    rec_i = rec_i + 1;
                                    rec_match(rec_i) = ts_final(ij,2); %#ok<SAGROW>
                                    % record agent type for each case
        %                             agree_agent(iii) = ts_final(ij,end);
        %                             iii = iii + 1;
        
                                    break; % only count 1 for each break
                                end
                            end
                            confsm(2) = confsm(2) + 1; % total number of ccd disturbance
                        end
                    end
                end
        
                % total number of reference disturbances
                for ij = 1:size(ts_final,1)
                    if ts_final(ij,end) > 2 && ts_final(ij,2) >= all_yrs(1)+1 && ts_final(ij,3) <= all_yrs(end)-1
                        confsm(3) = confsm(3) + 1; % total number of ref change
        %                 total_agent(jjj) = ts_final(ij,end);
        %                 jjj = jjj+1;
                    end
                end
            end
        end
        
        % output
        % # of agreement, # of ccd change, # of reference change
        fprintf('# of change agreement, # of ccd change, # of reference change, # of ALL\n');
        fprintf('%d, %d, %d, %d\n', confsm(1) , confsm(2), confsm(3), sum(confsm));
        com_err = (confsm(2)-confsm(1))/confsm(2); % # of disagree / # of ccd change
        omi_err = (confsm(3)-confsm(1))/confsm(3); % # of disagree of change / # of reference change
        f1 = 2*(1- com_err)*(1-omi_err)./(2- com_err - omi_err);
        fprintf('F1 score = %0.4f%% \r', f1*100);
        fprintf('Commission error = %0.4f%% \r', com_err*100);
        fprintf('Omission error = %0.4f%% \r', omi_err*100);

        % Record the outcomes
        Conse       = [Conse; con];
        Threshold   = [Threshold; prob];
        UpdateRate    = [UpdateRate; uprate];
        F1Score     = [F1Score; f1];
        Commission  = [Commission; com_err];
        Omission    = [Omission; omi_err];
        accuracy_table = table(Conse, Threshold, UpdateRate, F1Score, Commission, Omission);
        if composite
            writetable(accuracy_table, fullfile('accuracy_record', sprintf('accuracy_composite_%s.csv', subfoldername)));
        else
            writetable(accuracy_table, fullfile('accuracy_record', sprintf('accuracy_alldata_%s.csv', subfoldername)));
        end
    end
    
end

function [tsa,plotid,image_year,image_julday,dominant_landuse,dominant_landcover,change_process] = import_seg(filename, startRow, endRow)
%IMPORTFILE1 Import numeric data from a text file as column vectors.
%   [TSA,PLOTID,IMAGE_YEAR,IMAGE_JULDAY,DOMINANT_LANDUSE,DOMINANT_LANDCOVER,CHANGE_PROCESS]
%   = IMPORTFILE1(FILENAME) Reads data from text file FILENAME for the
%   default selection.
%
%   [TSA,PLOTID,IMAGE_YEAR,IMAGE_JULDAY,DOMINANT_LANDUSE,DOMINANT_LANDCOVER,CHANGE_PROCESS]
%   = IMPORTFILE1(FILENAME, STARTROW, ENDROW) Reads data from rows STARTROW
%   through ENDROW of text file FILENAME.
%
% Example:
%   [tsa,plotid,image_year,image_julday,dominant_landuse,dominant_landcover,change_process]
%   = importfile1('ts_vertex2.csv',2, 10269);
%
%    See also TEXTSCAN.

% Auto-generated by MATLAB on 2018/02/04 14:08:07

%% Initialize variables.
delimiter = ',';
if nargin<=2
    startRow = 2;
    endRow = inf;
end

%% Format string for each line of text:
%   column1: double (%f)
%	column2: double (%f)
%   column3: double (%f)
%	column4: double (%f)
%   column5: text (%s)
%	column6: text (%s)
%   column7: text (%s)
% For more information, see the TEXTSCAN documentation.
formatSpec = '%f%f%f%f%s%s%s%[^\n\r]';

%% Open the text file.
fileID = fopen(filename,'r');

%% Read columns of data according to format string.
% This call is based on the structure of the file used to generate this
% code. If an error occurs for a different file, try regenerating the code
% from the Import Tool.
dataArray = textscan(fileID, formatSpec, endRow(1)-startRow(1)+1, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines', startRow(1)-1, 'ReturnOnError', false);
for block=2:length(startRow)
    frewind(fileID);
    dataArrayBlock = textscan(fileID, formatSpec, endRow(block)-startRow(block)+1, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines', startRow(block)-1, 'ReturnOnError', false);
    for col=1:length(dataArray)
        dataArray{col} = [dataArray{col};dataArrayBlock{col}];
    end
end

%% Close the text file.
fclose(fileID);

%% Post processing for unimportable data.
% No unimportable data rules were applied during the import, so no post
% processing code is included. To generate code which works for
% unimportable data, select unimportable cells in a file and regenerate the
% script.

%% Allocate imported array to column variable names
tsa = dataArray{:, 1};
plotid = dataArray{:, 2};
image_year = dataArray{:, 3};
image_julday = dataArray{:, 4};
dominant_landuse = dataArray{:, 5};
dominant_landcover = dataArray{:, 6};
change_process = dataArray{:, 7};

end


function ts_seg = loadReferences(filepaths)

    % filepaths: paths of reference file (sometimes mutilpe files are used)
    
    plotid = [];
    image_year = [];
    change_process = [];
    for iref = 1: length(filepaths)
        [~,plotid1,image_year1,~,~,~,change_process1] = ...
            import_seg(filepaths{iref}); % change segments
        plotid = [plotid;plotid1];
        image_year = [image_year;image_year1];
        change_process = [change_process;change_process1];
    end
    clear plotid1 image_year1 change_process1; % empty the varibles
    
    % convert to ts_seg matrix
    ts_seg = zeros(1,4);% id, start, end, change
    
    uniq_ids = unique(plotid);
    l_ids = length(uniq_ids);
    
    n_row = 0;
    for i = 1:l_ids
        
        id_find = find(plotid == uniq_ids(i));
        for j = 1:length(id_find)
            
            if j == 1
                n_row = n_row + 1;
                ts_seg(n_row,1) = uniq_ids(i); % id
                ts_seg(n_row,2) = image_year(id_find(j)); % start year
            elseif j == 2
                ts_seg(n_row,3) = image_year(id_find(j)); % end year
                
                if strcmp(change_process(id_find(j)),'Stable') == 1
                    ts_seg(n_row,4) = 1; % stable
                elseif strcmp(change_process(id_find(j)),'Growth/Recovery') == 1
                    ts_seg(n_row,4) = 2; % regrowth
                elseif strcmp(change_process(id_find(j)), 'Structural Decline') == 1
                    ts_seg(n_row,4) = 3; 
                    if ts_seg(n_row,3)-ts_seg(n_row,2) > 10 % bad pixels
                        n_row = n_row - 1;
                    end
                elseif strcmp(change_process(id_find(j)), 'Fire') == 1
                    ts_seg(n_row,4) = 4; 
                    if ts_seg(n_row,3)-ts_seg(n_row,2) > 10 % bad pixels
                        n_row = n_row - 1;
                    end
                elseif strcmp(change_process(id_find(j)), 'Harvest') == 1
                    ts_seg(n_row,4) = 5; 
                    if ts_seg(n_row,3)-ts_seg(n_row,2) > 10 % bad pixels
                        n_row = n_row - 1;
                    end
                elseif strcmp(change_process(id_find(j)), 'Hydrology') == 1
                    ts_seg(n_row,4) = 6; 
                    if ts_seg(n_row,3)-ts_seg(n_row,2) > 10 % bad pixels
                        n_row = n_row - 1;
                    end
                elseif strcmp(change_process(id_find(j)), 'Mechanical') == 1
                    ts_seg(n_row,4) = 7; 
                    if ts_seg(n_row,3)-ts_seg(n_row,2) > 10 % bad pixels
                        n_row = n_row - 1;
                    end				
                elseif strcmp(change_process(id_find(j)), 'Other') == 1
                    ts_seg(n_row,4) = 8; 
                    if ts_seg(n_row,3)-ts_seg(n_row,2) > 10 % bad pixels
                        n_row = n_row - 1;
                    end
                elseif strcmp(change_process(id_find(j)), 'Wind') == 1
                    ts_seg(n_row,4) = 9; 
                    if ts_seg(n_row,3)-ts_seg(n_row,2) > 10 % bad pixels
                        n_row = n_row - 1;
                    end
			    else
				    ts_seg(n_row,4) = 10; 				
                end
            else
                n_row = n_row + 1;
                ts_seg(n_row,1) = uniq_ids(i); % id
                ts_seg(n_row,2) = image_year(id_find(j-1)); % start year
                ts_seg(n_row,3) = image_year(id_find(j)); % end year
                
                if strcmp(change_process(id_find(j)),'Stable') == 1
                    ts_seg(n_row,4) = 1; % stable
                elseif strcmp(change_process(id_find(j)),'Growth/Recovery') == 1
                    ts_seg(n_row,4) = 2; % regrowth
                elseif strcmp(change_process(id_find(j)), 'Structural Decline') == 1
                    ts_seg(n_row,4) = 3; 
                    if ts_seg(n_row,3)-ts_seg(n_row,2) > 10 % bad pixels
                        n_row = n_row - 1;
                    end
                elseif strcmp(change_process(id_find(j)), 'Fire') == 1
                    ts_seg(n_row,4) = 4; 
                    if ts_seg(n_row,3)-ts_seg(n_row,2) > 10 % bad pixels
                        n_row = n_row - 1;
                    end
                elseif strcmp(change_process(id_find(j)), 'Harvest') == 1
                    ts_seg(n_row,4) = 5; 
                    if ts_seg(n_row,3)-ts_seg(n_row,2) > 10 % bad pixels
                        n_row = n_row - 1;
                    end
                elseif strcmp(change_process(id_find(j)), 'Hydrology') == 1
                    ts_seg(n_row,4) = 6; 
                    if ts_seg(n_row,3)-ts_seg(n_row,2) > 10 % bad pixels
                        n_row = n_row - 1;
                    end
                elseif strcmp(change_process(id_find(j)), 'Mechanical') == 1
                    ts_seg(n_row,4) = 7; 
                    if ts_seg(n_row,3)-ts_seg(n_row,2) > 10 % bad pixels
                        n_row = n_row - 1;
                    end				
                elseif strcmp(change_process(id_find(j)), 'Other') == 1
                    ts_seg(n_row,4) = 8; 
                    if ts_seg(n_row,3)-ts_seg(n_row,2) > 10 % bad pixels
                        n_row = n_row - 1;
                    end
                elseif strcmp(change_process(id_find(j)), 'Wind') == 1
                    ts_seg(n_row,4) = 9; 
                    if ts_seg(n_row,3)-ts_seg(n_row,2) > 10 % bad pixels
                        n_row = n_row - 1;
                    end
			    else
				    ts_seg(n_row,4) = 10; 
                end
            end
        end
    end
end
function rec_cg_all = loadCOLDResults(dir_record_cg)
    regs = dir(fullfile(dir_record_cg, 'record_change_*.mat'));
    fprintf('Total of %d .mat\n', length(regs));
    
    rec_cg_all = [];
    
    for i = 1: length(regs)
        load(fullfile(regs(i).folder, regs(i).name));
        rec_cg_all = [rec_cg_all, rec_cg]; % old version test

    end
end