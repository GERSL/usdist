% The dataset was used to develop the orginal COLD, which used all
% available Landsat data
%
% Reference:
% Zhu Z, Zhang J, Yang Z, Aljaddani AH, Cohen WB, Qiu S, Zhou C. Continuous monitoring of land disturbance based on Landsat time series. Remote Sensing of Environment. 2020 Mar 1;238:111116.
function step1_cold(icore, ncore, composite)
    %% Add Pacakge Paths
    restoredefaultpath;
    addpath(genpath(fileparts(fileparts(mfilename('fullpath')))));

    %% Setup default parallel assignment
    if ~exist('icore', 'var')
        icore = 50;
    end
    if ~exist('ncore', 'var')
        ncore = 100;
    end
    if ~exist('composite', 'var')
        composite = 0;
    end
    
    %% Setup the filepaths
    FILEPATH_LOCATION = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/CalibrationCOLD/NAFD/9000pids_LatLon.csv';
    FILEPATH_LANDSAT = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/CalibrationCOLD/NAFD/nafd_c1_spectrals_SR.csv';
    FILEPATH_NAFD1 = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/CalibrationCOLD/NAFD/nafd1_10102018.csv';
    FILEPATH_NAFD2 = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/CalibrationCOLD/NAFD/nafd2_10102018.csv';
    % where the outputing will sad
    DIR_REC = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/CalibrationCOLD/NAFD_COLD';
    if composite
        DIR_REC = [DIR_REC, '_COMPOSITE'];
    else
        DIR_REC = [DIR_REC, '_ALLDATA'];
    end
    plotid_nafa1 = unique(readtable(FILEPATH_NAFD1).plotid);
    plotid_nafa2 = unique(readtable(FILEPATH_NAFD2).plotid);
    plotid_nafa = [plotid_nafa1; plotid_nafa2];

    %% Testing COLD
    CONS = [3:1:8];
    CHANGE_PROB = [0.8, 0.85, 0.9, 0.95, 0.99, 0.999]; % , 0.9999];
    MODEL_UPDATE = [0];

    CONS = [6];
    CHANGE_PROB = [0.95]; % reducing to 0.95, and then we will classify further.
    MODEL_UPDATE = [0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08];
    
    %% Landsat data, which was based on Collection 1
    pix_location = readtable(FILEPATH_LOCATION);
    pix_location = pix_location(ismember(pix_location.plotid, plotid_nafa), : ); % overlap dataset with the NAFD locations
    pix_location = append_singlepath(pix_location);
    pix_location = pix_location(:, {'plotid', 'lat_data_location', 'lon_data_location', 'path'});
    pix_location = renamevars(pix_location,{'lat_data_location', 'lon_data_location'},{'lat', 'lon'});

    lst = readtable(FILEPATH_LANDSAT);
    % latitude/longitude appended
    lst  = innerjoin(lst,  pix_location, 'Keys', {'plotid'});
    % extract single-path data
    lst = lst(fix([lst.image_ppprrr]./1000) == lst.path, :);
    % QA band
    lst.fmask =  getFmask(lst.pixel_qa);



    %% Parallel processing
    for task_id = icore: ncore: length(plotid_nafa)
        plotid = plotid_nafa(task_id);
        

        pixel_lst = lst(lst.plotid == plotid, :);
        % convert to the julian date
        sdate = datenummx(pixel_lst.year, pixel_lst.month, pixel_lst.day); % yyyy mm dd
        line_t = [pixel_lst.b1, pixel_lst.b2, pixel_lst.b3, pixel_lst.b4, pixel_lst.b5, pixel_lst.b7, pixel_lst.b6, pixel_lst.fmask];
        
        if composite
            sticks_overtime = construct_composite_interval('2023-12-31', true);
            [sdate, line_t] = composite_adaptive(sdate, line_t, sticks_overtime);
        end
        for con = CONS
            for prob = CHANGE_PROB
                for uprate = MODEL_UPDATE
                    subfoldername = sprintf('%02d_%05d_%03d', con, prob*10000, uprate*100);
                    filepath_rcg = fullfile(DIR_REC, subfoldername, sprintf('record_change_%010d.mat', plotid)); % r: row
                    if isfile(filepath_rcg)
                        fprintf('Exist %s\n', filepath_rcg);
                        continue;
                    end
                    if ~isfolder(fullfile(DIR_REC, subfoldername))
                        mkdir(fullfile(DIR_REC, subfoldername));
                    end
                    nbands = 7+1; % regular bands + QA band
                    max_c = 8; % max number of coeffs
                    B_detect = 2:6;  % Bands for detection change
                    Tmax_cg = 1-1e-5; % Treshold of noisercg_new
                    thermalfilter = true; % use thermal band to filter
                    rec_cg = TrendSeasonalFit_COLDLine(sdate, line_t, [], [], ... % [] [] do not provide satelite path information
                        1, 1, 1, ... % process each pixel vis columns
                        prob, Tmax_cg, con, max_c, nbands, B_detect, false, thermalfilter, uprate); % false here that we do not start up the compositing function in the cold function
                    [rec_cg.pos] = deal(plotid);
    
                    %% save record of time series segments
                    save([filepath_rcg, '.part'] ,'rec_cg'); % save as .part
                    clear rec_cg;
                    movefile([filepath_rcg, '.part'], filepath_rcg);  % and then rename it as normal format
                    close all;
                end
            end
        end
    end
end


function sticks_overtime = construct_composite_interval(yyyymmdd, anomly)
    
    datenum_start  = datenum(datetime(1982, 1, 1)); % landsat data start from 1982 data data
    datenum_last   = datenum(datetime(yyyymmdd));
    
    % define the datetime of each of sensor, which will be used to define the single or double satellite(s) period
    % when the images started to be acuqired rather than the lunch time

    % On November 18, 2011, image acquisitions were suspended for a period of 90 days, due to fluctuations in the performance of a critical amplifier in the satellite's transmission system.
    % Search by USGS Earth Explorer, the last image was acquired on May 5, 2012, but since November 18, 2011, there were very limited images acquired.
    landsat5_last   = datenum(datetime(2011,11,18));
    landsat7_first  = datenum(datetime(1999,6,30));
    landsat7_last   = datenum(datetime(2019, 12, 31)); % due to the orbit drift
    landsat8_first  = datenum(datetime(2013,3,18));
    landsat9_first  = datenum(datetime(2021,10,31));
    
    datenum_single = [datenum_start: landsat7_first - 1, ... % before landsat 7
        landsat5_last + 1: landsat8_first-1, ... % between end of landsat 5 and start of landsat 8, only Landsat 7
        landsat7_last + 1: landsat9_first - 1 ... % between end of landsat 7 and start of landsat 9, only Landsat 8
        ];
    if anomly
        landsat5_anomly = [datenum(datetime(2002,3,1)): datenum(datetime(2002,4,27)),... % bumper mode
            datenum(datetime(2005,11,27)): datenum(datetime(2006,1,8)),... % issue on back-up solar array drive
            datenum(datetime(2007,10,6)): datenum(datetime(2008,2,15)),... % issue with onboard batteries
            datenum(datetime(2009,12,19)): datenum(datetime(2010,1,6))]; % ther techinical difficulties
        landsat7_anomly = [datenum(datetime(2003,6,1)): datenum(datetime(2003,7,14))]; % because of the SLC-off, Landsat 7 did not collect data for one month
        datenum_single = [datenum_single, ... % before landsat 7
            landsat5_anomly, ... % during landsat 5 issue, only Landsat 7
            landsat7_anomly % during landsat 7 issue, only Landsat 5
            ];
    end
    % create adaptive intervals over time
    interval1_length = 16; % 1: single satellite
    interval2_length = 32; % 2: bi-satellites
    intervals1_overtime = datenum_start:interval1_length: datenum_last + interval1_length;


    % datenum_single = unique(datenum_single);

    % overlap the datenum list of single landsat with the 16-day intervals
    sticks_overtime = datenum_start;
    skip_next = false;
    for i = 1:length(intervals1_overtime)-1
        if skip_next
            skip_next = false; % turn off
            continue;
        end
        datenum_interval = intervals1_overtime(i):intervals1_overtime(i+1)-1;
        if sum(ismember(datenum_interval, datenum_single)) == length(datenum_interval)
            % all the days fall in the single landsat period, we make the
            % composite by each 16 days
            sticks_overtime = [sticks_overtime, intervals1_overtime(i) + interval1_length];
        else % otherwise, some days experienced two landsats, we used 32 days to composite 
            sticks_overtime = [sticks_overtime, intervals1_overtime(i) + interval2_length];
            skip_next = true; % skip next one of 16 days
        end
    end
    % remaining days as the last interval
    if sticks_overtime(end) < datenum_last
        sticks_overtime = [sticks_overtime, datenum_last];
    
    end
    sticks_overtime = sticks_overtime';
end

function id_idx = select_max_idx(max_rnb, idx_clear)
    idx_clear = find(idx_clear); % convert to id list
    [~, id_idx] = max(max_rnb(idx_clear));
    id_idx = idx_clear(id_idx);
end

function [datenum_obs, data_sr] = composite_adaptive(datenum_obs, data_sr, sticks_overtime)
    % sticks_datetime_overtime = datetime(sticks_overtime, "ConvertFrom", "datenum")
    max_rnb = data_sr(:, 4)./data_sr(:, 3);
    selected = zeros(size(max_rnb), 'logical');
    for i_v = 1:length(sticks_overtime)-1
        interval = sticks_overtime(i_v):sticks_overtime(i_v+1)-1;
        ids_interval = ismember(datenum_obs,interval);
        if any(ids_interval)
            % step1: select the observation with max rnb from the clear observations
            ids_clear = ids_interval & data_sr(:, end) <= 1;
            if any(ids_clear)
                selected(select_max_idx(max_rnb, ids_clear)) = 1;
            else
                % step 2: select observations with max rnb from the snow/ice obervations
                ids_snow = ids_interval & data_sr(:, end) ==3;
                if any(ids_snow)
                    selected(select_max_idx(max_rnb, ids_snow)) = 1;
                else
                    % Step 3: any one of the cloud cloud shadow observations will be remained
                    selected(select_max_idx(max_rnb, ids_interval)) = 1;
                end
            end
        end
    end
    datenum_obs = datenum_obs(selected,:);
    data_sr = data_sr(selected,:);

    % one year, max 12 clear observations
    selected = zeros(size(datenum_obs), 'logical');
    rng(42); % static random seed
    % randomly select 12 observations if more than 12 observations
    dateyear_obs = year(datenum_obs);
    for yr = unique(dateyear_obs)'
        ids_year = dateyear_obs==yr;
        if any(ids_year)
            % clear max 12
            idx_year = find(ids_year & data_sr(:, end) <= 1);
            if numel(idx_year) > 12
                selected(idx_year(randperm(numel(idx_year), 12))) = 1;
            else
                selected(idx_year) = 1;
            end
            % snow/ice max 12 for perminet snow ice pixels
            idx_year = find(ids_year & data_sr(:, end) == 3);
            if numel(idx_year) > 12
                selected(idx_year(randperm(numel(idx_year), 12))) = 1;
            else
                selected(idx_year) = 1;
            end
        end
    end
    datenum_obs = datenum_obs(selected,:);
    data_sr = data_sr(selected,:);
end


function data_sr = append_singlepath(data_sr)
    data_location = unique(data_sr(:, {'plotid', 'lat', 'lon'}), 'rows');
    filepath_conus_singlepath = fileparts(fileparts(mfilename('fullpath')));
    filepath_conus_singlepath = fullfile(filepath_conus_singlepath, 'ToolData', 'singlepath_landsat_conus.tif');
    % covnert lat lon to pixel locations, and append the information to the table
    [singlepath_map,R] = readgeoraster(filepath_conus_singlepath);
    [xIntrinsic,yIntrinsic] = geographicToIntrinsic(R,data_location.lat, data_location.lon);
    data_location.path = singlepath_map(sub2ind(size(singlepath_map), round(yIntrinsic), round(xIntrinsic)));

    % latitude/longitude appended
    data_sr  = innerjoin(data_sr,  data_location, 'Keys', {'plotid'});
end
function fmask_m = getFmask(line_m)
    fmask_m = line_m;
    % convert QA to Fmask numbers for SR
    fmask_m(bitget(line_m,1)==1) = 255; % fill
    fmask_m(bitget(line_m,2)==1) = 0; % clear
    fmask_m(bitget(line_m,3)==1) = 1; % water
    fmask_m(bitget(line_m,4)==1) = 2; % shadow
    fmask_m(bitget(line_m,5)==1) = 3; % snow
    fmask_m(bitget(line_m,6)==1) = 4; % cloud
end
