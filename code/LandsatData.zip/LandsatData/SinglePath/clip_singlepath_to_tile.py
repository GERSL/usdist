import os
import glob
from pathlib import Path
import click
import rasterio
from rasterio import warp

@click.command()
@click.option("--ci", "-i", type=int, help="The core's id",
              default=1)
@click.option("--cn", "-n", type=int, help="The number of cores", 
              default=1)
@click.option("--dir", "-d", type=str, help="The directory of results",
              default='/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/LandsatARDC2')
def main(ci, cn, dir):
    print('#######################################################')
    print('Working on')
    print('Core ID: {}'.format(ci))
    print('Total number of cores: {}'.format(cn))
    print('Directory: {}'.format(dir))
    print('\n')
    
    # get the profile of the source geotiff
    filepath_src = os.path.join(Path(os.path.abspath(__file__)).parent, 'singlepath_landsat_conus.tif')
    with rasterio.open(filepath_src, 'r') as src_mask: # obtain the resource dataset
        des_profile = src_mask.meta.copy()
      
        # loop each tile  
        path_tile_list  = sorted(glob.glob(os.path.join(dir, 'h*')))
        tasks_range = range(ci - 1, len(path_tile_list), cn)
        for i in tasks_range:
            path_tile = path_tile_list[i]
            tilename = Path(path_tile).name
            image_list  = sorted(glob.glob(os.path.join(path_tile, 'L*')))
            image_list = [img for img in image_list if Path(img).is_dir() ]
            if len(image_list) == 0:
                print('* (No data) Skipping {}\n'.format(tilename))
                continue
            print('Processing {}'.format(tilename))
            path_image = image_list[0]
            imagename = Path(path_image).name
            
            # define like-geotiff and destination geotiff
            filepath_like = os.path.join(path_tile, imagename, imagename + '_QA_PIXEL.TIF')
            filepath_des = os.path.join(path_tile, tilename + '_singlepath.tif')
            if Path(filepath_des).is_file():
                print('* (Exist) Skipping {}\n'.format(tilename))
                continue
            if not Path(filepath_like).is_file():
                print('* (No QA_pixel) Skipping {}: {}\n'.format(tilename, filepath_like))
                continue
            # update the profile same as to the like- geotiff
            with rasterio.open(filepath_like, 'r') as src_like:
                des_profile.update({
                    'crs':          src_like.crs,
                    'transform':    src_like.transform,
                    'width':        src_like.width,
                    'height':       src_like.height
                    })
            # save as local file # warp as the destination geotif
            with rasterio.open(filepath_des, 'w', **des_profile) as dst_mask:
                for i in range(1, src_mask.count + 1):
                    warp.reproject(
                        source          =   rasterio.band(src_mask, i),
                        destination     =   rasterio.band(dst_mask, i),
                        src_transform   =   src_mask.transform,
                        src_crs         =   src_mask.crs,
                        dst_transform   =   des_profile['transform'],
                        dst_crs         =   des_profile['crs'],
                        resampling      =   warp.Resampling.nearest,
                        dst_nodata      =   src_mask.nodata
                        )

if __name__ == "__main__":
    main()

    print('##########################END#############################')
