function createSingleRowLayer(folderpath_cold, varargin)
%CREATESINGLEROWLAYER is to create single row layer
tic

%% Check exist
filepath_out =  fullfile(folderpath_cold, 'singlerow_landsat.tif');
% % if isfile(filepath_out)
% %     fprintf('exist %s\r', filepath_out);
% %     return;
% % end

% Landsat row's range: 1: 248
warning('off','all');
addpath(fullfile(fileparts(fileparts(mfilename('fullpath'))), 'GRIDobj'));


%% Upper and lower rows
[folderpath_work, tilename] = fileparts(folderpath_cold);
path_num = str2num(tilename(2:4));
row_num = str2num(tilename(6:end)); % range 1: 248

%% read observations count later in the current path row
filepath_obs_count = fullfile(folderpath_cold, 'ObservationCount', 'observation_count.tif');
obs_count_layer = GRIDobj(filepath_obs_count);
single_row_layr = obs_count_layer;
single_row_layr.Z = row_num + zeros(single_row_layr.size);
single_row_layr.Z = uint8(single_row_layr.Z); % Landsat row's range: 1: 248

%% loop upper and lower path rows
for row_up_low = [row_num - 1, row_num + 1]
    pathrow = sprintf('p%3dr%03d', path_num, row_up_low);
    
    filepath_obs_count = fullfile(folderpath_work, pathrow, 'ObservationCount', 'observation_count.tif'); % see exportObservationCount.m
    if isfile(filepath_obs_count)
        obs_count_up_low = GRIDobj(filepath_obs_count);
        obs_count_up_low = resample(obs_count_up_low, obs_count_layer,'nearest', true, 'fillval', 0);
        single_row_layr.Z(obs_count_up_low.Z > obs_count_layer.Z) = row_up_low; % update the record if more observations
    else
        fprintf('No file at %s\r', filepath_obs_count);
    end
end
GRIDobj2geotiff(single_row_layr, filepath_out);
fprintf('Finished creating %s in %0.2f mins\r', filepath_out, toc/60);
end

