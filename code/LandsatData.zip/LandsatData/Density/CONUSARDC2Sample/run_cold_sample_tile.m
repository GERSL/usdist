function run_cold_sample_tile(icore, ncores, varargin)
    % get the folder of the current script
    script_folder = fileparts(fileparts(fileparts(fileparts(mfilename('fullpath')))));
    addpath(fullfile(script_folder, 'COLD', 'CCD'));
    %% Setup default parallel assignment
    if ~exist('icore', 'var')
        icore = 1;
    end
    if ~exist('ncores', 'var')
        ncores = 1;
    end

    %% optional (also see COLD.m)
    p = inputParser;
    addParameter(p,'cprob', 0.95); % probability for detecting surface change
    addParameter(p,'conse', 6); % number of consecutive observation
    addParameter(p,'maxc', 8); % number of maximum coefficients
    addParameter(p,'composite', true); % apply compositing approach
    addParameter(p,'adjust', false); % adjust the reflectance values of Landsat 8 to match Landsat 7
    addParameter(p,'onceread', true); % read the landsat data line by line, if enough memory, please set as true (optional)
    addParameter(p,'task', 1); % 1st task
    addParameter(p,'ntasks', 1); % single task to compute
    addParameter(p,'delstack', true); % delete stack data or not
    addParameter(p,'thermalfilter', false); % not to display info
    addParameter(p,'updaterate', 0.04); % not to display info
    addParameter(p,'msg', false); % not to display info
    % request user's input
    parse(p,varargin{:});
    
    onceread = p.Results.onceread;
    task = p.Results.task;
    ntasks = p.Results.ntasks;
    msg = p.Results.msg;
    T_cg = p.Results.cprob;
    conse = p.Results.conse;
    max_c = p.Results.maxc;
    adpt_comp = p.Results.composite;
    adjust = p.Results.adjust;
    delstack =  p.Results.delstack;
    thermalfilter = p.Results.thermalfilter;
    updaterate = p.Results.updaterate;
    
    %% Constants:
    % Bands for detection change
    B_detect = 2:6;
    % Treshold of noisercg_new
    Tmax_cg = 1-1e-5;

    folder_sample = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/LandsatDensity/SampleCONUSARDC2/OneTile5000Pixels';
    folder_cold = [folder_sample, 'COLDSinglePath'];
    if adpt_comp
        folder_cold = [folder_cold, 'Composite'];
    end
    if adjust
        folder_cold = [folder_cold, 'AdjustL89ToL7'];
    end
    if ~isfolder(folder_cold)
        mkdir(folder_cold);
    end
    
    tiles = dir(fullfile(folder_sample, 'h*'));
    
    % to get the unique tiles according to the name of the files like, 'h001v004_1982.csv'
    for i = 1: length(tiles)
        tile = tiles(i).name;
        tiles(i).tilename = tile(1: 8);
    end
    tile_names = unique({tiles.tilename});
    
    for i = icore: ncores: length(tile_names)
        tile_name = tile_names{i};

        if isfile(fullfile(folder_cold, [tile_name, '.csv']))
            fprintf('existing %s\n', tile_name);
            continue;
        else
            fprintf('processing %s\n', tile_name);
        end

        % to get the list of the files with the same tile name from tiles
        tile_files = tiles(find(contains({tiles.tilename}, tile_name)));
        % read the data from the files one by one
        tile_lst = table();
        for j = 1: length(tile_files)
            % load .csv dataset
            tile_lst_tmp = readtable(fullfile(folder_sample, tile_files(j).name));
            if isempty(tile_lst_tmp)
                continue;
            end
            % merge the data
            tile_lst = [tile_lst; tile_lst_tmp];
        end

        % tile = tiles(i).name;
        % load .csv dataset
        % tile_lst = readtable(fullfile(folder_sample, tile));

        % unique points
        [uni_samples, ~, idx] = unique(tile_lst(:, {'tile', 'row', 'col'}));
        
        % for each pixel  
        sample_dataset = table();
        for j = 1: height(uni_samples)
            sample = uni_samples(j,:);
            % all the data over pixel
            sample_lst = tile_lst(ismember(tile_lst.tile, sample.tile) & ismember(tile_lst.row, sample.row) & ismember(tile_lst.col, sample.col),:);
            % single path
            sample_lst = sample_lst(sample_lst.singlepath == sample_lst.imagepath,:);
            % exclude observations from same day, e.g., same path, but different row
            sample_lst  = sortrows(sample_lst, {'tile', 'row', 'col', 'year', 'doy', 'cfmask'}, 'ascend'); % cfmask: 0, 1, 2, 3, 4. (for mutiple observaions, clearer one will be remained)
            [~, idx]    = unique(sample_lst(:, {'tile', 'row', 'col', 'year', 'doy'}));
            sample_lst  = sample_lst(idx,:);

            if adjust
                % adjust sensor difference from Landsat 8/9 to Landsat 7
                % select landsat 8/9 data
                idlist_l89 = ismember(sample_lst.sensor, {'LC08', 'LC09'});
                sample_lst_89 = sample_lst(idlist_l89, :);
                sample_lst_89  = adjustL8ToL7(sample_lst_89, {'b1', 'b2', 'b3', 'b4', 'b5', 'b7'});
                % update the sample_lst with the adjusted sample_lst_89
                sample_lst(idlist_l89, :) = sample_lst_89;
                clear sample_lst_89 idlist_l89;
            end

            % input to the function of cold
            sdate = datenum(sample_lst.year, 1, sample_lst.doy);
            line_t = [sample_lst.b1, sample_lst.b2, sample_lst.b3, sample_lst.b4, sample_lst.b5, sample_lst.b7, sample_lst.b6, sample_lst.cfmask];
            line_t = round(line_t);
            if isempty(line_t)
                continue;
            end
            [rec_cg, ~, ~, id_composite] = TrendSeasonalFit_COLDLine(sdate, line_t, [], [], ...  % the single path has been filter out during stacking
                1, 1, 1, ... % process each pixel vis columns
                T_cg, Tmax_cg, conse, max_c, 8, B_detect, adpt_comp, thermalfilter, updaterate);
            
            % select the compositing data by the index list
            if ~isempty(id_composite)
                sample_lst = sample_lst(id_composite, :);
            end
            sample_lst.break = zeros(size(sample_lst, 1), 1);
            sample_lst.magnitude = zeros(size(sample_lst, 1), 1);
            
            % get disturbance mag.
            for irr = 1: length(rec_cg)
                rec_mag = rec_cg(irr).magnitude;
                rec_cg(irr).magnitude_rssq=rssq(rec_mag(2:end-1));
            end

            % append the date when the change happened
            rec_prob   = [rec_cg.change_prob];
            rec_mag    = [rec_cg.magnitude_rssq]; % single value
            rec_tbreak = [rec_cg.t_break];
            rec_tbreak = rec_tbreak(rec_prob == 1);
            rec_mag = rec_mag(rec_prob == 1);
            sample_lst_datenum = datenum(sample_lst.year, 1, sample_lst.doy);
            if ~isempty(rec_tbreak)
                for k = 1: length(rec_tbreak)
                    sample_lst(sample_lst_datenum==rec_tbreak(k), :).break = 1;
                    sample_lst(sample_lst_datenum==rec_tbreak(k), :).magnitude = rec_mag(k);
                end
            end

            sample_dataset = [sample_dataset; sample_lst];
        end
    
        % save data
        if ~isempty(sample_dataset)
            writetable(sample_dataset, fullfile(folder_cold, [tile_name, '.csv']));
        end
    end