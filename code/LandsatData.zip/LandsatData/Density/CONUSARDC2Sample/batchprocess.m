run_cold_sample_tile(1, 1, 'composite', false);
run_cold_sample_tile(1, 1, 'composite', true);