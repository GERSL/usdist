#!/bin/bash
#SBATCH -J collect
#SBATCH --partition=priority			# specify partition
#SBATCH --account=zhz18039			# specify the priority account 
#SBATCH --constraint='epyc128' 
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --array 1-30
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err
#SBATCH --mem-per-cpu=20G


echo $SLURMD_NODENAME # display the node name
echo $SLURM_ARRAY_TASK_ID
echo $SLURM_ARRAY_TASK_MAX

cd ../

module load matlab/R2023b

matlab -nojvm -nodisplay -nosplash -singleCompThread -r collect_sample_from_ard\($SLURM_ARRAY_TASK_ID,$SLURM_ARRAY_TASK_MAX\)


exit


#SBATCH --partition=priority			# specify partition
#SBATCH --account=zhz18039			# specify the priority account 


#SBATCH --partition=general