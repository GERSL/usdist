#!/bin/bash
#SBATCH -J cold
#SBATCH --partition=general
#SBATCH --constraint='epyc128' 
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --array 1-200
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err
#SBATCH --mem-per-cpu=20G


echo $SLURMD_NODENAME # display the node name
echo $SLURM_ARRAY_TASK_ID
echo $SLURM_ARRAY_TASK_MAX

cd ../

module load matlab/R2023b

matlab -nojvm -nodisplay -nosplash -singleCompThread -r "run_cold_sample_tile($SLURM_ARRAY_TASK_ID, $SLURM_ARRAY_TASK_MAX, 'adjust', 1)"
matlab -nojvm -nodisplay -nosplash -singleCompThread -r run_cold_sample_tile\($SLURM_ARRAY_TASK_ID,$SLURM_ARRAY_TASK_MAX\)


exit


#SBATCH --partition=priority			# specify partition
#SBATCH --account=zhz18039			# specify the priority account 
#SBATCH --constraint='epyc128' 


#SBATCH --partition=general
#SBATCH --constraint='epyc128' 


#SBATCH --partition=general-gpu


#SBATCH --partition=priority-gpu
#SBATCH --account=sas18043
#SBATCH --qos=sas18043a100
