import os
import glob
import pandas
import click

def count_yearly_obs(dir_1path, tile, yr, method = 'All Landsat', CLEARONLY = True):
    
    file_lndst_list = sorted(glob.glob(os.path.join(dir_1path, f'{tile}*{yr}.csv'))) # only h*.csv
    if len(file_lndst_list) == 0:
        return []
    dt_lndst_year = []
    for file_lndst in file_lndst_list:
        dt_lndst_year.append(pandas.read_csv(file_lndst))
    dt_lndst_year = pandas.concat(dt_lndst_year)
    # select the rows with the same imagepath and singlepath
    dt_lndst_year = dt_lndst_year[dt_lndst_year['imagepath'] == dt_lndst_year['singlepath']]
    # select the clear observations
    if CLEARONLY: dt_lndst_year = dt_lndst_year[dt_lndst_year['cfmask'] <=1]

    # count the total number of rows per method / per year / per method / per pixel
    dt_lndst_year_count = dt_lndst_year.groupby(['tile', 'row', 'col']).size().reset_index(name='count')
    # add year
    dt_lndst_year_count['year'] = yr
    # add method
    dt_lndst_year_count['method'] = method
    return dt_lndst_year_count
    

@click.command()
@click.option("--ci", "-i", type=int, help="The core's id", default=1)
@click.option("--cn", "-n", type=int, help="The number of cores", default=1)
def main(ci, cn) -> None:
    # variable to control the clear observation only or not
    CLEARONLY = True

    ## load all the datasets that we have
    dir_1path                = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/LandsatDensity/SampleCONUSARDC2/OneTile5000Pixels'
    dir_1path_composite      = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/LandsatDensity/SampleCONUSARDC2/OneTile5000PixelsCOLDSinglePathComposite'
    dir_1path_count          = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/LandsatDensity/SampleCONUSARDC2/OneTile5000PixelsYearlyCount'
    # create folder if not os.path.exists(dir_1path_count):
    if not os.path.exists(dir_1path_count):
        os.makedirs(dir_1path_count)
        
    # LOAD ALL THE COMPOSITE DATA, WHICH DOES NOT INFORMATIVE IN YEAR ACCORDING TO THE FILENAME
    file_lndst_list = sorted(glob.glob(os.path.join(dir_1path_composite, f'h*.csv'))) # only h*.csv
    
    for i in range(ci- 1, len(file_lndst_list), cn):
        file_lndst = file_lndst_list[i]
        print(f'Processing file {file_lndst}')
        tile = os.path.basename(file_lndst).split('.')[0] # get the tile name
        savepath = os.path.join(dir_1path_count, f'{tile}_obscount.csv')
        if os.path.exists(savepath):
            print(f'The file {savepath} exists.')
            continue
        dt_lndst_tile = pandas.read_csv(file_lndst)
        # select the rows with the same imagepath and singlepath
        dt_lndst_tile = dt_lndst_tile[dt_lndst_tile['imagepath'] == dt_lndst_tile['singlepath']]
        # select the clear observations
        if CLEARONLY: dt_lndst_tile = dt_lndst_tile[dt_lndst_tile['cfmask'] <=1]

        # count the total number of rows per method / per year / per method / per pixel
        dt_lndst_tile_count = dt_lndst_tile.groupby(['tile', 'row', 'col', 'year']).size().reset_index(name='count')
        # add method
        dt_lndst_tile_count['method'] = 'Compositing Landsat'

        
        years = range(1982, 2023+1)
        # load the data year by year
        dt_lndst_all = []
        # seperate years to individual cores
        for yr in years:
            # print(f'Processing year {yr}')
            dt_lndst_year_count_all = count_yearly_obs(dir_1path, tile, yr, method = 'All Landsat', CLEARONLY= CLEARONLY)
            if len(dt_lndst_year_count_all) == 0:
                print(f'No data found for {tile} in {yr}')
                continue
            dt_lndst_all.append(dt_lndst_year_count_all)
        dt_lndst_all = pandas.concat(dt_lndst_all)
        dt_lndst_1path_count = pandas.concat([dt_lndst_all, dt_lndst_tile_count])
        
        dt_lndst_1path_count.to_csv(savepath, index=False)
   
if __name__ == "__main__":
    main()