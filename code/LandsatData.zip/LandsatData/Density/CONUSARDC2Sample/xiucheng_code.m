
function P1_densityWithDifferentComposites(task,ntasks)
    %% Add all matlab paths
    pathCode = fullfile(fileparts(fileparts(fileparts(mfilename('fullpath')))));
    addpath(pathCode);
    addpath(fullfile(pathCode, 'Packages/GRIDobj'));  
           
    if ~exist('task', 'var')
        task = 1;
    end
    if ~exist('ntasks', 'var')
        ntasks = 1;
    end

    path_working = fileparts(fileparts(globalsets.PathDECODE));
   
    %% Create folder to save the csv
    folderTS = 'sampleTSObs';
   
    %% Locate to the working folder, in which all outputing data can be found
    pathSample = targetSampleSetting.pathSample;
    sampleStr = targetSampleSetting.sampleStr;
   
    samples = readtable(fullfile(pathSample,sprintf('%s.csv',sampleStr)));
    samples = sortrows(samples,'PlotID','ascend');

    [~,ia] = unique(samples(:,{'longitude','latitude'}),'rows','stable');
    samples = samples(ia,:);
    numSamples = height(samples);

    years = 1985:2020;

    pathTS = fullfile(path_working,folderTS,sampleStr,'Data');
     
    %% Check the sample CSV files
%     sampleNames = dir(fullfile(pathTS,'*Observations.csv'));
%     sampleNames = {sampleNames.name}';
%     numSamples = length(sampleNames);
   
    %% HPC Process
    fprintf('In total, %d CSV wait for process\n',numSamples);
   
    tic
    %% Define the matrix to save the results
    densitiesAll = zeros(numSamples,length(years));
    densities32 = zeros(numSamples,length(years));
    densities16 = zeros(numSamples,length(years));
    densitiesAdapt = zeros(numSamples,length(years));

    sampleInfos = zeros(numSamples,3);

    for i_s = 1:numSamples
        fprintf('Count %d/%d with %d min\n',i_s,numSamples,round(toc/60));
        sampleName = sprintf('%05d_h%03dv%03d_Observations.csv',samples.PlotID(i_s),samples.h(i_s),samples.v(i_s));  

        sampleValues = readtable(fullfile(pathTS,sampleName));

        % Plot Info
        plotID = unique(sampleValues.PlotID);
        lat = unique([sampleValues.latitude]);
        lon = unique([sampleValues.longitude]);
        sampleInfos(i_s,:) = [plotID,lat,lon];

        % Clear observation and single path
        clearSamples = sampleValues(sampleValues.QA<=1&sampleValues.Orbit==1,:);            
        obsYearsAll = year(clearSamples.Datenum);        
       
        % Composite calculation        
        sdate_all = clearSamples.Datenum;    
        if isempty(sdate_all)
            continue
        end
        %% Composite of 16 days
        compositeInterval = 16;
        intervals = sdate_all(1):compositeInterval:sdate_all(end)+compositeInterval;
        compositeDates = [];        
        for i_v = 1:length(intervals)-1
            interval = intervals(i_v):intervals(i_v+1)-1;
            idx = ismember(sdate_all,interval);
            compositeDate = sdate_all(idx);
            if ~isempty(compositeDate)
                compositeDates = [compositeDates;compositeDate(1)];
            end
        end
        obsYears16 = year(compositeDates);
   
        %% Composite of 32 days
        compositeInterval = 32;
        intervals = sdate_all(1):compositeInterval:sdate_all(end)+compositeInterval;
        compositeDates = [];        
        for i_v = 1:length(intervals)-1
            interval = intervals(i_v):intervals(i_v+1)-1;
            idx = ismember(sdate_all,interval);
            compositeDate = sdate_all(idx);
            if ~isempty(compositeDate)
                compositeDates = [compositeDates;compositeDate(1)];
            end
        end
        obsYears32 = year(compositeDates);

        %% Composite of adaptive days
        compositeIntervalSparse = 16;
        compositeIntervalDense = 32;      
       
        biSatelliteDate = datenum(1999,4,1);
        landsat5End = datenum(2011,12,1);
        landsat8Start = datenum(2013,3,18);

        intervals = [sdate_all(1):compositeIntervalSparse:biSatelliteDate,...
            biSatelliteDate:compositeIntervalDense:landsat5End,...
            landsat5End:compositeIntervalSparse:landsat8Start,...
            landsat8Start:compositeIntervalDense:sdate_all(end)+compositeIntervalDense];
        compositeDates = [];    

        for i_v = 1:length(intervals)-1
            interval = intervals(i_v):intervals(i_v+1)-1;
            idx = ismember(sdate_all,interval);
            compositeDate = sdate_all(idx);
            if ~isempty(compositeDate)
                compositeDates = [compositeDates;compositeDate(1)];
            end
        end
        obsYearsAdapt = year(compositeDates);
       
        for i_y = 1:length(years)        
            densitiesAll(i_s,i_y) = sum(obsYearsAll==years(i_y));
            densities32(i_s,i_y) = sum(obsYears32==years(i_y));
            densities16(i_s,i_y) = sum(obsYears16==years(i_y));
            densitiesAdapt(i_s,i_y) = min(sum(obsYearsAdapt==years(i_y)),12);
        end
    end

    sampleInfos = array2table(sampleInfos,'VariableNames',{'PlotID','lat','lon'});
    densitiesAll = [sampleInfos,array2table(densitiesAll,'VariableNames',string(years))];
    densities32 = [sampleInfos,array2table(densities32,'VariableNames',string(years))];
    densities16 = [sampleInfos,array2table(densities16,'VariableNames',string(years))];
    densitiesAdapt = [sampleInfos,array2table(densitiesAdapt,'VariableNames',string(years))];
       
    writetable(densitiesAll,'densitiesAll.csv');
    writetable(densities32,'densities32.csv');
    writetable(densities16,'densities16.csv');
    writetable(densitiesAdapt,'densitiesAdapt.csv');
end







%% Source code path:/home/xiy19029/DECODE_v2/Calibration/TemporalDensity/plotDensity.m
%% Add all matlab paths
clc
clear

% restoredefaultpath;
pathcode = fileparts(fileparts(mfilename('fullpath')));
addpath(pathcode);
pathSourceCode = fullfile('/home/xiy19029/DECODE_v2/Calibration/TemporalDensity/');
addpath(pathSourceCode);

%% Paths
PathGreeningData = '/shared/zhulab/Yang/GlobalGreening/';

path_working = PathGreeningData;
pathSample = fullfile(path_working,'LandsatData', 'SurfaceReflectance_SP/');

folderpath_density  = fullfile(path_working,'LandsatData', 'USDensity');

years = 1982:2023;
targetYears = 1986:2020;
nboot = 100;
%% Plot the density of each year
fontSize = 14;
subFigures = {'a','b','c','d'};
% densityNames = {'density','clearDensity'};
% densityName = 'density';
% densityName = 'clearDensity';
densityNames = {'density'};
offsetHorizon = -0.04;
offsetVertical = 0.98;
for i_d = 1:length(densityNames)
    figDensity = figure('Position',[1 1 2000 2000],'Visible','on');
    t = tiledlayout(2,1,"TileSpacing","loose",'Padding','tight');


    densityName = densityNames{i_d};
 
    % %% Check the sample CSV files
    % TSFiles = dir(fullfile(folderpath_density,'clear*.csv'));
    % TSFiles = {TSFiles.name}';
    % numSampleFiles = length(TSFiles);
    %
    % tic
    % fprintf('In total, %d CSV wait for process\n',numSampleFiles)
    % %% Locate to a certain task, one task for one row folder
    % if isfile("clearDensities.csv")
    %     clearDensities = readtable("clearDensities.csv",'ReadVariableNames',true,'VariableNamingRule','preserve');
    % else
    %     clearDensities = [];
    %     tic
    %     for i_t = 1:numSampleFiles
    %         fprintf('Count %d/%d with %d min\n',i_t,numSampleFiles,round(toc/60));
    %         fileName = TSFiles{i_t};
    %         density = readtable(fullfile(folderpath_density,fileName),'ReadVariableNames',true,'VariableNamingRule','preserve');
    %         clearDensities = [clearDensities;density];
    %     end
    %     writetable(clearDensities,fullfile(pwd,'clearDensities.csv'));
    % end
   
    %% Check the sample CSV files
    TSFiles = dir(fullfile(folderpath_density,sprintf('%s*.csv',densityName)));
    TSFiles = {TSFiles.name}';
    numSampleFiles = length(TSFiles);
   
    tic
    fprintf('In total, %d CSV wait for process\n',numSampleFiles)
    %% Locate to a certain task, one task for one row folder
    if isfile(fullfile(pathSourceCode,sprintf('%s.csv',densityName)))
        densities = readtable(fullfile(pathSourceCode,sprintf('%s.csv',densityName)),'ReadVariableNames',true,'VariableNamingRule','preserve');
    else
        densities = [];
        tic
        for i_t = 1:numSampleFiles
            fprintf('Count %d/%d with %d min\n',i_t,numSampleFiles,round(toc/60));
            fileName = TSFiles{i_t};
            density = readtable(fullfile(folderpath_density,fileName),'ReadVariableNames',true,'VariableNamingRule','preserve');
            densities = [densities;density];
        end
        writetable(densities,fullfile(pwd,sprintf('%s.csv',densityName)));
    end
   
   
    %% densities in and out US
    USDensities = densities(densities.US==1,:);
    OutDensities = densities(densities.US~=1,:);
    if isfile(fullfile(pathSourceCode,sprintf('yearly_%s.csv',densityName)))
        yearlyDensities = readtable(fullfile(pathSourceCode,sprintf('yearly_%s.csv',densityName)),'ReadVariableNames',true,'VariableNamingRule','preserve');
    else
        yearlyDensities = [];
        for i_y = 1:length(targetYears)
            targetYr = targetYears(i_y);
            yearlyDensity = densities{:,{'US',num2str(targetYr)}};
            yearlyDensity = [yearlyDensity,ones(length(yearlyDensity),1)*targetYr];
            yearlyDensities = [yearlyDensities;yearlyDensity];
        end
        yearlyDensities = array2table(yearlyDensities,'VariableNames',{'US','Density','Year'});
        yearlyDensities.Year = categorical(yearlyDensities.Year,targetYears);
        writetable(yearlyDensities,fullfile(pathSourceCode,sprintf('yearly_%s.csv',densityName)));
    end
    %% Bootstrapping
    if isfile(fullfile(pathSourceCode,sprintf('OutOfUSBootMean_%s.csv',densityName)))
        USBootMean = readtable(fullfile(pathSourceCode,sprintf('USBootMean_%s.csv',densityName)),'ReadVariableNames',true,'VariableNamingRule','preserve');
        OutBootMean = readtable(fullfile(pathSourceCode,sprintf('OutOfUSBootMean_%s.csv',densityName)),'ReadVariableNames',true,'VariableNamingRule','preserve');
    else
        rng(1);
       
        USBootMean = zeros(length(targetYears),2);
        OutBootMean = zeros(length(targetYears),2);        
       
        for i_y = 1:length(targetYears)
            targetYr = targetYears(i_y);
            yearlyUS = USDensities.(num2str(targetYr));
            yearlyOutOfUS = OutDensities.(num2str(targetYr));
            statsUS = bootstrp(nboot,@(x)[mean(x) std(x)],yearlyUS);
            statsOut = bootstrp(nboot,@(x)[mean(x) std(x)],yearlyOutOfUS);
            rate = statsUS(:,1)./statsOut(:,1);
           
            USBootMean(i_y,:) = mean(statsUS,1);
            OutBootMean(i_y,:) = mean(statsOut,1);
        end

        USBootMean = array2table([targetYears',USBootMean],'VariableNames',{'Year','Mean','Std'});
        OutBootMean = array2table([targetYears',OutBootMean],'VariableNames',{'Year','Mean','Std'});
       
        writetable(USBootMean,fullfile(pathSourceCode,sprintf('USBootMean_%s.csv',densityName)));
        writetable(OutBootMean,fullfile(pathSourceCode,sprintf('OutOfUSBootMean_%s.csv',densityName)));
    end
   
   
    %% Plot the box chart
    nexttile;
    boxchart(yearlyDensities.Year,yearlyDensities.Density,'GroupByColor',yearlyDensities.US,...
            'MarkerStyle','none');
   
    legend({'Outside conterminous U.S.','Conterminous U.S.'});
    % xticks(targetYears);
    % xticklabels(num2cell(targetYears));
    % xlim([targetYears(1) targetYears(end)]);
    xlim([1985 2020]);
    if strcmp(densityName,'density')
        ylabel('Annual observations');
        ylim([0 50]);
    else
        ylabel('Annual clear observations');
    end
   
    set(gca,'FontSize',fontSize,'FontWeight','normal','FontName','Arial');

    lgd = legend('Location','Northwest','FontSize',fontSize,'FontWeight','normal','FontName','Arial','box','off');
    lgd.ItemTokenSize = [50,15];
   
    ttl = title('a','FontName','Arial','FontSize',fontSize+4,'FontWeight','bold');
    ttl.Units = 'Normalize';
    ttl.Position(1) = offsetHorizon; % use negative values (ie, -0.1) to move further left
    ttl.Position(2) = offsetVertical; % use negative values (ie, -0.1) to move further left
    ttl.HorizontalAlignment = 'left';  

    %% Bootstrap to calculate the mean of the yearly density of US and out of US
 
    nexttile;
    hold on;
    errorbar(targetYears'-0.1,OutBootMean.Mean,OutBootMean.Std,'LineStyle','--','Color','#0072BD','Marker','.','LineWidth',2,'DisplayName','Outside conterminous U.S.');
    errorbar(targetYears'+0.1,USBootMean.Mean,USBootMean.Std,'LineStyle','-','Color','#D95319','Marker','.','LineWidth',2,'DisplayName','Conterminous U.S.');
    if strcmp(densityName,'density')
        ylabel('Annual observations');
        ylim([0 50]);
    else
        ylabel('Annual clear observations');
    end
%     xticks(targetYears);
%     xticklabels(num2cell(targetYears));
%     xlim([targetYears(1) targetYears(end)]);
    xlim([1985 2020]);
    lgd = legend('Location','Northwest','FontSize',fontSize,'FontWeight','normal','FontName','Arial', ...
        'box','off');
    lgd.ItemTokenSize = [50,15];  

    set(gca,'FontSize',fontSize,'FontWeight','normal','FontName','Arial');

    ttl = title('b','FontName','Arial','FontSize',fontSize+4,'FontWeight','bold');
    ttl.Units = 'Normalize';
    ttl.Position(1) = offsetHorizon; % use negative values (ie, -0.1) to move further left
    ttl.Position(2) = offsetVertical; % use negative values (ie, -0.1) to move further left
    ttl.HorizontalAlignment = 'left';  

    title(t,sprintf('Random sampling outside (%d Pixels) and in (%d Pixels) the conterminous U.S.',height(OutDensities),height(USDensities)),...
        'FontSize',fontSize+4,'FontWeight','normal','FontName','Arial');
     
    %% Export the figure
    exportgraphics(figDensity,sprintf('Figures/FigureS1_%s_OutInUS.jpg',densityName),'Resolution',300);
    saveas(figDensity,sprintf('Figures/FigureS1_%s_OutInUS.svg',densityName));

    %% Rate between out of and in the U.S. Before 2012 and after 2012
    periods = [1986,1999;2000,2011;2012,2020];
    rates = [];
    for i_p = 1:3
        period = periods(i_p,:);
        idxYr = ismember(targetYears,period(1):period(2));
        mean_Out = mean(OutBootMean.Mean(idxYr));
        std_Out = mean(OutBootMean.Std(idxYr));
        mean_US = mean(USBootMean.Mean(idxYr));
        std_US = mean(USBootMean.Std(idxYr));
        rates(i_p,:) = [mean_US,std_US,mean_Out,std_Out,[mean_US,(mean_US+std_US),(mean_US-std_US)]./[mean_Out,(mean_Out+std_Out),(mean_Out-std_Out)]];
    end

    rates= array2table(rates,'VariableNames',{'US Mean','US Std','Outside US Mean','Outside US Std','Rate','Lower','Upper'});
    periodsLabel = array2table(["1986-1999";"2000-2011";"2012-2000"],'VariableNames',{'Periods'});
    rates = [periodsLabel,rates];
    writetable(rates,'ratesOfUsAndOutsideUS.csv');
    heatmap(rates{:,end-2:end});
end

