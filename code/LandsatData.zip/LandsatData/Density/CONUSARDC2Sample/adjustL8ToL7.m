function L8_data = adjustL8ToL7(L8_data, bands)
    % ADJUSTL8TOL7 Adjusts Landsat 8 reflectance values to match Landsat 7.
    %
    % INPUTS:
    %   L8_data - A struct where each field corresponds to a band with reflectance data.
    %   bands   - A cell array of strings indicating the bands to be adjusted (e.g., {'b1', 'b2', ...}).
    %
    % OUTPUT:
    %   L8_data - Adjusted Landsat 8 data as a struct with the same fields as the input.
    %
    % Example:
    %   L8_data = adjustL8ToL7(L8_data, {'b1', 'b2', 'b3', 'b4', 'b5', 'b7'});

    % Define the adjustment coefficients for each band
    coefficients = struct(...
        'b1', [0.8960, 0.0122], ...
        'b2', [0.9357, 0.0086], ...
        'b3', [0.9778, 0.0082], ...
        'b4', [0.8820, 0.0218], ...
        'b5', [0.9668, 0.0114], ...
        'b7', [0.9915, 0.0025]);

    % Loop through each band to adjust reflectance values
    for i = 1:length(bands)
        band = bands{i};

        % Check if the band exists in the coefficients structure
        if isfield(coefficients, band)
            % Extract slope and intercept
            slope = coefficients.(band)(1);
            intercept = coefficients.(band)(2);

            % Adjust the reflectance values for the current band
            L8_data.(band) = slope * L8_data.(band) + intercept;
        else
            error('Band "%s" is not defined in the coefficients.', band);
        end
    end
end

