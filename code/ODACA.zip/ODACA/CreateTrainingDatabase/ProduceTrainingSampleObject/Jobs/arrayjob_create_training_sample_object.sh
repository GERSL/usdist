#!/bin/bash
#SBATCH -J samp_obj
#SBATCH --partition=priority			# specify partition
#SBATCH --account=zhz18039			# specify the priority account 
#SBATCH --constraint='epyc128'
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --array 1-200
#SBATCH --mem-per-cpu=70G
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err


# Go back to <COLD_v2>
cd ../

module load matlab


matlab -nodisplay -singleCompThread -r "batchProduceTrainingSampleObject($SLURM_ARRAY_TASK_ID, $SLURM_ARRAY_TASK_MAX); exit"

exit


#SBATCH --partition=priority			# specify partition
#SBATCH --account=zhz18039			# specify the priority account 
#SBATCH --constraint='epyc128' 

#SBATCH --partition=general


#SBATCH --partition=general-gpu
#SBATCH --constraint=a100
#SBATCH --gres=gpu:1
#SBATCH --ntasks=2
#SBATCH --nodes=1
#SBATCH --array 1-40
#SBATCH --mem-per-cpu=40G
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err