function  reference_lf = loadReferenceLF(tile, year)
%loadReferenceLF is to read the reference layers of LANDFIRE dataset.
%
% Input:
% tile     [Char] Tile name of Landsat ARD
% year       [Number] Year of the target
%
% see codes of Landfire event from produceReferenceLayerLF.m/<ProduceReferenceLayer>

 %% Locate the LandFire reference data
folderpath_lf = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderReferenceLayerLF);
filepath_lf_event = fullfile(folderpath_lf, sprintf('%s_event_type_landfire_%d.tif', tile, year));
filepath_lf_severity = fullfile(folderpath_lf, sprintf('%s_severity_landfire_%d.tif', tile, year));

if isfile(filepath_lf_event) && isfile(filepath_lf_severity)
    reference_lf = readgeoraster(filepath_lf_event);  % pixel value: code
    confidencelayer = readgeoraster(filepath_lf_severity);  % pixel value: servity
    
    % only Moderate and High confidence remained
    reference_lf(confidencelayer<2 | confidencelayer>3) = 0; % exclude the confidence, not 2 (Moderate) and 3 (High)
    clear confidencelayer; 
    reference_lf = uint8(reference_lf);
   
    if sum(reference_lf(:)) == 0
        reference_lf = [];
    end
else % file does not exist
    reference_lf = [];
end

end % end of function