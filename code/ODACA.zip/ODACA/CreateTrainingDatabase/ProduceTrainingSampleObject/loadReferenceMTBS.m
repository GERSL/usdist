function [fire, fire_mbts] = loadReferenceMTBS(hv_name, yr, disturbance_map)
% load MTBS mosaic reference later, in which pixel value indicates month of fire occurance
% see code at see https://www.mtbs.gov/product-descriptions
    if ~exist('disturbance_map', 'var')
        disturbance_map = []; % do not select the fire polygon
    end
    filepath_mtbs = fullfile(odacasets.pathResultODACA, hv_name, odacasets.folderTrainingData, odacasets.folderReferenceLayerMTBS, sprintf('%s_month_mtbs_%d.tif', hv_name, yr));
    fire = [];
    fire_mbts = [];
    if isfile(filepath_mtbs)
        fire = readgeoraster(filepath_mtbs); % Thematic Burn Severity, see https://www.mtbs.gov/product-descriptions
        fire(fire==255) = 0; % filled pixel
        fire_mbts= fire > 0;
        % How many pixels of the fire objects were identified?
        if sum(fire_mbts(:)) > 0 && ~isempty(disturbance_map)
            fire_objects = labelmatrix(bwconncomp(fire_mbts> 0)); % fire objects
            fire_objects_id = unique(fire_objects(fire_objects>0));
            for iobj = 1: length(fire_objects_id)
                fire_object_layer = fire_objects == fire_objects_id(iobj); % 2-d array to indicate fire object
                % check how large fire event
                if sum(sum(disturbance_map & fire_object_layer)) < odacasets.traindata_minarea_detected_fire %  Less than
                    fire(fire_object_layer) = 0; % convert to 0, that will not be used as the training samples, since the MTBS fires are difficult to be detected
                end
            end
            clear fire_objects_id fire_objects disturbance_map fire_object_layer;
        else
            fire = [];
        end
    end
end