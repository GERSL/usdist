function hydro = loadReferenceGSWO(tile, yr)
%LOADHYDROLOGY
% To learn hdrology from global water products, in which the change is
% between permanent water (3) and  no water/ Seasonal (1/2), No data (0)
    % 23_Hydrology yes or no
    path_23_hydro = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderReferenceLayerGSWO);
    % to get the water class in the year and in the previous one year
    file_hydro_yr = fullfile(path_23_hydro, sprintf('%s_water_class_%d.tif', tile, yr));
    file_hydro_yr_pre = fullfile(path_23_hydro, sprintf('%s_water_class_%d.tif', tile, yr - 1));
    
    if isfile(file_hydro_yr) && isfile(file_hydro_yr_pre)
        hydro_yr = imread(file_hydro_yr);
        hydro_yr_pre = imread(file_hydro_yr_pre);
        % when the pixel values were altered, and neither of them is 0(No data) or >3 (unnormal pixel value).
        hydro = (hydro_yr ~= hydro_yr_pre);
        hydro((hydro_yr == 0 | hydro_yr_pre == 0)) = 0;
        hydro((hydro_yr > 3 | hydro_yr_pre > 3))= 0;
    else
        hydro = [];
    end
end

