function batchProduceTrainingSampleObject(coreid, corenum, varargin)
%% BATCHPRODUCETRAININGSAMPLEOBJECT Produce training samples according the record .mat files
%  INPUTS:
%  coreid:                      ID of core, such as 1, 2, 3, 4, 5, ..., 100
%  corenum:                     Total number of cores, such as 100
%  process (Optional):          'job' is to create a local .mat at
%                               <Jobs> to arrange the parallel comupting resource
%                               'sample' is to produce training samples
%  source (Optional):           'open' is to create sample objects based on open-source data
%                               'manual' is to create sample objects based on purely manually interpreted data
%
%  Last update on Oct., 4, 2022

% sbatch --dependency=afterok:4957856 batchCreateModelReadyPixelTrainingSample.sh
% sbatch --dependency=afterok:4957856 batchCreateModelReadyPixelTrainingSample.sh
% 
% How to use this function? Set the variable 'p' with 'job' or 'sample'
% 1) generate the job list as local .mat at <Jobs> since this will startup dir [once only!]
% 2) startup to create training objects based on the job list

%% Add code paths
restoredefaultpath;
pathparent = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(genpath(pathparent));

%% Setup inputs
if ~exist('coreid', 'var') || ~exist('corenum', 'var')
    coreid = 1; corenum = 1;
end    
p = inputParser;
addParameter(p, 'source',  'manual'); % data source: 'open' or 'manual' or "manual_all"
addParameter(p, 'process', 'sample'); % 'job' for creating the task object list, 'sample' for processing samples based on the existing task list

parse(p,varargin{:});
process = p.Results.process;
source = p.Results.source;

%% ARD tiles
ARDTiles = odacasets.ARDTiles; % to read central tiles
ARDTiles = getAdjacentARDTiles(ARDTiles); % to add neighbor tiles

%% Assign tasks first
filepath_joblist = fullfile(pathparent, 'CreateTrainingDatabase', 'ProduceTrainingSampleObject', 'Jobs', 'arrayjob_list_to_create_sample_object.mat');

switch lower(process)
    case 'job'
        %% Generate job list for parallel computing, to avoid lots of cores to search the data at the same time.
        tic
        fprintf('Generating parallel tasks\r');
    
        tasks = [];
        years = odacasets.years; % control years
        for iyr = 1: length(years)  % loop years
            for iARD = 1: length(ARDTiles) % loop ARD to assign different tile to different cores, that will fully use all the computing resources
                hv_name = ARDTiles{iARD};
                % loop groups to save memeroy loaded
                obj_inputs = dir(fullfile(odacasets.pathResultODACA, hv_name, odacasets.YearlyODACAInputs, sprintf('record_objs_%d_*_*.mat', years(iyr)) ));
                for irec = 1: length(obj_inputs)
                   ic = length(tasks) + 1;
                   tasks(ic).tile = hv_name;
                   tasks(ic).year = years(iyr);
                   tasks(ic).recordname = obj_inputs(irec).name;
                end
            end
        end
        rng(1);
        tasks = tasks(randperm(length(tasks)));
        save(filepath_joblist, 'tasks');
        
        fprintf('Finished with %0.2f mins\r', toc/60);
    case 'sample'
        %% Load the job list, which was generated ahead of time
        % randomly stoping to give other cores to read the .mat
        if corenum > 1
            rng('shuffle');
            pause(randperm(10,1)); 
        end
        load(filepath_joblist); %#ok<LOAD> 
        %% Process each task
        for itask = coreid: corenum: length(tasks)
            taskobj = tasks(itask);
            generateTrainingSampleObjectsRecord(taskobj.tile, taskobj.year, taskobj.recordname, 'source', source);
        end
end % end of switch

end % end of function
