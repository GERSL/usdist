function [referencelayer_interpreted] = loadReferenceInterpreted(tile, yr, varargin)
%% loadReferenceInterpreted is to load interprated samples
   %% Setup the input vars
    p = inputParser;
    addParameter(p, 'format', 'hazard'); % tif or mat
    addParameter(p, 'sample_collection', odacasets.refineSampleCollection); %the round of refining sample colleciton
    parse(p,varargin{:});
    format = p.Results.format;
    sample_collection = p.Results.sample_collection;

    referencelayer_interpreted = [];
    switch format
        case 'hazard'
            % interpreted samples for hazard
            filepath_sample_interpreted = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderReferenceLayerInterpreted, sprintf('%s_year_landslide.tif', tile));
            referencelayer_landslide = loadSampleYearLayer(yr, filepath_sample_interpreted, 'natural_hazard');
            filepath_sample_interpreted = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderReferenceLayerInterpreted, sprintf('%s_year_wind.tif', tile));
            referencelayer_wind = loadSampleYearLayer(yr, filepath_sample_interpreted, 'natural_hazard');
            if ~isempty(referencelayer_landslide) &  ~isempty(referencelayer_wind)
                referencelayer_interpreted = referencelayer_landslide;
                referencelayer_interpreted(referencelayer_wind > 0) = referencelayer_wind(referencelayer_wind > 0);
            elseif ~isempty(referencelayer_landslide) 
                referencelayer_interpreted = referencelayer_landslide;
            elseif ~isempty(referencelayer_wind) 
                referencelayer_interpreted = referencelayer_wind;
            end
        case 'point'
            % reference layer with point
            filepath_sample_interpreted = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderReferenceLayerInterpreted, sprintf('%s_refine_point_%d_v%02d.tif', tile, yr, sample_collection));
            if isfile(filepath_sample_interpreted)
                referencelayer_interpreted = imread(filepath_sample_interpreted); % the agent code done, see preprocess2TileInterpretedSample.py/<PreprocessReferenceData>
            end
        case 'polygon'
            % reference layer with point
            filepath_sample_interpreted = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderReferenceLayerInterpreted, sprintf('%s_refine_polygon_%d_v%02d.tif', tile, yr, sample_collection));
            if isfile(filepath_sample_interpreted)
                referencelayer_interpreted = imread(filepath_sample_interpreted); % the agent code done, see preprocess2TileInterpretedSample.py/<PreprocessReferenceData>
            end
        case 'mat' %% support the matlab dataset, see produceReferenceLayerInterpretedSample.m
            referencelayer_interpreted_point   = loadSubSampleLayer(tile, yr, sprintf('samples_interpreted_%s_c%02d_point.mat', tile, sample_collection));
            referencelayer_interpreted_polygon = loadSubSampleLayer(tile, yr, sprintf('samples_interpreted_%s_c%02d_polygon.mat', tile, sample_collection));
            % assign the sample layer extracted from points
            if ~isempty(referencelayer_interpreted_point)
                referencelayer_interpreted = referencelayer_interpreted_point;
            end
            % assign the sample layer extracted from polygons
            if ~isempty(referencelayer_interpreted_polygon)
                if ~isempty(referencelayer_interpreted) % merged the point and the polygon layers
                    referencelayer_interpreted(referencelayer_interpreted_polygon > 0) = referencelayer_interpreted_polygon(referencelayer_interpreted_polygon > 0);
                else % only the polygon layer assigned
                    referencelayer_interpreted = referencelayer_interpreted_polygon;
                end
            end
    end
end

function referencelayer_interpreted = loadSampleYearLayer(yr, filepath_sample_interpreted, agent)
    referencelayer_interpreted = [];
    if isfile(filepath_sample_interpreted)
        referencelayer_interpreted = readgeoraster(filepath_sample_interpreted); % the agent code done, see produceReferenceLayerInterpreted.m/<ProduceReferenceLayer>
        referencelayer_interpreted_tmp = referencelayer_interpreted;
        referencelayer_interpreted = zeros(size(referencelayer_interpreted), 'uint8');
        referencelayer_interpreted(referencelayer_interpreted_tmp == yr) = getfield(odacasets.agents, agent);
    end
end

function referencelayer_interpreted = loadSubSampleLayer(tile, yr, filename_sample)
    referencelayer_interpreted = [];
    % filename_sample = sprintf('samples_interpreted_%s_c%02d_point.mat', tile, odacasets.refineSampleCollection);
    filepath_sample_interpreted = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderReferenceLayerInterpreted, filename_sample);
    if isfile(filepath_sample_interpreted)
        load(filepath_sample_interpreted); % sample and rastersize
        sample = sample([sample.year] == yr); % same year
        if ~isempty(sample)
            referencelayer_interpreted = zeros(rastersize, 'uint8');
            ind = sub2ind(rastersize,[sample.raster_row], [sample.raster_col]);
            referencelayer_interpreted(ind) = [sample.agent_id];
        end
    end
end