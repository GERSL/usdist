function generateTrainingSampleObjectsRecord(tile, year, recordname, varargin)
%% GENERATETRAININGSAMPLEOBJECTSRECORD Create disturbance agent training datasets from the .mat record, based on all reference data
%  
%  INPUTS:
%  tile:                The name of Landsat ARD tile
%  year:                The year of the record
%  recordname:          The file name of the .mat record
%  source [optional]:   The source of data, opendata (for creating prilimanary agent map) or manualdata (for refining agent map)
%
%  Last updated on May, 29, 2024

    %% Setup the input vars
    p = inputParser;
    addParameter(p, 'source', 'open'); % open  manual , manual_all
    parse(p,varargin{:});
    source = p.Results.source;

    %% Message of starting the program
    start_tic = tic;
    fprintf('\n*******************************************************************************************************************************');
    fprintf('\n* START of producing disturbance agent training samples (object) for %s in %s', recordname, tile);
    fprintf('\n*******************************************************************************************************************************\r');

    %% Parameters
    minoverlap = odacasets.traindata_minoverlap;
    minarea_climate_variability = odacasets.traindata_minarea_climate_variability;
    minarea_stress = odacasets.traindata_minarea_stress_ids;
    switch source
        case 'manual'
            %% Folder of sample data

            % filename_samples_merged = sprintf('%sManualC%02d', odacasets.folderTrainingSampleObject, odacasets.refineSampleCollection);
            % dir_samples_merged = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, filename_samples_merged); % The sample data's path

            dir_samples_merged = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, sprintf('%sRefineV%02d', odacasets.folderTrainingSampleObject, odacasets.refineSampleCollection)); % The sample data's path
            referencelayer_interpreted = loadReferenceInterpreted(tile, year, 'format', 'point');
            referencelayer_interpreted_polygon = loadReferenceInterpreted(tile, year, 'format', 'polygon');
            if isempty(referencelayer_interpreted) && isempty(referencelayer_interpreted_polygon)
                return;
            end
            % merge two layers as into one
            if ~isempty(referencelayer_interpreted) && ~isempty(referencelayer_interpreted_polygon)
                referencelayer_interpreted(referencelayer_interpreted_polygon> 0) = referencelayer_interpreted_polygon(referencelayer_interpreted_polygon> 0); 
            elseif isempty(referencelayer_interpreted) && ~isempty(referencelayer_interpreted_polygon)
                referencelayer_interpreted = referencelayer_interpreted_polygon;
            end
            
            % set up as the empty since we will not use anymore
            referencelayer_forest_management = [];
            referencelayer_agriculture_activity =[];
            referencelayer_construction = [];
            referencelayer_stress = [];
            referencelayer_debris = [];
            referencelayer_water_dynamic = [];
            referencelayer_fire =[];
            referencelayer_other =[];
            % end of extracting trainings sample from interpreted dataset only
            % to refine the prelimilary disturbance agent maps (on open-source datasets)
        case 'manual_all'
            %% Folder of sample data
            referencelayer_interpreted = [];
            for ir = 1: 10
                if isempty(referencelayer_interpreted)
                    referencelayer_interpreted = loadReferenceInterpreted(tile, year, 'format', 'mat', 'sample_collection', ir);
                else
                    referencelayer_interpreted_r = loadReferenceInterpreted(tile, year, 'format', 'mat', 'sample_collection', ir);
                    if ~isempty(referencelayer_interpreted_r)
                        referencelayer_interpreted(referencelayer_interpreted_r > 0) = referencelayer_interpreted_r(referencelayer_interpreted_r>0);
                    end
                end
            end
            dir_samples_merged = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, sprintf('%sManual', odacasets.folderTrainingSampleObject)); % set up as xxx Mannual: mean all data 
           
            % set up as the empty since we will not use anymore
            referencelayer_forest_management = [];
            referencelayer_agriculture_activity =[];
            referencelayer_construction = [];
            referencelayer_stress = [];
            referencelayer_debris = [];
            referencelayer_water_dynamic = [];
            referencelayer_fire =[];
            referencelayer_other =[];
            % end of extracting trainings sample from interpreted dataset only
            % to refine the prelimilary disturbance agent maps (on open-source datasets)
        case 'open'
            %% Folder of sample data
            dir_samples_merged = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderTrainingSampleObject); % The sample data's path
            %% Shared data, such as disturbance map with change time in month and change type
            % 1) change map in unit of MONTH, of which area less than 4 pixels (defined in odacasets.m)
            tic
            fprintf('\n* Loading shared reference datasets:\n');
            fprintf('> Yearly change map derived from COLD');
            [disturbance_month, disturbance_type] = loadYearlyChangeMap(tile, year, 'datetype', 'month'); % the disturbance map as month and the disturbance type was identified by COLD
            if isempty(disturbance_month)
                fprintf(' (Not Found)\n');
            else
                fprintf(' (Found)\n');
            end
        
            % 2) LandFire reference layer
            fprintf('> LandFire');
            reference_lf = loadReferenceLF(tile, year); % LandFire Reference layer 1999-2016
            if isempty(reference_lf)
                fprintf(' (Not Found)\n');
            else
                fprintf(' (Found)\n');
            end
        
            % 3) LCT reference layer
            fprintf('> Land Cover Trends');
            reference_lct = loadReferenceLCT(tile, year); % Land Cover Trends Reference layer
            if isempty(reference_lct)
                fprintf(' (Not Found)\n');
            else
                fprintf(' (Found)\n');
            end
            
            % 4) NLCD reference layer
            fprintf('> NLCD');  % Shared NLCD base layers [2001, 2004, 2006, 2008, 2011, 2013, 2016, 2019] % According the year range of the dataset, setup the function, for example, 'closest' for IDS, 'forward' and 'afterward' for LF
            [nlcd_current, nlcd_closest, nlcd_forward, nlcd_afterward] = loadReferenceNLCD(tile, year, ...
                'closest', ismember(year, odacasets.yearsIDS), ...      % closest NLCD layer to extract forest layer for IDS
                'forward', year >= min(odacasets.yearsLandfire), ... % foward NLCD layer to extract non-forest layer for LandFire's Development
                'afterward', year >= min(odacasets.yearsLandfire));  % afterward NLCD layer to extract forest and forest transition layer for LandFire's Plantation
            if isempty(nlcd_current) && isempty(nlcd_closest) && isempty(nlcd_forward) && isempty(nlcd_afterward)
                fprintf(' (Not Found)\n');
            else
                fprintf(' (Found)\n');
            end
            
            % NLCD 2001 for improving the farmland LCT 
            if year == 2001
               nlcd2001 = nlcd_current;
            else % NLCD 2001 as basic layer
               nlcd_filepath = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderReferenceLayerNLCD, sprintf('%s_nlcd_%d.tif', tile, 2001));
               if isfile(nlcd_filepath)
                   nlcd2001 = readgeoraster(nlcd_filepath); % see produceReferenceLayerNLCDLCFTC.m/<ProduceReferenceLayer>
               else
                   nlcd2001 = [];
               end
               clear nlcd_filepath;
            end
        
            % 5) Size of image
            image_size = size(disturbance_month);
        
            fprintf('* Finish loading shared reference datasets with %0.4f mins\n', toc/60);
            % End of Shared data
        
            %% Below codes for creating sample layer
            tic
            fprintf('\n* Creating sample layers (only available shown below):\n');
        
            %% Forest Management (code: 1)
            referencelayer_forest_management = zeros(image_size, 'logical');
            % Data source #1: derived LF
            if ~isempty(reference_lf)
                % Select clearcut, harvest, and thinning.
                referencelayer_forest_management(reference_lf == 2 | reference_lf == 3 | reference_lf == 4) = 1; % see code at produceReferenceLayerLF.m/<ProduceReferenceLayer>
                % Select planting, seeding, and afforestation
                referencelayer_forest_management(reference_lf == 19 | reference_lf == 20 | reference_lf == 21) = 1; % see code at produceReferenceLayerLF.m/<ProduceReferenceLayer>
                % % Select planting, seeding, and afforestation, and their afterward NLCD land cover were forest or forest transition (i.e., shrub-forest and herbaceous-forest).
                % if ~isempty(nlcd_afterward) % only when we have the afterward land cover map
                %     nlcd_afterward_forest_transition = imerode(nlcd_afterward >= 41 & nlcd_afterward <=46, true(odacasets.traindata_window_size_boundary_nlcd));
                %     referencelayer_forest_management((reference_lf == 19 | reference_lf == 20 | reference_lf == 21) & nlcd_afterward_forest_transition == 1) = 1; % see code at produceReferenceLayerLF.m/<ProduceReferenceLayer>
                %     clear nlcd_afterward_forest_transition;% never be use below
                % end
            end
            
            % Data source #2: derived LCT
            if ~isempty(reference_lct)
                % Select changed pixels where the land cover/land use was changed from forest to mechanically disturbed between two consecutive years (i.e., 1986-1992 and 1992-2000) and only one change was identified by COLD.
                referencelayer_forest_management(reference_lct == 10) = 1; % see code at produceReferenceLayerLCT.m/<ProduceReferenceLayer>
            end
        
            % Clear the reference layer to save computing
            if sum(referencelayer_forest_management(:)) == 0
                referencelayer_forest_management = []; % empty varible to save memory
            else
                fprintf('> Forest Management\n');
            end
            % End of Forest Management
        
            %% Agriculture Activity (code: 7) that was here because we will clear reference lct as soon as possible
            referencelayer_agriculture_activity  = zeros(image_size, 'logical');
            % Data source #1 (only): derived LCT
            if ~isempty(reference_lct)
                % see code at produceReferenceLayerLCT.m/<ProduceReferenceLayer>
                % 31: Select changed pixels where the land cover/land use was changed from grassland/shrubland, wetland, or barren to agriculture (or opposite) between two consecutive years (i.e., 1986-1992 and 1992-2000) and only one change was identified by COLD.
                % 32: Select stable pixels where the land cover/land use was always agriculture between two consecutive years (i.e., 1986-1992 and 1992-2000).
                nlcd_agriculture_2001 = nlcd2001==81 | nlcd2001==82;
                nlcd_agriculture_2001 = imerode(nlcd_agriculture_2001, true(odacasets.traindata_window_size_boundary_nlcd));
                referencelayer_agriculture_activity(reference_lct == 31) = 1;
                referencelayer_agriculture_activity(reference_lct == 32 & nlcd_agriculture_2001) = 1;
                clear nlcd_agriculture_2001;
                % Note: remove boundary pixels by a moving window with 5-by-5
                % pixels. This can reduce the confusion between
                % agriculture_activity and construction
            end
            % Clear the reference layer to save computing
            if sum(referencelayer_agriculture_activity(:)) == 0
                referencelayer_agriculture_activity = []; % empty varible to save memory
            else
                fprintf('> Agriculture Activity\n');
            end
            % End of Agriculture Activity
        
            %% Construction  (code: 2)
            referencelayer_construction  = zeros(image_size, 'logical');
            % Data source #1: derived LF
            if ~isempty(reference_lf) && ~isempty(nlcd_forward) % derived LF and the NLCD forward non-forest layer is available
                % Select development, and the forward NLCD land cover was non-forest.
                nlcd_forward_nonforest = imerode(~(nlcd_forward >= 41 & nlcd_forward <=43), true(odacasets.traindata_window_size_boundary_nlcd));
                referencelayer_construction(reference_lf == 1 & nlcd_forward_nonforest == 1) = 1; % see code at produceReferenceLayerLF.m/<ProduceReferenceLayer>
                clear nlcd_forward_nonforest; % never be use below
            end
            % Data source #2: derived LCT
            if ~isempty(reference_lct) % derived LCT
                % see code at produceReferenceLayerLCT.m/<ProduceReferenceLayer>
                % 21: Select the pixels where grassland/shrubland, wetland, barren, or agriculture was changed to developed or mining between two consecutive years (i.e., 1986-1992 and 1992-2000) and only one change was identified by COLD.
                % 22: Select the pixels where the land cover/land use was always developed between two consecutive years (i.e., 1986-1992 and 1992-2000) and only one change was identified by COLD.
                nlcd_developed_2001 = nlcd2001>=21 & nlcd2001 <30;
                nlcd_developed_2001 = imerode(nlcd_developed_2001, true(odacasets.traindata_window_size_boundary_nlcd)); 
                referencelayer_construction(reference_lct == 21) = 1;
                referencelayer_construction(reference_lct == 22 & nlcd_developed_2001) = 1;
                clear nlcd_developed_2001;
            end
            clear nlcd2001 reference_lct;
            % Clear the reference layer to save computing
            if sum(referencelayer_construction(:)) == 0
                referencelayer_construction = []; % empty varible to save memory
            else
                fprintf('> Construction\n');
            end
            % End of Construction
        
        
            %% Stress (code: 3)
            referencelayer_stress  = zeros(image_size, 'logical');
            % Data source #1: derived LF
            if ~isempty(reference_lf)
                % Select insects, disease, and insects/disease
                referencelayer_stress(reference_lf == 14 | reference_lf == 15 | reference_lf == 16) = 1; % see code at produceReferenceLayerLF.m/<ProduceReferenceLayer>
            end
            % Data source #2: derived IDS
            reference_ids = loadReferenceIDS(tile, year);
            if ~isempty(reference_ids)
                % Monthly disturbance over forest, but exclude the pixels with greener direction 
                disturbance_month_type3 = disturbance_month; % Monthly disturbance
                % Exclude the pixels with greener direction
                disturbance_month_type3(disturbance_type ~= 3) = 0; %  3 => land disturbance  1 => regrowth break  2 => aforestation break
                % Over forest layer, add shrubland, young tree
                nlcd_closest_forest = (nlcd_closest >= 41 & nlcd_closest <= 43) | nlcd_closest == 90 | (nlcd_closest == 45 & nlcd_closest == 52) ;
                nlcd_closest_forest = imerode(nlcd_closest_forest, true(odacasets.traindata_window_size_boundary_nlcd));
                disturbance_month_type3(nlcd_closest_forest == 0) = 0; 
                clear nlcd_closest_forest;
                % Select insects, disease, and insects/disease, drought, and heat
                disturbance_month_type3(reference_ids == 0) = 0;
                % Large disturbance
                referencelayer_stress = extractMaxMonthlyDisturbance(disturbance_month_type3, minarea_stress);
                clear disturbance_month_type3;
            end
            clear reference_ids nlcd_closest;
            % Clear the reference layer to save computing
            if sum(referencelayer_stress(:)) == 0
                referencelayer_stress = []; % empty varible to save memory
            else
                fprintf('> Stress\n');
            end
            % End of Stress
        
            %% Debris (code: 4)
            referencelayer_debris  = zeros(image_size, 'logical');
            % Data source #1 (only): derived LF
            if ~isempty(reference_lf)
                % Select weather, 'a weather related event that results in loss of vegetation such as blowdown, hurricane, or tornado', defined by LandFire
                referencelayer_debris(reference_lf == 11) = 1; % see code at produceReferenceLayerLF.m/<ProduceReferenceLayer>
            end
            clear reference_lf;
            % Clear the reference layer to save computing
            if sum(referencelayer_debris(:)) == 0
                referencelayer_debris = []; % empty varible to save memory
            else
                fprintf('> Debris\n');
            end
            % End of Debris
        
            %% Water Dynamic (code: 5)
            % Data source #1 (only): derived GWSO
            if ~isempty(nlcd_current) % only when NLCD OK
                referencelayer_water_dynamic = loadReferenceGSWO(tile, year);  % derived GWSO
                if ~isempty(referencelayer_water_dynamic) % exclude cropland pixels which often caused water dynamic, but its driver is agriculture activities
                    nlcd_agriculture_developed = (80< nlcd_current & nlcd_current< 90); % | (20< nlcd_current & nlcd_current< 30); % agriculture or urban
                    nlcd_agriculture_developed = imdilate(nlcd_agriculture_developed, true(odacasets.traindata_window_size_dilate_nlcd));
                    referencelayer_water_dynamic(nlcd_agriculture_developed) = 0; % exclude agriculture 
                    clear nlcd_agriculture_developed;
                    fprintf('> Water Dynamic\n');
                else
                    referencelayer_water_dynamic = [];
                end
            else
                referencelayer_water_dynamic = [];
            end
            % End of Water Dynamic
        
            %% Fire (code: 6) 
            % Data source #1 (only): derived MTBS
            % NOTE the layer includes the pixels varing from 1 to 5, and nnly the 3: moderate burn severity and 4: high burn severity will be used to train the model
            [referencelayer_fire, fire_mtbs] = loadReferenceMTBS(tile, year, disturbance_month > 0); % 3: moderate burn severity and 4: high burn severity
            % Clear the reference layer to save computing
            if sum(referencelayer_fire(:)) == 0
                referencelayer_fire = []; % empty varible to save memory
            else
                fprintf('> Fire\n');
            end
            % End of Fire
            
            %% Other (Code: 8)
            referencelayer_other = zeros(image_size, 'logical');
            % Overlap annual COLD disturbance maps, to find out the disturbances with very large area, over barren, grass and shrub land
            % nlcd_current, nlcd_closest, nlcd_forward, nlcd_afterward
        %     if ~isempty(nlcd_current) && ~isempty(nlcd_forward) && ~isempty(nlcd_afterward) && ~isempty(fire_mtbs) % two-year NLCD and no fire
            if isempty(nlcd_current) && ~isempty(nlcd_forward) && ~isempty(nlcd_afterward) && ~isempty(fire_mtbs) % two-year NLCDs and no fire
                % Data source #1: short-term large disturbance broken within a same month and over NLCD barren (31), grass (71), and shrub (52)
                disturbance_month_potential_climate = disturbance_month;
        
                % over NLCD barren (31), grass (71), and shrub (52), only
                nlcd_potential_climate = (nlcd_afterward == 31 | nlcd_afterward == 71 | nlcd_afterward == 52) & ...
                                         (nlcd_forward   == 31 | nlcd_forward   == 71 | nlcd_forward   == 52); % consective NLCD layers
                nlcd_potential_climate = imerode(nlcd_potential_climate, true(odacasets.traindata_window_size_erode_nlcd));
                disturbance_month_potential_climate(~nlcd_potential_climate) = 0;
                clear nlcd_potential_climate;
        
                % remove fire
                disturbance_month_potential_climate(fire_mtbs == 1) = 0;
        
                % disturbance with the maximum of monthly breakout area
                referencelayer_other = extractMaxMonthlyDisturbance(disturbance_month_potential_climate, minarea_climate_variability); 
                clear disturbance_month_potential_climate;
        
                % Data source #2: COLD regrowth layer and NLCD forest and forest transition layer
        %         nlcd_regrowth = nlcd_current >= 41 & nlcd_current <=46;
                nlcd_regrowth = nlcd_forward == 46                      & nlcd_afterward >= 41 & nlcd_afterward <=46;      % grass - > shrubland/forest
                nlcd_regrowth(nlcd_forward == 45                        & nlcd_afterward >= 41 & nlcd_afterward <=45) = 1; % shrubland - > forest
                nlcd_regrowth(nlcd_forward >= 41 & nlcd_forward <=43    & nlcd_afterward >= 41 & nlcd_afterward <=43) = 1; % young forest - > mature forest
                nlcd_regrowth = imerode(nlcd_regrowth, true(odacasets.traindata_window_size_boundary_nlcd));
                referencelayer_other(disturbance_type == 1 & nlcd_regrowth) = 1;  % disturbance_type 1 => regrowth break  2 => aforestation break
                clear nlcd_regrowth;
            end
            clear nlcd_current nlcd_forward nlcd_afterward disturbance_type  disturbance_month;
            % Clear the reference layer to save computing
            if sum(referencelayer_other(:)) == 0
                referencelayer_other = []; % empty varible to save memory
            else
                fprintf('> Other\n');
            end
        
            %% Post-process reference layers
            % 1) There were no fire events two years before harvest, which can reduce the commission errors from post-fire harvest
            if ~isempty(referencelayer_forest_management)
                if ~isempty(fire_mtbs) % the 
                    referencelayer_forest_management(fire_mtbs) = 0;
                end
                clear fire_mbts;
                [~, fire_mbts_backforward1year] = loadReferenceMTBS(tile, year-1);
                if ~isempty(fire_mbts_backforward1year)
                    referencelayer_forest_management(fire_mbts_backforward1year) = 0;
                end
                clear fire_mbts_backforward1year;
                [~, fire_mbts_backforward2year] = loadReferenceMTBS(tile, year-2);
                if ~isempty(fire_mbts_backforward2year)
                    referencelayer_forest_management(fire_mbts_backforward2year) = 0;
                end
                clear fire_mbts_backforward2year;
            end
        
            %% Interpreted sample layer, of which codes are same as what we defined.
            referencelayer_interpreted = loadReferenceInterpreted(tile, year, 'format', 'hazard'); % at very begining, we manully selected the hazard samples from wind and landslide
            if sum(referencelayer_interpreted(:)) == 0
                referencelayer_interpreted = []; % empty varible to save memory
            else
                fprintf('> Interpreted samples, such as debris\n');
            end
        
            fprintf('* Finish creating sample layers with %0.4f mins\n', toc/60);
    end % End of extracting training sample from open-source datasets

    %% Extracting sample objects
    % Record of all samples in ONE structure, one type, one variable
    fprintf('\n* Extracting sample objects\n');
    
    %% Define agent types, that will be assigned based on majority vote
    name_opensample = lower(fieldnames(odacasets.agents,'-full')); % agents that were defined or focused on
    lbs_opensample  = struct2array(odacasets.agents); % get the value lists
    
    %% When no sample, just return
    if isempty(referencelayer_forest_management) && isempty(referencelayer_agriculture_activity) && isempty(referencelayer_construction) &&...
            isempty(referencelayer_stress) && isempty(referencelayer_debris) && isempty(referencelayer_water_dynamic) && ...
            isempty(referencelayer_fire) && isempty(referencelayer_other) && isempty(referencelayer_interpreted)
        % if no sample layers, no processes further
        fprintf('\n* No reference layers available\r');
        fprintf('\nEND of producing samples for %s in %s with %0.2f mins in total\r', recordname, tile, toc(start_tic)/ 60);
        fprintf('\n-------------------------------------------------------------------------------------------------------------------------------\r\r');
        return;
    end

    %% Rotate the reference layers to match the COLD results, pixel location.
    referencelayer_forest_management = referencelayer_forest_management'; % [logical]
    referencelayer_agriculture_activity = referencelayer_agriculture_activity'; % [logical]
    referencelayer_construction = referencelayer_construction'; % [logical]
    referencelayer_stress = referencelayer_stress'; % [logical]
    referencelayer_debris = referencelayer_debris'; % [logical]
    referencelayer_water_dynamic = referencelayer_water_dynamic'; % [logical]
    referencelayer_fire = referencelayer_fire'; % [uint8] [uint8], pixel value = burn severity, such as 1, 2, "3", "4", and 5. 3: moderate burn severity and 4: high burn severity
    referencelayer_other = referencelayer_other'; % [logical]
    referencelayer_interpreted = referencelayer_interpreted'; % [uint8], pixel value = agent code

    %% Overlap each disturbance object to determine the sample finally
    tic
    load(fullfile(odacasets.pathResultODACA, tile, odacasets.YearlyODACAInputs, recordname)); %#ok<LOAD>  % load .mat changes with inputting features  variable name: record_objs
    
    fprintf('> Loading %s with %0.4f mins\n', fullfile(tile, odacasets.YearlyODACAInputs, recordname), toc/60);
    % iterate each of disturbance object to find the training objects with agent type
    for i_obj = 1 : length(record_objs) %#ok<NODEF> 
        %% Message of processing status
        % process_prct = fix(100.*i_obj/length(record_objs));
        % if process_prct - fix(100.*(i_obj-1)/length(record_objs)) > 0
        %     fprintf('> Processing %03d percent\n', process_prct);
        % end
        
        %% Initatlize the overlap, that will be used to filter the disturbance objects
        record_objs(i_obj).Overlap = 0; %#ok<AGROW> % inilizate the overlap as 0
        record_objs(i_obj).AgentCodeClassified = 0; % indicate we need to consider the previous classified results
        pixelIdx_obj = record_objs(i_obj).PixelIdxList; % pixel locations of disturbance object

        %% highest priority for the interpreted samples
        if ~isempty(referencelayer_interpreted)
            agent_code = unique(referencelayer_interpreted(pixelIdx_obj));
            agent_code(agent_code == 0) = [];% remove the pixels with 0
            agent_code(agent_code == 255) = [];% remove the pixels with 255
            if length(agent_code) == 1 % only single agent was interpreted
                record_objs(i_obj).AgentCode = agent_code; %#ok<AGROW>
                record_objs(i_obj).Overlap = 1; %#ok<AGROW> % 100%
                record_objs(i_obj).PixelIdxListSample = true(size(pixelIdx_obj)); %#ok<AGROW> % all pixels can be the training samples
                clear agent_code;
                continue; % next obj
            end
            clear agent_code;
        end

        %% vote for disturbance object
        vote_nums = zeros(size(name_opensample)); % must be order as same as agents/odacasets.m
        for i_agent = 1: length(name_opensample)
            switch name_opensample{i_agent}
                case 'forest_management'
                    if ~isempty(referencelayer_forest_management)
                        samplepixels_forest_management = referencelayer_forest_management(pixelIdx_obj) > 0;
                        vote_nums(i_agent) = sum(samplepixels_forest_management);
                    end
                case 'construction'
                    if ~isempty(referencelayer_construction)
                        samplepixels_construction = referencelayer_construction(pixelIdx_obj) > 0;
                        vote_nums(i_agent) = sum(samplepixels_construction);
                    end
                case 'stress'
                    if ~isempty(referencelayer_stress)
                        samplepixels_stress = referencelayer_stress(pixelIdx_obj) > 0;
                        vote_nums(i_agent) = sum(samplepixels_stress);
                    end
                case 'natural_hazard'
                    if ~isempty(referencelayer_debris)
                        samplepixels_debris = referencelayer_debris(pixelIdx_obj) > 0;
                        vote_nums(i_agent) = sum(samplepixels_debris);
                    end
                case 'water_dynamic'
                    if ~isempty(referencelayer_water_dynamic)
                        samplepixels_water_dynamic = referencelayer_water_dynamic(pixelIdx_obj) > 0;
                        vote_nums(i_agent) = sum(samplepixels_water_dynamic);
                    end
                case 'fire'
                    if ~isempty(referencelayer_fire)
                        samplepixels_fire = referencelayer_fire(pixelIdx_obj); % pixel value, month
                        vote_nums(i_agent) = sum(samplepixels_fire > 0);
                    end
                case 'agriculture_activity'
                    if ~isempty(referencelayer_agriculture_activity)
                        samplepixels_agriculture_activity = referencelayer_agriculture_activity(pixelIdx_obj) > 0;
                        vote_nums(i_agent) = sum(samplepixels_agriculture_activity);
                    end
                case 'other'        
                    if ~isempty(referencelayer_other)
                        samplepixels_other = referencelayer_other(pixelIdx_obj) > 0;
                        vote_nums(i_agent) = sum(samplepixels_other);
                    end
            end
        end

        %% When votes available, the training object was identified successfully
        if sum(vote_nums) > 0
            % sort by descend
            [majr_num, vote_id] = sort(vote_nums, 'descend');
            pcr_vote =  majr_num(1)/length(pixelIdx_obj); % majority vote results
            clear majr_num;

            if pcr_vote >= minoverlap
                record_objs(i_obj).AgentCode = lbs_opensample((vote_id(1))); %#ok<AGROW>
                record_objs(i_obj).Overlap = pcr_vote; %#ok<AGROW> % update the overlap
                % assign a logical array to indicate sample pixels
                switch name_opensample{(vote_id(1))}
                    case 'forest_management'
                        record_objs(i_obj).PixelIdxListSample = samplepixels_forest_management; %#ok<AGROW>
                        clear samplepixels_forest_management;
                    case 'construction'
                        record_objs(i_obj).PixelIdxListSample = samplepixels_construction; %#ok<AGROW>
                        clear samplepixels_construction;
                    case 'stress'
                        if record_objs(i_obj).StdDOY > 10 % exclude forest harvest that usually happen within same day
                            record_objs(i_obj).PixelIdxListSample = samplepixels_stress < 0; %#ok<AGROW> % update the pixel list of sample pixels as none
                            record_objs(i_obj).Overlap = 0; %#ok<AGROW> % update the percentage overlaid 
                        else
                            record_objs(i_obj).PixelIdxListSample = samplepixels_stress; %#ok<AGROW>
                        end
                        clear samplepixels_stress;
                    case 'natural_hazard'
                        record_objs(i_obj).PixelIdxListSample = samplepixels_debris; %#ok<AGROW>
                        clear samplepixels_debris;
                    case 'water_dynamic'
                        record_objs(i_obj).PixelIdxListSample = samplepixels_water_dynamic; %#ok<AGROW>
                        clear samplepixels_water_dynamic;
                    case 'fire' 
                        record_objs(i_obj).PixelIdxListSample = samplepixels_fire > 0; %#ok<AGROW> % update the training pixels
                    case 'agriculture_activity'
                        record_objs(i_obj).PixelIdxListSample = samplepixels_agriculture_activity; %#ok<AGROW>
                        clear samplepixels_agriculture_activity;
                    case 'other'
                        record_objs(i_obj).PixelIdxListSample = samplepixels_other; %#ok<AGROW>
                        clear samplepixels_other;
                end
                continue;
            end
        end  
    end % End of matching disturbance objects


    %% Save data
    if isempty(record_objs)
        fprintf('\n* No samples found\r');
    else
        fprintf('* Finish extracting sample objects with %0.4f mins\n', toc/60);
        fprintf('\n* Saving sample objects\n');
        [~, recordname] = fileparts(recordname); % remove the extension
        record_objs([record_objs.Overlap] < minoverlap) = []; % delete the objects without any samples
        if ~isempty(record_objs)
            if ~isfolder(dir_samples_merged)
                mkdir(dir_samples_merged);
            end
            for k = 1: length(name_opensample)
                record_objs_samples = record_objs([record_objs.AgentCode] == lbs_opensample(k));
                if ~isempty(record_objs_samples)
                    % remain the samples that pointed out the places with
                    % error
                    % if strcmpi(source, "manual")
                    %     filepath_classified = fullfile(odacasets.pathResultODACA, tile, "ChangeObjectOutputV00", recordname);
                    %     record_objs_classified = load(filepath_classified).record_objs;
                    %     % remain the object that has different agent
                    %     % between predication and interpretation where we
                    %     % need to revise
                    %     record_objs_classified = record_objs_classified(ismember([record_objs_classified.ID], [record_objs_samples.ID])); % same to sample
                    % 
                    %     ids_obj_disagree = [record_objs_classified.agent_primary] ~= [record_objs_samples.AgentCode]; % classifed incorectly
                    %     % 0 means no control
                    %     % > 0 means we only remain the specific agents
                    %     ids_obj_classified = ([record_objs_classified.agent_primary] == [record_objs_samples.AgentCodeClassified]) | ([record_objs_samples.AgentCodeClassified] == 0);
                    %     ids_obj = find(ids_obj_disagree & ids_obj_classified);
                    %     if isempty(ids_obj)
                    %         continue; % just jump to next
                    %     end
                    % 
                    %     record_objs_samples = record_objs_samples(ids_obj);
                    % end
                    num_pixelsamples = length(convertChangeObjects2Pixels(record_objs_samples, 'number', true));
                    filenameout = replace(recordname,'objs', sprintf('samples_%s', name_opensample{k}));
                    path_samples_merged = fullfile(dir_samples_merged, sprintf('%s_%010d_%010d.mat', filenameout, length(record_objs_samples), num_pixelsamples));
                    save([path_samples_merged, '.part'], 'record_objs_samples', '-v7.3');
                    movefile([path_samples_merged, '.part'], path_samples_merged);
                    fprintf('%s\n', path_samples_merged);
                end
            end
        end
        fprintf('* Finish saving sample objects with %0.4f mins\n', toc/60);
    end

    fprintf('\nEND of producing samples for %s in %s with %0.2f mins in total\r', recordname, tile, toc(start_tic)/ 60);
    fprintf('\n-------------------------------------------------------------------------------------------------------------------------------\r\r');
end % End of function

function monthlydisturb = extractMaxMonthlyDisturbance(disturbance_month, min_area)
%% EXTRACTMAXMONTHLYDISTURBANCE extract monthly disturbance map
    monthlydisturb = zeros(size(disturbance_month));
    num_dist = 0;
    uniq_months = unique(disturbance_month(disturbance_month>0));
    for iunqm = 1: length(uniq_months)
        dist_month = disturbance_month == uniq_months(iunqm); % same month;  +/- 3 months, 3 months in total agree
        num_dist_month = sum(dist_month(:));
        if num_dist_month > num_dist && num_dist_month >= min_area
            num_dist = num_dist_month;
            monthlydisturb = dist_month;
        end
    end
end

function largedisturb = extractLargeDisturbanceMap(disturbance_month, distance, min_area)
%% GETLARGEDISTURBANCEMAP Label large-scale disturbance map, and so the small disturbance objects can be excluded from natural disturbances,
% that often break out at large area within a narrow period, like insect and climate varibility

    % link damaged objects as a very large change object
    img_dist_cluserarea = zeros(size(disturbance_month));
    uniq_months = unique(disturbance_month(disturbance_month>0));
    for iunqm = 1: length(uniq_months)
        % not linked yet, changed map, within a certain period
        dist_month = img_dist_cluserarea == 0 & disturbance_month > 0 & abs(disturbance_month - uniq_months(iunqm)) <= 0; % same month;  +/- 3 months, 3 months in total agree
        dist_month_obj = imdilate(dist_month, true(distance)); % 17 pixels, 500 meters if the neighbor change objects are not less than 500 meters, we will link them together
        dist_month_obj = bwlabel(dist_month_obj); % default 8-by-8 pixels connection
        dist_month_obj(~dist_month) = 0; % exclude the buffered pixel, & only once analyze for each pixel
        clear dist_month;
        stats = regionprops(dist_month_obj, 'Area', 'PixelIdxList');
        for i_obj = 1: length(stats)
            img_dist_cluserarea(stats(i_obj).PixelIdxList) = stats(i_obj).Area;
        end
        clear stats;
        clear stats dist_month_obj;
    end
    largedisturb = img_dist_cluserarea >= min_area; % 1000; % 90 ha that can exclude humanb-being activeities such as harvest
end

