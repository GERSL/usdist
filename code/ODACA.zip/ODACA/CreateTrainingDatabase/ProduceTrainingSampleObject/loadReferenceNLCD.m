function [nlcd_current, nlcd_closest,  nlcd_forward, nlcd_afterward] = loadReferenceNLCD(tile, year, varargin)
%LOADNLCDBASEDLAYERS is to load layers derived from NLCD
%
% Input:
% tile       [Char] Tile name of Landsat ARD
% year       [Number] Year of the target
%
% Output (see below variables):
    nlcd_current = []; % [uint8]  NLCD layer
    nlcd_closest = []; % [Logistical] for forest layer for IDS 
    nlcd_forward = [];  % [Logistical]  Non-forest or forest transition mask after planting, seeding, and afforestation of LandFire
    nlcd_afterward = []; % [Logistical]  Forest or forest transition mask after planting, seeding, and afforestation of LandFire
    
    %% Setup inputs
    p = inputParser;
    addParameter(p,'closest', false);
    addParameter(p,'forward', false);
    addParameter(p,'afterward', false);
    parse(p,varargin{:});
    closest = p.Results.closest;
    forward = p.Results.forward;
    afterward = p.Results.afterward;


    %% NLCD Years
    years_nlcd = odacasets.yearsNLCD; % this is all the data
    % Read forward and afterward NLCD' year
    years_diff = years_nlcd - year;
    year_forward = year + max(years_diff(years_diff < 0));
    year_afterward = year + min(years_diff(years_diff > 0));
    % Read cloest NLCD
    [~, idsort] = sort(abs(years_nlcd - year));
    year_closet = years_nlcd(idsort(1));

    %% Update the NLCD years according the requirements
    years_nlcd = years_nlcd(ismember(years_nlcd, year)); % add current year, if the year is within NLCD years
    if closest
        years_nlcd = [years_nlcd, year_closet];
    end
    if forward && ~isempty(year_forward) 
        years_nlcd = [years_nlcd, year_forward];
    end
    if afterward && ~isempty(year_afterward) 
        years_nlcd = [years_nlcd, year_afterward];
    end
    years_nlcd = sort(unique(years_nlcd)); % Update NLCD years that we have to read; do not change the variable name

    %% Read the NLCD data we need to read
    folderpath_auxi_nlcd = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderReferenceLayerNLCD);
    for iyear = 1: length(years_nlcd)
        % Locate the NLCD layer
        nlcd_filepath = fullfile(folderpath_auxi_nlcd, sprintf('%s_nlcd_%d.tif', tile, years_nlcd(iyear)));
        if isfile(nlcd_filepath)
            nlcd_layer = readgeoraster(nlcd_filepath); % see produceReferenceLayerNLCDLCFTC.m/<ProduceReferenceLayer>
        else
            continue;
        end

        % Current year: NLCD forest or forest transition for the current year
        if years_nlcd(iyear) == year
            nlcd_current = nlcd_layer;
        end

        % Closet Year: NLCD closet forest layer for IDS
        if years_nlcd(iyear) == year_closet
            nlcd_closest = nlcd_layer;
%             nlcd_closest_forest = (nlcd_layer >= 41 & nlcd_layer <= 43) | nlcd_layer == 90; % forest and woodywetland
        end
        
        % Forward Year: non-forest for the development samples from LandFire
        if ~isempty(year_forward) && years_nlcd(iyear) == year_forward
            nlcd_forward = nlcd_layer;
%             nlcd_forward_nonforest = ~(nlcd_layer >= 41 & nlcd_layer <=43);
        end

        % Afterward Year: non-forest for the development samples from LandFire
        if ~isempty(year_afterward) && years_nlcd(iyear) == year_afterward
            nlcd_afterward = nlcd_layer;
%             nlcd_afterward_forest_transition = nlcd_layer >= 41 & nlcd_layer <=46;
        end

    end
end

% CODE of NLCD Science product
%         <edomv>41</edomv>
%         <edomvd>Deciduous Forest - Areas dominated by trees generally greater than 5 meters tall, and greater than 20% of total vegetation cover. More than 75 percent of the tree species shed foliage simultaneously in response to seasonal change.</edomvd>
%         <edomvds>NLCD Legend Land Cover Class Descriptions</edomvds>
%         <edomv>42</edomv>
%         <edomvd>Evergreen Forest - Areas dominated by trees generally greater than 5 meters tall, and greater than 20% of total vegetation cover. More than 75 percent of the tree species maintain their leaves all year. Canopy is never without green foliage.</edomvd>
%         <edomv>43</edomv>
%         <edomvd>Mixed Forest - Areas dominated by trees generally greater than 5 meters tall, and greater than 20% of total vegetation cover. Neither deciduous nor evergreen species are greater than 75 percent of total tree cover.</edomvd>
%         <edomv>45</edomv>
%         <edomvd>Shrub-Forest - Areas identified as currently shrub, but showing spectral properties of transitioning to future forest.</edomvd>
%         <edomv>46</edomv>
%         <edomvd>Herbaceous-Forest - Areas identified as currently grass, but showing spectral properties of transitioning from being either a past forest or to future shrub-forest.</edomvd>