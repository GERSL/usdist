function reference_lct = loadReferenceLCT(tile, year)
%% loadLCTTransition
%
% Input:
% tile          [Char] Tile name of Landsat ARD
% year          [Number] Year of the target
%
% Output:
% reference_lct  [uint8]  Sample layer of the land cover land use transition
%
% see codes of reference from produceReferenceLayerLCT.m/<ProduceReferenceLayer>

    %% Load all years' LCT layer
    folderpath_referencelayer = fullfile(odacasets.pathResultODACA, tile,odacasets.folderTrainingData, odacasets.folderReferenceLayerLCT);
    files_referencelayer = dir(fullfile(folderpath_referencelayer, sprintf('%s_*.tif', tile))); % year starts from 1 or 2, eg., 1999, 2001, etc.

    %% Compare the blocks to confirm land cover land use change
    % known years uniqued
    sample_ids = [];
    for i = 1 : length(files_referencelayer)
        name_tmp = files_referencelayer(i).name;
        cells_splited = split(name_tmp, "_");
        if length(cells_splited) > 2 % exclude h025v014_30to60.tif
            if length(cells_splited) > 8
                % sliver :  longer name
                id_tmp = append(cells_splited{1}, "_", cells_splited{2}, "_",...
                    cells_splited{3}, "_", cells_splited{4},"_", cells_splited{5});
                sample_ids = [sample_ids; id_tmp];
                % h000v000_samp63_0218_sliver_09743_1981_lc_final_60m
            else
                % h000v000_samp63_0218_1993_lc_final_60m_v2
                % h000v000_samp63_0218_1993_lc_final_60m
                id_tmp = append(cells_splited{1}, "_", cells_splited{2}, "_",...
                    cells_splited{3});
                sample_ids = [sample_ids; id_tmp];
            end
        end
    end
    sample_ids = unique(sample_ids);

    clear id_tmp cells_splited;

    %% in each block, we can compare the data layer in close years
    reference_lct = [];
    for i = 1: length(sample_ids)
        id_tmp = sample_ids(i);
        % file name without silver: h030v005_samp59_0089_1985_lc_final_60m.tif
        % file name with silver: h030v005_samp59_0089_sliver_19213_1985_lc_final_60m.tif
        %% find out the files accordingly
        blocks_multiyears = [];
        for i_f = 1: length(files_referencelayer)
            if contains(files_referencelayer(i_f).name, id_tmp)
                block_yr = getLandCoverTrendsYear(files_referencelayer(i_f).name);
                files_referencelayer(i_f).year = block_yr;
                blocks_multiyears = [blocks_multiyears; files_referencelayer(i_f)];
            end
        end
        [~,idx] = sort([blocks_multiyears.year]); % sort by name that can give get the close years
        blocks_multiyears = blocks_multiyears(idx);
        clear i_f idx;
        % must > 2 images to compare
        if length(blocks_multiyears) < 2
            continue;
        end

        % find the two years across the target year
        block_yrs = [blocks_multiyears.year];
        % block_yr_start = block_yrs(1:end-1);
        % block_yr_end = block_yrs(2:end);
        block_id = find(block_yrs(1:end-1) < year & year < block_yrs(2:end));
        
        % not within the two consective years
        if length(block_id) ~= 1
            continue;
        end

        
        %% To get two consecutive years (i.e., 1986-1992 and 1992-2000) 
        block1 = readgeoraster(fullfile(folderpath_referencelayer, blocks_multiyears(block_id).name));
        block2 = readgeoraster(fullfile(folderpath_referencelayer, blocks_multiyears(block_id+1).name)); % plus 1 indicates next block
        
        % change_frequency = zeros(size(block1), 'uint8');
        % for i_yr_tmp = blocks_multiyears(block_id).year+1: blocks_multiyears(block_id+1).year-1 % between
        %     img_dist_mask_tmp = loadYearlyChangeMap(tile, i_yr_tmp, 'datetype', 'doy'); % DOY
        %     change_frequency = change_frequency + uint8(img_dist_mask_tmp > 0);
        % end
        % clear img_dist_mask_tmp;
        % % remove the change pixels with > 1 time
        % block1(change_frequency~=1) = 0;
        % block2(change_frequency~=1) = 0;
        % clear change_frequency;

        % intialize the reference lct layer
        if isempty(reference_lct)
            reference_lct = zeros(size(block1), 'uint8');
        end

        %% Forest management: Pixel value =  = 10
        % forest (code: 6) to mechanically disturbed (code: 3) (see the table at the last)
        reference_lct(block1 == 6 & block2==3) = 10;

        %% Mechanical: 
        %% Pixel value = 21 for Land cover/land use transitions 
        % Land cover/land use transitions: 
        % grassland/shrubland (code: 7), wetland (code: 9), barren(code: 5) , or agriculture (code: 8) was changed to developed (code: 2) or mining (code: 4)
        % (see the table at the last)
        reference_lct((block1 == 7 | block1 == 9 | block1 == 5| block2==8) & (block2==2| block2==4)) = 21; % only one-time change was identified by COLD
        
        %% Pixel value = 22 for Modification
        % Modification: developed (code: 2) (see the table at the last)
        reference_lct(block1 == 2 & block2==2) = 22; % only one-time change was identified by COLD
        
        %% Agriculture activities: 
        %% Pixel value = 31 for Agriculture transitions and 
        % Agriculture transitions: grassland/shrubland (code: 7), wetland (code: 9), or barren (code: 5) to agriculture (code: 8) (see the table at the last)
        block12_agriculture_activites = (block1 == 7 | block1 == 9 | block1 == 5) & block2==8;
        block12_agriculture_activites((block2 == 7 | block2 == 9 | block2 == 5) & block1==8) = 1; % agriculture abandonment
        reference_lct(block12_agriculture_activites == 1) = 31; % only one-time change was identified by COLD
        clear block12_agriculture_activites;
        
        %% Pixel value = 32 for Agriculture practice
        % Agriculture practice: agriculture (code: 8) (see the table at the last)
        reference_lct(block1 == 8 & block2==8) = 32; % only one-time change was identified by COLD
        
    end
    
    % when no data , return []
    if isempty(reference_lct)
        return;
    else
        if sum(reference_lct(:)) == 0
            reference_lct = [];
        end
    end
end


function yr = getLandCoverTrendsYear(name_img)
%% This is to get the data year of Land Cover Trends
    cells_splited_sub = split(name_img, "_");
    if length(cells_splited_sub) > 8
        % sliver :  longer name
        yr =  cells_splited_sub{6};
        % h_samp63_0218_sliver_09743_1981_lc_final_60m
    else
        % h_samp63_0218_1993_lc_final_60m
        yr =  cells_splited_sub{4};
    end
    yr = str2double(yr);
end



%% LandCoverTrends' Legend
%
% Enumerated_Domain:
% Enumerated_Domain_Value: 0 - Unclassified
% Enumerated_Domain_Value_Definition:
% Areas not classified by interpreter, treated as NoData in statistics.
% Enumerated_Domain:
% Enumerated_Domain_Value: 1 - Water
% Enumerated_Domain_Value_Definition:
% Areas persistently covered with water, such as streams, canals, lakes, reservoirs, bays, or oceans.
% Enumerated_Domain_Value_Definition_Source:
% Trends land-use/land-cover class descriptions
% Enumerated_Domain:
% Enumerated_Domain_Value: 2 - Developed
% Enumerated_Domain_Value_Definition:
% Areas of intensive use with much of the land covered with structures or anthropogenic impervious surfaces (e.g., high-density residential, commercial, industrial, roads, etc.) or less intensive uses where the land cover matrix includes both vegetation and structures (e.g., low-density residential, recreational facilities, cemeteries, parking lots, utility corridors, etc.), including any land functionally related to urban or built-up environments (e.g., parks, golf courses, etc.).
% Enumerated_Domain_Value_Definition_Source: Trends land-use/land-cover class descriptions
% Enumerated_Domain:
% Enumerated_Domain_Value: 3 - Mechanically disturbed
% Enumerated_Domain_Value_Definition:
% Land in an altered and often unvegetated state that, due to disturbances by mechanical means, is in transition from one cover type to another. Mechanical disturbances include forest clear-cutting, earthmoving, scraping, chaining, reservoir drawdown, and other similar human-induced changes.
% Enumerated_Domain_Value_Definition_Source: Trends land-use/land-cover class descriptions
% Enumerated_Domain:
% Enumerated_Domain_Value: 4 - Mining
% Enumerated_Domain_Value_Definition:
% Areas with extractive mining activities that have a significant surface expression. This includes (to the extent that these features can be detected) mining buildings, quarry pits, overburden, leach, evaporative, tailings, or other related components.
% Enumerated_Domain_Value_Definition_Source: Trends land-use/land-cover class descriptions
% Enumerated_Domain:
% Enumerated_Domain_Value: 5 - Barren
% Enumerated_Domain_Value_Definition:
% Land comprised of soils, sand, or rocks where less than 10 percent of the area is vegetated. Barren lands are usually naturally occurring.
% Enumerated_Domain_Value_Definition_Source: Trends land-use/land-cover class descriptions
% Enumerated_Domain:
% Enumerated_Domain_Value: 6 - Forest
% Enumerated_Domain_Value_Definition:
% Tree-covered land where the tree cover density is greater than 10 percent. Note that cleared forest land (i.e., clear-cuts) is mapped according to current cover (e.g., mechanically disturbed or grassland/shrubland).
% Enumerated_Domain_Value_Definition_Source: Trends land-use/land-cover class descriptions
% Enumerated_Domain:
% Enumerated_Domain_Value: 7 - Grassland/Shrubland
% Enumerated_Domain_Value_Definition:
% Land predominately covered with grasses, forbs, or shrubs. The vegetated cover must comprise at least 10 percent of the area.
% Enumerated_Domain_Value_Definition_Source: Trends land-use/land-cover class descriptions
% Enumerated_Domain:
% Enumerated_Domain_Value: 8 - Agriculture
% Enumerated_Domain_Value_Definition:
% Land in either a vegetated or an unvegetated state used for the production of food and fiber. This includes cultivated and uncultivated croplands, hay lands, pasture, orchards, vineyards, and confined livestock operations. Note that forest plantations are considered forests regardless of the use of the wood products.
% Enumerated_Domain_Value_Definition_Source: Trends land-use/land-cover class descriptions
% Enumerated_Domain:
% Enumerated_Domain_Value: 9 - Wetland
% Enumerated_Domain_Value_Definition:
% Land where water saturation is the determining factor in soil characteristics, vegetation types, and animal communities. Wetlands usually contain both water and vegetated cover.
% Enumerated_Domain_Value_Definition_Source: Trends land-use/land-cover class descriptions
% Enumerated_Domain:
% Enumerated_Domain_Value: 10 - Non-mechanically disturbed
% Enumerated_Domain_Value_Definition:
% Land in an altered and often unvegetated state that, due to disturbances by non-mechanical means, is in transition from one cover type to another. Non-mechanical disturbances are caused by fire, wind, floods, animals, and other similar phenomena.
% Enumerated_Domain_Value_Definition_Source: Trends land-use/land-cover class descriptions
% Enumerated_Domain:
% Enumerated_Domain_Value: 11 - Ice and Snow
% Enumerated_Domain_Value_Definition:
% Land where the accumulation of snow and ice does not completely melt during the summer period (e.g., alpine glaciers and snowfields).
% Enumerated_Domain_Value_Definition_Source: Trends land-use/land-cover class descriptions



% % % Version of loading one-time chaneg between
% % % function reference_lct = loadReferenceLCT(tile, year)
% % % %% loadLCTTransition
% % % %
% % % % Input:
% % % % tile          [Char] Tile name of Landsat ARD
% % % % year          [Number] Year of the target
% % % %
% % % % Output:
% % % % reference_lct  [uint8]  Sample layer of the land cover land use transition
% % % %
% % % % see codes of reference from produceReferenceLayerLCT.m/<ProduceReferenceLayer>
% % % 
% % %     min_year = min(odacasets.years); % exclude the LCT images before the study year
% % %     %% Load all years' LCT layer
% % %     folderpath_referencelayer = fullfile(odacasets.pathResultODACA, tile,odacasets.folderTrainingData, odacasets.folderReferenceLayerLCT);
% % %     files_referencelayer = dir(fullfile(folderpath_referencelayer, 'reference*.tif')); % year starts from 1 or 2, eg., 1999, 2001, etc.
% % % 
% % %     %% Process each of the files
% % %     reference_lct = [];
% % %     for i = 1: length(files_referencelayer)
% % %         filename_referencelayer = files_referencelayer(i).name;
% % %         % find start and end years
% % %         nameparts = split(filename_referencelayer, '_');
% % %         st_yr = str2double(nameparts{2});
% % %         ed_yr = str2double(nameparts{3});
% % %         clear nameparts;
% % % 
% % %         % within the data range
% % %         if (min_year <= st_yr) && (st_yr < year && year < ed_yr) % do not exceed the min year & between the two year maps
% % %             reference_lct_i = imread(fullfile(files_referencelayer(i).folder, filename_referencelayer));
% % %             if isempty(reference_lct)
% % %                 reference_lct = reference_lct_i;
% % %             else
% % %                 reference_lct(reference_lct_i>0) = reference_lct_i(reference_lct_i>0); % append to one layer
% % %             end
% % %         end
% % %     end
% % %     clear reference_lct_i;
% % %     
% % %     if isempty(reference_lct)
% % %         return;
% % %     else
% % %         if sum(reference_lct(:)) == 0
% % %             reference_lct = [];
% % %         end
% % %     end
% % %     
% % % end
