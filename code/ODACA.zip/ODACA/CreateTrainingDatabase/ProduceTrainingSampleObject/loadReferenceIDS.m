function sample_layer = loadReferenceIDS(tile, yr)
%LOADIDSINSECT is to load insect in IDS
%
% Input:
% tile     [Char] Tile name of Landsat ARD
% yr       [Number] Year of the target
%
% Output:
% sample_layer  [Logistical]  Sample layer of IDS insect
%
    file_insect = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderReferenceLayerIDS, ...
        sprintf('%s_dca_code_*_%d.tif', tile, yr));
    
    files_insect = dir(file_insect);

    sample_layer = [];
    if isempty(files_insect)
        return;
    end
    for i = 1: length(files_insect)
        sample_layer_tmp = readgeoraster(fullfile(files_insect(i).folder, files_insect(i).name));
        sample_layer_tmp = (sample_layer_tmp > 0 & sample_layer_tmp < 30000) | ...  % codes < 30000 are stress caused by insects
            (sample_layer_tmp == 50003) | ... % codes = 50003 are stress caused by drought
            (sample_layer_tmp == 50007); % codes = 50007 are stress caused by heat
            % code = 50013  wind-tornado/hurricane, but the accuracy is not
            % good enough
        if i == 1
            sample_layer = sample_layer_tmp;
        else
            sample_layer(sample_layer_tmp >  0) = 1;
        end
    end

    if sum(sample_layer(:)) == 0
        sample_layer = []; % back to none
    end
end