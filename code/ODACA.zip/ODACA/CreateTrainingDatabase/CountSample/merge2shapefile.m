% Define folder paths
folder_sampleset_refine = 'TrainingSampleObjectRefineV00';
folder_sampleset_open_source = 'TrainingSampleObject';

folder_samplset = folder_sampleset_open_source;

dir_csv = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSSampleMap/Centriod';

% Get all CSV files in the specified directory
csv_files = dir(fullfile(dir_csv, folder_samplset, '*.csv'));

% Initialize an empty table to hold merged data
data = table(); 

% Load all CSV files
for i = 1:length(csv_files)
    csv_file = csv_files(i);
    % Print the progress
    fprintf('Processing %d/%d csv file: %s\n', i, length(csv_files), csv_file.name);
    
    csv_path = fullfile(csv_file.folder, csv_file.name);
    csv_data = readtable(csv_path, "Delimiter", ','); % Read CSV file
    
    % Merge the data
    data = [data; csv_data]; % Append the current CSV data to the merged table
end

% Check if required coordinate fields exist in the data
if ismember('Latitude', data.Properties.VariableNames) && ismember('Longitude', data.Properties.VariableNames)
    % Create a structure for shapefile
    shapeData = struct('Geometry', cell(height(data), 1), ... % Create empty cell array
                       'Name', cell(height(data), 1), ...      % Create empty cell array
                       'Latitude', zeros(height(data), 1), ... % Initialize as zeros
                       'Longitude', zeros(height(data), 1));   % Initialize as zeros

    % Populate the structure
    for i = 1:height(data)
        shapeData(i).Geometry = 'Point'; % Set geometry type
        shapeData(i).Agent = data.Agent(i); % Replace with your field for names
        shapeData(i).Tile = data.Tile(i); % Replace with your field for names
        shapeData(i).Filename = data.Filename(i); % Replace with your field for names
        shapeData(i).Latitude = data.Latitude(i); % Assign latitude
        shapeData(i).Longitude = data.Longitude(i); % Assign longitude
    end

    % Create the shapefile
    shapefilePath = fullfile(dir_csv, folder_samplset, sprintf('%s.shp', folder_samplset));
    shapewrite(shapeData, shapefilePath);
else
    error('Data must contain Latitude and Longitude fields for shapefile creation.');
end

fprintf('Shapefile created at: %s\n', shapefilePath);
