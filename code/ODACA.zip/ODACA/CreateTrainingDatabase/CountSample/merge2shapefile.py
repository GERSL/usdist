import os
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point

# Define folder paths
# TrainingSampleObjectRefineV00  TrainingSampleObject
folder_samplset = 'TrainingSampleObjectRefine'

dir_csv = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSSampleMap/Centriod'

# Get all CSV files in the specified directory
if folder_samplset == 'TrainingSampleObject':
    csv_files = [os.path.join(dir_csv, folder_samplset, f) for f in os.listdir(os.path.join(dir_csv, folder_samplset)) if f.endswith('.csv')]
else:
    # subfolders: TrainingSampleObjectRefineV00 TrainingSampleObjectRefineV01 TrainingSampleObjectRefineV02
    csv_files = []
    subfolders = [f for f in os.listdir(os.path.join(dir_csv)) if f.startswith('TrainingSampleObjectRefine')]
    for subfolder in subfolders:
        csv_files += [os.path.join(dir_csv, subfolder, f) for f in os.listdir(os.path.join(dir_csv, subfolder)) if f.endswith('.csv')]


# Initialize an empty DataFrame to hold merged data
data = pd.DataFrame() 

# Load all CSV files
for i, csv_file in enumerate(csv_files):
    # Print the progress
    print(f'Processing {i+1}/{len(csv_files)} csv file: {csv_file}')
    
    # csv_path = os.path.join(dir_csv, folder_samplset, csv_file)
    csv_path = csv_file
    csv_data = pd.read_csv(csv_path)  # Read CSV file
    
    # Merge the data
    data = pd.concat([data, csv_data], ignore_index=True)  # Append the current CSV data to the merged DataFrame
    
    # # convert to shapefile and save
    # # Create geometry from latitude and longitude
    # geometry = [Point(xy) for xy in zip(csv_data['Longitude'], csv_data['Latitude'])]
    # geo_data = gpd.GeoDataFrame(csv_data, geometry=geometry)
    # # define crs for the GeoDataFrame
    # geo_data.crs = {'init': 'epsg:4326'}
    # shapefile_path = os.path.join(dir_csv, folder_samplset, f'{csv_file[:-4]}.shp')
    # # Write the GeoDataFrame to a shapefile
    # geo_data.to_file(shapefile_path, driver='ESRI Shapefile')

# report the number of records by each agent
print(data['Agent'].value_counts())


# Check if required coordinate fields exist in the data
if 'Latitude' in data.columns and 'Longitude' in data.columns:
    # Create geometry from latitude and longitude
    geometry = [Point(xy) for xy in zip(data['Longitude'], data['Latitude'])]

    # Create a GeoDataFrame
    geo_data = gpd.GeoDataFrame(data, geometry=geometry)

    # Specify the shapefile path
    shapefile_path = os.path.join(dir_csv, folder_samplset, f'{folder_samplset}.shp')
    # create folder if not exist
    os.makedirs(os.path.join(dir_csv, folder_samplset), exist_ok=True)
    geo_data.crs = {'init': 'epsg:4326'}
    # Write the GeoDataFrame to a shapefile
    geo_data.to_file(shapefile_path, driver='ESRI Shapefile')
else:
    raise ValueError('Data must contain Latitude and Longitude fields for shapefile creation.')

# print(f'Shapefile created at: {shapefile_path}')
