function countSampleObjects(coreid, corenum, varargin)
%% countSampleObjects to collect the sample object's central point
% training samples according the record .mat files
%  INPUTS:
%  coreid:                      ID of core, such as 1, 2, 3, 4, 5, ..., 100
%  corenum:                     Total number of cores, such as 100
%  Last update on Oct., 4, 2022

% sbatch --dependency=afterok:4957856 batchCreateModelReadyPixelTrainingSample.sh
% sbatch --dependency=afterok:4957856 batchCreateModelReadyPixelTrainingSample.sh
% 
% How to use this function? Set the variable 'p' with 'job' or 'sample'
% 1) generate the job list as local .mat at <Jobs> since this will startup dir [once only!]
% 2) startup to create training objects based on the job list
% works b<= MATLAB R2023b
% hiden warning for projection
warning('off','all');

%% Add code paths
restoredefaultpath;
pathparent = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(genpath(pathparent));

%% Setup inputs
if ~exist('coreid', 'var') || ~exist('corenum', 'var')
    coreid = 1; corenum = 1;
end    

%% ARD tiles
ARDTiles = odacasets.ARDTiles; % to read central tiles
ARDTiles = getAdjacentARDTiles(ARDTiles); % to add neighbor tiles

%% define output path
folders_sampleset = {'TrainingSampleObject', 'TrainingSampleObjectRefineV00', 'TrainingSampleObjectRefineV01','TrainingSampleObjectRefineV02'}; % define the folder containing samples, we need to plot as points
for ifd = 1: length(folders_sampleset)
    folder_dataset = folders_sampleset{ifd};
    dir_saving = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSSampleMap/Centriod';
    dir_saving = fullfile(dir_saving, folder_dataset);
    if ~exist(dir_saving, 'dir')
        mkdir(dir_saving);
    end


    %% Path of saple object, such as /gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Classification/h011v017/TrainingData/TrainingSampleObject/
    for iARD = coreid: corenum: length(ARDTiles) % loop ARD to assign different tile to different cores, that will fully use all the computing resources
        % processing tile msg
        fprintf('Processing %d/%d ARD tile: %s\n', iARD, length(ARDTiles), ARDTiles{iARD});
        hv_name = ARDTiles{iARD};
        % check the file exists or not
        filepath_sampleset = fullfile(dir_saving, sprintf('%s_sampleset_centriod.csv', hv_name));
        if exist(filepath_sampleset, 'file')
            fprintf('The file %s exists, skip!\n', filepath_sampleset);
            continue;
        end
        % find a geotif mask as reference
        % i.e., /gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Classification/h011v017/AuxilliaryData/DEM/h011v017_dem.tif
        filepath_ref = fullfile(odacasets.pathResultODACA, hv_name,odacasets.folderAuxilliaryData, odacasets.folderDEM, sprintf('%s_dem.tif', hv_name));
        % read the reference geotif
        info = geotiffinfo(filepath_ref);
        % loop groups to save memeroy loaded
        sample_objs = dir(fullfile(odacasets.pathResultODACA, hv_name, odacasets.folderTrainingData, folder_dataset, 'record_samples_*.mat'));
        % create a table with tile, record_name, agent, lat, lon
        % Step 1: Create an empty structure array
        sampleset = struct('Tile', {}, 'Agent', {}, 'Year', {}, 'Filename', {} ,'Latitude', {}, 'Longitude', {});
        for irec = 1: length(sample_objs)
            % to get the agent namd according to the filename
            % i.e., record_samples_1.mat
            rec_filename = sample_objs(irec).name;
            % split the filename by _
            agent_name = strsplit(rec_filename, '_');
            % get the agent name at 3
            % agent_name = agent_name{3};
            % get the data year
            % if 4 is number, then it is year
            if sum(isstrprop(agent_name{4}, 'digit')) > 0
                data_year = agent_name{4};
                agent_name = agent_name{3};
            else
                data_year = agent_name{5};
                % if 4 is not number, then the agent name is to merge with 3 and 4 by _
                agent_name = sprintf('%s_%s', agent_name{3}, agent_name{4});
            end

            % the file path of the record
            filepath_sample_obj = fullfile(sample_objs(irec).folder, sample_objs(irec).name);
            load(filepath_sample_obj); % record_objs_sample
            % to get the sample 
            for isam = 1: length(record_objs_samples)
                sample_obj = record_objs_samples(isam);
                pixel_id_list = sample_obj.PixelIdxList;
                % convert to row and col % to fit the COLD pos.
                [col, row] = ind2sub(info.Height, pixel_id_list);

                % to get the geometric center (that is centroid) of the sample object
                sample_obj_centroid= [mean(row), mean(col)];
                % Get the raster reference object from the GeoTIFF info
                R = info.RefMatrix; % Or use 'info.SpatialRef' if it's available
                [x_projected, y_projected] = pix2map(R, sample_obj_centroid(1), sample_obj_centroid(2));
                [sample_obj_lat, sample_obj_lon] = projinv(info.SpatialRef.ProjectedCRS, x_projected, y_projected);
        

                % Populate the structure
                sampleset(end + 1) = struct('Tile', hv_name, 'Agent', agent_name, 'Year', str2num(data_year), 'Filename', rec_filename,'Latitude', sample_obj_lat, 'Longitude', sample_obj_lon);
            end
        end
        % Save the table as a CSV file
        writetable(struct2table(sampleset), filepath_sampleset);
    end
end
end