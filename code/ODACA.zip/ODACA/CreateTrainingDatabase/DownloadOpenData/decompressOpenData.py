import os
import datetime
import time
import rasterio
from rasterio import warp
from rasterio.merge import merge
import pyproj
import numpy as np
from pathlib import Path
import click
import glob
import pandas as pd
import geopandas as gpd
import zipfile as zf

filepath_landfire = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Reference/LandFire/LF_Public_Events_1999_2022.zip'
dirpath_landfire = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Reference/Temp/LandFire'

dirpath_ids_src = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Reference/IDS/'
dirpath_ids_des = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Reference/Temp/IDS'


filepath_nlcd = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Reference/NLCD/NLCD_science_products_2021_release_all_files_20230630.zip'
dirpath_nlcd_des = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Reference/Temp/NLCD'

filepath_mtbs = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Reference/MTBS/mtbs_perimeter_data_1984_2022.zip'
dirpath_mtbs_des = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Reference/Temp/MTBS'

filepath_lct = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Reference/LandCoverTrends/ds844_national.zip'
dirpath_lct_des = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Reference/Temp/LandCoverTrends'

def process_landfire():
    # uncompress the landfire data by python
    print('Uncompressing {}\n'.format(filepath_landfire))
    os.system('unzip -o {} -d {}'.format(filepath_landfire, dirpath_landfire))
    
    # read CONUS_230_PublicModelReadyEvents from the geodatabase
    print('Reading LF_Public_Events_1999_2022 from the geobase\n')
    ld_gpd = gpd.read_file(os.path.join(dirpath_landfire, 'LF_Public_Events_1999_2022.gdb'), driver='FileGDB', layer='CONUS_230_PublicModelReadyEvents')
    
    # select the data for each year, and save it to shapefile format and exclude nan values
    years = ld_gpd['Year'].unique()
    # exclude nan values and sort the years
    years = years[~np.isnan(years)]
    years = np.sort(years)
    for i in years:
        print('Processing {}\n'.format(i))
        ld_gpd_yr = ld_gpd[ld_gpd['Year'] == i]
        ld_gpd_yr = ld_gpd_yr.drop(columns=['Start_Date', 'End_Date']) # drop the columns of Start_Date and End_Date that are not needed and are not suppored by shapefile when exporting it
        
        # check out the columns of Severity and Event_Type according its offical document from landfire
        # replace severity values with integer values, and not senstive to case
        # severity values: Low, Moderate, High to lower case and remove spaces
        # remove spaces for the severity
        ld_gpd_yr['Severity'] = ld_gpd_yr['Severity'].str.replace(' ', '')
        ld_gpd_yr['Severity'] = ld_gpd_yr['Severity'].str.lower()
        ld_gpd_yr['Severity'] = ld_gpd_yr['Severity'].replace('low', 1)
        ld_gpd_yr['Severity'] = ld_gpd_yr['Severity'].replace('low/moderate', 2)
        ld_gpd_yr['Severity'] = ld_gpd_yr['Severity'].replace('moderate/low', 2)
        ld_gpd_yr['Severity'] = ld_gpd_yr['Severity'].replace('moderate', 3)
        ld_gpd_yr['Severity'] = ld_gpd_yr['Severity'].replace('moderate/high', 4)
        ld_gpd_yr['Severity'] = ld_gpd_yr['Severity'].replace('high/moderate', 4)
        ld_gpd_yr['Severity'] = ld_gpd_yr['Severity'].replace('high', 5)
        # replace empty values with 0
        ld_gpd_yr['Severity'] = ld_gpd_yr['Severity'].replace('', 0) # replace empty values with 0
        ld_gpd_yr['Severity'] = ld_gpd_yr['Severity'].replace('unchanged', 0) # replace empty values with 0
        # replace none values with 0
        ld_gpd_yr['Severity'] = ld_gpd_yr['Severity'].replace(np.nan, 0) # replace empty values with 0
        ld_gpd_yr['Severity'] = ld_gpd_yr['Severity'].astype(int)
        
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].str.replace(' ', '')
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].str.lower()
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('development', 1)
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('clearcut', 2)
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('harvest', 3)
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('thinning', 4)
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('mastication', 5)
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('othermechanical', 6)
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('wildfire', 7)
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('wildlandfireuse', 8)
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('prescribedfire', 9)
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('wildlandfire', 10)
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('weather', 11)
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('insecticide', 12)
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('chemical', 13)
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('insects', 14)
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('disease', 15)
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('insects/disease', 16)
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('herbicide', 17)
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('biological', 18)
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('planting', 19)
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('reforestation', 20) # Reforestation reestablishing a vegetative community by planting 
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('seeding', 21)
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace('', 0) # replace empty values with 0
        
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].replace(np.nan, 0) # replace empty values with 0
        ld_gpd_yr['Event_Type'] = ld_gpd_yr['Event_Type'].astype(int)
        
        # create new columm, Even_STyID, the columns of Severity and Event_Type to a new column of Event_Type_Severity
        ld_gpd_yr['Even_STyID'] = 100*ld_gpd_yr['Severity'] + ld_gpd_yr['Event_Type'] # 100* !Severity! + !Event_Type!
        
        # save the data to shapefile format
        ld_gpd_yr.to_file(os.path.join(dirpath_landfire, 'landfire_{}.shp'.format(int(i))))
        
def process_ids():
    # search files in the directory
    file_regions = glob.glob(os.path.join(dirpath_ids_src, '*.zip'))
    # sort the files
    
    # loop each of file
    for file_region in file_regions:
        print('Uncompressing {}\n'.format(file_region))
        os.system('unzip -o {} -d {}'.format(file_region, dirpath_ids_des))
        
        filename_region = Path(file_region).stem
        region_name = filename_region.split('_')[1]
        region_number = region_name[6:]
        # read the data from the geodatabase
        print('Reading IDS data from the geodatabase\n')
        damage_gpd = gpd.read_file(os.path.join(dirpath_ids_des, filename_region), driver='FileGDB', layer='DAMAGE_AREAS_FLAT_AllYears_CONUS_Rgn{}'.format(region_number))
        # survey_gpd = gpd.read_file(os.path.join(dirpath_ids_des, 'IDS.gdb'), driver='FileGDB', layer='SURVEYED_AREAS_FLAT_AllYears_CONUS_Rgn1')
        
        # select the data for each year, and save it to shapefile format and exclude nan values
        years = damage_gpd['SURVEY_YEAR'].unique()
        # exclude nan values and sort the years
        years = years[~np.isnan(years)]
        years = np.sort(years)
        for i in years:
            print('Processing {}\n'.format(i))
            damage_gpd_yr = damage_gpd[damage_gpd['SURVEY_YEAR'] == i]
            
            # ESRI Shapefile does not support datetime fields
            damage_gpd_yr = damage_gpd_yr.drop(columns=['CREATED_DATE', 'MODIFIED_DATE']) # drop the columns of Start_Date and End_Date that are not needed and are not suppored by shapefile when exporting it
        
            # save the data to shapefile format
            damage_gpd_yr.to_file(os.path.join(dirpath_ids_des, 'region{}_{}.shp'.format(region_number, int(i))))

def process_nlcd():
    # uncompress the nlcd data by python
    print('Uncompressing {}\n'.format(filepath_nlcd))
    # create folder if it does not exist
    Path(dirpath_nlcd_des).mkdir(parents=True, exist_ok=True)
    # uncompressed the file
    with zf.ZipFile(filepath_nlcd, 'r') as zip_ref:
        zip_ref.extractall(dirpath_nlcd_des)

def process_lct():
    # uncompress the nlcd data by python
    print('Uncompressing {}\n'.format(filepath_lct))
    # create folder if it does not exist
    Path(dirpath_lct_des).mkdir(parents=True, exist_ok=True)
    # uncompressed the file
    with zf.ZipFile(filepath_lct, 'r') as zip_ref:
        zip_ref.extractall(dirpath_lct_des)
    

def process_mtbs():
    # uncompress the nlcd data by python
    print('Uncompressing {}\n'.format(filepath_mtbs))
    # create folder if it does not exist
    Path(dirpath_mtbs_des).mkdir(parents=True, exist_ok=True)
    
    # uncompressed the file
    with zf.ZipFile(filepath_mtbs, 'r') as zip_ref:
        zip_ref.extractall(dirpath_mtbs_des)
        
    # read CONUS_230_PublicModelReadyEvents from the geodatabase
    print('Reading mtbs_perims_DD.shp\n')
    mtbs_gpd = gpd.read_file(os.path.join(dirpath_mtbs_des, 'mtbs_perims_DD.shp'))
    
    # converty to datetime
    mtbs_gpd['Ig_Date'] = pd.to_datetime(mtbs_gpd['Ig_Date'])
    mtbs_gpd['Year']    = mtbs_gpd['Ig_Date'].dt.year
    mtbs_gpd['Month']   = mtbs_gpd['Ig_Date'].dt.month
    mtbs_gpd['Day']     = mtbs_gpd['Ig_Date'].dt.day
    
    # exclude nan values and sort the years
    years = mtbs_gpd['Year'].unique()
    years = np.sort(years)
    for i in years:
        print('Processing {}\n'.format(i))
        mtbs_gpd_yr = mtbs_gpd[mtbs_gpd['Year'] == i]
        mtbs_gpd_yr = mtbs_gpd_yr.drop(columns=['Ig_Date']) # drop the columns of Ig_Date that are not needed and are not suppored by shapefile when exporting it
        # save the data to shapefile format
        mtbs_gpd_yr.to_file(os.path.join(dirpath_mtbs_des, 'mtbs_{}.shp'.format(int(i))))
    

def empty_storage(dir, key_remain):
    files = glob.glob(os.path.join(dir, '*'))
    for fil in files:
        need2remove = True
        for key in key_remain:
            if key in Path(fil).stem:
                need2remove = False
                break
        if need2remove:
            os.system('rm -r {}'.format(fil))
            print('Removed {}\n'.format(fil))
            
def remove_files(dir, key):
    files = glob.glob(os.path.join(dir, '*{}*'.format(key)))
    for fil in files:
        os.system('rm -r {}'.format(fil))

# Main function
if __name__ == "__main__":
    
    # Process landfire data
    # process_landfire()
    # empty_storage(dirpath_landfire, ['landfire'])
    
    # MTBS
    # process_mtbs()
    # remove_files(dirpath_mtbs_des, 'mtbs_perims_DD') # remove the files that are not needed
    
    # USFS IDS
    # process_ids()
    # empty_storage(dirpath_ids_des, ['region', 'IDS2_FlatFiles_Readme.pdf'])
    
    # USGS Land Cover Trends
    process_lct()
    
    # NLCD
    # process_nlcd()
    # dirpath_nlcd_des = os.path.join(dirpath_nlcd_des, Path(filepath_nlcd).stem) # the folder name is the same as the file name by using unzipfile
    # empty_storage(dirpath_nlcd_des, ['Land_Cover_Science_Product', 'land_cover_science_product'])