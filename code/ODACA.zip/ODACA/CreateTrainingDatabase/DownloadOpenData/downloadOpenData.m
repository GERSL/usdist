%% Download all the open-source datasets
% By shi qiu
% Last updated on 3/29/3024

%% Setup paths
restoredefaultpath;
pathpackage = fileparts(fileparts(fileparts(mfilename('fullpath')))); 
addpath(genpath(pathpackage));


%% NLCD     -2021
% Download the NLCD science product bundle from
% https://www.mrlc.gov/nlcd-2021-science-research-products
fprintf('Downloading NLCD\n');
download_data_by_url('https://s3-us-west-2.amazonaws.com/mrlc/NLCD_science_products_2021_release_all_files_20230630.zip', odacasets.pathDataNLCDSci);

%% GSWO 1986-2022
% Download JRC Yearly Water Classification History, v1.4 from
% https://developers.google.com/earth-engine/datasets/catalog/JRC_GSW1_4_YearlyHistory
% please use python script to download this dataset, with geeup package
% installed downloadGSWO.py, which directly download the dataset to each ARD tile


%% MTBS 1984-2022
% https://mtbs.gov/direct-download 
fprintf('Downloading MTBS\n');
download_data_by_url('https://edcintl.cr.usgs.gov/downloads/sciweb1/shared/MTBS_Fire/data/composite_data/burned_area_extent_shapefile/mtbs_perimeter_data.zip', odacasets.pathDataMTBS);

%% Land Cover Trends 2000-2011
% https://www.usgs.gov/data/land-cover-trends-dataset-2000-2011
fprintf('Downloading Land Cover Trends\n');
download_data_by_url('https://www.sciencebase.gov/catalog/item/5ec6b77682ce476925eddbda', odacasets.pathDataLCT);

%% LandFire 1999-2022 -- LF 2022
% websit: https://landfire.gov/version_download.php#
fprintf('Downloading LandFire\n');
download_data_by_url('https://landfire.gov/zip/LF_Public_Events_1999_2022.zip', odacasets.pathDataUSGSLandFireEvent);


%% USFS IDS      -2023
fprintf('Downloading IDS\n');
download_data_by_url('https://www.fs.usda.gov/foresthealth/docs/IDS_Data_for_Download/CONUS_Region1_AllYears.gdb.zip', fullfile(odacasets.pathDataUSFSIDS, 'CONUS_Region1_AllYears.gdb.zip'))
download_data_by_url('https://www.fs.usda.gov/foresthealth/docs/IDS_Data_for_Download/CONUS_Region2_AllYears.gdb.zip', fullfile(odacasets.pathDataUSFSIDS, 'CONUS_Region2_AllYears.gdb.zip'))
download_data_by_url('https://www.fs.usda.gov/foresthealth/docs/IDS_Data_for_Download/CONUS_Region3_AllYears.gdb.zip', fullfile(odacasets.pathDataUSFSIDS, 'CONUS_Region3_AllYears.gdb.zip'))
download_data_by_url('https://www.fs.usda.gov/foresthealth/docs/IDS_Data_for_Download/CONUS_Region4_AllYears.gdb.zip', fullfile(odacasets.pathDataUSFSIDS, 'CONUS_Region4_AllYears.gdb.zip'))
download_data_by_url('https://www.fs.usda.gov/foresthealth/docs/IDS_Data_for_Download/CONUS_Region5_AllYears.gdb.zip', fullfile(odacasets.pathDataUSFSIDS, 'CONUS_Region5_AllYears.gdb.zip'))
download_data_by_url('https://www.fs.usda.gov/foresthealth/docs/IDS_Data_for_Download/CONUS_Region6_AllYears.gdb.zip', fullfile(odacasets.pathDataUSFSIDS, 'CONUS_Region6_AllYears.gdb.zip'))
% no Region #7
download_data_by_url('https://www.fs.usda.gov/foresthealth/docs/IDS_Data_for_Download/CONUS_Region8_AllYears.gdb.zip', fullfile(odacasets.pathDataUSFSIDS, 'CONUS_Region8_AllYears.gdb.zip'))
download_data_by_url('https://www.fs.usda.gov/foresthealth/docs/IDS_Data_for_Download/CONUS_Region9_AllYears.gdb.zip', fullfile(odacasets.pathDataUSFSIDS, 'CONUS_Region9_AllYears.gdb.zip'))


%% Other funtions required
function download_data_by_url(url_src, filepath_des)
    if ~isfolder(fileparts(filepath_des))
        mkdir(fileparts(filepath_des));
    end
    if ~isfile(filepath_des)
        websave(filepath_des,url_src);
    end
end