## geemap requires installation (pip install geemap) 
# https://geemap.org/
# env: geepy310

import os
import rasterio
from rasterio import warp
from rasterio.merge import merge
import pyproj
import numpy as np
from pathlib import Path
import click
import ee
import geemap
import glob


###################################################################################
ee.Initialize()
###################################################################################

@click.command()
@click.option("--ci",          "-i", default=1, type=int, help="The core's id")
@click.option("--cn",          "-n", default=1, type=int, help="The number of cores")
@click.option("--destination", "-l", default="/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Classification/", type=str, help="The filepath of the data's location")
def main(ci, cn, destination):
   # msg of core
   print('\n*****************************************************************************************************')
   print('* RC Yearly Water Classification History for CONUS')
   print('* Core: {:04d}/{:04d}\n'.format(ci, cn))
   
   # search folder of tile
   tile_list  = sorted(glob.glob(os.path.join(destination, 'h*')))
   
   # for each tile
   for itile in range(ci-1, len(tile_list), cn):
      tile = tile_list[itile]
      tile_name = Path(tile).stem
      # the destination
      dir_gswo_tile = os.path.join(destination, tile_name, 'TrainingData', 'ReferenceLayerGSWO')
      Path(dir_gswo_tile).mkdir(parents=True, exist_ok=True)
      
      # the image-like using the dem data to obtain the extent's latitude and longitude
      filepath_tile_dem = os.path.join(destination, tile_name, 'AuxilliaryData', 'DEM', '{}_dem.tif'.format(tile_name))
      with rasterio.open(filepath_tile_dem) as imagelike:
         left, bottom, right, top = imagelike.bounds
         
         # x-y to lat-long
         transformer = pyproj.Transformer.from_crs(imagelike.crs._crs, "epsg:4326")
      [lats, lons] = transformer.transform([left, right, left, right], [top, top, bottom, bottom]) # x y
   
      # for each year
      for i in range(1984, 2022): # 1984 to 2021 for v 1.4
         print('Processing {} {}\n'.format(tile_name, i))
         yr = str(i)
         filepath_water = os.path.join(dir_gswo_tile, '{}_water_class_{}.tif'.format(tile_name, yr))
         filepath_mosaic= os.path.join(dir_gswo_tile, '{}_water_class_{}.temp.tif'.format(tile_name, yr))
         if os.path.exists(filepath_water) and not os.path.exists(filepath_mosaic): # final file exists but temp file does not
            print('Exist {} {}\n'.format(tile_name, i))
            continue
         
         collection = (ee.ImageCollection('JRC/GSW1_4/YearlyHistory').filterDate("{}-01-01".format(yr), "{}-12-31".format(yr)))
         image = collection.first()
         
         # step 1. cut of the extent into small pieces by adjusting the lat and long numbers
         size_degree = 1
         ipart = 1
         for lat in np.arange(min(lats), max(lats), size_degree):
            for lon in np.arange(min(lons), max(lons), size_degree):
               lon_min = lon
               lon_max = lon + size_degree
               lat_min = lat
               lat_max = lat + size_degree
               roi = ee.Geometry.BBox(lon_min, lat_min, lon_max, lat_max).buffer(distance=10000) # 10 km buffer
               geemap.ee_export_image(image, filename=os.path.join(dir_gswo_tile, '{}.part{:03d}.tif'.format(yr, ipart)), scale=30, region=roi, file_per_band=True)
               ipart+=1
               
         # step2. mosaic the small pieces into one image
         files_list = [os.path.join(dir_gswo_tile, '{}.part{:03d}.waterClass.tif'.format(yr, i)) for i in range(1, ipart)]
         src_files_to_mosaic = []
         for fp in files_list:
               src = rasterio.open(fp)
               src_files_to_mosaic.append(src)
         mosaic, out_trans = merge(src_files_to_mosaic, nodata=None)
         # save as to local geotiff
         out_meta = src.meta.copy()
         out_meta.update({"driver": "GTiff",
                           "dtype": "uint8",
                           "height": mosaic.shape[1],
                           "width": mosaic.shape[2],
                           "transform": out_trans,})
         with rasterio.open(filepath_mosaic, "w", **out_meta) as dest:
               dest.write(mosaic)
         
         # step 3. warp the mosaic image to the same extent as the DEM image by rasterio
         with rasterio.open(filepath_mosaic, 'r') as src_mask: # obtain the resource dataset
            des_profile = src_mask.meta.copy()
            # update the profile to the image-like
            des_profile.update({
               'crs':          imagelike.crs,
               'transform':    imagelike.transform,
               'width':        imagelike.width,
               'height':       imagelike.height
               })
      
            # save as local file # warp as the destination geotif
            with rasterio.open(filepath_water, 'w', **des_profile) as dst_mask:
                  for i in range(1, src_mask.count + 1):
                     warp.reproject(
                        source          =   rasterio.band(src_mask, i),
                        destination     =   rasterio.band(dst_mask, i),
                        src_transform   =   src_mask.transform,
                        src_crs         =   src_mask.crs,
                        dst_transform   =   des_profile['transform'],
                        dst_crs         =   des_profile['crs'],
                        resampling      =   warp.Resampling.nearest,
                        dst_nodata      =   src_mask.nodata
                        )
         
         # step 4. delete the small pieces
         for fp in files_list: os.remove(fp)
         os.remove(filepath_mosaic)
# Main function
if __name__ == "__main__":
    main()