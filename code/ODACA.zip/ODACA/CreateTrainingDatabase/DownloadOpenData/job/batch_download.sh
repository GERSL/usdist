#!/bin/bash
#SBATCH -J down # jobname
#SBATCH --partition=general
#SBATCH --nodes 1 
#SBATCH --ntasks 1
#SBATCH --array 1-5
#SBATCH --mem-per-cpu=10G
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err

echo $SLURMD_NODENAME # display the node name

# start up conda
. "/home/shq19004/miniconda3/etc/profile.d/conda.sh"
conda activate geepy310

# at the code package
cd ../

python ./downloadGSWO.py -l '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Classification' -i $SLURM_ARRAY_TASK_ID -n $SLURM_ARRAY_TASK_MAX


exit

#SBATCH --partition=general

#SBATCH --partition=priority
#SBATCH --account=zhz18039

#SBATCH --partition=osg
#SBATCH --account=osgusers

#SBATCH --partition=priority-gpu
#SBATCH --account=sas18043
#SBATCH --qos=sas18043a100


#SBATCH --partition=general-gpu