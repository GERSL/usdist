function batchProduceReferenceLayer(jobid, jobnum)
%% This is to generate the training sample layers for each ARD tile

%% Add code paths
restoredefaultpath;
pathpackage = fileparts(fileparts(fileparts(mfilename('fullpath')))); 
addpath(genpath(pathpackage));

if ~exist('jobid', 'var') || ~exist('jobnum', 'var')
    jobid = 1; jobnum = 1;
end

%% ARD tiles
ARDTiles = odacasets.ARDTiles; % to read central tiles
ARDTiles = getAdjacentARDTiles(ARDTiles); % to add neighbor tiles

%% sample data' names
datanames = {'Interpreted'};
% note that the debris samples were interpreted based on potential layer
% created from open data such as landslide and wind events
isupdate = true; % force to update all the data even though it exists

%% Assign tasks first
objtasks = [];
for iARD = 1: length(ARDTiles)
    hv_name = ARDTiles{iARD};
    for ipro = 1: length(datanames)
        % control years
        years = 0;
        % loop years
        for iyr = 1: length(years)
            ic = length(objtasks) + 1;
            objtasks(ic).tile = hv_name;
            objtasks(ic).dataname = datanames{ipro};
            objtasks(ic).year = years(iyr);
        end
    end
end

rng(1);
objtasks = objtasks(randperm(length(objtasks)));

%% Process each task
for itask = jobid: jobnum: length(objtasks)
    taskobj = objtasks(itask);
    switch lower(taskobj.dataname)
        case 'interpreted'
            % produceReferenceLayerInterpretedAgent(taskobj.tile, isupdate); % do not support the set of update
            produceReferenceLayerInterpretedYear(taskobj.tile, isupdate); % do not support the set of update
            % produceReferenceLayerInterpretedSample(taskobj.tile, odacasets.refineSampleCollection);
    end
end % end of parallel computing

end % end of function

