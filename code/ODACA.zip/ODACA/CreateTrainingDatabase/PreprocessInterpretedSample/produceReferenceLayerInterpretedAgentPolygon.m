function produceReferenceLayerInterpretedAgentPolygon(tile)
% This tool process the interpreted samples with polygons, in which we
% labeled the agent should be and the start_year, end_year, and previous
% classified agent. We can use this tool to generate the raster, of which
% pixel value is the agent code should be, of which file name will be like
% 'hhhvvv_startyear_endyear_agentcode_previousagentcodes.tif'

