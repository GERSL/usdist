function produceReferenceLayerInterpretedSample(tile, collection)
% produceReferenceLayerInterpretedSample is to produce reference training
% samples based on the interpreted sample data.

% tile = 'h003v009';


%% where the new samples will be saved
folderpath_sample = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderReferenceLayerInterpreted); % output's folder
if ~isfolder(folderpath_sample)
    mkdir(folderpath_sample);
end

filepath_tile_extent = fullfile(odacasets.pathResultCOLD, tile, 'singlepath_landsat.tif'); % Find out the tile extent

%% When the disturbance year and the agent were interpreted based on the prelimiary disturbance agent maps
filepath_sample = odacasets.pathDataInterpretedCOLDSamples;

sample = [];
if strcmpi(shapeinfo(filepath_sample).ShapeType, 'point')
    %% get the pixel from the training points
%     if collection == 1
%         filename_sample = sprintf('samples_interpreted_%s.mat', tile); % for the first version, at the moment, we did not use the collection numebr appended to the filename
%     elseif collection > 1
    filename_sample = sprintf('samples_interpreted_%s_c%02d_point.mat', tile, collection);
%     end

    sample_conus = shaperead(filepath_sample);
    [~, R] = readgeoraster(filepath_tile_extent);
    rastersize = R.RasterSize; % convert to image later on, which can be same format as to the previous version.
    [x, y] = projfwd(R.ProjectedCRS, [sample_conus.lat], [sample_conus.lon]);
    [row, col] = worldToDiscrete(R, x, y);
    id_list =find(~isnan(row) &  ~isnan(col));
    if ~isempty(id_list)
        sample_tile = sample_conus(id_list);
        row = row(id_list);
        col = col(id_list);
        row = num2cell(row);
        col = num2cell(col);
        [sample_tile.raster_row] = deal(row{:});
        [sample_tile.raster_col] = deal(col{:});
        sample = sample_tile;
        save(fullfile(folderpath_sample, filename_sample), 'sample', 'rastersize');
    end
else
    %% get the rasterized geotiff
    % This tool process the interpreted samples with polygons, in which we
    % labeled the agent should be and the start_year, end_year, and previous
    % classified agent. We can use this tool to generate the raster, of which
    % pixel value is the agent code should be, of which file name will be like
    % 'hhhvvv_startyear_endyear_agentname.tif', of which pixel value can be
    % the ones relative to the colmun 'classified'
 
%     basedmap = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSLandDisturbanceV041'; % based this disturbance agent maps to select the polygons

    basedmap = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSProductMapV06'; % based this disturbance agent maps to select the polygons

    % extract the unique interpreted layer on 
    % 'classified' 
    % 'start_year'
    % 'end_year'
    % 'agent'
    sample_conus = shaperead(filepath_sample);
%     classified = {sample_conus.classified};
%     start_year = {sample_conus.start_year};
%     end_year = {sample_conus.end_year};
%     agent = {sample_conus.agent};
%     classified = vertcat(classified{:});
%     start_year = vertcat(start_year{:});
%     end_year = vertcat(end_year{:});
%     agent = vertcat(agent{:});
%     sample_unique_features = table(classified, start_year, end_year, agent);
%     sample_unique_features= unique(sample_unique_features);

    sample_unique_features = struct2table(sample_conus);
    classified = sample_unique_features.classified;
    start_year = sample_unique_features.start_year;
    end_year = sample_unique_features.end_year;
    agent = sample_unique_features.agent;
    sample_unique_features = table(classified, start_year, end_year, agent);
    sample_unique_features= unique(sample_unique_features);
   
    agents = odacasets.agents;


    % filter out the unique rows
    for iu = 1: height(sample_unique_features)
        start_year = sample_unique_features(iu,:).start_year;
        end_year = sample_unique_features(iu,:).end_year;
        agents_classified = sample_unique_features(iu,:).classified{1};
        agent = sample_unique_features(iu,:).agent{1};
        % convert the agent names to their code
        agents_classified_code = convertClassified2Codes(agents, split(agents_classified, ',')); 
        agent_code = getfield(agents, agent);

        % select the current unique sample dataset
        sample_conus_unique = sample_conus(ismember({sample_conus(:).classified}, agents_classified) & ...
            [sample_conus(:).start_year] == start_year & ...
            [sample_conus(:).end_year]== end_year & ...
            ismember({sample_conus(:).agent}, agent) ,:);

        % set up a static value to mask the polygons
        [sample_conus_unique(:).pixelvalue] = deal(1);
        
        % save the shapfile
        filename_sample = sprintf('samples_interpreted_%s_c%02d_%d_%d_%s_%s.shp', tile, collection, start_year, end_year, agent, agents_classified);
        filepath_out_shp =  fullfile(folderpath_sample, filename_sample);
        shapewrite(sample_conus_unique, filepath_out_shp);

        % copy the shapefile's .prj
        filepath_src_prj = strrep(filepath_sample, '.shp', '.prj');
        filepath_des_prj = strrep(filepath_out_shp, '.shp', '.prj');
        copyfile(filepath_src_prj, filepath_des_prj);
        
        
        % rasterize the shapfile with polygons to geotiff 
        filepath_des_tif = strrep(filepath_out_shp, '.shp', '.tif');

        % the first number is the agent should be, the remaining numbers are the agent classified at the previous round
        rasterizeShapfilePyGDAL(filepath_out_shp, filepath_tile_extent, filepath_des_tif, 'pixelvalue', 'byte'); 
        fprintf('Create raster dataset : %s \n', filepath_des_tif);

        % convert as .mat
        sample_layer = imread(filepath_des_tif);
        % only when any interprated polygons given
        if sum(sample_layer(:)) > 0
            % read the previous disturbance agent map for each year
            for yr = start_year: end_year
%                 map_disturb = load_disturbance_map(basedmap, yr, 'AGENT', str2num(tile(2:4)), str2num(tile(6:8)), 'V04');
                map_disturb = load_disturbance_map(basedmap, yr, 'APRI', str2num(tile(2:4)), str2num(tile(6:8)), 'V06');
                for ig = 1: length(agents_classified_code)
                    [row, col] = find(sample_layer == 1 & map_disturb == agents_classified_code(ig)); % find the overloped pixels
                    if ~isempty(row)
                        agent_id = repmat(agent_code, size(row));
                        year = repmat(yr, size(row));
                        raster_row = row;
                        raster_col = col;
                        sample_tile = table(raster_row, raster_col,agent_id, year);
                        sample_tile = table2struct(sample_tile);
                        sample = [sample; sample_tile];
                    end
                end
            end
        end
        
        % delete the temporal files
        delete(filepath_des_tif);
        delete(strrep(filepath_des_tif, '.tif', '.dbf'));
        delete(strrep(filepath_des_tif, '.tif', '.prj'));
        delete(strrep(filepath_des_tif, '.tif', '.shp'));
        delete(strrep(filepath_des_tif, '.tif', '.shx'));

    end

    if ~isempty(sample)
        [~, R] = readgeoraster(filepath_tile_extent);
        rastersize = R.RasterSize; % convert to image later on, which can be same format as to the previous version.
        filename_sample = sprintf('samples_interpreted_%s_c%02d_polygon.mat', tile, collection);
        save(fullfile(folderpath_sample, filename_sample), 'sample', 'rastersize');
    end

end
fprintf('Finish extracing samples for %s with %05d points\r', tile, length(sample));



end

function pixel_value = convertClassified2Codes(agents, classified_types)
    pixel_value = [];
    for i = 1: length(classified_types)
        agent_code = getfield(agents, classified_types{i});
        pixel_value = [pixel_value, agent_code];
    end
end

function map_disturb = load_disturbance_map(dir_map, yr, key, h, v, version)
    mapname = sprintf('CD_%03d%03d_%04d_%s', h, v, yr, version);
    filepath_map = fullfile(dir_map, sprintf('h%03dv%03d', h, v), mapname, sprintf('%s_%s.tif', mapname, key));
    map_disturb = imread(filepath_map);
end
