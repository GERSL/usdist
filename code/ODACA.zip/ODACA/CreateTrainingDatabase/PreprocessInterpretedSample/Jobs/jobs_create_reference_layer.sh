#!/bin/bash
#SBATCH -J sample
#SBATCH --partition=general
#SBATCH --constraint='epyc128' # Target the AMD Epyc node architecture
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --array 1-100
#SBATCH --mem-per-cpu=20G
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err



# Go back to <COLD_v2>
cd ../

module load matlab
matlab -nodisplay -singleCompThread -r "batchProduceReferenceLayer($SLURM_ARRAY_TASK_ID, $SLURM_ARRAY_TASK_MAX); exit"

