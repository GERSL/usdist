function produceReferenceLayerInterpretedYear(tile, isupdate)
% PRODUCEREFERENCELAYERINTERPRETEDYear Produce interpreted samples
% The debris may be caused by earthquake as well as wind evens
%
% Input:
% tile       [Char] Tile name of Landsat ARD
    
    %% Setup the function
    filename_yearly_sample = 'samples_interpreted_%d_%s.tif'; % Define the file name that will be exported
    agents = odacasets.agents; % agents that were defined or focused on
    
    folderpath_sample = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderReferenceLayerInterpreted); % output's folder
    if isupdate && isfolder(folderpath_sample) % force to update
        rmdir(folderpath_sample, 's');
    end
    if ~isfolder(folderpath_sample)
        mkdir(folderpath_sample);
    end

    filepath_hv_extent = fullfile(odacasets.pathResultODACA, tile, odacasets.folderAuxilliaryData, odacasets.folderDEM, sprintf('%s_dem.tif', tile)); % Find out the tile extent

    %% When the disturbance year was interpreted for each agent
    interpreted_struct = odacasets.pathDataInterpretedCOLDSamplesLabelYear;
    if ~isempty(interpreted_struct)
        agentnames = fieldnames(interpreted_struct); % get LIST of agent names
        for i = 1: length(agentnames) % for each agent names
            %% Agent's name, code, and filepath
            agentname = agentnames{i}; % agent name
            agentcode = getfield(agents, agentname); %#ok<GFLD> % code
            filepaths = getfield(interpreted_struct, agentname); %#ok<GFLD> % file path
            %% Process each file
            for j = 1: length(filepaths)
                % file info
                filepath_shp = filepaths{j};
                [~, filename] = fileparts(filepath_shp);
                filepath_sample = fullfile(folderpath_sample, sprintf('%s_%s.tif', agentname, filename));
                
                % rasterize shpefile to raster
                rasterizeShapfilePyGDAL(filepath_shp, filepath_hv_extent, filepath_sample, 'Year', 'uint16'); % year
                fprintf('Created: %s\n', filepath_sample);

                % save as yearly image with pixel value as agent
                disturbance_label_year = GRIDobj(filepath_sample);
                years_interpreted = unique(disturbance_label_year.Z(:));
                years_interpreted = years_interpreted(ismember(years_interpreted, odacasets.years)); % only within the defined years
                for i_yr = 1: length(years_interpreted)
                    disturbance_label_agent = disturbance_label_year;  % refresh the disturbance layer with labeling agent type
                    disturbance_label_agent.Z = zeros(disturbance_label_agent.size, 'uint8'); % 0-255
                    year_interpreted = years_interpreted(i_yr);
                    filepath_yearlysample = fullfile(folderpath_sample, sprintf(filename_yearly_sample, year_interpreted, tile));

                    % give agent's code to the disturbance image
                    disturbance_label_agent.Z(disturbance_label_year.Z==year_interpreted) = agentcode; 

                    % merge or append the sample layers
                    if isfile(filepath_yearlysample)
                        fprintf('Appended to %s\n', filepath_yearlysample);
                        disturbance_label_agent_existing = imread(filepath_yearlysample);
                        disturbance_label_agent.Z(disturbance_label_agent_existing>0 & disturbance_label_agent_existing<255) = disturbance_label_agent_existing(disturbance_label_agent_existing>0 & disturbance_label_agent_existing<255); % append to the existing sample images
                        clear disturbance_label_agent_existing;
                    end
                    GRIDobj2geotiff(disturbance_label_agent, filepath_yearlysample);
                    fprintf('Created: %s\n', filepath_yearlysample);
                    clear disturbance_label_agent filepath_yearlysample;
                end
                
                % delete the raster data that we do not need
                if isfile(filepath_sample)
                    delete(filepath_sample);
                    fprintf('Deleted: %s\n', filepath_sample);
                end
            end
        end
    end % end of processing the samples labeling disturbance year per agent
end

