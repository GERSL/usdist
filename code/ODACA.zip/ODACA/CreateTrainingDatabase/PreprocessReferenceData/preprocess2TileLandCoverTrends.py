'''To extract the extent of the .img file and append the number into the filename'''
import os
import rasterio
import pyproj
import numpy as np
from pathlib import Path
import click
import glob
from shapely.geometry import box
import geopandas as gpd
import pandas as pd
from utils import get_like_profile, warp_to_tile


# decompressed land cover trends dataset
DIRIECTORY_LCT = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Reference/Temp/LandCoverTrends'
FILEPATH_ARD_SHAPE = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/LandsatARDC2/CONUS_C2_ARD_grid/conus_c2_ard_grid.shp'


def extract_lct_extent(destination):
    filepath_output = os.path.join(destination, 'lct_extent.shp')
    if not os.path.exists(filepath_output):
        # search folders
        extent_gpd = gpd.GeoDataFrame(columns=['name', 'path', 'crs', 'geometry'])
        eco_list  = sorted(glob.glob(os.path.join(destination, 'Eco*')))
        for eco_folder in eco_list:
            sample_list  = sorted(glob.glob(os.path.join(eco_folder, 'samp*')))
            for sample_folder in sample_list:
                img_list = sorted(glob.glob(os.path.join(sample_folder, '*.img')))
                for img_file in img_list:
                    img_name = Path(img_file).stem
                    # extract the extent of the .img file and append the number into the filename
                    with rasterio.open(img_file) as raster:
                        proj = raster.crs.to_string()
                        geom = box(*raster.bounds)
                        extent_gpd = pd.concat([extent_gpd, gpd.GeoDataFrame({'name': [img_name], 'path': [img_file], 'crs': [proj], 'geometry': [geom]})], ignore_index=True)

        # Convert the DataFrame to a GeoDataFrame
        extent_gpd.set_crs(proj, inplace=True)
        # extent_gpd = gpd.GeoDataFrame(extent_gpd, crs='EPSG:5070') # set the crs to EPSG:5070 which is same as the dataset
        extent_gpd.to_file(filepath_output)
        print('The extent of the land cover trends dataset has been extracted\n')
    else:
        print('The extent of the land cover trends dataset exists\n')
    return filepath_output


@click.command()
@click.option("--ci",          "-i", default=1, type=int, help="The core's id")
@click.option("--cn",          "-n", default=1, type=int, help="The number of cores")
@click.option("--destination", "-l", default="/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Classification", type=str, help="The filepath of the data's location")
def main(ci, cn, destination):
    
    # read the shapefile of ARD
    gpd_ard = gpd.read_file(FILEPATH_ARD_SHAPE)
    # extract the extent of each of image into shapfile
    filepath_lct_extent = extract_lct_extent(DIRIECTORY_LCT)
    # read the shapefile of extent of land cover trends
    gpd_lct = gpd.read_file(filepath_lct_extent)
    # same crs
    gpd_lct.to_crs(gpd_ard.crs, inplace=True)
    # intersect the two shapefiles
    gpd_lct_ard = gpd.overlay(gpd_lct, gpd_ard, how='intersection')
    
    # find the tile in the folder
    tiles = sorted(glob.glob(os.path.join(destination, 'h*')))

    for itile in range(ci-1, len(tiles), cn):
        tile = tiles[itile]
        tile_name = Path(tile).stem
        tile_h = int(tile_name[1:4])
        tile_v = int(tile_name[5:8])
        lct_list_tile = gpd_lct_ard[(gpd_lct_ard['h'] == tile_h) & (gpd_lct_ard['v'] == tile_v)]
        
        # build the path of the reference layer of land cover trends
        dir_lct_tile = os.path.join(tile, 'TrainingData', 'ReferenceLayerLCT')
        Path(dir_lct_tile).mkdir(parents=True, exist_ok=True)
        
        like_profile = get_like_profile(destination, tile_name)
        
        # loop each of the row and warp the image according to the extent of the ARD
        for i, lct_tile in lct_list_tile.iterrows():
            filepath_lct_src = lct_tile['path']
            filepath_lct_des = os.path.join(dir_lct_tile, '{}_{}.tif'.format(tile_name, lct_tile['name']))
            warp_to_tile(filepath_lct_src, filepath_lct_des, like_profile)
            print('Warped {}\n'.format(filepath_lct_des))
        
 
 # /gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/LandsatARDC2/CONUS_C2_ARD_grid/
# Main function
if __name__ == "__main__":
    main()