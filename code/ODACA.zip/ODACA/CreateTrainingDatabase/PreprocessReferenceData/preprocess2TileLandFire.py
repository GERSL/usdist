'''To extract the extent of the .img file and append the number into the filename'''
import os
import rasterio
import click
import glob
import geopandas as gpd
from utils import conus_ard_tiles, batch_ratserize_to_tile
# decompressed land cover trends dataset
DIRIECTORY_LF = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Reference/Temp/LandFire'
FILEPATH_ARD_SHAPE = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/LandsatARDC2/CONUS_C2_ARD_grid/conus_c2_ard_grid.shp'

@click.command()
@click.option("--ci",          "-i", default=1, type=int, help="The core's id")
@click.option("--cn",          "-n", default=1, type=int, help="The number of cores")
@click.option("--destination", "-l", default="/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Classification", type=str, help="The filepath of the data's location")
def main(ci, cn, destination):
   
    # find the tile in the folder
    # tiles = sorted(glob.glob(os.path.join(destination, 'h*')))
    tiles = conus_ard_tiles()
    # select tiles by the core id and the number of cores
    tiles = [os.path.join(destination, tiles[i]) for i in range(ci-1, len(tiles), cn) ]
    # read the shapefile of ARD
    gpd_ard = gpd.read_file(FILEPATH_ARD_SHAPE)
    # find the mtbs shapfile in the folder
    shapfiles = sorted(glob.glob(os.path.join(DIRIECTORY_LF, 'landfire*.shp')))
    # rasterize the shapefile to each of the tiles
    batch_ratserize_to_tile(tiles, shapfiles, gpd_ard, destination, 'ReferenceLayerLF', ['Event_Type', 'Severity'], fill_value = 255, dtype = rasterio.uint8)

# Main function
if __name__ == "__main__":
    main()