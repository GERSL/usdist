'''To extract the extent of the .img file and append the number into the filename'''
import os
import datetime
import time
import rasterio
import pyproj
import numpy as np
from pathlib import Path
import click
import glob
from shapely.geometry import box
import geopandas as gpd
import pandas as pd
from utils import get_like_profile, warp_to_tile

# decompressed land cover trends dataset
DIRIECTORY_NLCD = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Reference/Temp/NLCD/NLCD_science_products_2021_release_all_files_20230630/'
FILEPATH_ARD_SHAPE = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/LandsatARDC2/CONUS_C2_ARD_grid/conus_c2_ard_grid.shp'

@click.command()
@click.option("--ci",          "-i", default=1, type=int, help="The core's id")
@click.option("--cn",          "-n", default=1, type=int, help="The number of cores")
@click.option("--destination", "-l", default="/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Classification", type=str, help="The filepath of the data's location")
def main(ci, cn, destination):
    
    # find the tile in the folder
    tiles = sorted(glob.glob(os.path.join(destination, 'h*')))
    # not senstive to case upper or lower
    nlcds = sorted(glob.glob(os.path.join(DIRIECTORY_NLCD, '*_*and_*over_*.img'))) # land_cover
    
    for itile in range(ci-1, len(tiles), cn):
        tile = tiles[itile]
        tile_name = Path(tile).stem
        tile_h = int(tile_name[1:4])
        tile_v = int(tile_name[5:8])
        like_profile = get_like_profile(destination, tile_name)
        
        # build the path of the reference layer of land cover trends
        dir_nlcd_tile = os.path.join(tile, 'TrainingData', 'ReferenceLayerNLCD')
        Path(dir_nlcd_tile).mkdir(parents=True, exist_ok=True)
        
        # process each nlcd file
        for inlcd in range(len(nlcds)):
            filepath_nlcd_src = nlcds[inlcd]
            nlcd_year = Path(filepath_nlcd_src).stem.split('_')[1]
            filepath_nlcd_des = os.path.join(dir_nlcd_tile, '{}_nlcd_{}.tif'.format(tile_name, nlcd_year))
            if os.path.exists(filepath_nlcd_des):
                print('Exist {}\n'.format(filepath_nlcd_des))
                continue
            warp_to_tile(filepath_nlcd_src, filepath_nlcd_des, like_profile)
            # rename
            # os.rename(filepath_nlcd_des + '.part', filepath_nlcd_des)
            print('Warped {}\n'.format(filepath_nlcd_des))
 
 # /gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/LandsatARDC2/CONUS_C2_ARD_grid/
# Main function
if __name__ == "__main__":
    main()