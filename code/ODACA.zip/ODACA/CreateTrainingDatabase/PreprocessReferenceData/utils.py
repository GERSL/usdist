import os
from pathlib import Path
import rasterio
import geopandas as gpd
from rasterio import warp
from rasterio import features
from rasterio.enums import MergeAlg
import numpy as np
from skimage.measure import label, regionprops

def conus_ard_tiles():
    ARDTilesCONUS = [
        'h001v004', 'h001v005', 'h001v006', 'h001v007', 'h001v008', 'h001v009', 'h001v010',
        'h002v001', 'h002v002', 'h002v003', 'h002v004', 'h002v005', 'h002v006', 'h002v007',
        'h002v008', 'h002v009', 'h002v010', 'h002v011', 'h002v012', 'h003v000', 'h003v001',
        'h003v002', 'h003v003', 'h003v004', 'h003v005', 'h003v006', 'h003v007', 'h003v008',
        'h003v009', 'h003v010', 'h003v011', 'h003v012', 'h003v013', 'h004v000', 'h004v001',
        'h004v002', 'h004v003', 'h004v004', 'h004v005', 'h004v006', 'h004v007', 'h004v008',
        'h004v009', 'h004v010', 'h004v011', 'h004v012', 'h004v013', 'h005v001', 'h005v002',
        'h005v003', 'h005v004', 'h005v005', 'h005v006', 'h005v007', 'h005v008', 'h005v009',
        'h005v010', 'h005v011', 'h005v012', 'h005v013', 'h005v014', 'h006v001', 'h006v002',
        'h006v003', 'h006v004', 'h006v005', 'h006v006', 'h006v007', 'h006v008', 'h006v009',
        'h006v010', 'h006v011', 'h006v012', 'h006v013', 'h006v014', 'h007v001', 'h007v002',
        'h007v003', 'h007v004', 'h007v005', 'h007v006', 'h007v007', 'h007v008', 'h007v009',
        'h007v010', 'h007v011', 'h007v012', 'h007v013', 'h007v014', 'h007v015', 'h008v001',
        'h008v002', 'h008v003', 'h008v004', 'h008v005', 'h008v006', 'h008v007', 'h008v008',
        'h008v009', 'h008v010', 'h008v011', 'h008v012', 'h008v013', 'h008v014', 'h008v015',
        'h009v002', 'h009v003', 'h009v004', 'h009v005', 'h009v006', 'h009v007', 'h009v008',
        'h009v009', 'h009v010', 'h009v011', 'h009v012', 'h009v013', 'h009v014', 'h009v015',
        'h010v002', 'h010v003', 'h010v004', 'h010v005', 'h010v006', 'h010v007', 'h010v008',
        'h010v009', 'h010v010', 'h010v011', 'h010v012', 'h010v013', 'h010v014', 'h010v015',
        'h011v002', 'h011v003', 'h011v004', 'h011v005', 'h011v006', 'h011v007', 'h011v008',
        'h011v009', 'h011v010', 'h011v011', 'h011v012', 'h011v013', 'h011v014', 'h011v015',
        'h011v016', 'h011v017', 'h012v002', 'h012v003', 'h012v004', 'h012v005', 'h012v006',
        'h012v007', 'h012v008', 'h012v009', 'h012v010', 'h012v011', 'h012v012', 'h012v013',
        'h012v014', 'h012v015', 'h012v016', 'h012v017', 'h013v002', 'h013v003', 'h013v004',
        'h013v005', 'h013v006', 'h013v007', 'h013v008', 'h013v009', 'h013v010', 'h013v011',
        'h013v012', 'h013v013', 'h013v014', 'h013v015', 'h013v016', 'h013v017', 'h014v002',
        'h014v003', 'h014v004', 'h014v005', 'h014v006', 'h014v007', 'h014v008', 'h014v009',
        'h014v010', 'h014v011', 'h014v012', 'h014v013', 'h014v014', 'h014v015', 'h014v016',
        'h014v017', 'h014v018', 'h014v019', 'h015v002', 'h015v003', 'h015v004', 'h015v005',
        'h015v006', 'h015v007', 'h015v008', 'h015v009', 'h015v010', 'h015v011', 'h015v012',
        'h015v013', 'h015v014', 'h015v015', 'h015v016', 'h015v017', 'h015v018', 'h015v019',
        'h016v002', 'h016v003', 'h016v004', 'h016v005', 'h016v006', 'h016v007', 'h016v008',
        'h016v009', 'h016v010', 'h016v011', 'h016v012', 'h016v013', 'h016v014', 'h016v015',
        'h016v016', 'h016v017', 'h016v018', 'h016v019', 'h016v020', 'h017v002', 'h017v003',
        'h017v004', 'h017v005', 'h017v006', 'h017v007', 'h017v008', 'h017v009', 'h017v010',
        'h017v011', 'h017v012', 'h017v013', 'h017v014', 'h017v015', 'h017v016', 'h017v017',
        'h017v018', 'h018v003', 'h018v004', 'h018v005', 'h018v006', 'h018v007', 'h018v008',
        'h018v009', 'h018v010', 'h018v011', 'h018v012', 'h018v013', 'h018v014', 'h018v015',
        'h018v016', 'h018v017', 'h019v003', 'h019v004', 'h019v005', 'h019v006', 'h019v007',
        'h019v008', 'h019v009', 'h019v010', 'h019v011', 'h019v012', 'h019v013', 'h019v014',
        'h019v015', 'h019v016', 'h019v017', 'h020v003', 'h020v004', 'h020v005', 'h020v006',
        'h020v007', 'h020v008', 'h020v009', 'h020v010', 'h020v011', 'h020v012', 'h020v013',
        'h020v014', 'h020v015', 'h020v016', 'h020v017', 'h021v003', 'h021v004', 'h021v005',
        'h021v006', 'h021v007', 'h021v008', 'h021v009', 'h021v010', 'h021v011', 'h021v012',
        'h021v013', 'h021v014', 'h021v015', 'h021v016', 'h021v017', 'h022v003', 'h022v004',
        'h022v005', 'h022v006', 'h022v007', 'h022v008', 'h022v009', 'h022v010', 'h022v011',
        'h022v012', 'h022v013', 'h022v014', 'h022v015', 'h022v016', 'h023v004', 'h023v005',
        'h023v006', 'h023v007', 'h023v008', 'h023v009', 'h023v010', 'h023v011', 'h023v012',
        'h023v013', 'h023v014', 'h023v015', 'h023v016', 'h024v004', 'h024v005', 'h024v006',
        'h024v007', 'h024v008', 'h024v009', 'h024v010', 'h024v011', 'h024v012', 'h024v013',
        'h024v014', 'h024v015', 'h024v016', 'h025v006', 'h025v007', 'h025v008', 'h025v009',
        'h025v010', 'h025v011', 'h025v012', 'h025v013', 'h025v014', 'h025v015', 'h025v016',
        'h025v017', 'h025v018', 'h026v005', 'h026v006', 'h026v007', 'h026v008', 'h026v009',
        'h026v010', 'h026v011', 'h026v012', 'h026v013', 'h026v014', 'h026v015', 'h026v016',
        'h026v017', 'h026v018', 'h026v019', 'h026v020', 'h027v004', 'h027v005', 'h027v006',
        'h027v007', 'h027v008', 'h027v009', 'h027v010', 'h027v011', 'h027v012', 'h027v013',
        'h027v014', 'h027v017', 'h027v018', 'h027v019', 'h027v020', 'h028v004', 'h028v005',
        'h028v006', 'h028v007', 'h028v008', 'h028v009', 'h028v010', 'h028v011', 'h028v012',
        'h028v013', 'h029v003', 'h029v004', 'h029v005', 'h029v006', 'h029v007', 'h029v008',
        'h029v009', 'h029v011', 'h029v012', 'h030v002', 'h030v003', 'h030v004', 'h030v005',
        'h030v006', 'h030v007', 'h031v002', 'h031v003', 'h031v004', 'h031v006', 'h032v003']
    return ARDTilesCONUS


def get_like_profile(destination, tile_name):
    filepath_tile_dem = os.path.join(destination, tile_name, 'AuxilliaryData', 'DEM', '{}_dem.tif'.format(tile_name))
    with rasterio.open(filepath_tile_dem) as imagelike:
        like_profile = imagelike.meta.copy()
    return like_profile

def get_like_image(destination, tile_name):
    filepath_tile_dem = os.path.join(destination, tile_name, 'AuxilliaryData', 'DEM', '{}_dem.tif'.format(tile_name))
    raster = rasterio.open(filepath_tile_dem)
    return raster


def batch_ratserize_to_tile(tiles, shapfiles, gpd_ard, destination, foldername, attributes, fill_value = 255, dtype = rasterio.uint8):
    for shp in shapfiles:
        shp_gpd_all = gpd.read_file(shp)
        shp_name = Path(shp).stem
        for tile in tiles:
            tile_name = Path(tile).stem
            tile_h = int(tile_name[1:4])
            tile_v = int(tile_name[5:8])
            gpd_ard_tile = gpd_ard[(gpd_ard['h'] == tile_h) & (gpd_ard['v'] == tile_v)]
            
            # Open example raster
            like_image = get_like_image(destination, tile_name)
            # overlay the two shapefiles
            shp_gpd = shp_gpd_all.copy()
            shp_gpd.to_crs(gpd_ard_tile.crs, inplace=True) # same crs
            shp_tile = gpd.overlay(gpd_ard_tile, shp_gpd, how='intersection', keep_geom_type=False)
            if shp_tile.empty:
                print('Empty for {}: {}\n'.format(tile_name, shp))
                continue           
            for attribu in attributes:
                # build the path of the reference layer of MTBS
                dir_ref_tile = os.path.join(tile, 'TrainingData', foldername)
                Path(dir_ref_tile).mkdir(parents=True, exist_ok=True)
                filepath_des = os.path.join(dir_ref_tile, '{}_{}_{}.tif'.format(tile_name, attribu.lower(), shp_name))
                
                # create tuples of geometry, value pairs, where value is the attribute value you want to burn
                geom_value = ((geom,value) for geom, value in zip(shp_tile.geometry, shp_tile[attribu]))
                # rasterize to geotiff with the extent and transform of the image-like
                rasterize_to_tile(geom_value, like_image, filepath_des, fill_value = fill_value, dtype = dtype)
                print('Rasterize for {}\n'.format(filepath_des))

def rasterize_to_tile(geom_value, like_image, filepath_des = None, fill_value = 255, dtype = rasterio.uint8):

    # Rasterize vector using the shape and transform of the raster
    rasterized = features.rasterize(geom_value,
                                    out_shape = like_image.shape,
                                    transform = like_image.transform,
                                    all_touched = True,
                                    fill = fill_value,   # background value
                                    merge_alg = MergeAlg.replace)
    if filepath_des is None:
        return rasterized
    else:
        with rasterio.open(
            filepath_des, "w",
            driver = "GTiff",
            crs = like_image.crs,
            transform = like_image.transform,
            dtype = dtype,
            count = 1,
            width = like_image.width,
            height = like_image.height) as dst:
            dst.write(rasterized, indexes = 1)
        return None

def warp_to_tile(filepath_src, filepath_des, like_profile):
    with rasterio.open(filepath_src, 'r') as src_mask: # obtain the resource dataset
        des_profile = src_mask.meta.copy()
        # update the profile to the image-like
        des_profile.update({
        'crs':          like_profile['crs'],
        'transform':    like_profile['transform'],
        'width':        like_profile['width'],
        'height':       like_profile['height']
        })
        # save as local file # warp as the destination geotif
        with rasterio.open(filepath_des, 'w', **des_profile) as dst_mask:
            for i in range(1, src_mask.count + 1):
                warp.reproject(
                    source          =   rasterio.band(src_mask, i),
                    destination     =   rasterio.band(dst_mask, i),
                    src_transform   =   src_mask.transform,
                    src_crs         =   src_mask.crs,
                    dst_transform   =   des_profile['transform'],
                    dst_crs         =   des_profile['crs'],
                    resampling      =   warp.Resampling.nearest,
                    dst_nodata      =   src_mask.nodata
                    )

def convert_refine_sample_polygon_to_tile(tiles, shapfiles, gpd_ard, destination, foldername, folderpath_product_pri, maxnum_per_obj = 100):
    base_product_version = Path(folderpath_product_pri).stem
    base_product_version = base_product_version[0:3] # only the first three letters are used for the version

    shp_gpd_all = gpd.read_file(shapfiles[0])
    for shp in shapfiles[1:]:
        # merge the shapefiles into one
        shp_gpd_all = gpd.GeoDataFrame(gpd.concat([shp_gpd_all, gpd.read_file(shp)], ignore_index=True), crs = shp_gpd_all.crs)

    # convert agent name to agent code
    shp_gpd_all['agent'] = shp_gpd_all['agent'].map({'forest_management': 1, 'construction': 2, 'stress': 3, 'natural_hazard': 4, 'debris':  4, 'water_dynamic': 5, 'fire': 6, 'agriculture_activity': 7, 'other': 8})
    shp_gpd_all['classified'] = shp_gpd_all['classified'].map({'forest_management': 1, 'construction': 2, 'stress': 3, 'natural_hazard': 4, 'debris':  4, 'water_dynamic': 5, 'fire': 6, 'agriculture_activity': 7, 'other': 8})
    # in case for the natural hazard and for old version

    for tile in tiles:
        tile_name = Path(tile).stem
        tile_h = int(tile_name[1:4])
        tile_v = int(tile_name[5:8])
        gpd_ard_tile = gpd_ard[(gpd_ard['h'] == tile_h) & (gpd_ard['v'] == tile_v)]
        
        # Open example raster
        like_image = get_like_image(destination, tile_name)
        # overlay the two shapefiles
        shp_gpd = shp_gpd_all.copy()
        shp_gpd.to_crs(gpd_ard_tile.crs, inplace=True) # same crs
        shp_tile = gpd.overlay(gpd_ard_tile, shp_gpd, how='intersection', keep_geom_type=False)
        if shp_tile.empty:
            print('Empty refine samples for {}\n'.format(tile_name))
            continue
        
        # iterate through the year one by one
        start_year = shp_tile['start_year'].min()
        end_year = shp_tile['end_year'].max()
        for yr in range(start_year, end_year+1):
            # turn the year into the year range
            shp_tile_yr = shp_tile[(shp_tile['start_year'] <= yr) & (shp_tile['end_year'] >= yr)]
            if shp_tile_yr.empty:
                continue

            # create tuples of geometry, value pairs, where value is the attribute value you want to burn
            geom_value = ((geom,value) for geom, value in zip(shp_tile_yr.geometry, shp_tile_yr['classified']*10 + shp_tile_yr['agent']))
            # rasterize to geotiff with the extent and transform of the image-like
            sample_convert_layer = rasterize_to_tile(geom_value, like_image, fill_value = 0, dtype = rasterio.uint8)
            sample_agent_classified = sample_convert_layer//10
            sample_agent_reference = sample_convert_layer%10

            # read the agent layer 
            # e.g., /gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Product/V00/h001v007/CD_001007_1987_V00/
            agent_filename = f'CD_{tile_h:03d}{tile_v:03d}_{yr}_{base_product_version}'
            filepath_agent_pri = os.path.join(folderpath_product_pri, tile_name, agent_filename, agent_filename + '_APRI.tif')
            # read the classified layer
            with rasterio.open(filepath_agent_pri) as src:
                agent_layer = src.read(1)
            # print(np.unique(agent_layer))
            # print(np.unique(sample_agent_classified))
            # print(np.unique(sample_agent_reference))
            # replace the agent layer with the refined layer
            sample_agent_refine = np.zeros_like(sample_agent_reference)
            sample_agent_refine[sample_agent_classified == agent_layer] = sample_agent_reference[sample_agent_classified == agent_layer]
            # save the refined layer
            if np.count_nonzero(sample_agent_refine) > 0:
                # get the total years represented by the sample polygon, and each polygon contribues 100 samples in total
                geom_value = ((geom,value) for geom, value in zip(shp_tile_yr.geometry, shp_tile_yr['end_year'] - shp_tile_yr['start_year'] + 1))
                sample_num_years = rasterize_to_tile(geom_value, like_image, fill_value = 0, dtype = rasterio.uint8)
                # segment the layer of samples into sample objects
                sample_polygon_objects = label(sample_agent_reference > 0, background=0, return_num=False, connectivity=None)
                # get the unique sample objects
                sample_obj_ids = np.unique(sample_polygon_objects[sample_polygon_objects > 0])
                # record the samples that will be remained further
                sample_remain = np.zeros_like(sample_agent_refine)
                for sample_obj_id in sample_obj_ids:
                    # check the reference samples for each object
                    sample_agent_refine_obj = (sample_agent_refine > 0) & (sample_polygon_objects==sample_obj_id)
                    if not np.any(sample_agent_refine_obj):
                        continue

                    # for each sampling polygon, get the number of years
                    sample_obj_nyears = sample_num_years[sample_polygon_objects == sample_obj_id]
                    sample_obj_nyears = sample_obj_nyears[0] # that should have same value, indicating the total number of years represented by the sample polygon
                    if sample_obj_nyears == 1:
                        pass
                    sample_obj_npixels = round(maxnum_per_obj/sample_obj_nyears)

                    # less than 10 samples object for each agent and each ARD tile, to avoid the over-collection of the training sample
                    sample_refine_objects = label(sample_agent_refine_obj, background=0, return_num=False, connectivity=None)
                    sample_ids = np.unique(sample_refine_objects[(sample_refine_objects > 0)])
 
                    # randomly sort the sample ids
                    np.random.seed(seed=42)
                    
                    # before data v3, we used this one. This will duplicate the samples when they are very small,
                    # when finalizing the data, we will exclude the samples duplicated to trian the model
                    # random_list = np.random.randint(0, len(sample_ids), size=min(len(sample_ids), sample_obj_npixels))
                    
                    # randomly select the samples from the sample object
                    random_list = np.random.choice(sample_ids, min(len(sample_ids), sample_obj_npixels), replace = False)
                    random_list = random_list - 1 # convert to the index
                    print('Sample object {} has {} samples, and {} samples will be remained\n'.format(sample_obj_id, len(sample_ids), len(random_list)))
                    print(random_list)
                    sample_ids = sample_ids[random_list]
                    
                    for sample_id in sample_ids:
                        sample_remain[sample_refine_objects == sample_id] = 1
                # remove the samples that are not selected
                sample_agent_refine[sample_remain==0] = 0
                # build the path of the reference layer of MTBS
                dir_ref_tile = os.path.join(tile, 'TrainingData', foldername)
                Path(dir_ref_tile).mkdir(parents=True, exist_ok=True)
                filepath_des = os.path.join(dir_ref_tile, '{}_refine_polygon_{}_{}.tif'.format(tile_name, yr, base_product_version.lower()))
                with rasterio.open(
                    filepath_des, "w",
                    driver = "GTiff",
                    crs = like_image.crs,
                    transform = like_image.transform,
                    dtype = rasterio.uint8,
                    count = 1,
                    width = like_image.width,
                    height = like_image.height) as dst:
                    dst.write(sample_agent_refine, indexes = 1)
                print('Rasterize to {}\n'.format(filepath_des))
      

def convert_refine_sample_point_to_tile(tiles, shapfiles, gpd_ard, destination, foldername, folderpath_product_pri):
    """
    Converts refine sample points to raster tiles.

    Args:
        tiles (list): List of tile file paths.
        shapfiles (list): List of shapefile file paths.
        gpd_ard (GeoDataFrame): GeoDataFrame containing ARD data.
        destination (str): Destination directory for the output raster tiles.
        foldername (str): Name of the folder to store the output raster tiles.

    Returns:
        None
    """
    base_product_version = Path(folderpath_product_pri).stem
    base_product_version = base_product_version[0:3] # only the first three letters are used for the version

    shp_gpd_all = gpd.read_file(shapfiles[0])
    for shp in shapfiles[1:]:
        # merge the shapefiles into one
        shp_gpd_all = gpd.GeoDataFrame(gpd.concat([shp_gpd_all, gpd.read_file(shp)], ignore_index=True), crs = shp_gpd_all.crs)

    # convert agent name to agent code
    shp_gpd_all['agent'] = shp_gpd_all['agent'].map({'forest_management': 1, 'construction': 2, 'stress': 3, 'natural_hazard': 4, 'debris':  4, 'water_dynamic': 5, 'fire': 6, 'agriculture_activity': 7, 'other': 8})
    # in case for the natural hazard and for old version

    for tile in tiles:
        tile_name = Path(tile).stem
        tile_h = int(tile_name[1:4])
        tile_v = int(tile_name[5:8])
        gpd_ard_tile = gpd_ard[(gpd_ard['h'] == tile_h) & (gpd_ard['v'] == tile_v)]
        
        # Open example raster
        like_image = get_like_image(destination, tile_name)
        # overlay the two shapefiles
        shp_gpd = shp_gpd_all.copy()
        shp_gpd.to_crs(gpd_ard_tile.crs, inplace=True) # same crs
        shp_tile = gpd.overlay(gpd_ard_tile, shp_gpd, how='intersection', keep_geom_type=False)
        if shp_tile.empty:
            print('Empty refine samples for {}\n'.format(tile_name))
            continue
        years = shp_tile['year'].unique()

        for yr in years:
            shp_tile_yr = shp_tile[shp_tile['year'] == yr]
            # create tuples of geometry, value pairs, where value is the attribute value you want to burn
            geom_value = ((geom,value) for geom, value in zip(shp_tile_yr.geometry, shp_tile_yr['agent']))
            # rasterize to geotiff with the extent and transform of the image-like
            sample_agent_reference = rasterize_to_tile(geom_value, like_image, fill_value = 255, dtype = rasterio.uint8)
            
            
            agent_filename = f'CD_{tile_h:03d}{tile_v:03d}_{yr}_{base_product_version}'
            filepath_agent_pri = os.path.join(folderpath_product_pri, tile_name, agent_filename, agent_filename + '_APRI.tif')
            # read the classified layer
            with rasterio.open(filepath_agent_pri) as src:
                agent_layer = src.read(1)


            sample_agent_refine = np.zeros_like(sample_agent_reference)
            sample_agent_refine[sample_agent_reference != agent_layer] = sample_agent_reference[sample_agent_reference != agent_layer]
            # save the refined layer
            if np.count_nonzero(sample_agent_refine) > 0:
                # build the path of the reference layer of MTBS
                dir_ref_tile = os.path.join(tile, 'TrainingData', foldername)
                Path(dir_ref_tile).mkdir(parents=True, exist_ok=True)
                filepath_des = os.path.join(dir_ref_tile, '{}_refine_point_{}_{}.tif'.format(tile_name, yr, base_product_version.lower()))
                with rasterio.open(
                    filepath_des, "w",
                    driver = "GTiff",
                    crs = like_image.crs,
                    transform = like_image.transform,
                    dtype = rasterio.uint8,
                    count = 1,
                    width = like_image.width,
                    height = like_image.height) as dst:
                    dst.write(sample_agent_refine, indexes = 1)
                print('Rasterize to {}\n'.format(filepath_des))