#!/bin/bash
#SBATCH -J pre # jobname
#SBATCH --partition=general
#SBATCH --nodes 1 
#SBATCH --ntasks 1
#SBATCH --array 1-427
#SBATCH --mem-per-cpu=20G
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err


echo $SLURMD_NODENAME # display the node name
cd ../

# start up conda
. "/home/shq19004/miniconda3/etc/profile.d/conda.sh"
conda activate dist

# run the python script, tile by tile
python ./preprocess2TileLandFire.py -i $SLURM_ARRAY_TASK_ID -n $SLURM_ARRAY_TASK_MAX
python ./preprocess2TileIDS.py -i $SLURM_ARRAY_TASK_ID -n $SLURM_ARRAY_TASK_MAX
python ./preprocess2TileMTBS.py -i $SLURM_ARRAY_TASK_ID -n $SLURM_ARRAY_TASK_MAX
python ./preprocess2TileLandCoverTrends.py -i $SLURM_ARRAY_TASK_ID -n $SLURM_ARRAY_TASK_MAX
python ./preprocess2TileNLCD.py -i $SLURM_ARRAY_TASK_ID -n $SLURM_ARRAY_TASK_MAX


exit

#SBATCH --partition=general

#SBATCH --partition=priority
#SBATCH --account=zhz18039