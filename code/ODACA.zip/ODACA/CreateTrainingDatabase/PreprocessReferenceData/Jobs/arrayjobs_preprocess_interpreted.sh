#!/bin/bash
#SBATCH -J int # jobname
#SBATCH --partition=general-gpu
#SBATCH --mem-per-cpu=10G
#SBATCH --gres=gpu:1
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --array 1-30
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err


echo $SLURMD_NODENAME # display the node name
cd ../

# start up conda
. "/home/shq19004/miniconda3/etc/profile.d/conda.sh"
conda activate dist

python ./preprocess2TileInterpretedSample.py -i $SLURM_ARRAY_TASK_ID -n $SLURM_ARRAY_TASK_MAX -t 'refine_point_v3'
python ./preprocess2TileInterpretedSample.py -i $SLURM_ARRAY_TASK_ID -n $SLURM_ARRAY_TASK_MAX -t 'refine_polygon_v3'

exit

python ./preprocess2TileInterpretedSample.py -i $SLURM_ARRAY_TASK_ID -n $SLURM_ARRAY_TASK_MAX -t 'hazard_year'
# run the python script, tile by tile
python ./preprocess2TileInterpretedSample.py -i $SLURM_ARRAY_TASK_ID -n $SLURM_ARRAY_TASK_MAX -t 'refine_point_v0'
python ./preprocess2TileInterpretedSample.py -i $SLURM_ARRAY_TASK_ID -n $SLURM_ARRAY_TASK_MAX -t 'refine_polygon_v0'

python ./preprocess2TileInterpretedSample.py -i $SLURM_ARRAY_TASK_ID -n $SLURM_ARRAY_TASK_MAX -t 'refine_point_v1'
python ./preprocess2TileInterpretedSample.py -i $SLURM_ARRAY_TASK_ID -n $SLURM_ARRAY_TASK_MAX -t 'refine_polygon_v1'

python ./preprocess2TileInterpretedSample.py -i $SLURM_ARRAY_TASK_ID -n $SLURM_ARRAY_TASK_MAX -t 'refine_point_v2'
python ./preprocess2TileInterpretedSample.py -i $SLURM_ARRAY_TASK_ID -n $SLURM_ARRAY_TASK_MAX -t 'refine_polygon_v2'

exit

#SBATCH --partition=general

#SBATCH --partition=priority
#SBATCH --account=zhz18039
#SBATCH --constraint='epyc128'
#SBATCH --nodes 1 
#SBATCH --ntasks 1
#SBATCH --array 1-20
#SBATCH --mem-per-cpu=20G
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err



#SBATCH --partition=general-gpu
#SBATCH --constraint=a100
#SBATCH --mem-per-cpu=10G
#SBATCH --gres=gpu:1
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --array 1-30
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err