import os
import rasterio
import click
import glob
import geopandas as gpd
from utils import conus_ard_tiles, batch_ratserize_to_tile, convert_refine_sample_point_to_tile, convert_refine_sample_polygon_to_tile

# decompressed land cover trends dataset
FILEPATH_ARD_SHAPE = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/LandsatARDC2/CONUS_C2_ARD_grid/conus_c2_ard_grid.shp'

@click.command()
@click.option("--ci",          "-i", default=1, type=int, help="The core's id")
@click.option("--cn",          "-n", default=1, type=int, help="The number of cores")
@click.option("--dtype",        "-t", default='refine_polygon_v7', type=str, help="the data type of the reference layer")
@click.option("--destination", "-d", default="/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Classification", type=str, help="The filepath of the data's location")
def main(ci, cn, dtype, destination):
    # find the tile in the folder
    tiles = conus_ard_tiles()
    # select tiles by the core id and the number of cores
    tiles = [os.path.join(destination, tiles[i]) for i in range(ci-1, len(tiles), cn) ]
    # read the shapefile of ARD
    gpd_ard = gpd.read_file(FILEPATH_ARD_SHAPE)
    if dtype == 'hazard_year':
        # At very beginning, we only have the year of the hazard event according the historal records in US for the testing 45 tiles
        reference_layers = ['/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Reference/InterpretedSample/Wind/Wind/wind.shp',
                            '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Reference/InterpretedSample/Landslide/landslide.shp']
        batch_ratserize_to_tile(tiles, reference_layers, gpd_ard, destination, 'ReferenceLayerInterpreted', ['Year'], fill_value = 65535, dtype = rasterio.uint16)
    if dtype == 'refine_point_v0':
        reference_layer = ['/shared/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSTrainingSampleRefine/collection0/refine_sample_point_v0.shp']
        folderpath_product_pri = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Product/V00'
        convert_refine_sample_point_to_tile(tiles, reference_layer, gpd_ard, destination, 'ReferenceLayerInterpreted', folderpath_product_pri)
    if dtype == 'refine_polygon_v0':
        reference_layer = ['/shared/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSTrainingSampleRefine/collection0/refine_sample_polygon_v0.shp']
        folderpath_product_pri = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Product/V00'
        convert_refine_sample_polygon_to_tile(tiles, reference_layer, gpd_ard, destination, 'ReferenceLayerInterpreted', folderpath_product_pri)
    if dtype == 'refine_point_v1':
        reference_layer = ['/shared/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSTrainingSampleRefine/collection1/refine_sample_point_v1.shp']
        folderpath_product_pri = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Product/V01'
        convert_refine_sample_point_to_tile(tiles, reference_layer, gpd_ard, destination, 'ReferenceLayerInterpreted', folderpath_product_pri)
    if dtype == 'refine_polygon_v1':
        reference_layer = ['/shared/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSTrainingSampleRefine/collection1/refine_sample_polygon_v1.shp']
        folderpath_product_pri = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Product/V01'
        convert_refine_sample_polygon_to_tile(tiles, reference_layer, gpd_ard, destination, 'ReferenceLayerInterpreted', folderpath_product_pri)
    if dtype == 'refine_point_v2':
        reference_layer = ['/shared/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSTrainingSampleRefine/collection2/refine_sample_point_v2.shp']
        folderpath_product_pri = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Product/V02'
        convert_refine_sample_point_to_tile(tiles, reference_layer, gpd_ard, destination, 'ReferenceLayerInterpreted', folderpath_product_pri)
    if dtype == 'refine_polygon_v2':
        reference_layer = ['/shared/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSTrainingSampleRefine/collection2/refine_sample_polygon_v2.shp']
        folderpath_product_pri = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Product/V02'
        convert_refine_sample_polygon_to_tile(tiles, reference_layer, gpd_ard, destination, 'ReferenceLayerInterpreted', folderpath_product_pri)
    if dtype == 'refine_point_v3':
        reference_layer = ['/shared/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSTrainingSampleRefine/collection3/refine_sample_point_v3.shp']
        folderpath_product_pri = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Product/V03'
        convert_refine_sample_point_to_tile(tiles, reference_layer, gpd_ard, destination, 'ReferenceLayerInterpreted', folderpath_product_pri)
    if dtype == 'refine_polygon_v3':
        reference_layer = ['/shared/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSTrainingSampleRefine/collection3/refine_sample_polygon_v3.shp']
        folderpath_product_pri = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Product/V03'
        convert_refine_sample_polygon_to_tile(tiles, reference_layer, gpd_ard, destination, 'ReferenceLayerInterpreted', folderpath_product_pri)
    if dtype == 'refine_point_v4':
        reference_layer = ['/shared/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSTrainingSampleRefine/collection4/refine_sample_point_v4.shp']
        folderpath_product_pri = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Product/V04Post'
        convert_refine_sample_point_to_tile(tiles, reference_layer, gpd_ard, destination, 'ReferenceLayerInterpreted', folderpath_product_pri)
    if dtype == 'refine_polygon_v4':
        reference_layer = ['/shared/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSTrainingSampleRefine/collection4/refine_sample_polygon_v4.shp']
        folderpath_product_pri = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Product/V04Post'
        convert_refine_sample_polygon_to_tile(tiles, reference_layer, gpd_ard, destination, 'ReferenceLayerInterpreted', folderpath_product_pri)

    if dtype == 'refine_point_v5':
        reference_layer = ['/shared/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSTrainingSampleRefine/collection5/refine_sample_point_v5.shp']
        folderpath_product_pri = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Product/V05Post'
        convert_refine_sample_point_to_tile(tiles, reference_layer, gpd_ard, destination, 'ReferenceLayerInterpreted', folderpath_product_pri)
    if dtype == 'refine_polygon_v5':
        reference_layer = ['/shared/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSTrainingSampleRefine/collection5/refine_sample_polygon_v5.shp']
        folderpath_product_pri = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Product/V05Post'
        convert_refine_sample_polygon_to_tile(tiles, reference_layer, gpd_ard, destination, 'ReferenceLayerInterpreted', folderpath_product_pri)
        
    if dtype == 'refine_point_v6':
        reference_layer = ['/shared/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSTrainingSampleRefine/collection6/refine_sample_point_v6.shp']
        folderpath_product_pri = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Product/V06Post'
        convert_refine_sample_point_to_tile(tiles, reference_layer, gpd_ard, destination, 'ReferenceLayerInterpreted', folderpath_product_pri)
        
    if dtype == 'refine_point_v7':
        reference_layer = ['/shared/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSTrainingSampleRefine/collection7/refine_sample_point_v7.shp']
        folderpath_product_pri = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Product/V07Post'
        convert_refine_sample_point_to_tile(tiles, reference_layer, gpd_ard, destination, 'ReferenceLayerInterpreted', folderpath_product_pri)
    if dtype == 'refine_polygon_v7':
        reference_layer = ['/shared/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSTrainingSampleRefine/collection7/refine_sample_polygon_v7.shp']
        folderpath_product_pri = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Product/V07Post'
        convert_refine_sample_polygon_to_tile(tiles, reference_layer, gpd_ard, destination, 'ReferenceLayerInterpreted', folderpath_product_pri)


# Main function
if __name__ == "__main__":
    main()