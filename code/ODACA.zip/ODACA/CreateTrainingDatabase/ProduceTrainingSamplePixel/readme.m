
%% Step 1: initilize the job records, local and global by running this
% script
batchProduceTrainingSamplePixel('local', 'open', 1, 1)
batchProduceTrainingSamplePixel('global', 'open', 1, 1)

%% Step 2: submit create_training_pixels.sh, that will convert objects to pixels, including local and global

%% Step 3: submit merge jobs to combine the small data files into one for each agent