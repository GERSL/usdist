function selectPixelSamplesFromObjectSamples(folderpath_sampleready, tile, record_filefolder, record_filename, samplepixel_ids)
    tic

    % check the file
    [~, record_filename_full] = fileparts(record_filename);
    filepath_out = fullfile(folderpath_sampleready, ...
     sprintf('%s_%s_%010d.mat', record_filename_full, tile, length(samplepixel_ids)));

    if isfile(filepath_out)
        fprintf('Existing %s in %0.4f mins\r', filepath_out, toc/60);
        return;
    end
    % create folder if it does not exist
    if ~isfolder(folderpath_sampleready)
        mkdir(folderpath_sampleready);
    end

    % start to extract training pixels from sample objects
    load(fullfile(record_filefolder, record_filename)); % load record_objs_samples
    record_pixels_samples = convertChangeObjects2Pixels(record_objs_samples, 'train', true); 
    clear record_objs_samples;
    
    record_pixels_samples = record_pixels_samples(samplepixel_ids);

    save([filepath_out, '.part'], 'record_pixels_samples', '-v7.3');
    movefile([filepath_out, '.part'], filepath_out);
    fprintf('Finished processing %s in %0.4f mins\r', filepath_out, toc/60);
end