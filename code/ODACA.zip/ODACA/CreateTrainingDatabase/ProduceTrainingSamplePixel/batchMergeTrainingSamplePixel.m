function batchMergeTrainingSamplePixel(process, source, jobid, jobnum, maxnum)
%% BATCHMERGETRAININGSAMPLEPIXEL Merge sample pixels together as a single .mat, per agent

%% Add code paths
restoredefaultpath;
addpath(genpath(fileparts(fileparts(fileparts(mfilename('fullpath'))))));

%% Setup jobs
if ~exist('process', 'var')
    process = 'local'; % 'local': per tile  or 'global': conus-wide
end
if ~exist('jobid', 'var')
    jobid = 1;
end
if ~exist('jobnum', 'var')
    jobnum = 1;
end
if ~exist('source', 'var')
    source = 'open';  % data source: 'open' or 'manual'
end
if ~exist('maxnum', 'var')
    maxnum = []; % 1000;
end

%% ARD tiles
centralTiles = odacasets.ARDTiles; % to read central tiles

%**** turn if on to check the test tiles
centralTiles = odacasets.ARDTilesTest; % to read central tiles for test 5 tiles

%% Assign tasks first
objtasks = [];

% Randomly stop to dir if mutiple cores are in operations
if jobnum > 1
    rng('shuffle');
    pause(randperm(20,1)); % randomly stoping to give time to other cores to dir!
end
% agents that were defined or focused on
agent_names = lower(fieldnames(odacasets.agents,'-full')); 


% Per agent
fprintf('* Searching sample records to build parallel computing tasks\r');
for j = 1: length(agent_names)
    agentname = char(agent_names(j));
    fprintf('  %s\r', agentname);
    
    switch process
        case 'local'
            % For each tile
            for k = 1: length(centralTiles)
                tile = centralTiles{k};
                switch source
                    case 'open'
                        foldernameSamplePixel = odacasets.folderTrainingSamplePixel;
                    case 'manual'
                        % foldernameSamplePixel = [odacasets.folderTrainingSamplePixel, 'Manual'];
                        foldernameSamplePixel = sprintf('%sManualC%02d', odacasets.folderTrainingSamplePixel, odacasets.refineSampleCollection);
                end
        
                if isempty(maxnum)
                    folderpath_samplepixel = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, foldernameSamplePixel);
                else % number at the end of the filename
                    folderpath_samplepixel = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, sprintf('%s_%04d', foldernameSamplePixel, maxnum));
                end
                % create lookup table
                ic = length(objtasks) + 1;
                objtasks(ic).folder = folderpath_samplepixel;
                objtasks(ic).agentname = agentname;
                objtasks(ic).centraltile = tile;
            end
        case 'global'
            % For global data
            switch source
                case 'open'
                    foldernameSamplePixel = odacasets.folderpathGlobalSamplePixel;
                case 'manual'
                    foldernameSamplePixel = sprintf('%sManualC%02d', odacasets.folderpathGlobalSamplePixel, odacasets.refineSampleCollection);
            end
            if isempty(maxnum)
                folderpath_samplepixel = foldernameSamplePixel;
            else % number at the end of the filename
                folderpath_samplepixel = sprintf('%s_%04d', foldernameSamplePixel, maxnum);
            end
            % create lookup table
            ic = length(objtasks) + 1;
            objtasks(ic).folder = folderpath_samplepixel;
            objtasks(ic).agentname = agentname;
            objtasks(ic).centraltile = [];
    end
end

%% Randomly generate tasks
rng(1);
objtasks = objtasks(randperm(length(objtasks)));
for itask = jobid: jobnum: length(objtasks)
    taskobj = objtasks(itask);
    % Select pixels from objects.
    tic
    if isempty(taskobj.centraltile)
        fprintf('\n* Merging sample records for %s for %s\r', 'global samples', taskobj.agentname);
    else
        fprintf('\n* Merging sample records for %s for %s\r', taskobj.centraltile, taskobj.agentname);
    end

    sample_records = dir(fullfile(taskobj.folder, sprintf('record_samples_%s*.mat', taskobj.agentname)));
    if ~isempty(sample_records)
        mergePixelSamples(sample_records, taskobj.agentname);
    end
    fprintf('* Finished merging sample records with %0.2f mins\r\n', toc/60);
end % end of task
end % end of function

function mergePixelSamples(records, agentname)
    %% Check the merged dataset available or not
    % if the merged dataset exists, we just need to delete the remaining
    % dataset
    fileout = dir(fullfile(records(1).folder, sprintf('record_samples_merged_%s_*.mat', agentname)));
    if ~isempty(fileout)
        %% Delete files which have been loaded
        fprintf('Deletig old records ...\r');
        % remove the old indiviudal records
        for i = 1: length(records)
            delete(fullfile(records(i).folder, records(i).name)); % delete record_objs_samples
        end
        return
    end
    

    %% Load all the records
    fprintf('Loading all records ...\r');
    record_objs_samples_all = [];
    for i = 1: length(records)
        load(fullfile(records(i).folder, records(i).name)); % load record_objs_samples
        % how many samples can we have?
        [~, filename_samp]=fileparts(records(i).name);
        tile_samples = split(filename_samp, '_');
        tile_samples = tile_samples{end-1};
        [record_pixels_samples.Tile] = deal(tile_samples); % that will be used to exclude self tile data
        clear tile_samples;
        record_objs_samples_all = [record_objs_samples_all, record_pixels_samples];
    end
    %% Merge as one
    fprintf('Merging ...\r');
    if ~isempty(record_objs_samples_all)
        record_pixels_samples = record_objs_samples_all; clear record_objs_samples_all;
        filepath_out = fullfile(records(i).folder, ...
         sprintf('record_samples_merged_%s_%010d.mat', agentname, length(record_pixels_samples)));
        save([filepath_out, '.part'], 'record_pixels_samples', '-v7.3');
        movefile([filepath_out, '.part'], filepath_out);
        clear record_pixels_samples;
    end
    %% Delete files which have been loaded
    fprintf('Deletig old records ...\r');
    for i = 1: length(records)
        delete(fullfile(records(i).folder, records(i).name)); % delete record_objs_samples
    end
end
