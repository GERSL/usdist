function batchProduceTrainingSamplePixel(process, source, jobid, jobnum,  maxnum)
%% BATCHPRODUCETRAININGSAMPLEPIXEL Extract sample pixels based on the records of sample objects, and also compress the training sample pixels for each record, and randomly select 100, 000 pixels for for each agent at each 3 by 3 tiles
%% Before starting up, please generate the task list using ONE core by setting 'jobnum = 1'
%% Add code paths
restoredefaultpath;
pathparent = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(genpath(pathparent));

%% Setup jobs
if ~exist('process', 'var')
    process = 'local'; % 'local': per tile  or 'global': conus-wide
end
if ~exist('source', 'var')
    source = 'manual';  % data source: 'open' or 'manual'
end

if ~exist('jobid', 'var')
    jobid = 1;
end
if ~exist('jobnum', 'var')
    jobnum = 1;
end
if ~exist('maxnum', 'var')
    maxnum = []; % [] means this limitaiton was excluded, we did not use this for open-source dataset
end

%% How many training pixels will be extracted for each agent type, for 3-by-3 tiles
numperagent = odacasets.traindata_pixel_num_per_agent; % 50000; % pixels;

%% ARD tiles
centralTiles = odacasets.ARDTiles; % to read central tiles

%**** turn if on to check the test tiles
% centralTiles = odacasets.ARDTilesTest; % to read central tiles for test 5 tiles


%% Assign tasks first
objtasks = [];

% agents that were defined or focused on
agent_names = lower(fieldnames(odacasets.agents,'-full')); 

pause(jobid); % randomly pause to wait different cores to dir the datasets

for i = 1: length(centralTiles) % each region like 3 by 3 tiles
    switch process
        case 'local'
            if odacasets.neighbor
                ARDTiles = getAdjacentARDTiles(centralTiles{i}); % to add neighbor tiles
            else
                ARDTiles = centralTiles; % to add neighbor tiles
            end
            fprintf('* Searching sample records for %s with %d neighbor tiles\r', centralTiles{i}, length(ARDTiles) - 1);
        case 'global'
            if odacasets.neighbor
                ARDTiles = getAdjacentARDTiles(centralTiles); % to add neighbor tiles, and here all tiles will be assigned
            else
                ARDTiles = centralTiles; % to add neighbor tiles
            end
            fprintf('* Searching sample records for %d tiles\r', length(ARDTiles));
    end

    % Per agent
    for j = 1: length(agent_names)
        agentname = char(agent_names(j));
        fprintf('  %s\r', agentname);

        %% Create a lookup table for all records, with attributes of folder,name, tile, and number
        lookup_records = [];
        i_record = 1;
        for k = 1: length(ARDTiles)
            tile = ARDTiles{k};
            switch source
                case 'open'
                    foldernameSampleObject = odacasets.folderTrainingSampleObject;
                case 'manual'
                    foldernameSampleObject = sprintf('%sRefineV%02d', odacasets.folderTrainingSampleObject, odacasets.refineSampleCollection);
            end
            if isempty(maxnum)
                sample_records = dir(fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, foldernameSampleObject,                              sprintf('record_samples_%s*.mat', agentname)));
            else % number at the end of the filename
                sample_records = dir(fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, sprintf('%s_%04d', foldernameSampleObject, maxnum),  sprintf('record_samples_%s*.mat', agentname)));
            end

            for m = 1: length(sample_records)
                % restrieve information
                [~, sample_record] = fileparts(sample_records(m).name);
                sample_record = split(sample_record, '_');
                num_samplepixels = str2double(sample_record{end}); % number of valid pixel samples

                % create lookup table
                lookup_records(i_record).folder = sample_records(m).folder;
                lookup_records(i_record).name = sample_records(m).name;
                lookup_records(i_record).tile = tile;
                lookup_records(i_record).number = num_samplepixels;
                i_record = i_record + 1;
            end
        end
        clear i_record tile sample_records num_samplepixels sample_record;

        %% Randomly select the training pixels
        totalnum = 0;
        if ~isempty(lookup_records)
            totalnum = sum([lookup_records.number]); % count toal number of training pixel samples over 3 by 3 tiles
        end
        if totalnum > 0
            % generate a random list of id of pixel on all training samples, based on static random
            ids_rand = randpermStatic(totalnum, numperagent);
            id_accumulated = 0; % indicate the starting ID
            for i_record = 1: length(lookup_records)
                ids_pixels = 1: lookup_records(i_record).number; % ID of pixels for the current record
                lookup_records(i_record).sampleids = ids_pixels(ismember(id_accumulated + ids_pixels, ids_rand)); % 'id_accumulated +' will match the id randomly selected ahead of time
                id_accumulated = id_accumulated + lookup_records(i_record).number; % update to new ID
            end
            clear i_record id_accumulated ids_rand ids_pixels;
        end
        
        %% Setup parallel jobs
        if totalnum > 0
            % assgin new task
            for i_record = 1: length(lookup_records)
                sample_records = lookup_records(i_record);
                if ~isempty(sample_records.sampleids)
                    ic = length(objtasks) + 1;
                    objtasks(ic).centraltile = centralTiles{i};
                    objtasks(ic).tile = sample_records.tile;
                    objtasks(ic).folder = sample_records.folder;
                    objtasks(ic).name = sample_records.name;
                    objtasks(ic).sampleids = sample_records.sampleids;
                    objtasks(ic).maxnum = maxnum;
                end
            end
        end
    end

    %% Do not need to iterate to the next i, since all tiles have been assigned
    if strcmpi(process, 'global')
        break; % only one-time process
    end
end

%% Randomly generate tasks
rng(1);
objtasks = objtasks(randperm(length(objtasks)));
for itask = jobid: jobnum: length(objtasks)
    taskobj = objtasks(itask);
    % Define the process
    switch process
        case 'local'
            %% Create sample pixels for each tile with being 3-by-3 tiles, moving window
            switch source
                case 'open'
                    foldernameSamplePixel = odacasets.folderTrainingSamplePixel;
                case 'manual'
                    foldernameSamplePixel = sprintf('%sRefineV%02d', odacasets.folderTrainingSamplePixel, odacasets.refineSampleCollection);
            end

            if isempty(taskobj.maxnum)
                folderpath_sampleready = fullfile(odacasets.pathResultODACA, taskobj.centraltile, odacasets.folderTrainingData, foldernameSamplePixel);
            else % number at the end of the filename
                folderpath_sampleready = fullfile(odacasets.pathResultODACA, taskobj.centraltile, odacasets.folderTrainingData, sprintf('%s_%04d', foldernameSamplePixel, taskobj.maxnum));
            end
            
            if ~isfolder(folderpath_sampleready)
                mkdir(folderpath_sampleready);
            end
        case 'global'
            %% global sample pixels all the tiles
            switch source
                case 'open'
                    foldernameSamplePixel = odacasets.folderpathGlobalSamplePixel;
                case 'manual'
                    foldernameSamplePixel = [odacasets.folderpathGlobalSamplePixel, 'Refine'];
            end

            if isempty(taskobj.maxnum)
                folderpath_sampleready = foldernameSamplePixel;
            else % number at the end of the filename
                folderpath_sampleready = sprintf('%s_%04d', foldernameSamplePixel, taskobj.maxnum);
            end
            if ~isfolder(folderpath_sampleready)
                mkdir(folderpath_sampleready);
            end
    end
    % Select pixels from objects.
    selectPixelSamplesFromObjectSamples(folderpath_sampleready, taskobj.tile, taskobj.folder, taskobj.name, taskobj.sampleids);
end % end of task
end % end of function

