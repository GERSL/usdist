function compressPixelSamples(centraltile, tile, sample_record, sampleratio)
%COMPRESSPIXELSAMPLES 
   filepath_record = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderTrainingSamplePixel, sample_record);
   folderpath_out = fullfile(odacasets.pathResultODACA, centraltile, odacasets.folderTrainingData, odacasets.folderTrainingSampleModelReady);
   if ~isfolder(folderpath_out)
        mkdir(folderpath_out);
   end
    tic
    [~, sample_record_name] = fileparts(sample_record);
    sample_record = split(sample_record_name, '_');
    sample_num = str2num(sample_record{end});
    sample_num = round(sampleratio.* sample_num);
    if sample_num > 0
         load(filepath_record); % load record_pixels_samples
         if sampleratio < 1 % some of them picked
            record_pixels_samples = record_pixels_samples(randpermStatic(length(record_pixels_samples), sample_num));
         end
         filepath_out = fullfile(folderpath_out, ...
             sprintf('%s_%s_%010d.mat', sample_record_name, tile, length(record_pixels_samples)));

        save([filepath_out, '.part'], 'record_pixels_samples', '-v7.3');
        movefile([filepath_out, '.part'], filepath_out);
        fprintf('Finished processing %s in %0.4f mins\r', filepath_out, toc/60);
    end
end

