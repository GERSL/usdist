% just update the job tasks
batchProduceTrainingSamplePixel('local', 'open', 1, 1);
batchProduceTrainingSamplePixel('global', 'open', 1, 1);