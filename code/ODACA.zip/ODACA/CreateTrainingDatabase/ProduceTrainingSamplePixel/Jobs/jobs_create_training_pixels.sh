#!/bin/bash
#SBATCH -J samp_pix
#SBATCH --partition=priority			# specify partition
#SBATCH --account=zhz18039			# specify the priority account 
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --array 1-300
#SBATCH --constraint='epyc128'
#SBATCH --mem-per-cpu=50G
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err

# Go back to <COLD_v2>
cd ../

module load matlab


matlab -nodisplay -singleCompThread -r "batchProduceTrainingSamplePixel('local', 'open', $SLURM_ARRAY_TASK_ID, $SLURM_ARRAY_TASK_MAX, 200); exit"
matlab -nodisplay -singleCompThread -r "batchProduceTrainingSamplePixel('local', 'open', $SLURM_ARRAY_TASK_ID, $SLURM_ARRAY_TASK_MAX, 400); exit"
matlab -nodisplay -singleCompThread -r "batchProduceTrainingSamplePixel('local', 'open', $SLURM_ARRAY_TASK_ID, $SLURM_ARRAY_TASK_MAX, 600); exit"
matlab -nodisplay -singleCompThread -r "batchProduceTrainingSamplePixel('local', 'open', $SLURM_ARRAY_TASK_ID, $SLURM_ARRAY_TASK_MAX, 800); exit"
matlab -nodisplay -singleCompThread -r "batchProduceTrainingSamplePixel('local', 'open', $SLURM_ARRAY_TASK_ID, $SLURM_ARRAY_TASK_MAX, 1000); exit"
matlab -nodisplay -singleCompThread -r "batchProduceTrainingSamplePixel('local', 'open', $SLURM_ARRAY_TASK_ID, $SLURM_ARRAY_TASK_MAX, 1200); exit"
matlab -nodisplay -singleCompThread -r "batchProduceTrainingSamplePixel('local', 'open', $SLURM_ARRAY_TASK_ID, $SLURM_ARRAY_TASK_MAX, 1400); exit"
matlab -nodisplay -singleCompThread -r "batchProduceTrainingSamplePixel('local', 'open', $SLURM_ARRAY_TASK_ID, $SLURM_ARRAY_TASK_MAX, 1600); exit"
matlab -nodisplay -singleCompThread -r "batchProduceTrainingSamplePixel('local', 'open', $SLURM_ARRAY_TASK_ID, $SLURM_ARRAY_TASK_MAX, 1800); exit"

exit

matlab -nodisplay -singleCompThread -r "batchProduceTrainingSamplePixel('local', 'open', $SLURM_ARRAY_TASK_ID, $SLURM_ARRAY_TASK_MAX); exit"
matlab -nodisplay -singleCompThread -r "batchProduceTrainingSamplePixel('global', 'open', $SLURM_ARRAY_TASK_ID, $SLURM_ARRAY_TASK_MAX); exit"

exit

#SBATCH --partition=priority			# specify partition
#SBATCH --account=zhz18039			# specify the priority account 


#SBATCH --partition=general