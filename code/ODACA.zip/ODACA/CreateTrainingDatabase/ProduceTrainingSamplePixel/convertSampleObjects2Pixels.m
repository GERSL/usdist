function convertSampleObjects2Pixels(tile, recordname, varargin)
%     tile = 'h002v009';
%     recordname = 'record_samples_fire_2006_0000000108.mat';
    tic
    p = inputParser;
    addParameter(p, 'minoverlap', 0.5);
    addParameter(p, 'maxpixels', []); % NONE means 'do not setup'
    parse(p,varargin{:});
    minoverlap = p.Results.minoverlap;
    maxpixels = p.Results.maxpixels;
    
    load(fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderTrainingSamples, recordname));

    recordnames = split(recordname, '_');
    recordagent = recordnames{3};
    record_objs_samples = filterTrainingSamples(recordagent, record_objs_samples, 'minoverlap', minoverlap, 'maxpixels', maxpixels);
    record_pixels_samples = convertChangeObjects2Pixels(record_objs_samples, 'train', true);
    clear record_objs_samples;
    
    [~, recordname]= fileparts(recordname);

    folder_pixelsamples = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderTrainingSamplePixel);
    if ~isfolder(folder_pixelsamples)
        mkdir(folder_pixelsamples);
    end
    path_samples_pixels = fullfile(folder_pixelsamples, sprintf('%s_%010d.mat', recordname, length(record_pixels_samples)));
    save([path_samples_pixels, '.part'], 'record_pixels_samples', '-v7.3');
    movefile([path_samples_pixels, '.part'], path_samples_pixels);

    fprintf('Finished processing %s in %0.2f mins\r', path_samples_pixels, toc/60);
end