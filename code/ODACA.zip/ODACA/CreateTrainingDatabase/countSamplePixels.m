
%% Add code paths
[pathpackage, ~] = fileparts(mfilename('fullpath')); 
addpath(pathpackage);
addpath(fullfile(pathpackage, 'TrainingSampleObject'));
addpath(fullfile(pathpackage, 'TrainingSamplePixel'));
pathparent = fileparts(pathpackage); 
addpath(pathparent);
addpath(fullfile(pathparent, 'Shared')); % add the <Shared>
addpath(fullfile(pathparent, 'Classification')); 


%% ARD tiles
centralTiles = odacasets.ARDTiles; % to read central tiles

%% Assign tasks first
objtasks = [];

agent_names = AgentTypes('').name; 
fprintf('%s %s %s %s %s %s %s %s\r', 'centraltile', agent_names);
    
for i = 1: length(centralTiles) % each region like 3 by 3 tiles
    ARDTiles = getAdjacentARDTiles(centralTiles{i}); % to add neighbor tiles

        
    % count toal number of training pixel samples over 3 by 3 tiles
    totalnum = zeros(length(agent_names), 1);
    record_dir = [];
    for k = 1: length(ARDTiles)
        tile = ARDTiles{k};
        for j = 1: length(agent_names)
            agentname = char(agent_names(j));
            sample_records = dir(fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderTrainingSamples, sprintf('record_samples_%s*.mat', agentname)));
            record_dir(k).dir = sample_records; % will be used later
            for m = 1: length(sample_records)
                sample_record = sample_records(m).name;
                [~, sample_record] = fileparts(sample_record);
                sample_record = split(sample_record, '_');
                totalnum(j) = totalnum(j) + str2num(sample_record{end}); % number of valid pixel samples
            end
        end
    end
    fprintf('%s %d %d %d %d %d %d %d\r', centralTiles{i}, totalnum);
end
