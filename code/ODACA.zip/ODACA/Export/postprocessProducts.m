% This function postprocess the products

function postprocessProducts(jobid, jobnum)
    %% Add code paths
    [pathpackage, ~] = fileparts(mfilename('fullpath')); 
    pathparent = fileparts(pathpackage); 
    addpath(genpath(pathparent));

    %% Jobs
    if ~exist('jobid', 'var') || ~exist('jobnum', 'var')
        jobid = 1; jobnum = 1;
    end
    %% ARD tiles
    ARDTilesCentral = odacasets.ARDTiles; % to read central tiles
    if odacasets.neighbor
        ARDTiles = getAdjacentARDTiles(ARDTilesCentral); % to add neighbor tiles. 
    else
        ARDTiles = ARDTilesCentral; % to add neighbor tiles. 
    end

    years = odacasets.years;

    objtasks = [];
    for jARD = 1: length(ARDTiles) % loop ARD to assign different tile to different coresprocess, that will fully use all the computing resources
        for iy = 1: length(years)
            objtasks(jARD).tile  = ARDTiles{jARD};
            objtasks(jARD).year  = years(iy);
        end
    end
    rng(1);
    objtasks = objtasks(randperm(length(objtasks)));
    [taskids] = assignTasks(objtasks, jobid, jobnum);

    %% Process each task
    product_version = odacasets.product_version;
    for itask = taskids

        taskobj = objtasks(itask);
        tile = taskobj.tile;
        year = taskobj.year;
        
        dir_product = fullfile(odacasets.pathResultMaps);
    
        postprocessAgentMaps(tile, year, product_version, dir_product);
    end
end

function entire_map_grid_index = loadEntireGrids(dir_product, year, product_version, name_reg, h_min, h_max, v_min, v_max)
    tile_size = 5000;
    hs = h_min:h_max;
    vs = v_min:v_max;
    entire_map_grid_index = zeros(tile_size.*length(hs), tile_size.*length(vs));
    for iv = 1: length(vs)
        for ih = 1: length(hs)
            tile = sprintf('h%03dv%03d', ih, iv);
            path_product = fullfile(dir_product, tile, sprintf('CD_%s_%d_V%02d', tile([2:4, 6:8]), year, product_version), sprintf('CD_%s_%d_V%02d_%s.tif', tile([2:4, 6:8]), year, product_version, name_reg));
            if isfile(path_product)
                entire_map_grid_index((iv -1)*tile_size + 1 : iv*tile_size, (ih-1)*tile_size + 1: ih*tile_size)= imread(path_product);
            end
        end
    end
end

function postprocessAgentMaps(tile, year, product_version, dir_product)
    tic;
    
    % load the 3 by 3 tiles as one map, and locate the tile at the central
    % region
    tile_h = str2num(ntiles{t}(2:4));
    tile_v = str2num(ntiles{t}(6:8));
    entire_APRI = loadEntireGrids(dir_product, year, product_version, 'APRI', tile_h - 1, tile_h + 1, tile_v - 1, tile_v + 1);
    entire_APRICONF = loadEntireGrids(dir_product, year, product_version, 'APRICONF', tile_h - 1, tile_h + 1, tile_v - 1, tile_v + 1);
    entire_ASEC = loadEntireGrids(dir_product, year, product_version, 'ASEC', tile_h - 1, tile_h + 1, tile_v - 1, tile_v + 1);
    entire_ASECCONF = loadEntireGrids(dir_product, year, product_version, 'ASECCONF', tile_h - 1, tile_h + 1, tile_v - 1, tile_v + 1);
    entire_AQA = loadEntireGrids(dir_product, year, product_version, 'AQA', tile_h - 1, tile_h + 1, tile_v - 1, tile_v + 1);
    
    % create map into objects
    patches = regionprops(bwconncomp(entire_APRI > 0 & entire_APRI < 255), 'Area', 'PixelIdxList');
    
    % loop each object
    for ip = 1: length(patches)
        % primary agent
        agent_pri_labels = entire_APRI(patches(ip).PixelIdxList);
        % mutiple disturbance agents
        if length(unique(agent_pri_labels)) >  1
            score_pri_record = 0;
            for ilab = 1: length(agent_pri_labels)
                agent_pri_lab = agent_pri_labels(ilab);
                pixel_list_part = patches(ip).PixelIdxList(agent_pri_labels == agent_pri_lab);
                score_pri_lab = mean(entire_APRICONF(pixel_list_part)); % object's classification score
                if (score_pri_lab > score_pri_record)
                    % update pixel AQA if the agent was updated
                    if agent_pri_lab~=unique(entire_APRI(pixel_list_part))
                        entire_AQA(patches(ip).PixelIdxList) = 4; % 4: refined by neighboring tiles, also see exportProducts.m
                    end
                    % update entire object
                    entire_APRI(patches(ip).PixelIdxList)       = agent_pri_lab;
                    entire_APRICONF(patches(ip).PixelIdxList)   = score_pri_lab;
                    score_pri_record = score_pri_lab; % update the classification score
                end
            end
        end

        % secondary agent
        agent_sec_labels = entire_ASEC(patches(ip).PixelIdxList);
        % mutiple disturbance agents
        if length(unique(agent_sec_labels)) >  1
            score_sec_record = 0;
            for ilab = 1: length(agent_sec_labels)
                agent_sec_lab = agent_sec_labels(ilab);
                pixel_list_part = patches(ip).PixelIdxList(agent_sec_labels == agent_sec_lab);
                score_sec_lab = mean(entire_ASECCONF(pixel_list_part)); % object's classification score
                if (score_sec_lab > score_sec_record)
                    % update entire object
                    entire_ASEC(patches(ip).PixelIdxList)       = agent_sec_lab;
                    entire_ASECCONF(patches(ip).PixelIdxList)   = score_sec_lab;
                    score_sec_record = score_sec_lab; % update the classification score
                end
            end
        end
    end


    % load GRIDObj
    filepath_changeobjmap = fullfile(odacasets.pathResultODACA, tile, odacasets.folderAuxilliaryData, 'DEM', sprintf('%s_DEM.tif',  tile));
    image_obj = GRIDobj(filepath_changeobjmap);
    image_obj.Z = entire_APRI(5001:10000, 5001:10000);
    GRIDobj2geotiff(image_obj, fullfile(folderpath_map, sprintf('CD_%s_%d_V%02d_APRI.tif', tile([2:4, 6:8]), year, product_version)));

    image_obj.Z = entire_APRICONF(5001:10000, 5001:10000);
    GRIDobj2geotiff(image_obj, fullfile(folderpath_map, sprintf('CD_%s_%d_V%02d_ASEC.tif', tile([2:4, 6:8]), year, product_version)));

    image_obj.Z = entire_ASEC(5001:10000, 5001:10000);
    GRIDobj2geotiff(image_obj, fullfile(folderpath_map, sprintf('CD_%s_%d_V%02d_APRICONF.tif', tile([2:4, 6:8]), year, product_version)));

    image_obj.Z = entire_ASECCONF(5001:10000, 5001:10000);
    GRIDobj2geotiff(image_obj, fullfile(folderpath_map, sprintf('CD_%s_%d_V%02d_ASECCONF.tif', tile([2:4, 6:8]), year, product_version)));

    image_obj.Z = entire_AQA(5001:10000, 5001:10000);
    GRIDobj2geotiff(image_obj, fullfile(folderpath_map, sprintf('CD_%s_%d_V%02d_AQA.tif', tile([2:4, 6:8]), year, product_version)));




    image_obj = [];
    path_product = fullfile(dir_product, tile, sprintf('CD_%s_%d_V%02d', tile([2:4, 6:8]), year, product_version), sprintf('CD_%s_%d_V%02d_%s.tif', tile([2:4, 6:8]), year, product_version, name_reg));
    fprintf('Loading %s\n', path_product);
    
    image_obj_year = GRIDobj(path_product);

    % update to the new object
    if isempty(image_obj)
        image_obj = image_obj_year;
        if ~isempty(data_type)
            image_obj.Z = zeros([size(image_obj_year.Z), length(years)], data_type);
        else
            image_obj.Z = zeros([size(image_obj_year.Z), length(years)]);
        end
    end
    image_obj.Z(:,:, i) = image_obj_year.Z;

    dir_product_stack = [dir_product, 'Stack'];
    dir_product_stack = fullfile(dir_product_stack, name_reg);
    if ~isfolder(dir_product_stack)
        mkdir(dir_product_stack);
    end
    filename_stack = sprintf('CD_%s_%d_%d_V%02d_%s.tif', tile([2:4, 6:8]), min(years), max(years), product_version, name_reg);
    filepath_stack = fullfile(dir_product_stack, filename_stack);
    
    tiffTags = struct('Compression', Tiff.Compression.LZW);
    
    geotiffwrite(filepath_stack,image_obj.Z,image_obj.georef.SpatialRef,...
        'GeoKeyDirectoryTag',image_obj.georef.GeoKeyDirectoryTag,...
        'TiffTags', tiffTags);

    fprintf('Finished stacking %s with %0.2f mins\n', filepath_stack, toc/60);
end

