function extractAnnualChangeDetectionMap(jobid, jobnum)
    %% Add code paths
    [pathpackage, ~] = fileparts(mfilename('fullpath')); 
    pathparent = fileparts(pathpackage); 
    addpath(genpath(pathparent));

    %% Jobs
    if ~exist('jobid', 'var') || ~exist('jobnum', 'var')
        jobid = 1; jobnum = 1;
    end
    name_reg = 'AGENT';
    odacasets.pathResultRelease
    folder_des = odacasets.pathResultRelease;

    %% ARD tiles
    ARDTilesCentral = odacasets.ARDTiles; % to read central tiles
    if odacasets.neighbor
        ARDTiles = getAdjacentARDTiles(ARDTilesCentral); % to add neighbor tiles. 
    else
        ARDTiles = ARDTilesCentral; % to add neighbor tiles. 
    end

    years = odacasets.years;

    objtasks = [];
    for jARD = 1: length(ARDTiles) % loop ARD to assign different tile to different coresprocess, that will fully use all the computing resources
        objtasks(jARD).tile  = ARDTiles{jARD};
        objtasks(jARD).years  = years;
    end
    rng(1);
    objtasks = objtasks(randperm(length(objtasks)));
    [taskids] = assignTasks(objtasks, jobid, jobnum);

    %% Process each task
    product_version = odacasets.product_version;
    for itask = taskids

        taskobj = objtasks(itask);
        tile = taskobj.tile;
        years = taskobj.years;
        
        for iy = 1: length(years)
            yr = years(iy);
            foldername = sprintf('CD_%s_%d_V%02d', tile([2:4, 6:8]), yr, product_version);
            filepath_map_src = fullfile( odacasets.pathResultRelease, tile, foldername, sprintf('%s_%s.tif', foldername, name_reg));
            dir_year_map = fullfile(folder_des, num2str(yr));
            if ~isfolder(dir_year_map)
                mkdir(dir_year_map);
            end
            map_obj = GRIDobj(filepath_map_src);
            map_obj.Z(map_obj.Z==255) = 0;
            map_obj.Z(map_obj.Z==2) = 0; % agr.
            map_obj.Z(map_obj.Z==8) = 0; % other
            map_obj.Z(map_obj.Z>0) = 255;
            map_obj.Z = uint8(map_obj.Z);
            filepath_map_des = fullfile(dir_year_map, sprintf('%s_CHANGE.tif', foldername));
            GRIDobj2geotiff(map_obj, filepath_map_des);
            % copyfile(filepath_map_src, dir_year_map);
        end
    end
end











