function exportProducts(jobid, jobnum)
%% exportProductAgent Export yearly disturbance agent map

    %% Add code paths
    [pathpackage, ~] = fileparts(mfilename('fullpath')); 
    addpath(pathpackage);
    pathparent = fileparts(pathpackage); 
    addpath(pathparent);
    addpath(fullfile(pathparent, 'Shared')); % add the <Shared>

    %% Jobs
    if ~exist('jobid', 'var') || ~exist('jobnum', 'var')
        jobid = 1; jobnum = 1;
    end

    products = {'time', 'magnitude', 'rmagnitude', 'duration', 'model_qa', 'agent'};
    products = {'agent'}; % automatedly start up the post-processings
    products = {'agent_tile_post'};
    % products = {'time', 'magnitude'};
    % products = {'rmagnitude'};

    %% ARD tiles
    ARDTilesCentral = odacasets.ARDTiles; % to read central tiles
    if odacasets.neighbor
        ARDTiles = getAdjacentARDTiles(ARDTilesCentral); % to add neighbor tiles. 
    else
        ARDTiles = ARDTilesCentral; % to add neighbor tiles. 
    end
    years = odacasets.years;
    % product_version = odacasets.product_version;
    % product_version = 2;

    if isempty(odacasets.refineSampleCollection)
        product_version = 0; % indicate the maps using open-source data
    else
        product_version = odacasets.refineSampleCollection + 1; % following the sample collection's #
    end
    % product_version = 3;

    objtasks = [];

    for jARD = 1: length(ARDTiles) % loop ARD to assign different tile to different coresprocess, that will fully use all the computing resources
        for iy = 1: length(years)
            for ip = 1: length(products)
                ic = length(objtasks) + 1;
                objtasks(ic).tile = ARDTiles{jARD}; 
                objtasks(ic).year  = years(iy);
                objtasks(ic).product  = products{ip};
            end
        end
    end
    rng(1);
    objtasks = objtasks(randperm(length(objtasks)));

    %% Process each task
    for itask = jobid: jobnum: length(objtasks)
        taskobj = objtasks(itask);
        tile = taskobj.tile;
        year = taskobj.year;
        product = taskobj.product;
        dir_product = fullfile(odacasets.pathResultMaps, sprintf('V%02d', product_version), tile, sprintf('CD_%s_%d_V%02d', tile([2:4, 6:8]), year, product_version));
        switch product
            case 'time'
                exportDisturbanceTimeMaps(tile, year, product_version, dir_product);
            case 'magnitude'
                exportDisturbanceMagnitudeMaps(tile, year, product_version, dir_product);
            case 'rmagnitude'
                exportDisturbanceRMagnitudeMaps(tile, year, product_version, dir_product);
            case 'duration'
                exportDisturbanceDurationMaps(tile, year, product_version, dir_product);
            case 'model_qa'
                exportDisturbanceModelQAMaps(tile, year, product_version, dir_product);
            case 'agent'
                exportDisturbanceAgentMaps(tile, year, product_version, dir_product, 'mapround', product_version); % V00 V01 products based on the first-round manul data, 
                % extract the postprocessed maps afterforwar
                % dir_product = fullfile(odacasets.pathResultMapsPost, tile, sprintf('CD_%s_%d_V%02d', tile([2:4, 6:8]), year, product_version));
                % exportDisturbanceAgentMapsTilePostprocess(tile, year, product_version, dir_product, 'mapround', mapround); % V04 products based on the fourth-round manul data
            case 'agent_tile_post'
                dir_product = fullfile(odacasets.pathResultMaps, sprintf('V%02dPost', product_version), tile, sprintf('CD_%s_%d_V%02d', tile([2:4, 6:8]), year, product_version));
                % mapround = odacasets.refineSampleCollection; % following the sample collection's #
                exportDisturbanceAgentMapsTilePostprocess(tile, year, product_version, dir_product); % V04 products based on the fourth-round manul data
        end
    end
end


function exportDisturbanceTimeMaps(tile, yr, product_version, dir_product)
    %% EXPORTDISTURBANCETIMEMAPS is export disturbance time map (unit: DOY)
    tic
    %% Pre-setted paras
    path_disturbanc_time = dir_product;
    if ~isfolder(path_disturbanc_time)
        mkdir(path_disturbanc_time);
    end
    path_out = fullfile(path_disturbanc_time, sprintf('CD_%s_%d_V%02d_TIME.tif', tile([2:4, 6:8]), yr, product_version));

    if isfile(path_out)
        fprintf('Exist %s\r', path_out);
        return;
    end
    
    %% Load COLD change map
    img_dist = loadCOLDDisturbanceDOYMap(tile, yr);

    %% Load Gridobj
    load(fullfile(odacasets.pathResultCOLD, tile, 'metadata.mat')); %#ok<LOAD>
    gridobj = metadata.GRIDobj;
    gridobj.Z = uint16(img_dist);  % DOY 1~366
    gridobj.Z(img_dist==0) = intmax('uint16'); % exclude pixels with no disturbance
    clear img_dist;


    %% CONUS region only
    conus_region = getNLCDCONUSRegion(tile, 2021); % CONUS region's ROI
    gridobj.Z(~conus_region) = intmax('uint16'); % exclude pixels out of CONUS region
    clear conus_region;

    %% Save as
    GRIDobj2geotiff(gridobj, path_out);
    fprintf('Finish creating %s with %0.2f mins\r', path_out, toc/60);

end

function exportDisturbanceDurationMaps(tile, yr, product_version, dir_product)
%% EXPORTDISTURBANCEDURATIONMAPS is to export disturbance duration maps
    tic
    %% Pre-setted paras
    path_disturbance_dur = dir_product;
    if ~isfolder(path_disturbance_dur)
        mkdir(path_disturbance_dur);
    end
    path_out = fullfile(path_disturbance_dur, sprintf('CD_%s_%d_V%02d_DUR.tif', tile([2:4, 6:8]), yr, product_version));
    if isfile(path_out)
        fprintf('Exist %s\r', path_out);
        return;
    end
    
    %% Load COLD change map
    img_dist = loadCOLDDisturbanceDOYMap(tile, yr);

    %% Load COLD duration map
    path_result_changemap = fullfile(odacasets.pathResultCOLD, tile, odacasets.folderYearlyCOLDChangeDurMap);
    img_dist_dur = imread(fullfile(path_result_changemap, ['change_duration_map_',num2str(yr),'.tif']));
    img_dist_dur(img_dist ==0) = intmax('uint16'); % remove non-disturbance, less than 4 pixels, 65535 is no disturbance
    clear img_dist;
    
    %% Load Gridobj
    load(fullfile(odacasets.pathResultCOLD, tile, 'metadata.mat')); %#ok<LOAD>
    gridobj = metadata.GRIDobj;
    gridobj.Z = uint16(img_dist_dur);  % days 1~65535; 65534 means post-time series model (see COLD package, exportChangeDurationMap.m)
    clear img_dist_dur;

    %% CONUS region only
    conus_region = getNLCDCONUSRegion(tile, 2021); % CONUS region's ROI
    gridobj.Z(~conus_region) = intmax('uint16'); % exclude pixels out of CONUS region
    clear conus_region;

    %% Save as
    GRIDobj2geotiff(gridobj, path_out);
    fprintf('Finish creating %s with %0.2f mins\r', path_out, toc/60);

end

function exportDisturbanceModelQAMaps(tile, yr, product_version, dir_product)
 % EXPORTDISTURBANCEMODELQAMAPS is to export disturbance model QA map
    tic
    %% Pre-setted paras
    path_disturbance_qa = dir_product;
    if ~isfolder(path_disturbance_qa)
        mkdir(path_disturbance_qa);
    end
    path_out = fullfile(path_disturbance_qa, sprintf('CD_%s_%d_V%02d_MQA.tif', tile([2:4, 6:8]), yr, product_version));
    if isfile(path_out)
        fprintf('Exist %s\r', path_out);
        return;
    end

    %% Load COLD change map
    img_dist = loadCOLDDisturbanceDOYMap(tile, yr);

    %% Load COLD Model QA map
    path_result_changemap = fullfile(odacasets.pathResultCOLD, tile, odacasets.folderYearlyCOLDModelQAMap);
    img_dist_qa = imread(fullfile(path_result_changemap, ['change_premodel_qa_map_',num2str(yr),'.tif']));
    img_dist_qa(img_dist ==0) = intmax('uint8');  % remove non-disturbance, less than 4 pixels, 255 is no disturbance
    clear img_dist;

    %% Load Gridobj
    load(fullfile(odacasets.pathResultCOLD, tile, 'metadata.mat')); %#ok<LOAD>
    gridobj = metadata.GRIDobj;
    gridobj.Z = uint8(img_dist_qa);  % 0-255
    clear img_dist_qa;

    %% CONUS region only
    conus_region = getNLCDCONUSRegion(tile, 2021); % CONUS region's ROI
    gridobj.Z(~conus_region) = intmax('uint8'); % exclude pixels out of CONUS region
    clear conus_region;

    %% Save as
    GRIDobj2geotiff(gridobj, path_out);
    fprintf('Finish creating %s with %0.2f mins\r', path_out, toc/60);

end


function exportDisturbanceMagnitudeMaps(tile, yr, product_version, dir_product)
%% EXPORTDISTURBANCEMAGNITUDEMAPS is export disturbance magnitude map
    tic
    %% Pre-setted paras
    path_disturbance_mag = dir_product;
    if ~isfolder(path_disturbance_mag)
        mkdir(path_disturbance_mag);
    end
    path_out = fullfile(path_disturbance_mag, sprintf('CD_%s_%d_V%02d_MAG.tif', tile([2:4, 6:8]), yr, product_version));
    if isfile(path_out)
        fprintf('Exist %s\r', path_out);
        return;
    end
    
   
    %% Load COLD change map
    img_dist = loadCOLDDisturbanceDOYMap(tile, yr);

    %% Load COLD magnitude map
    path_result_changemap = fullfile(odacasets.pathResultCOLD, tile, odacasets.folderYearlyCOLDChangeMagMap);
    img_dist_mag = imread(fullfile(path_result_changemap, ['change_magnitude_map_',num2str(yr),'.tif']));
    img_dist_mag(img_dist ==0) = 0; % i.e., 365 days
    clear img_dist;

    %% Load Gridobj
    load(fullfile(odacasets.pathResultCOLD, tile, 'metadata.mat')); %#ok<LOAD>
    gridobj = metadata.GRIDobj;
    gridobj.Z = img_dist_mag; % single
    clear img_dist_mag;

    %% CONUS region only
    conus_region = getNLCDCONUSRegion(tile, 2021); % CONUS region's ROI
    gridobj.Z(~conus_region) = 0; % exclude pixels out of CONUS region
    clear conus_region;

    %% Save as
    GRIDobj2geotiff(gridobj, path_out);
    fprintf('Finish creating %s with %0.2f mins\r', path_out, toc/60);

end

function exportDisturbanceRMagnitudeMaps(tile, yr, product_version, dir_product)
%% EXPORTDISTURBANCEMAGNITUDEMAPS is export disturbance magnitude map
    tic
    %% Pre-setted paras
    path_disturbance_mag = dir_product;
    if ~isfolder(path_disturbance_mag)
        mkdir(path_disturbance_mag);
    end
    path_out = fullfile(path_disturbance_mag, sprintf('CD_%s_%d_V%02d_RMAG.tif', tile([2:4, 6:8]), yr, product_version));
    if isfile(path_out)
        fprintf('Exist %s\r', path_out);
        return;
    end
    
   
    %% Load COLD change map
    img_dist = loadCOLDDisturbanceDOYMap(tile, yr);

    %% Load COLD magnitude map
    path_result_changemap = fullfile(odacasets.pathResultCOLD, tile, odacasets.folderYearlyCOLDChangeMagMap);
    img_dist_mag = imread(fullfile(path_result_changemap, ['change_rmagnitude_map_',num2str(yr),'.tif']));
    img_dist_mag(img_dist ==0) = 0; % i.e., 365 days
    clear img_dist;

    %% Load Gridobj
    load(fullfile(odacasets.pathResultCOLD, tile, 'metadata.mat')); %#ok<LOAD>
    gridobj = metadata.GRIDobj;
    gridobj.Z = img_dist_mag; % single
    clear img_dist_mag;

    %% CONUS region only
    conus_region = getNLCDCONUSRegion(tile, 2021); % CONUS region's ROI
    gridobj.Z(~conus_region) = 0; % exclude pixels out of CONUS region
    clear conus_region;

    %% Save as
    GRIDobj2geotiff(gridobj, path_out);
    fprintf('Finish creating %s with %0.2f mins\r', path_out, toc/60);

end


function exportDisturbanceAgentMapsTilePostprocess(tile, year, product_version, dir_product)
    tic

    folderpath_map = dir_product; 
    if ~isfolder(folderpath_map)
        mkdir(folderpath_map);
    end
    
    % check the QA band existing or not

    if isfile(fullfile(folderpath_map, sprintf('CD_%s_%d_V%02d_AQA.tif', tile([2:4, 6:8]), year, product_version)))
        fprintf('Exist %s\r', folderpath_map);
        return;
    end
    % load GRIDObj
    filepath_changeobjmap = fullfile(odacasets.pathResultODACA, tile, odacasets.folderAuxilliaryData, 'DEM', sprintf('%s_dem.tif',  tile));
    image_agent1 = GRIDobj(filepath_changeobjmap);
    image_agent1.Z = zeros([image_agent1.size(2), image_agent1.size(1)], 'uint8'); % ratation
    image_agent2 = image_agent1;
    
    image_score1 = image_agent1;
    image_score1.Z = zeros(image_score1.size, 'double');
    image_score2 = image_score1;

    image_qa = image_agent1;
    image_qa.Z = zeros(image_qa.size, 'uint8');
    % layer presents the classification process
    % 1: normal classification
    % 2: refined by MTBS
    % 3: refined by manual interpretation
    % 4: refined by neighboring tiles
    
    % load record
    folderpath_record = fullfile(odacasets.pathResultODACA, tile, [odacasets.YearlyODACAOutputs, sprintf('V%02d', product_version)]);
    if ~isfolder(folderpath_record)
        fprintf('No classified records %s\r', folderpath_record);
        return;
    end

    %% Overlap the MTBS fire polygons, also see loadReferenceMTBS.m
    fire_mtbs = zeros(image_agent1.size); % no fire at default
    % If the classification score less than 0.5, the classified 'fire' will be rejected, and the second agent will be assigned as to.
    filepath_mtbs = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderReferenceLayerMTBS, sprintf('%s_month_mtbs_%d.tif', tile, year));
    % pixel values only vary between 1, 2, 3, 4, and 5, and 6. see code at loadReferenceMTBS.m/<ProduceTrainingSampleObject>
    if isfile(filepath_mtbs)
        fire_temp = imread(filepath_mtbs); % pixel value is month
        fire_mtbs(fire_temp > 0 & fire_temp< 255) = 1;
        % fire_mtbs(imread(filepath_mtbs)> 0) = 1;  # <= v061 we used this
        % code, which did not control the fire.
    end
    filepath_mtbs = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderReferenceLayerMTBS, sprintf('%s_month_mtbs_%d.tif', tile, year-1));
    if isfile(filepath_mtbs)
        fire_temp = imread(filepath_mtbs);
        fire_mtbs(fire_temp > 0 & fire_temp< 255) = 1;
        % fire_mtbs(imread(filepath_mtbs)> 0) = 1;# <= v061 we used this
        % code, which did not control the fire
    end
    filepath_mtbs = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderReferenceLayerMTBS, sprintf('%s_month_mtbs_%d.tif', tile, year+1));
    if isfile(filepath_mtbs)
        fire_temp = imread(filepath_mtbs);
        fire_mtbs(fire_temp > 0 & fire_temp< 255) = 1;
        % fire_mtbs(imread(filepath_mtbs)> 0) = 1;# <= v061 we used this
        % code, which did not control the fire
    end
    fire_mtbs = fire_mtbs'; % rotate the matrix to fit COLD results

    %% Iterate the .mat
    recordfiles = dir(fullfile(folderpath_record, sprintf('record_objs_%d_*.mat', year)));
    for i = 1: length(recordfiles)
        load(fullfile(folderpath_record, recordfiles(i).name));
        for j = 1: length(record_objs)
            image_agent1.Z(record_objs(j).PixelIdxList) = record_objs(j).agent_primary;
            image_agent2.Z(record_objs(j).PixelIdxList) = record_objs(j).agent_secondary;
            image_score1.Z(record_objs(j).PixelIdxList) = record_objs(j).score_primary;
            image_score2.Z(record_objs(j).PixelIdxList) = record_objs(j).score_secondary;
            image_qa.Z(record_objs(j).PixelIdxList) = 1;
            
            % post-process the agent maps using MTBS when the
            % classification scores less than 0.5
            % This can reduce the commission errors of fires
            thrd_fire_conf = odacasets.min_conf_fire;
            if ~isempty(fire_mtbs) && record_objs(j).agent_primary == getfield(odacasets.agents, 'fire') && record_objs(j).score_primary < thrd_fire_conf
                % if no one pixels overlapped to the mtbs fire, switch the secondary and primary agents
                if sum(sum(fire_mtbs(record_objs(j).PixelIdxList))) == 0
                    image_agent1.Z(record_objs(j).PixelIdxList) = record_objs(j).agent_secondary;
                    image_agent2.Z(record_objs(j).PixelIdxList) = record_objs(j).agent_primary;
                    image_score1.Z(record_objs(j).PixelIdxList) = record_objs(j).score_secondary;
                    image_score2.Z(record_objs(j).PixelIdxList) = record_objs(j).score_primary;
                    image_qa.Z(record_objs(j).PixelIdxList) = 2;
                end
            end

        end
        clear record_objs;
    end

    %% Iterate the interpretated samples, sorted by collections 1, 2, 3, 4
    % foldernameSamplePixel = sprintf('%sManual', odacasets.folderTrainingSampleObject);
    % folderpath_sampleready = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, foldernameSamplePixel);
    % % name example: record_samples_forest_management_2015_0000000001_0000004482_0000000002_0000000132.mat
    % recordfiles = dir(fullfile(folderpath_sampleready, sprintf('record_samples_*_%d_*.mat', year)));
    % for i = 1: length(recordfiles)
    %     load(fullfile(folderpath_sampleready, recordfiles(i).name));
    %     for j = 1: length(record_objs_samples)
    %         % when the classified result is not same as to the
    %         % interpreted one, we force to adjust the label
    %         if record_objs_samples(j).AgentCode ~= unique(image_agent1.Z(record_objs_samples(j).PixelIdxList)) % here the ind has been rotated to fit COLD results
    %             % give the primary ones to secondary ones
    %             image_agent2.Z(record_objs_samples(j).PixelIdxList) = image_agent1.Z(record_objs_samples(j).PixelIdxList);
    %             image_score2.Z(record_objs_samples(j).PixelIdxList) = image_score1.Z(record_objs_samples(j).PixelIdxList);
    %             % update the primary ones
    %             image_agent1.Z(record_objs_samples(j).PixelIdxList) = record_objs_samples(j).AgentCode;
    %             image_score2.Z(record_objs_samples(j).PixelIdxList) = 1; % 100 % is given to interpreted samples
    %             image_qa.Z(record_objs_samples(j).PixelIdxList) = 3;
    %         end
    %     end
    %     clear record_objs_samples;
    % end
    for ic = 0: odacasets.refineSampleCollection
        foldernameSamplePixel = sprintf('%sRefineV%02d', odacasets.folderTrainingSampleObject, ic);

        folderpath_sampleready = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, foldernameSamplePixel);
        if isfolder(folderpath_sampleready)
            % name example: record_samples_forest_management_2015_0000000001_0000004482_0000000002_0000000132.mat
            recordfiles = dir(fullfile(folderpath_sampleready, sprintf('record_samples_*_%d_*.mat', year)));
            for i = 1: length(recordfiles)
                load(fullfile(folderpath_sampleready, recordfiles(i).name));
                for j = 1: length(record_objs_samples)
                    % when the classified result is not same as to the
                    % interpreted one, we force to adjust the label
                    if record_objs_samples(j).AgentCode ~= unique(image_agent1.Z(record_objs_samples(j).PixelIdxList)) % here the ind has been rotated to fit COLD results
                        % give the primary ones to secondary ones
                        image_agent2.Z(record_objs_samples(j).PixelIdxList) = image_agent1.Z(record_objs_samples(j).PixelIdxList);
                        image_score2.Z(record_objs_samples(j).PixelIdxList) = image_score1.Z(record_objs_samples(j).PixelIdxList);
                        % update the primary ones
                        image_agent1.Z(record_objs_samples(j).PixelIdxList) = record_objs_samples(j).AgentCode;
                        image_score1.Z(record_objs_samples(j).PixelIdxList) = 1; % 100 % is given to interpreted samples
                        image_qa.Z(record_objs_samples(j).PixelIdxList) = 3;
                    end
                end
                clear record_objs_samples;
            end
        end
    end



    %% Overlap the labeled samples ordered by the versions 1, 2, 3, and 4
    image_agent1.Z = image_agent1.Z'; % same as COLD
    image_agent2.Z = image_agent2.Z'; % same as COLD
    image_score1.Z = round(100.*image_score1.Z'); % same as COLD
    image_score2.Z = round(100.*image_score2.Z'); % same as COLD
    image_qa.Z = image_qa.Z'; % same as COLD


    %% Exclude permanent water
    filepath_gswo = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderReferenceLayerGSWO, sprintf('%s_water_class_%d.tif', tile, year));  % h003v008_1985YearlySeasonality-0000000000-0000000000.tif
	if ~isfile(filepath_gswo) % in case when we do not have the data of the last year see GEE. For example, we do not have layer in 2002 by 2024.
        filepath_gswo = fullfile(odacasets.pathResultODACA, tile, odacasets.folderTrainingData, odacasets.folderReferenceLayerGSWO, sprintf('%s_water_class_%d.tif', tile, year-1));  % h003v008_1985YearlySeasonality-0000000000-0000000000.tif
    end
    files_tmp = dir(filepath_gswo);
    % lead raw gswo layers, also see produceReferenceLayerGSWO.m
    if ~isempty(files_tmp) % if having data available
        i_file = 1; % for the first image intitially
        path_file = fullfile(files_tmp(i_file).folder, files_tmp(i_file).name);
        yearlyimg = imread(path_file);
        for i_file = 2: length(files_tmp)
            path_file = fullfile(files_tmp(i_file).folder, files_tmp(i_file).name);
            yearlyimg = max(imread(path_file), yearlyimg);
        end
        yearlyimg = yearlyimg ==3; % permenant water
        image_agent1.Z(yearlyimg) = intmax('uint8'); % exclude pixels with permanent water
        image_agent2.Z(yearlyimg) = intmax('uint8'); % exclude pixels with permanent water
        image_score1.Z(yearlyimg) = intmax('uint8'); % exclude pixels with permanent water
        image_score2.Z(yearlyimg) = intmax('uint8'); % exclude pixels with permanent water
        image_qa.Z(yearlyimg)     = intmax('uint8'); % exclude pixels with permanent water
        clear gswyearlyimgo;
    else
        warning("No gswo data found from %s\nPlease ahead of time create the raw gswo layers in each ARD by preProcessARDYearlyGSWO.m at <PreprocessOpenData>", filepath_gswo )
    end

    %% exclude pixels with no disturbance
    img_dist = loadCOLDDisturbanceDOYMap(tile, year);
    image_agent1.Z(img_dist==0) = intmax('uint8'); % exclude pixels no disturbance
    image_agent2.Z(img_dist==0) = intmax('uint8'); % exclude pixels no disturbance 
    image_score1.Z(img_dist==0) = intmax('uint8'); % exclude pixels no disturbance
    image_score2.Z(img_dist==0) = intmax('uint8'); % exclude pixels no disturbance
    image_qa.Z(img_dist==0)     = intmax('uint8'); % exclude pixels no disturbance
    clear img_dist;
    
    conus_region = getNLCDCONUSRegion(tile, 2021); % CONUS region's ROI
    image_agent1.Z(~conus_region) = intmax('uint8'); % exclude pixels out of CONUS region
    image_agent2.Z(~conus_region) = intmax('uint8'); % exclude pixels out of CONUS region   
    image_score1.Z(~conus_region) = intmax('uint8'); % exclude pixels out of CONUS region
    image_score2.Z(~conus_region) = intmax('uint8'); % exclude pixels out of CONUS region  
    image_qa.Z(~conus_region)     = intmax('uint8'); % exclude pixels out of CONUS region  
    clear conus_region;


    GRIDobj2geotiff(image_agent1, fullfile(folderpath_map, sprintf('CD_%s_%d_V%02d_APRI.tif', tile([2:4, 6:8]), year, product_version)));
    GRIDobj2geotiff(image_agent2, fullfile(folderpath_map, sprintf('CD_%s_%d_V%02d_ASEC.tif', tile([2:4, 6:8]), year, product_version)));
    GRIDobj2geotiff(image_score1, fullfile(folderpath_map, sprintf('CD_%s_%d_V%02d_APRICONF.tif', tile([2:4, 6:8]), year, product_version)));
    GRIDobj2geotiff(image_score2, fullfile(folderpath_map, sprintf('CD_%s_%d_V%02d_ASECCONF.tif', tile([2:4, 6:8]), year, product_version)));
    GRIDobj2geotiff(image_qa, fullfile(folderpath_map, sprintf('CD_%s_%d_V%02d_AQA.tif', tile([2:4, 6:8]), year, product_version)));
    
    fprintf('Finish exporting the agent map with tile-based postprocess for %s in %d in %0.2f mins\r', tile, year, toc/60);
end

function exportDisturbanceAgentMaps(tile, year, product_version, dir_product, varargin)
%% EXPORTDISTURBANCEAGENTMAPS
    tic
    p = inputParser;
    addParameter(p, 'mapround',  0); % 0: primlimary map; 1: 1st update using manual training samples
    parse(p,varargin{:});
    mapround = p.Results.mapround;

    folderpath_map =  dir_product; 
    if ~isfolder(folderpath_map)
        mkdir(folderpath_map);
    end
    % the outputing path of the map
    filepath_map = fullfile(folderpath_map, sprintf('CD_%s_%d_V%02d_APRICONF.tif', tile([2:4, 6:8]), year, product_version));
    if isfile(filepath_map)
        fprintf('Exist %s\n', filepath_map);
        return;
    end
    % load GRIDObj
    filepath_changeobjmap = fullfile(odacasets.pathResultODACA, tile, odacasets.folderAuxilliaryData, 'DEM', sprintf('%s_dem.tif',  tile));
    image_agent1 = GRIDobj(filepath_changeobjmap);
    image_agent1.Z = zeros([image_agent1.size(2), image_agent1.size(1)], 'uint8'); % ratation
    image_agent2 = image_agent1;
    
    image_score1 = image_agent1;
    image_score1.Z = zeros(image_score1.size, 'double');
    image_score2 = image_score1;
    
    % load record
    % find the previous round if no updated given
    for ir = mapround: -1 : 0
        folderpath_record = fullfile(odacasets.pathResultODACA, tile, [odacasets.YearlyODACAOutputs, sprintf('V%02d', mapround)]);
        if isfolder(folderpath_record)
            break;
        end
    end
    recordfiles = dir(fullfile(folderpath_record, sprintf('record_objs_%d_*.mat', year)));
    for i = 1: length(recordfiles)
        load(fullfile(folderpath_record, recordfiles(i).name));
        for j = 1: length(record_objs)
            image_agent1.Z(record_objs(j).PixelIdxList) = record_objs(j).agent_primary;
            image_agent2.Z(record_objs(j).PixelIdxList) = record_objs(j).agent_secondary;
            image_score1.Z(record_objs(j).PixelIdxList) = record_objs(j).score_primary;
            image_score2.Z(record_objs(j).PixelIdxList) = record_objs(j).score_secondary;
        end
        clear record_objs;
    end
    
    
    image_agent1.Z = image_agent1.Z'; % same as COLD
    image_agent2.Z = image_agent2.Z'; % same as COLD
    image_score1.Z = round(100.*image_score1.Z'); % same as COLD
    image_score2.Z = round(100.*image_score2.Z'); % same as COLD

    %% exclude pixels with no disturbance
    img_dist = loadCOLDDisturbanceDOYMap(tile, year);
    image_agent1.Z(img_dist==0) = intmax('uint8'); % exclude pixels no disturbance
    image_agent2.Z(img_dist==0) = intmax('uint8'); % exclude pixels no disturbance 
    image_score1.Z(img_dist==0) = intmax('uint8'); % exclude pixels no disturbance
    image_score2.Z(img_dist==0) = intmax('uint8'); % exclude pixels no disturbance
    clear img_dist;
    
    conus_region = getNLCDCONUSRegion(tile, 2021); % CONUS region's ROI
    image_agent1.Z(~conus_region) = intmax('uint8'); % exclude pixels out of CONUS region
    image_agent2.Z(~conus_region) = intmax('uint8'); % exclude pixels out of CONUS region   
    image_score1.Z(~conus_region) = intmax('uint8'); % exclude pixels out of CONUS region
    image_score2.Z(~conus_region) = intmax('uint8'); % exclude pixels out of CONUS region  
    clear conus_region;

    GRIDobj2geotiff(image_agent1, fullfile(folderpath_map, sprintf('CD_%s_%d_V%02d_APRI.tif', tile([2:4, 6:8]), year, product_version)));
    GRIDobj2geotiff(image_agent2, fullfile(folderpath_map, sprintf('CD_%s_%d_V%02d_ASEC.tif', tile([2:4, 6:8]), year, product_version)));
    GRIDobj2geotiff(image_score1, fullfile(folderpath_map, sprintf('CD_%s_%d_V%02d_APRICONF.tif', tile([2:4, 6:8]), year, product_version)));
    GRIDobj2geotiff(image_score2, fullfile(folderpath_map, sprintf('CD_%s_%d_V%02d_ASECCONF.tif', tile([2:4, 6:8]), year, product_version)));
    
    fprintf('Finish exporting the agent map for %s in %d in %0.2f mins\r', tile, year, toc/60);

end

function img_dist = loadCOLDDisturbanceDOYMap(tile, yr)
    img_dist = imread(fullfile(odacasets.pathResultODACA, tile, ...
        odacasets.folderYearlyCOLDDisturbanceMap, ...
        ['changemap_typedoy_',num2str(yr),'.tif']));
    % Pixel value: Type*1000 + DOY
    % All changes: 1 -> Regrowth   2 -> Afforestation   3 -> Disturbance
    img_dist = img_dist - fix(img_dist./1000).*1000; %DOY
    img_dist = img_dist'; % Note this!, which ensure the same ID as COLD outputs
    img_dist(~bwareaopen(img_dist>0, odacasets.minarea)) = 0; % remove tiny objects with fewer than 4 pixels
    img_dist = img_dist'; % back to normal
end

function img_nlcd = getNLCDCONUSRegion(hv_name, nlcd_yr)
    nlcdImagePath = fullfile(odacasets.pathResultODACA, hv_name, odacasets.folderTrainingData, odacasets.folderReferenceLayerNLCD, sprintf('%s_nlcd_%d.tif', hv_name, nlcd_yr) ); % only land cover
    img_nlcd = readgeoraster(nlcdImagePath);
    img_nlcd = img_nlcd > 0;
end