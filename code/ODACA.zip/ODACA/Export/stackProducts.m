function stackProducts(jobid, jobnum)
    %% Add code paths
    [pathpackage, ~] = fileparts(mfilename('fullpath')); 
    pathparent = fileparts(pathpackage); 
    addpath(genpath(pathparent));

    %% Jobs
    if ~exist('jobid', 'var') || ~exist('jobnum', 'var')
        jobid = 1; jobnum = 1;
    end
    % product_version = 1;
    % product_version = 2;
    if isempty(odacasets.refineSampleCollection)
        product_version = 0; % indicate the maps using open-source data
    else
        product_version = odacasets.refineSampleCollection + 1; % following the sample collection's #
    end

    post_product = true;

    %% ARD tiles
    ARDTilesCentral = odacasets.ARDTiles; % to read central tiles
    if odacasets.neighbor
        ARDTiles = getAdjacentARDTiles(ARDTilesCentral); % to add neighbor tiles. 
    else
        ARDTiles = ARDTilesCentral; % to add neighbor tiles. 
    end

    years = odacasets.years;

    objtasks = [];
    for jARD = 1: length(ARDTiles) % loop ARD to assign different tile to different coresprocess, that will fully use all the computing resources
        objtasks(jARD).tile  = ARDTiles{jARD};
        objtasks(jARD).years  = years;
    end
    rng(1);
    objtasks = objtasks(randperm(length(objtasks)));
    %% Process each task
    % product_version = odacasets.product_version;
    for itask = jobid: jobnum: length(objtasks)

        taskobj = objtasks(itask);
        tile = taskobj.tile;
        years = taskobj.years;
        
        % postprocessing or not
        if post_product
            dir_product = fullfile( odacasets.pathResultMaps, sprintf('V%02dPost', product_version));
        else
            dir_product = fullfile( odacasets.pathResultMaps, sprintf('V%02d', product_version));
        end

        dir_product_stack = [dir_product, 'Stack'];
        % dir_product = fullfile( odacasets.pathResultMapsPost);
    
% %         stackProductTile(tile, years, 'MAG',  [], product_version, dir_product);
% %         stackProductTile(tile, years, 'TIME', 'uint16', product_version, dir_product);
        
        stackProductTile(dir_product, tile, years, 'APRI', 'uint8', product_version, dir_product_stack);
% %         stackProductTile(tile, years, 'ASEC', 'uint8', product_version, dir_product);
% %         stackProductTile(tile, years, 'APRICONF', 'uint8', product_version, dir_product);
% %         stackProductTile(tile, years, 'ASECCONF', 'uint8', product_version, dir_product);
    end
end

function stackProductTile(dir_product, tile, years, name_reg, data_type, product_version, dir_product_stack)
    tic;
    image_obj = [];
    for i = 1: length(years)
        year= years(i);
        path_product = fullfile(dir_product, tile, sprintf('CD_%s_%d_V%02d', tile([2:4, 6:8]), year, product_version), sprintf('CD_%s_%d_V%02d_%s.tif', tile([2:4, 6:8]), year, product_version, name_reg));
        fprintf('Loading %s\n', path_product);
        
        image_obj_year = GRIDobj(path_product);

        % update to the new object
        if isempty(image_obj)
            image_obj = image_obj_year;
            if ~isempty(data_type)
                image_obj.Z = zeros([size(image_obj_year.Z), length(years)], data_type);
            else
                image_obj.Z = zeros([size(image_obj_year.Z), length(years)]);
            end
        end
        image_obj.Z(:,:, i) = image_obj_year.Z;
    end
    dir_product_stack = fullfile(dir_product_stack, name_reg);
    if ~isfolder(dir_product_stack)
        mkdir(dir_product_stack);
    end
    filename_stack = sprintf('CD_%s_%d_%d_V%02d_%s.tif', tile([2:4, 6:8]), min(years), max(years), product_version, name_reg);
    filepath_stack = fullfile(dir_product_stack, filename_stack);
    
    tiffTags = struct('Compression', Tiff.Compression.LZW);
    
    geotiffwrite(filepath_stack,image_obj.Z,image_obj.georef.SpatialRef,...
        'GeoKeyDirectoryTag',image_obj.georef.GeoKeyDirectoryTag,...
        'TiffTags', tiffTags);

    fprintf('Finished stacking %s with %0.2f mins\n', filepath_stack, toc/60);
end

