function  accumulateProducts(jobid, jobnum)
    %% Add code paths
    addpath(genpath(fileparts(fileparts(mfilename('fullpath')))));
    %% Setup processing products
    products = {'time', 'magnitude', 'duration', 'model_qa', 'agent'};
    products = {'agent'};
    % product_version = odacasets.product_version; % shared product's version 
    % product_version = 1;
    if isempty(odacasets.refineSampleCollection)
        product_version = 0; % indicate the maps using open-source data
    else
        product_version = odacasets.refineSampleCollection + 1; % following the sample collection's #
    end

    

    %% Setup parallel computing cores
    if ~exist('jobid', 'var') || ~exist('jobnum', 'var')
        jobid = 1; jobnum = 1;
    end
    
    
    %% ARD tiles
    ARDTilesCentral = odacasets.ARDTiles; % to read central tiles
    % ARDTilesCentral =  {'h007v003'}; % Rocky Mountians'
    if odacasets.neighbor
        ARDTiles = getAdjacentARDTiles(ARDTilesCentral); % to add neighbor tiles. 
    else
        ARDTiles = ARDTilesCentral; % to add neighbor tiles. 
    end
    

    %% Setup jobs
    years = odacasets.years;
    dir_product = fullfile(odacasets.pathResultMaps, sprintf('V%02d', product_version));
    objtasks = [];
    for jARD = 1: length(ARDTiles) % loop ARD to assign different tile to different cores, that will fully use all the computing resources
         for ip = 1: length(products)
            ic = length(objtasks) + 1;
            objtasks(ic).tile = ARDTiles{jARD}; 
            objtasks(ic).product  = products{ip};
            objtasks(ic).years  = years;
            objtasks(ic).folderout  = [dir_product, 'Accumulated'];
         end
    end
    rng(1);
    objtasks = objtasks(randperm(length(objtasks)));

    %% Process each task
    for itask = jobid: jobnum: length(objtasks)
        taskobj = objtasks(itask);
        tile = taskobj.tile;
        product = taskobj.product;
        years = taskobj.years;
        dir_accumulated = objtasks(ic).folderout;
        switch product
            case 'time'
                accumulateDisturbanceMaps(dir_product, dir_accumulated, tile, years, 'TIME', 'version', product_version);
            case 'magnitude'
                accumulateDisturbanceMaps(dir_product, dir_accumulated, tile, years, 'MAG', 'version', product_version);
            case 'duration'
                accumulateDisturbanceMaps(dir_product, dir_accumulated, tile, years, 'DUR', 'version', product_version);
            case 'model_qa'
                accumulateDisturbanceMaps(dir_product, dir_accumulated, tile, years, 'MQA', 'version', product_version);
            case 'agent'
                accumulateDisturbanceAgentMap(dir_product, dir_accumulated, tile, years, 'APRI', 'version', product_version, 'agents', 'construction');
                % accumulateDisturbanceAgentMap(dir_product, dir_accumulated, tile, years, 'ASEC', 'version', product_version);
                % accumulateDisturbanceAgentScoreMap(dir_product, dir_accumulated, tile, years, 'APRICONF', 'version', product_version);
                % accumulateDisturbanceAgentScoreMap(dir_product, dir_accumulated, tile, years, 'ASECCONF', 'version', product_version);
        end
    end
end


function accumulateDisturbanceAgentMap(folderin, folderout, tile, years, data_type, varargin)
    func_tic = tic;
    %% setup function
    p = inputParser;
    addParameter(p,'version', 0);
    addParameter(p,'agents', lower(fieldnames(odacasets.agents,'-full')));
    addParameter(p,'format', 'all'); % all agents single
    parse(p,varargin{:});
    product_version = p.Results.version;
    agents_defined = p.Results.agents;
    format = p.Results.format;
    if ~iscell(agents_defined)
        agents_defined = {agents_defined}; % convert to cell if not
    end
    folderout = fullfile(folderout, data_type);

    %% Agents that were defined or focused on
    agent_names = lower(fieldnames(odacasets.agents,'-full')); 
    agent_codes = struct2array(odacasets.agents); % get the value lists
    % select agents according to the defined
    agent_codes = agent_codes(ismember(agent_names, agents_defined));
    agent_names = agent_names(ismember(agent_names, agents_defined));
    clear agents_defined;
    
    agent_map_cube = [];
    years = sort(years);
    for i = 1: length(years)
        %% Load agent map
        tic
        fprintf('Updating to %s %s map in %d ', tile, data_type, years(i));

        path_agentmap = fullfile(folderin, tile, sprintf('CD_%s_%d_V%02d', tile([2:4, 6:8]),  years(i), product_version), ...
            sprintf('CD_%s_%d_V%02d_%s.tif', tile([2:4, 6:8]), years(i), product_version, data_type));
        
        agentmap = GRIDobj(path_agentmap);
    
        % create variable
        if isempty(agent_map_cube)
            cube_size = [agentmap.size, length(agent_codes)]; 
            agent_map_cube = zeros([agentmap.size, length(agent_codes)], 'uint16');
        end
        % find each of the agent
        for j = 1: length(agent_codes)
            [i1, i2] = ind2sub(agentmap.size, find(agentmap.Z == agent_codes(j)));
            i3 = zeros(size(i2)) + j;
            agent_map_cube(sub2ind(cube_size, i1, i2, i3)) = years(i);
        end
        fprintf('with %0.2f mins\r', toc/60);
    end
    clear i1 i2 i3;
    
    fprintf('Setting maximum change year ');
    mask_maxyear = max(agent_map_cube, [], 3);
    for j = 1: length(agent_names)
        [i1, i2] = ind2sub(agentmap.size, find(agent_map_cube(:, :, j) < mask_maxyear));
        i3 = zeros(size(i2)) + j;
        agent_map_cube(sub2ind(cube_size, i1, i2, i3)) = 0;
    end
    clear mask_maxyear;
    clear i1 i2 i3;
    fprintf('with %0.2f mins\r', toc/60);
    
    if ~isfolder(folderout)
        mkdir(folderout);
    end
    
    switch format
        case 'all'
            agentmap.name = 'all agents';
            agentmap.Z = zeros(agentmap.size, 'uint32');
            for j = 1: length(agent_codes)
                agentyear_layer = agent_codes(j)*10000 + agent_map_cube(:,:, j);
                update_layer = agent_map_cube(:,:, j) > 0;
                agentmap.Z(update_layer) = agentyear_layer(update_layer);
            end
            fprintf('Saving %s for %s ', 'all agents', tile);
    
            filename_accumulated = sprintf('ACD_%s_%d_%d_V%02d_%s.tif', tile([2:4, 6:8]), min(years), max(years), product_version, data_type);
            GRIDobj2geotiff(agentmap, fullfile(folderout, filename_accumulated));
            fprintf('with %0.2f mins\r', toc/60);
 
        case 'single'
            for j = 1: length(agent_names)
                fprintf('Saving %s for %s ', agent_names{j}, tile);
                agentmap.Z = agent_map_cube(:,:, j);
                agentmap.name = agent_names{j};
        
                filename_accumulated = sprintf('ACD_%s_%d_%d_V%02d_%s_%s.tif', tile([2:4, 6:8]), min(years), max(years), product_version, data_type, agent_names{j});
        
                geotiffwrite(fullfile(folderout,  filename_accumulated),agentmap.Z,agentmap.georef.SpatialRef,...
                    'GeoKeyDirectoryTag',agentmap.georef.GeoKeyDirectoryTag,...
                    'TiffTags', struct('Compression', Tiff.Compression.LZW));
            
                fprintf('with %0.2f mins\r', toc/60);
            end
    end
    fprintf('Finish processing %s in %0.2f mins\r', folderout, toc(func_tic)/60);
end




function accumulateDisturbanceMaps(folderin, folderout, tile, years, data_type, varargin)
    func_tic = tic;
    %% setup function
    p = inputParser;
    addParameter(p,'version', 0);
    addParameter(p,'agents', lower(fieldnames(odacasets.agents,'-full')));
    addParameter(p,'format', 'all'); % all agents single
    parse(p,varargin{:});
    product_version = p.Results.version;
    agents_defined = p.Results.agents;
    format = p.Results.format;
    if ~iscell(agents_defined)
        agents_defined = {agents_defined}; % convert to cell if not
    end
    folderout = fullfile(folderout, data_type);

    %% Agents that were defined or focused on
    agent_names = lower(fieldnames(odacasets.agents,'-full')); 
    agent_codes = struct2array(odacasets.agents); % get the value lists
    % select agents according to the defined
    agent_codes = agent_codes(ismember(agent_names, agents_defined));
    clear agents_defined;
    
    map_cube = [];
    years = sort(years);
    for i = 1: length(years)
        %% Load agent map
        tic
        fprintf('Updating to %s %s map in %d ', tile, data_type, years(i));
    
        path_agentmap = fullfile(folderin, tile, sprintf('CD_%s_%d_V%02d', tile([2:4, 6:8]),  years(i), product_version), ...
            sprintf('CD_%s_%d_V%02d_%s.tif', tile([2:4, 6:8]), years(i), product_version, 'APRI'));
        agentmap = GRIDobj(path_agentmap);
        agentmap_selected = zeros(agentmap.size, 'uint8');
        % find each of the agent
        for j = 1: length(agent_codes)
            agentmap_selected(agentmap.Z == agent_codes(j)) = 1;
        end

        path_qamap = fullfile(folderin, tile, sprintf('CD_%s_%d_V%02d', tile([2:4, 6:8]),  years(i), product_version), ...
            sprintf('CD_%s_%d_V%02d_%s.tif', tile([2:4, 6:8]), years(i), product_version, data_type));
        qamap = imread(path_qamap);
    
        % create variable
        if isempty(map_cube)
            switch lower(data_type)
                case 'mag'
                    filledvalue = 0;
                otherwise
                    filledvalue = intmax(class(qamap));
            end 
            % filled value 0 only for change magnitude, other is max
            map_cube = qamap;
            map_cube(map_cube~=filledvalue) = filledvalue;
        end
        % find each of the agents
        switch lower(data_type)
            case 'time'
                map_cube(agentmap_selected > 0) = years(i);
            otherwise
                map_cube(agentmap_selected > 0) = qamap(agentmap_selected > 0);
        end
        clear agentmap_selected agentmap_conf;
        fprintf('with %0.2f mins\r', toc/60);
    end
    
    if ~isfolder(folderout)
        mkdir(folderout);
    end


    switch format
        case 'all'
            agentmap.name = 'all agents';
            agentmap.Z = zeros(agentmap.size, 'uint32');
            for j = 1: length(agent_codes)
                agentyear_layer = agent_codes(j)*10000 + map_cube(:,:, j);
                update_layer = map_cube(:,:, j) > 0;
                agentmap.Z(update_layer) = agentyear_layer(update_layer);
            end
            fprintf('Saving %s for %s ', 'all agents', tile);
    
            filename_accumulated = sprintf('ACD_%s_%d_%d_V%02d_%s.tif', tile([2:4, 6:8]), min(years), max(years), product_version, data_type);
            GRIDobj2geotiff(agentmap, fullfile(folderout, filename_accumulated));
%             geotiffwrite(fullfile(folderout, filename_accumulated), agentmap.Z, agentmap.georef.SpatialRef,...
%                 'GeoKeyDirectoryTag', agentmap.georef.GeoKeyDirectoryTag,...
%                 'TiffTags', struct('Compression', Tiff.Compression.LZW));
        
            fprintf('with %0.2f mins\r', toc/60);
 
        case 'single'
            for j = 1: length(agent_names)
                fprintf('Saving %s for %s ', agent_names{j}, tile);
                agentmap.Z = agent_map_cube(:,:, j);
                agentmap.name = agent_names{j};
        
                filename_accumulated = sprintf('ACD_%s_%d_%d_V%02d_%s_%s.tif', tile([2:4, 6:8]), min(years), max(years), product_version, data_type, agent_names{j});
        
                geotiffwrite(fullfile(folderout,  filename_accumulated),agentmap.Z,agentmap.georef.SpatialRef,...
                    'GeoKeyDirectoryTag',agentmap.georef.GeoKeyDirectoryTag,...
                    'TiffTags', struct('Compression', Tiff.Compression.LZW));
            
                fprintf('with %0.2f mins\r', toc/60);
            end
    end



    agentmap.Z = map_cube;
    filename_accumulated = sprintf('ACD_%s_%d_%d_V%02d_%s.tif', tile([2:4, 6:8]), min(years), max(years), product_version, data_type);
    
    tiffTags = struct('Compression', Tiff.Compression.LZW);
    geotiffwrite(fullfile(folderout,  filename_accumulated),agentmap.Z,agentmap.georef.SpatialRef,...
        'GeoKeyDirectoryTag',agentmap.georef.GeoKeyDirectoryTag,...
        'TiffTags', tiffTags);
    
    fprintf('Finish processing %s in %0.2f mins\r', fullfile(folderout,  filename_accumulated), toc(func_tic)/60);
end



function accumulateDisturbanceAgentScoreMap(folderin, folderout, tile, years, data_type, varargin)
    func_tic = tic;
    %% setup function
    p = inputParser;
    addParameter(p,'version', 0);
    addParameter(p,'agents', lower(fieldnames(odacasets.agents,'-full')));
    parse(p,varargin{:});
    product_version = p.Results.version;
    agents_defined = p.Results.agents;
    if ~iscell(agents_defined)
        agents_defined = {agents_defined}; % convert to cell if not
    end
    folderout = fullfile(folderout, data_type);


    %% Agents that were defined or focused on
    agent_names = lower(fieldnames(odacasets.agents,'-full')); 
    agent_codes = struct2array(odacasets.agents); % get the value lists
    % select agents according to the defined
    agent_codes = agent_codes(ismember(agent_names, agents_defined));
    agent_names = agent_names(ismember(agent_names, agents_defined));
    clear agents_defined;
    
    agent_map_cube = [];
    years = sort(years);
    for i = 1: length(years)
        %% Load agent map
        tic
        fprintf('Updating to %s %s map in %d ', tile, data_type, years(i));
    
        path_agentmap = fullfile(folderin, tile, sprintf('CD_%s_%d_V%02d', tile([2:4, 6:8]),  years(i), product_version), ...
            sprintf('CD_%s_%d_V%02d_%s.tif', tile([2:4, 6:8]), years(i), product_version, data_type(1:end-4)));
        agentmap = GRIDobj(path_agentmap);
        agentmap_selected = zeros(agentmap.size, 'uint8');
        % find each of the agent
        for j = 1: length(agent_codes)
            agentmap_selected(agentmap.Z == agent_codes(j)) = 1;
        end
    
        path_agentmap = fullfile(folderin, tile, sprintf('CD_%s_%d_V%02d', tile([2:4, 6:8]),  years(i), product_version), ...
            sprintf('CD_%s_%d_V%02d_%s.tif', tile([2:4, 6:8]), years(i), product_version, data_type));
        agentmap_conf = GRIDobj(path_agentmap);
    
        % create variable
        if isempty(agent_map_cube)
            agent_map_cube = zeros(agentmap_conf.size, 'uint8');
        end
        % find each of the agent
        agent_map_cube(agentmap_selected > 0) = agentmap_conf.Z(agentmap_selected > 0);
        clear agentmap_selected agentmap_conf;
        fprintf('with %0.2f mins\r', toc/60);
    end
    
    if ~isfolder(folderout)
        mkdir(folderout);
    end
    agentmap.Z = agent_map_cube;
    filename_accumulated = sprintf('ACD_%s_%d_%d_V%02d_%s.tif', tile([2:4, 6:8]), min(years), max(years), product_version, data_type);
    
    tiffTags = struct('Compression', Tiff.Compression.LZW);
    geotiffwrite(fullfile(folderout,  filename_accumulated),agentmap.Z,agentmap.georef.SpatialRef,...
        'GeoKeyDirectoryTag',agentmap.georef.GeoKeyDirectoryTag,...
        'TiffTags', tiffTags);
    
    fprintf('Finish processing %s in %0.2f mins\r', fullfile(folderout,  filename_accumulated), toc(func_tic)/60);
end