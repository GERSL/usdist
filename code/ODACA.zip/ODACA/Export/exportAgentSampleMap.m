function exportAgentSampleMap(jobid, jobnum, varargin)
%% EXPORTAGENTSAMPLEMAP is to export the sample's agent map, which is accumulated among the study years
% 
% INPUT:
% map (optional):  change_year or std_doy (default: change_year)
% * change_year: Each agent will have a inidividual map, in which the pixel
% is change year
% * std_doy: Each agent will have a inidividual map, in which the pixel
% is DOY's standard deviation

    %% Add code paths
    addpath(genpath(fileparts(fileparts(mfilename('fullpath')))));
    
    %% Setup parallel computing core
    if ~exist('jobid', 'var') || ~exist('jobnum', 'var')
        jobid = 1; jobnum = 1;
    end
    p = inputParser;
    addParameter(p,'map', 'change_year'); % input can be: change_year std_doy
    parse(p,varargin{:});
    map = p.Results.map;

    refineround = []; % indciate open data
    refineround = 0; 

    %% Setup function
    ARDTilesCentral = odacasets.ARDTiles; % to read central tiles
    % ARDTilesCentral = odacasets.ARDTilesTest;
    ARDTiles = getAdjacentARDTiles(ARDTilesCentral); % to add neighbor tiles. 
    years = odacasets.years;
    agent_names = lower(fieldnames(odacasets.agents,'-full')); % Obtain agents that were defined or focused on
    if isempty(refineround)
        folderout = fullfile(odacasets.pathResultSampleMap, 'Open');
    else
        folderout = fullfile(odacasets.pathResultSampleMap, sprintf('RefineV%02d', refineround));
    end

    %% Setup parallel computing
    objtasks = [];
    for jARD = 1: length(ARDTiles) % loop ARD to assign different tile to different cores, that will fully use all the computing resources
        ic = length(objtasks) + 1;
        objtasks(ic).tile = ARDTiles{jARD}; 
        objtasks(ic).years  = years;
        objtasks(ic).agents  = agent_names;
        objtasks(ic).folderout  = folderout;
    end
    rng(1);
    objtasks = objtasks(randperm(length(objtasks)));
        
    %% Process each task
    for itask = jobid: jobnum: length(objtasks)
        taskobj = objtasks(itask);
        exportAgentSampleMapTile(taskobj.tile, taskobj.agents, taskobj.years, taskobj.folderout, map, refineround);
    end
end

function exportAgentSampleMapTile(tile, agent_names, years, folderpath_out, map, refineround)
%% EXPORTAGENTSAMPLEMAPTILE Export the sample map for defined tile

%% Setup functions
years = sort(years);
if ~isfolder(folderpath_out)
    mkdir(folderpath_out);
end

%% Load GRIDObj
image_year = GRIDobj(fullfile(odacasets.pathResultODACA, tile, odacasets.folderYearlyCOLDDisturbanceMapObject, sprintf('change_object_%d.tif', min(years))));

%% Load all samples for each agent
for iagent = 1: length(agent_names)
    tic
    fprintf('\n******************************************************************************************\r');
    fprintf('Start exporting the map of training samples for %s for %s\r', tile, agent_names{iagent});
    fprintf('******************************************************************************************\r');
    image_year.Z = zeros(image_year.size, 'uint16');
    for iy = 1: length(years)
        trainingsamples = loadTrainingObjectSamples(tile, agent_names{iagent}, 'years', years(iy), 'v', refineround);
        trainingsamples = trainingsamples.samples;
        for is = 1: length(trainingsamples)
            sampletrain = trainingsamples(is);
%             image_year.Z(sampletrain.PixelIdxList) = years(iy); % all
            pixelids = sampletrain.PixelIdxList;
            pixelids = pixelids(boolean(sampletrain.PixelIdxListSample));
            switch map
                case 'change_year'
                    image_year.Z(pixelids) = years(iy); % overlaip pixels
                case 'std_doy'
                    image_year.Z(pixelids) = sampletrain.StdDOY; % overlaip pixels
            end
        end
        clear trainingsamples sampletrain pixelids;
    end
    image_year.Z = image_year.Z'; % same as COLD
    GRIDobj2geotiff(image_year, ...
        fullfile(folderpath_out, sprintf('sample_map_%s_%s_%s_%d_%d.tif', map, tile, agent_names{iagent}, min(years), max(years))));
    image_year.Z = image_year.Z'; % back up normal
    fprintf('Finish exporting the map of training samples for %s for %s with %0.2f mins\r', tile, agent_names{iagent}, toc/60);
end

end % end of func

function trainingsamples = loadTrainingObjectSamples(tiles, agent_types, varargin )
%% This function is to load the trianing samples

    p = inputParser;
    addParameter(p,'version', []);
    addParameter(p,'years',[]); % number of object samples
    parse(p,varargin{:});
    v=p.Results.version;
    years=p.Results.years;
    
    if ~iscell(tiles) % also support single tile at char model
        tiles = {tiles};
    end
    if ~iscell(agent_types)
        agent_types = {agent_types};
    end

    trainingsamples = [];        
    % loop each class
    for ia = 1: length(agent_types)
        record_objects_samples_all = [];
        start_tic = tic;
        for it = 1: length(tiles)
            if isempty(v)
                samples = dir(fullfile(odacasets.pathResultODACA, tiles{it}, odacasets.folderTrainingData, ...
                    odacasets.folderTrainingSampleObject, sprintf('record_samples_%s_*.mat', lower(char(agent_types(ia))))));
            else
                samples = dir(fullfile(odacasets.pathResultODACA, tiles{it}, odacasets.folderTrainingData, ...
                    sprintf('%sRefineV%02d',odacasets.folderTrainingSampleObject, v), sprintf('record_samples_%s_*.mat', lower(char(agent_types(ia))))));
            end
            for is = 1: length(samples)
                % remove extension
                [~, filename_samp]=fileparts(samples(is).name);
                % how many sample objects stored here?
                num_samples_char = split(filename_samp, '_');
                num_samples = str2double(num_samples_char{end-1});  % number of objects
                if ~isempty(years) % force to filter out the datasets not within the defined years
                    year_sample = str2double(num_samples_char{end-4});
                    if ~ismember(year_sample, years)
                        continue;
                    end
                end
                if num_samples > 0
                    load(fullfile(samples(is).folder, samples(is).name)); % load record_objs_samples
                    record_objects_samples_all = [record_objects_samples_all, record_objs_samples];
                end
            end
        end
        trainingsamples(ia).agent = lower(char(agent_types(ia)));
        trainingsamples(ia).samples = record_objects_samples_all;
        fprintf('Finished loading %s samples (%09d objects) for %d with %0.2f mins\r', trainingsamples(ia).agent, length(trainingsamples(ia).samples), years, toc(start_tic)/60);
    end
end


function num_samples_pertype = countTotalNumSamples(ARDTiles, agent_types)
%% This is to count the total number of samples (objects), and then we can determine whether downsampling the cluster of samples
    % loop each class
    num_samples_pertype = zeros(length(agent_types), 1);
    for ia = 1: length(agent_types)
        total_num_samples_class = 0;
        for it = 1: length(ARDTiles)
            samples = dir(fullfile(odacasets.pathResultODACA, ARDTiles{it}, odacasets.folderTrainingData, ...
                odacasets.folderTrainingSamplePixel, sprintf('record_samples_%s_*.mat', lower(char(agent_types(ia))))));
             for is = 1: length(samples)
                % remove extension
                [~, filename_samp]=fileparts(samples(is).name);
                % how many sample objects stored here?
                num_samples_char = split(filename_samp, '_');
                total_num_samples_class = total_num_samples_class + str2num(num_samples_char{end});
             end
        end
        num_samples_pertype(ia) = total_num_samples_class;
    end
end

