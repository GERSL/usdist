function batchOrganizeMaps(jobid, jobnum)
%% This is to copy maps
[pathpackage, ~] = fileparts(mfilename('fullpath')); 
addpath(pathpackage);
pathparent = fileparts(pathpackage); 
addpath(pathparent);
addpath(fullfile(pathparent, 'Shared')); % add the <Shared>

if ~exist('jobid', 'var')
    jobid = 1;
end

if ~exist('jobnum', 'var')
    jobnum = 1;
end


%% ARD tiles
ARDTilesCentral = odacasets.ARDTiles; % to read central tiles
% ARDTilesCentral =  {'h029v005', ... % New England Area
%                     'h021v015',... % Southeast
%                     'h015v009',... % Great Plains
%                     'h007v003'};  % Far west
% ARDTilesCentral =  {'h029v005'};  % Far west
ARDTiles = getAdjacentARDTiles(ARDTilesCentral); % to add neighbor tiles. 
years = odacasets.years;

objtasks = [];
for jARD = 1: length(ARDTiles) % loop ARD to assign different tile to different cores, that will fully use all the computing resources
    for iy = 1: length(years)
        ic = length(objtasks) + 1;
        objtasks(ic).tile = ARDTiles{jARD}; 
        objtasks(ic).year  = years(iy);
    end
        
end
rng(1);
objtasks = objtasks(randperm(length(objtasks)));
[taskids] = assignTasks(objtasks, jobid, jobnum);

folderout = '/lustre/scratch/qiu25856/ProjectCONUSDisturbanceAgent/product/v101/doy';
if ~isfolder(folderout)
    mkdir(folderout);
end

mapname= 'doy'; % time, agent, magnitude, agent_mostrecent

%% Process each task
for itask = taskids
    taskobj = objtasks(itask);
    tile = taskobj.tile;
    year = taskobj.year;
    recodeMaps(tile, year, folderout, mapname);
%     organizeMaps(tile, year, folderout, mapname);
end

end

function recodeMaps(tile, year, folderout, mapname)
    tic
    switch mapname
        case 'doy'
            % load agent map, with the pixels out of CONUS as 255
            filename = sprintf('%s_agent_%d.tif',  tile, year); % h028v005_agent_1989.tif
            filepath_changeobjmap = fullfile(odacasets.pathResultODACA, tile, odacasets.folderAgentMap, filename); 
            agentmap = imread(filepath_changeobjmap);
            
            filename = ['changemap_typedoy_',num2str(year),'.tif'];
            path_result_changemap = fullfile(odacasets.pathResultCOLD, tile, odacasets.folderYearlyCOLDDisturbanceMap);
            doymap = GRIDobj(fullfile(path_result_changemap, filename));
            img_dist = doymap.Z;
            % Pixel value: Type*1000 + DOY
            % All changes: 1 -> Regrowth   2 -> Afforestation   3 -> Disturbance
            img_dist = fix(img_dist./1000).*1000 - img_dist; % as DOY
            img_dist(agentmap==0) = 0;
            img_dist(agentmap==255) = intmax('uint16');
            doymap.Z = uint16(img_dist); % 0 - 366  65535 as nan
            filename = sprintf('%s_doy_%d.tif',  tile, year); % h028v005_doy_1989.tif
            doymap.name = filename;
            GRIDobj2geotiff(doymap, fullfile(folderout, filename));
            
        case 'agent'
            filename = sprintf('%s_agent_%d.tif',  tile, year); % h028v005_agent_1989.tif
            filepath_changeobjmap = fullfile(odacasets.pathResultODACA, tile, odacasets.folderAgentMap, filename); 
            agentmap = GRIDobj(filepath_changeobjmap);
            % Orginal code,
%           {'harvest', 'mechanical', 'insect', 'debris', 'hydrology', 'fire', 'other'}
%           [11 12 21 22 23 30 40]
            agentmap.Z(agentmap.Z==11) = 1;
            agentmap.Z(agentmap.Z==12) = 2;
            agentmap.Z(agentmap.Z==21) = 3;
            agentmap.Z(agentmap.Z==22) = 4;
            agentmap.Z(agentmap.Z==23) = 5;
            agentmap.Z(agentmap.Z==30) = 6;
            agentmap.Z(agentmap.Z==40) = 7;
            agentmap.Z(isnan(agentmap.Z)) = 255;
            agentmap.Z = uint8(agentmap.Z);
            GRIDobj2geotiff(agentmap, fullfile(folderout,filename));
    end

	fprintf('Finish %s %s in %0.2f mins\r', mapname, filename, toc/60);
end


function organizeMaps(tile, year, folderout, mapname)
% Add code paths
tic
pathpackage = fileparts(fileparts(fileparts(mfilename('fullpath')))); 
addpath(pathpackage); % add ODACA's parent folder

% load GRIDObj
folderout = fullfile(folderout, tile, mapname);
if ~isfolder(folderout)
    mkdir(folderout);
end

filepath_changeobjmap = fullfile(odacasets.pathResultODACA, tile, odacasets.folderAgentMap, sprintf('%s_agent_%d.tif',  tile, year)); % h028v005_agent_1989.tif

copyfile(filepath_changeobjmap, folderout);

fprintf('Finish copying %s in %0.2f mins\r', filepath_changeobjmap, toc/60);

end
