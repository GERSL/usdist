
'This function is to crop image predictors as lots of small chips'
import os
import click
from pathlib import Path

@click.command()
@click.option("--ci", "-i", default=1, type=int, help="The core's id")
@click.option("--cn", "-n", default=1, type=int, help="The number of cores")
@click.option("--src", "-s", default='/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSProductMapV041YearlyMap', type=str, help="The folder of source")
@click.option("--des", "-d", default='/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSProductMapV041YearlyMap900/', type=str, help="The folder of destination")
@click.option("--res", "-r", default=900, type=int, help="Resolution of output image")
@click.option("--method", "-m", default='mode', type=str, help="Method of aggregating")
def main(ci, cn, src, des, res, method):

    for yr in range(1985, 2021):
        dir_maps = os.path.join(src, f"{yr}")
        dir_maps_out = os.path.join(des, f"{yr}")
        res = res
        method = method
        Path(dir_maps_out).mkdir(parents=True, exist_ok=True)

        # orginal image input
        maps = [entry for entry in os.listdir(dir_maps) if entry.endswith('.tif')]
        maps = sorted(maps)

        # Process each task
        # Create task record object
        tasks = []
        for map in maps:
            tasks.append({"map": map})
        # Process each task
        tasks_range = range(ci - 1, len(tasks), cn)

        for itask in tasks_range:
            map = tasks[itask]['map']
            filepath_map  = os.path.join(dir_maps, map)
            filepath_map_out = os.path.join(dir_maps_out, map)
            # creates the gdal warp command
            # command = f"gdalwarp -srcnodata {'0,255'} -tr {res} {res} -r {method} -overwrite {filepath_map} {filepath_map_out}"
            command = f"gdalwarp -srcnodata 0 -tr {res} {res} -r {method} -overwrite {filepath_map} {filepath_map_out}"
            # runs the command
            os.system(command)


if __name__ == "__main__":
    main()