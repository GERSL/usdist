function accumulateChangeMagnitudeMap(tile, years, folderout)

tic
%% Add code paths
[pathpackage, ~] = fileparts(mfilename('fullpath')); 
addpath(pathpackage);
pathparent = fileparts(pathpackage); 
addpath(pathparent);
addpath(fullfile(pathparent, 'Shared')); % add the <Shared>

folderpath_map =  fullfile(odacasets.pathResultCOLD, tile, odacasets.folderYearlyCOLDChangeMagMap); 

years = sort(years);

accmagmap = []; 

for i = 1: length(years)
    year = years(i);
    filepath_map = fullfile(folderpath_map, sprintf('changemagnitudemap_doy_%d.tif', year));
    magmap = GRIDobj(filepath_map);
    path_changemap_obj = fullfile(odacasets.pathResultODACA, tile, odacasets.folderYearlyCOLDDisturbanceMapObject);
    path_changemap_obj = fullfile(path_changemap_obj, sprintf('changeobjectmap_%04d.tif', year));
    changemap_obj = imread(path_changemap_obj); % that removed tiny objects with fewer than 4 pixels
   
    if isempty(accmagmap)
        accmagmap = magmap;
        accmagmap.Z(changemap_obj==0) = 0;
    else
        accmagmap.Z(changemap_obj>0) = magmap.Z(changemap_obj>0);
    end
end

if ~isfolder(folderout)
    mkdir(folderout);
end
GRIDobj2geotiff(accmagmap, fullfile(folderout,  sprintf('%s_changemagnitude_%d_%d.tif', tile, min(years), max(years))));
fprintf('Finish processing %s in %0.2f mins\r', folderout, toc/60);