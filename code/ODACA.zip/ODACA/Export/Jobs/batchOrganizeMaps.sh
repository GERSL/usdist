#!/bin/bash
#SBATCH -J org
#SBATCH -p quanah
#SBATCH -o out-org-%A_%4a.out
#SBATCH -e err-org-%A_%4a.err
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -t 48:00:00
#SBATCH -a 1-25:1


#NOTE: This job is to arrage cores in My Matlab function.  nocona  quanah
#The variable $SGE_TASK_ID is the ID for this task. 
#The variable $SGE_TASK_FIRST is the ID for the first task.
#The variable $SGE_TASK_LAST is the ID for the last task.
#This script is a companion script for submitmjobs for MATLAB apps
#It demonstrates how the passed "task" can be used to make each of
#The ntasks to perform a different task or use different data. If your
#app is a function m-file, "task" needs to be passed as input argument.
#If your app is a script m-file, "task" is automatically available
#because it shares the same workspace as myscript.
# IMPORTANT: DONOT indent any of the below statements  nocona  quanah

cd /home/qiu25856/ODACA/Export/
module load matlab
matlab -nodisplay -singleCompThread -r "batchOrganizeMaps($SLURM_ARRAY_TASK_ID, $SLURM_ARRAY_TASK_MAX); exit"
