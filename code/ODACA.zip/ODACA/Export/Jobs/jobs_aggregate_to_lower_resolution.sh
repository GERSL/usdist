#!/bin/bash
#SBATCH -J agg
#SBATCH --partition=priority
#SBATCH --account=zhz18039
#SBATCH --exclude=cn[244,245,246,252,254,255,268,269,270,271,285,288,289,290,291,293]
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --array 1-20
#SBATCH --mem-per-cpu=10G
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err


. "/home/shq19004/miniconda3/etc/profile.d/conda.sh"  # startup conda
conda activate dlpy310

echo $SLURMD_NODENAME # display the node name
cd ../

python aggregateToLowerResolution.py --ci=$SLURM_ARRAY_TASK_ID --cn=$SLURM_ARRAY_TASK_MAX

echo 'Finished!'
exit

#SBATCH --partition=general

#SBATCH --partition=priority
#SBATCH --account=zhz18039


#SBATCH --partition=priority
#SBATCH --account=zhz18039
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --array 1-170
#SBATCH --exclude=cn[244,245,246,252,254,255,268,269,270,271,285,289,290,291,293]