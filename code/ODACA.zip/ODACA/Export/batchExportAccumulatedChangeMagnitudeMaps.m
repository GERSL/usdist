function  batchExportAccumulatedChangeMagnitudeMaps(jobid, jobnum)
%% Add code paths
[pathpackage, ~] = fileparts(mfilename('fullpath')); 
addpath(pathpackage);
pathparent = fileparts(pathpackage); 
addpath(pathparent);
addpath(fullfile(pathparent, 'Shared')); % add the <Shared>

if ~exist('jobid', 'var')
    jobid = 1;
end

if ~exist('jobnum', 'var')
    jobnum = 1;
end


%% ARD tiles
ARDTilesCentral = odacasets.ARDTiles; % to read central tiles

ARDTilesCentral =  {'h029v005', ... % New England Area
                    'h021v015',... % Southeast
                    'h015v009',... % Great Plains
                    'h007v003'};  % Far west
ARDTilesCentral =  {'h029v005'};  % Far west
ARDTiles = getAdjacentARDTiles(ARDTilesCentral); % to add neighbor tiles. 
ARDTiles = {'h030v006'};
years = odacasets.years;
% folderout = '/lustre/scratch/qiu25856/ProjectCONUSDisturbanceAgent/AgentMapsAccumulated/';
folderout = '/lustre/scratch/qiu25856/ProjectCONUSDisturbanceAgent/AgentMapsAccumulated_Planting100_10/';
folderout = '/lustre/scratch/qiu25856/ProjectCONUSDisturbanceAgent/AgentMapsAccumulated_HaHi_Obj/'; % object
folderout = '/lustre/scratch/qiu25856/ProjectCONUSDisturbanceAgent/AgentMapsAccumulated_Obj_FireLag111/'; % object
% folderout = '/lustre/scratch/qiu25856/ProjectCONUSDisturbanceAgent/AgentMapsAccumulated_Obj_FireSameMonth/'; % object Test45TilesPixelSampleBackup_FireSameMonth
% folderout = '/lustre/scratch/qiu25856/ProjectCONUSDisturbanceAgent/AgentMapsAccumulated_Obj_FireSameMonth_Mech';
% folderout = '/lustre/scratch/qiu25856/ProjectCONUSDisturbanceAgent/AgentMapsAccumulated_Obj_FireYear100ha_Mech';
% folderout = '/lustre/scratch/qiu25856/ProjectCONUSDisturbanceAgent/AgentMapsAccumulated_Obj_FireYear200ha_Mech';
% folderout = '/lustre/scratch/qiu25856/ProjectCONUSDisturbanceAgent/AgentMapsAccumulated_HaHi/'; % pixel
objtasks = [];
for jARD = 1: length(ARDTiles) % loop ARD to assign different tile to different cores, that will fully use all the computing resources
    ic = length(objtasks) + 1;
    objtasks(ic).tile = ARDTiles{jARD}; 
    objtasks(ic).years  = years;
    objtasks(ic).folderout  = folderout;
end
rng(1);
objtasks = objtasks(randperm(length(objtasks)));
[taskids] = assignTasks(objtasks, jobid, jobnum);
    
%% Process each task
for itask = taskids
    taskobj = objtasks(itask);
    tile = taskobj.tile;
    years = taskobj.years;
    folderout = objtasks(ic).folderout;
    
%     accumulateChangeMagnitudeMap(tile, years, folderout);
    accumulateChangeMagnitudeMapSingleAgent(tile, years, folderout);
end