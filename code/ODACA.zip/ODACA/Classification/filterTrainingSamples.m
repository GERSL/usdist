function record_trainingsamples = filterTrainingSamples(agentname, record_trainingsamples, varargin)
%FILTERTRAININGSAMPLES is to filter training samples using some criteria,
%such as minimum area for fire, priority knowadge for insect, and maximum
%sample pixels per change object

    p = inputParser;
    addParameter(p, 'minoverlap', 0.5);
    addParameter(p, 'overlap', true); % designed for training samples
    addParameter(p, 'maxpixels', []); % NONE means 'do not setup'
    parse(p,varargin{:});
    minoverlap = p.Results.minoverlap;
    maxpixels = p.Results.maxpixels;
    overlap = p.Results.overlap;
    
    if ~isempty(record_trainingsamples)
        switch lower(agentname)
            case 'insect'
%                 for isamp = 1: length(record_trainingsamples)
%                     coeffs_tmp = record_trainingsamples(isamp).CoeffsMag;
%                     % ONLY pixels less green
% %                     ids_tmp = coeffs_tmp(5,:)>0&coeffs_tmp(4,:)<0 & ...
% %                                 abs(coeffs_tmp(5,:))<ther_tmp& abs(coeffs_tmp(4,:))<ther_tmp;
% %                     ids_tmp = coeffs_tmp(3,:)>0 & coeffs_tmp(5,:)>0&coeffs_tmp(4,:)<0 & ...
% %                                 abs(coeffs_tmp(3,:))< 800 & abs(coeffs_tmp(5,:))< 1500;
% 
%                     % The insects usually decrease the reflectance of NIR
%                     % band, but sometimes the understory vegetations may
%                     % increase the NIR band. Thus, the change magnitude of
%                     % NIR band is less than 0.05.
% %                     ids_tmp = coeffs_tmp(3,:)>0 & coeffs_tmp(5,:)>0& ...
% %                                 abs(coeffs_tmp(3,:))< 800 & abs(coeffs_tmp(5,:))< 1500 & ...
% %                                 coeffs_tmp(4,:)<500;
% % 
% %                     record_trainingsamples(isamp).PixelIdxListSample(~ids_tmp) = 0;
% %                     record_trainingsamples(isamp).OverlapPerct = sum(record_trainingsamples(isamp).PixelIdxListSample)./length(record_trainingsamples(isamp).PixelIdxListSample);
%                 end
            case {'fire'} % exclude small disturbance objects that will cause lots of commission errors from fire 
%                   record_trainingsamples = record_trainingsamples([record_trainingsamples.area] >= 0.09*222); % 222 pixels == 20 ha. 0.09 ha == 1 Landsat pixel 
            case {'hydrology', 'other'} % exclude small change objects
%                  record_trainingsamples = record_trainingsamples([record_trainingsamples.area] >= 0.09*10); % 0.09 ha == 1 Landsat pixel
        end
    end
    if ~isempty(record_trainingsamples)
        record_trainingsamples = record_trainingsamples([record_trainingsamples.OverlapPerct] >= minoverlap);
        
        % limited number of pixel samples per change object
        if ~isempty(maxpixels)
            for iobj = 1: length(record_trainingsamples)
                if ~overlap % if all will be selected, reser the sample list
                    record_trainingsamples(iobj).PixelIdxListSample(:) = 1; % reset all as '1'
                end
                % re-selecting samples with maximum pixel samples
                if length(record_trainingsamples(iobj).PixelIdxListSample) > maxpixels % if too many
                    idx = find(record_trainingsamples(iobj).PixelIdxListSample == 1); % find out overlaip
                    if length(idx) > maxpixels % if too many still,
                        record_trainingsamples(iobj).PixelIdxListSample(:) = 0; % reset all as '0'
                        record_trainingsamples(iobj).PixelIdxListSample(idx(randpermDynamic(length(idx), maxpixels))) = 1; % select sub pixels
                    end
                end
            end
        elseif ~overlap  % if all will be selected, reser the sample list
            for iobj = 1: length(record_trainingsamples)
                record_trainingsamples(iobj).PixelIdxListSample(:) = 1; % reset all as '1'
            end
        end
    end
    
end

