function batchCreateClassifierUpdate(jobid, jobnum, mapround)
%% This is to generate RFC with two-time iterations

%% Add code paths
% restoredefaultpath;
addpath(genpath(fileparts(fileparts(mfilename('fullpath')))));

if ~exist('jobid', 'var') || ~exist('jobnum', 'var')
    jobid = 1; jobnum = 1;
end
if ~exist('mapround', 'var')
    mapround = odacasets.refineSampleCollection; % following the sample collection's #
    % 0: primlimary map based on open dataset; 
    % 1: 1st update 10% training samples using manual training samples; 
    % 2: 2nd update 10% training samples using manual training samples;
    % 3: 3th update 10% training samples using manual training samples;
    % 4: 4th update 10% training samples using manual training samples;
    % 5: 5th update 10% training samples using manual training samples;
end

if ~exist('update', 'var')
    update = 'sample';

    % 'sample': update 10% training samples using manual training samples
    % 'proportion':  Update the proportion, and if more trianing samples were requried, we extract them from all manual interprated samples

    % adjprop = 2; 
    % 0: based on the open-data-based model
    % 2: based on the 1st round map
end

%% ARD tiles
ARDTiles = odacasets.ARDTiles; % to read central tiles            
% ARDTiles = {'h002v008'};
%% Assign tasks first
objtasks = [];
for iARD = 1: length(ARDTiles) % Loop ARD to assign different tile to different cores, that will fully use all the computing resources
    ic = length(objtasks) + 1;
    objtasks(ic).tile = ARDTiles{iARD};
end
rng(1);
objtasks = objtasks(randperm(length(objtasks)));
[taskids] = assignTasks(objtasks, jobid, jobnum);
    
%% Process each task
for itask = taskids
    taskobj = objtasks(itask);
    tile = taskobj.tile;
    %% training classifier
    tic
    fprintf('Started training RFC for %s\r', tile);
    %% setup the folder
    folderpath_rfc = fullfile(odacasets.pathResultODACA, tile, odacasets.folderRandomForestModel);
    if ~isfolder(folderpath_rfc)
        mkdir(folderpath_rfc);
    end
    %% start to process
    if mapround == 0 % first map, that is the prelimiliary map
        % Given the central tile, all the neighbors will be considered.
        % Set #1: fill the training samples with minimum number if there are no local samples
        % Set #2: numn == 0: do not add new training samples
        % Set #3: updaterate == 0: do not update the training sampels with new training samples
        [modelRF, ~, proportions, inputs_training_samples, agents_training_samples] = ...
            createPixelClassifier(tile, 1, 'cfill', true, 'numn', 0, 'updaterate', 0); 

        % save the model 
        save(fullfile(folderpath_rfc, odacasets.modelRFCName), 'modelRF', 'proportions', 'inputs_training_samples', 'agents_training_samples');
    elseif mapround >=1 % second map
        % load proportion
%         updaterate = odacasets.modelRFCUpdateRateNewTrainingSamples; % 10%
          
        % when we load the model based on previous updated model with manual trianing samples to get the training samples pixels we used at the previous round
        if mapround > 1
            % load the model at previous and available round. Note
            % sometimes we did not update the tile, so we iterated to look back
            for ir = mapround: -1: 0
                if ir ==0
                    path_model = fullfile(folderpath_rfc, odacasets.modelRFCName);
                else
                    path_model = fullfile(folderpath_rfc, strrep(odacasets.modelRFCName,'.mat', sprintf('_updated%02d.mat', ir - 1)));
                end
                if isfile(path_model)
                    load(path_model);
                    break;
                end
            end
        else
            % other case will load the first model
            load(fullfile(folderpath_rfc, odacasets.modelRFCName)); % this make sure we always have the proportions, and we do not save proportions for the RFC_10000_updated01.mat and RFC_1000_updated02.mat which shared the open-data-based proportions
        end

        % Given the central tile, all the neighbors will be considered.
        % Set #1: do not fill the training samples
        [modelRF, ~, ~, inputs_training_samples, agents_training_samples] = ...
            createPixelClassifier(tile, 0, 'initmodel', modelRF, 'proportions', proportions, 'cfill', false, 'numn', 1);


        % save the model 
        if ~isempty(modelRF)
            save(fullfile(folderpath_rfc, strrep(odacasets.modelRFCName,'.mat', sprintf('_updated%02d.mat', mapround))), 'modelRF',  'proportions', 'inputs_training_samples', 'agents_training_samples');
        end
    end

    fprintf('Finished training RFC for %s with %0.2f mins\r', tile, toc/60);
end

end

 
function proportions = estimateUpdatedMapProportion(tile, mapround)
    %% Estimate the proportions of the updated map

    % To obtain neighbor tiles
    if odacasets.neighbor
        tiles = getAdjacentARDTiles(tile); % to add neighbor tiles
    else
        tiles = {tile};    
    end
    
    % agents
    agent_codes     = struct2array(odacasets.agents); % get the value lists
    % years
    years = odacasets.years;

    proportions = zeros(size(agent_codes)); % update the propotions for next iteration

    for k = 1: length(tiles)
        tile = tiles{k};
        % load record
        if mapround == 0
            folderpath_record = fullfile(odacasets.pathResultODACA, tile, odacasets.YearlyODACAOutputs); 
        elseif mapround >=1
            folderpath_record = fullfile(odacasets.pathResultODACA, tile, [odacasets.YearlyODACAOutputs, sprintf('Updated%02d', mapround)]); 
        end
        for y = 1: length(years)
            year = years(y);
            recordfiles = dir(fullfile(folderpath_record, sprintf('record_objs_%d_*.mat', year)));
            for i = 1: length(recordfiles)
                load(fullfile(folderpath_record, recordfiles(i).name));
                for j = 1: length(record_objs)
                     agent_primary = record_objs(j).agent_primary;
                     proportions(agent_codes==agent_primary) = proportions(agent_codes==agent_primary) + length(record_objs(j).PixelIdxList); % add the number of pixels 
                end
                clear record_objs;
            end
        end
    end

    proportions = proportions ./ sum(proportions);
end













