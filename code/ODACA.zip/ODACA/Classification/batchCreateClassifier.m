function batchCreateClassifier(jobid, jobnum, mapround)
%% This is to generate RFC with two-time iterations

%% Add code paths
restoredefaultpath;
addpath(genpath(fileparts(fileparts(mfilename('fullpath')))));

if ~exist('jobid', 'var') || ~exist('jobnum', 'var')
    jobid = 1; jobnum = 1;
end
if ~exist('mapround', 'var')
    if isempty(odacasets.refineSampleCollection)
        mapround = 0; % indicate the maps using open-source data
    else
        mapround = odacasets.refineSampleCollection + 1; % following the sample collection's #
    end
    % 0: primlimary map based on open dataset; 
    % 1: 1st update 10% training samples using manual training samples; 
    % 2: 2nd update 10% training samples using manual training samples;
    % 3: 3th update 10% training samples using manual training samples;
    % 4: 4th update 10% training samples using manual training samples;
    % 5: 5th update 10% training samples using manual training samples;
    % mapround = 0; % indicate the maps using open-source data
    % mapround = 1; % indciate the maps by appending refine samples
    % mapround = 2; % for third product
end


%% ARD tiles
ARDTiles = odacasets.ARDTiles; % to read central tiles            
% ARDTiles = {'h007v014'};
%% Assign tasks first
objtasks = [];
for iARD = 1: length(ARDTiles) % Loop ARD to assign different tile to different cores, that will fully use all the computing resources
    ic = length(objtasks) + 1;
    objtasks(ic).tile = ARDTiles{iARD};
end
rng(1);
objtasks = objtasks(randperm(length(objtasks)));

%% Process each task
for itask = jobid: jobnum: length(objtasks)
    taskobj = objtasks(itask);
    tile = taskobj.tile;
    %% training classifier
    tic
    fprintf('Started training RFC for %s\r', tile);
    %% setup the folder
    folderpath_rfc = fullfile(odacasets.pathResultODACA, tile, odacasets.folderRandomForestModel);
    if ~isfolder(folderpath_rfc)
        mkdir(folderpath_rfc);
    end
    %% start to process
    path_model = fullfile(folderpath_rfc, sprintf('%s_v%02d.mat',odacasets.modelRFCName, mapround));
    if isfile(path_model)
        fprintf('Exist %s\n', path_model);
        continue;
    end

    if mapround == 0 % first map, that is the prelimiliary map
        % Given the central tile, all the neighbors will be considered.
        % Set #1: fill the training samples with minimum number if there are no local samples
        % Set #2: numn == 0: do not add new training samples
        % Set #3: updaterate == 0: do not update the training sampels with new training samples
        [modelRF, ~, proportions, inputs_training_samples, agents_training_samples] = ...
            createPixelClassifier(tile, 1, 'cfill', true, 'numrate', 0, 'updaterate', 0); 
    elseif mapround >=1 % second map
        % when we load the model based on previous updated model with manual trianing samples to get the training samples pixels we used at the previous round
        % load the model at previous and available round. Note
        % sometimes we did not update the tile, so we iterated to look back
        for ir = mapround-1: -1: 0
            path_model_pre = fullfile(folderpath_rfc, sprintf('%s_v%02d.mat',odacasets.modelRFCName, ir));
            if isfile(path_model_pre)
                load(path_model_pre);
                break;
            end
        end
        % Given the central tile, all the neighbors will be considered.
        % Set #1: do not fill the training samples
        [modelRFUpdated, ~, ~, inputs_training_samples, agents_training_samples] = ...
            createPixelClassifier(tile, 0, 'initmodel', modelRF, 'proportions', proportions, 'cfill', false, 'maxnum', 1);
        if ~isempty(modelRFUpdated)
            modelRF = modelRFUpdated;
        else
            modelRF = [];
        end
    end
    % save the model 
    if ~isempty(modelRF)
        save(path_model, 'modelRF', 'proportions', 'inputs_training_samples', 'agents_training_samples');
        fprintf('Finished training RFC for %s with %0.2f mins\r', tile, toc/60);
    else
        fprintf('No RFC updated for %s with %0.2f mins\r', tile, toc/60);
    end
end

end

 
function proportions = estimateUpdatedMapProportion(tile, mapround)
    %% Estimate the proportions of the updated map

    % To obtain neighbor tiles
    if odacasets.neighbor
        tiles = getAdjacentARDTiles(tile); % to add neighbor tiles
    else
        tiles = {tile};    
    end
    
    % agents
    agent_codes     = struct2array(odacasets.agents); % get the value lists
    % years
    years = odacasets.years;

    proportions = zeros(size(agent_codes)); % update the propotions for next iteration

    for k = 1: length(tiles)
        tile = tiles{k};
        % load record
        if mapround == 0
            folderpath_record = fullfile(odacasets.pathResultODACA, tile, odacasets.YearlyODACAOutputs); 
        elseif mapround >=1
            folderpath_record = fullfile(odacasets.pathResultODACA, tile, [odacasets.YearlyODACAOutputs, sprintf('Updated%02d', mapround)]); 
        end
        for y = 1: length(years)
            year = years(y);
            recordfiles = dir(fullfile(folderpath_record, sprintf('record_objs_%d_*.mat', year)));
            for i = 1: length(recordfiles)
                load(fullfile(folderpath_record, recordfiles(i).name));
                for j = 1: length(record_objs)
                     agent_primary = record_objs(j).agent_primary;
                     proportions(agent_codes==agent_primary) = proportions(agent_codes==agent_primary) + length(record_objs(j).PixelIdxList); % add the number of pixels 
                end
                clear record_objs;
            end
        end
    end

    proportions = proportions ./ sum(proportions);
end













