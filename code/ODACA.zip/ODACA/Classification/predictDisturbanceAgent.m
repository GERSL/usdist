function sample_object_predict = predictDisturbanceAgent(modelRF, sample_object, type)
%PREDICTDISTURBANCEAGENT Summary of this function goes here
    if ~exist('type', 'var')
        type = 'accuracy'; % map accuracy
    end
    ismap = strcmpi(type, 'map');
    agent_code_list = str2num(cell2mat(modelRF.ClassNames)); %#ok<ST2NM> 

    [pixel_inputs, ~, object_id_list] = getClassificationInputs(convertChangeObjects2Pixels(sample_object)); % convert object to pixels as the input of classifier
    [~, pixel_scores_predict] = predict(modelRF, pixel_inputs); clear pixel_inputs;
%     object_ids = unique(object_id_list); % for each object according to ID
    object_ids = [sample_object.ID]; % for each object according to ID
    
    sample_object_predict = [];
    for i = 1: length(object_ids)
        scores_mean = mean(pixel_scores_predict(object_id_list == object_ids(i), :), 1); % find the object's pixels and calculate the mean value
        [scores_mean , ids_scores_sort] = sort(scores_mean, 'descend'); % 1st and 2nd
        if ismap % info for mapping
            sample_object_predict(i).ID          = object_ids(i);
            sample_object_predict(i).PixelIdxList= sample_object(i).PixelIdxList;
        end
%         sample_object_predict(i).object_id   = object_ids(i);
        sample_object_predict(i).agent_primary   = agent_code_list(ids_scores_sort(1));
        sample_object_predict(i).agent_secondary = agent_code_list(ids_scores_sort(2));
        sample_object_predict(i).score_primary   = scores_mean(1);
        sample_object_predict(i).score_secondary = scores_mean(2);
    end
end

