function [modelRF, inputs_training_samples, agents_training_samples] = createPixelClassifierUpdate(tile, iteration, varargin)
%createPixelClassifierUpdate is to create random forest model for ARD tile,
% by appending the new training samples

% message
fprintf('\r* Start of creating pixel classifier\r');

%% Add code paths
pathpackage = fileparts(fileparts(mfilename('fullpath'))); 
addpath(pathpackage); % add ODACA's parent folder
addpath(fullfile(pathpackage, 'Shared')); % add the <Shared>
addpath(fullfile(pathpackage, 'Classification')); % add the <Classification>

%% Setup function
p = inputParser;
addParameter(p,'number',    odacasets.modelRFCNumberTrainingSamples);
addParameter(p,'local',     1.0); % optimal 100% local samples
addParameter(p,'ntrees',    odacasets.modelRFCNumberTrees); % number of random forest's trees
addParameter(p,'nump',      odacasets.modelRFCNumberSamplesUpdateProportion); % 50,000 pixels randomly sampled from all change maps
addParameter(p,'maxnum',    odacasets.traindata_pixel_maxnum_per_object); % maxmum number of pixels per disturbance object
addParameter(p,'maxnumappend',    odacasets.modelRFCMaxNumberTrainingSamplesUpdate); % maxmum number of the appending pixels 
addParameter(p,'fill',      false); % fill training samples using CONUS-wide samples when the local samples are not enough, except of the firt iteration
addParameter(p,'random',    'dynamic'); % dynamic (for test) or static (for production) to select training pixels

parse(p,varargin{:});
total_number    = p.Results.number;
localratio      = p.Results.local;
ntrees          = p.Results.ntrees; % number of random forest's trees
num_mapsamples  = p.Results.nump; % 50,000 pixels randomly sampled from all change maps
maxnum          = p.Results.maxnum; % 1000 training pixels per object
fill            = p.Results.fill; % fill training samples using CONUS-wide samples
random          = p.Results.random; % dynamic or static to select training pixels
maxnumappend    = p.Results.maxnumappend;

max_num_pertype = odacasets.traindata_pixel_num_cache;  % unit: pixels! too large samples here, then downsample them to save memeory

%% To obtain neighbor tiles
if odacasets.neighbor
    tiles = getAdjacentARDTiles(tile); % to add neighbor tiles
else
    tiles = [];    
end

% message
tic;
fprintf('\r Start of loading the local training samples\r');
% agents
agent_names     = lower(fieldnames(odacasets.agents,'-full')); % agents that were defined or focused on
agent_codes     = struct2array(odacasets.agents); % get the value lists
% load training samples, 30 mins in toal for the tile with heavy changes,
% for example CA tile has too many climatic varibility changes
trainingsamples = loadLocalTrainingSamplePixel(tile, agent_names, 'source', 'manual', 'maxload', max_num_pertype, 'maxnum', maxnum);
fprintf('End of loading the local training samples with %0.2f mins\r', toc/60);

%% training a iterated classification model
fprintf('\r Start of creating random forest classifier\r');

% convert to numbers of training samples with maximum number
numbers = [trainingsamples.number];
numbers(numbers> maxnumappend) = maxnumappend; % cannot give too many samples

tic
%% load new sample dataset
[inputs_training_samples_new, agents_training_samples_new] = selectTrainingSamples(tiles, agent_names, agent_codes, numbers, trainingsamples, ...
    max_num_pertype, localratio, maxnum, ...
    'random', random, ... % how to select training pixels,
    'fill', fill); % update the 'trainingsamples' to consider loading backup samples to fill only for the second iteration, that is based on proportional samples
fprintf('New samples:\r');
displaySampleNumbers(agent_names, agent_codes, agents_training_samples_new); % too fast to be displayed
%% load previous samples
filepath_rfc = fullfile(odacasets.pathResultODACA, tile, odacasets.folderRandomForestModel, odacasets.modelRFCName); % see batchCreateClassifier.m
load(filepath_rfc); % 'inputs_training_samples', 'agents_training_samples'
fprintf('Old samples:\r');
displaySampleNumbers(agent_names, agent_codes, agents_training_samples); % too fast to be displayed

%% merge them
inputs_training_samples = [inputs_training_samples; inputs_training_samples_new];
agents_training_samples = [agents_training_samples; agents_training_samples_new];
fprintf('All samples:\r');
displaySampleNumbers(agent_names, agent_codes, agents_training_samples); % too fast to be displayed


% training random forest classifier based on all available pixel samples
% see matlab random forest at https://in.mathworks.com/help/stats/treebagger.html
% training time: 25000 pixel samples in 500 seconds
modelRF = TreeBagger(ntrees, inputs_training_samples, agents_training_samples, 'Method', 'classification', 'NumPredictorsToSample', 'all'); % 'all' invokes Breiman's random forest algorithm
fprintf(' Finished training random forest classifier with %d trees based on %d pixel samples with %0.2f mins\r', ntrees, total_number, toc/60);

end



function displaySampleNumbers(agent_names, agent_codes, agents_training_samples)
    for i = 1: length(agent_names)
        fprintf(' %s: actual number = %d\r', agent_names{i}, sum(agents_training_samples==agent_codes(i)));
    end
end
