function batchClassify(jobid, jobnum, tile, process, mapround)
%% This is to generate RFC with two-time iterations
%% Add code paths
% restoredefaultpath;
% Please run with 1 core to create job list as .mat!!!!!!!!!!!!!!

pathparent = fileparts(fileparts(mfilename('fullpath')));
addpath(genpath(pathparent));


if ~exist('jobid', 'var') || ~exist('jobnum', 'var')
    jobid = 1; jobnum = 1;
end

if ~exist('tile', 'var')
    ARDTilesCentral = odacasets.ARDTiles; % to read central tiles
else
    if ~iscell(tile)
        ARDTilesCentral = {tile};
    end
end

%% NOTE: Please revise line #31 for testing algorithm
if ~exist('process', 'var')
    process = 'product'; % 'product' or 'test'
end
if ~exist('mapround', 'var')
    % mapround = odacasets.refineSampleCollection; % following the sample collection's #
    % mapround = 0;
    % mapround = 1;
    % mapround = 2;
    if isempty(odacasets.refineSampleCollection)
        mapround = 0; % indicate the maps using open-source data
    else
        mapround = odacasets.refineSampleCollection + 1; % following the sample collection's #
    end
end

% mapround = 8;
%% Assign tasks first
filepath_joblist = fullfile(pathparent, 'Classification', 'Jobs', 'arrayjob_list_to_classify.mat');

if jobnum == 0
    tasks = [];
    for iARD = 1: length(ARDTilesCentral) % loop ARD to assign different tile to different cores, that will fully use all the computing resources
        switch process
            case 'test'
                ARDTiles = getAdjacentARDTiles(ARDTilesCentral{iARD}); % to add neighbor tiles. 
            case 'product'
                ARDTiles = {ARDTilesCentral{iARD}}; % to produce
        end
        for jARD = 1: length(ARDTiles) % loop ARD to assign different tile to different cores, that will fully use all the computing resources
            folderpath_input = fullfile(odacasets.pathResultODACA, ARDTiles{jARD}, odacasets.YearlyODACAInputs);
            folderpath_output = fullfile(odacasets.pathResultODACA, ARDTiles{jARD}, odacasets.YearlyODACAOutputs); 
            odaca_inputs = dir(fullfile(folderpath_input, 'record*.mat'));
            for ircord = 1: length(odaca_inputs)
                ic = length(tasks) + 1;
                tasks(ic).tilecenter = ARDTilesCentral{iARD}; 
                tasks(ic).tile = ARDTiles{jARD}; 
                tasks(ic).inpath  = fullfile(folderpath_input, odaca_inputs(ircord).name);
                tasks(ic).outpath = fullfile(folderpath_output, odaca_inputs(ircord).name);
            end
        end
    end
    
    save(filepath_joblist, 'tasks');
    return;
else
    load(filepath_joblist); %#ok<LOAD> 
end

rng(1);
tasks = tasks(randperm(length(tasks)));
    
%% Process each task
for itask = jobid: jobnum: length(tasks)
    taskobj = tasks(itask);
    tile = taskobj.tile;
    tilecenter = taskobj.tilecenter;
    inpath = taskobj.inpath;
    outpath = taskobj.outpath;
    % update the version number appended
    outpath = strrep(outpath, odacasets.YearlyODACAOutputs, [odacasets.YearlyODACAOutputs, sprintf('V%02d', mapround)]);

    if isfile(outpath)
        filesize = dir(outpath);
        if filesize.bytes > 0
            % fprintf('Existing  %s\r', outpath);
            continue;
        end
    end
    fprintf('\nProcessing  %s\r', inpath);

    classifyODACARecordPixel(tile, tilecenter, inpath, outpath, 'mapround', mapround);
end