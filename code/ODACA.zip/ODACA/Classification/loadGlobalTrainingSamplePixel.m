function record_pixels_samples = loadGlobalTrainingSamplePixel(tiles, agent_type, varargin)
%% This is to read the global backup training samples
    p = inputParser;
    addParameter(p, 'source',  'open'); % data source: 'open' or 'manual'
    addParameter(p, 'maxload', []); % number of object samples
    addParameter(p, 'maxnum',  []); % maximum number of pixels per object sample
    parse(p,varargin{:});
    source = p.Results.source;
    max_num_pertype=p.Results.maxload;
    maxnum=p.Results.maxnum;
    
    % loop each class
    % search record_samples_merged_xxx.mat first
    switch source
        case 'open'
            foldernameSamplePixel = odacasets.folderpathGlobalSamplePixel;
        case 'manual'
            foldernameSamplePixel = [odacasets.folderpathGlobalSamplePixel, 'Manual'];
    end

    if ~isempty(maxnum)
        folderpathSamplePixel = sprintf('%s_%04d', foldernameSamplePixel, maxnum); % append the maxnum
        if ~isfolder(folderpathSamplePixel) % we use any one existing if the folder is not available
            folderpathSamplePixel = foldernameSamplePixel;
        end
    else
        folderpathSamplePixel = foldernameSamplePixel;
    end

    samples = dir(fullfile(folderpathSamplePixel, sprintf('record_samples_merged_%s_*.mat', lower(char(agent_type)))));
    % search record_samples_xxx.mat if there are no merged sample pixels
    if isempty(samples)
        samples = dir(fullfile(folderpathSamplePixel, sprintf('record_samples_%s_*.mat', lower(char(agent_type)))));
    end
    record_pixels_samples = [];
    record_objs_samples_all = [];
    for i = 1: length(samples)
        load(fullfile(samples(i).folder, samples(i).name)); % load record_objs_samples
        % how many samples can we have?
        if ~isfield(record_pixels_samples, 'Tile')
            [~, filename_samp]=fileparts(samples(i).name);
            tile_samples = split(filename_samp, '_');
            tile_samples = tile_samples{end-1};
            [record_pixels_samples.Tile] = deal(tile_samples); % that will be used to exclude self tile data
            clear tile_samples;
        end
        record_objs_samples_all = [record_objs_samples_all, record_pixels_samples];
    end
    if ~isempty(record_objs_samples_all)
        record_pixels_samples = record_objs_samples_all; clear record_objs_samples_all;
        sample_tiles = extractfield(record_pixels_samples, 'Tile');
        record_pixels_samples(ismember(sample_tiles, tiles)) = []; % delete the samples within themself
        if length(record_pixels_samples) > max_num_pertype % only load part of them to save memeory
            num_samples = length(record_pixels_samples);
            if num_samples > max_num_pertype % when there are too many samples which are hard to be loaded 
                record_pixels_samples = record_pixels_samples(randperm(num_samples, max_num_pertype));
            end
        end
        if isfield(record_pixels_samples, 'Tile')
            record_pixels_samples = rmfield(record_pixels_samples, 'Tile'); % remove this field
        end
    end
end