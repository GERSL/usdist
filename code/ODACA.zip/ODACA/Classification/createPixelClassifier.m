function [modelRF, trainingsamples, proportions, inputs_training_samples, agents_training_samples] = createPixelClassifier(tile, iteration, varargin)
%CREATEPIXELCLASSIFIER is to create random forest model for ARD tile

% message
start_func_tic = tic;
fprintf('\r* Start of creating pixel classifier\r');

%% Add code paths
pathpackage = fileparts(fileparts(mfilename('fullpath'))); 
addpath(pathpackage); % add ODACA's parent folder
addpath(fullfile(pathpackage, 'Shared')); % add the <Shared>
addpath(fullfile(pathpackage, 'Classification')); % add the <Classification>

%% Setup function
p = inputParser;
addParameter(p,'number',    odacasets.modelRFCNumberTrainingSamples);
addParameter(p,'local',     1.0); % optimal 100% local samples
addParameter(p,'maxnum',    odacasets.traindata_pixel_maxnum_per_object); % maxmum number of pixels per disturbance object
addParameter(p,'numrate',   odacasets.modelRFCMaxRateNewTrainingSamples); % number of new training pixels can be appended, per agent
addParameter(p,'updaterate',odacasets.modelRFCUpdateRateNewTrainingSamples); % The percentage of the training data replaced by the new training pixels; default is 0.1 (taht is 10%)
addParameter(p,'initmodel', []); % set the initlized model, and the default is empty, so this function can create it accordingly
addParameter(p,'proportions', []);

addParameter(p,'random',    'static'); % dynamic (for test) or static (for production) to select training pixels

addParameter(p,'ntrees',    odacasets.modelRFCNumberTrees); % number of random forest's trees
addParameter(p,'minp',      odacasets.modelRFCMinProportion); % 600/ 20,000 see Zhu et al., ISPRS, 2016
addParameter(p,'maxp',      odacasets.modelRFCMaxProportion); % 8000/20,000 see Zhu et al., ISPRS, 2016
addParameter(p,'nump',      odacasets.modelRFCNumberSamplesUpdateProportion); % 50,000 pixels randomly sampled from all change maps
addParameter(p,'cfill',      true); % fill training samples using CONUS-wide samples when the local samples are not enough, except of the last iteration
addParameter(p,'mfill',      false); % fill training samples using Manual interprated samples when the proportions were adjust


parse(p,varargin{:});
total_number    = p.Results.number;
localratio      = p.Results.local;
maxnum          = p.Results.maxnum;  % 1000 training pixels per object
numr            = p.Results.numrate;    % number of new training pixels can be appended, per gent
updaterate      = p.Results.updaterate; % The percentage of the training data replaced by the new training pixels
randseed        = p.Results.random;  % dynamic or static to select training pixels
initmodel       = p.Results.initmodel;
proportions     = p.Results.proportions;

ntrees          = p.Results.ntrees; % number of random forest's trees
min_proportion  = p.Results.minp;   % 600/ 20,000 see Zhu et al., ISPRS, 2016
max_proportion  = p.Results.maxp;   % 8000/20,000 see Zhu et al., ISPRS, 2016
num_mapsamples  = p.Results.nump;   % 50,000 pixels randomly sampled from all change maps
cfill           = p.Results.cfill;   % fill training samples using CONUS-wide samples
mfill           = p.Results.mfill;   % fill training samples using new interprated samples when the proportions were adjust

%% Set up the random's seed, and the MATLAB program will follow
switch randseed % Set random method
    case 'static'
        rng(42); % static seed to re-generate same results
    case 'dynamic'
        rng('shuffle'); % If you want to avoid repeating the same random number arrays when MATLAB restarts, then execute the command,
end

max_num_pertype = odacasets.traindata_pixel_num_cache;  % unit: pixels! too large samples here, then downsample them to save memeory

%% To obtain neighbor tiles
if odacasets.neighbor
    tiles = getAdjacentARDTiles(tile); % to add neighbor tiles
else
    tiles = [];    
end

%% Load the pre-created model's training sample
is_preload_model = true; % see whether we pre-loaded a existing model
if isempty(initmodel)
    inputs_training_samples = [];
    agents_training_samples = [];
    is_preload_model = false;
else
    % obtain the previous training samples
    inputs_training_samples = initmodel.X;
    agents_training_samples = str2double(initmodel.Y);

end
if isempty(proportions)
    is_preload_model = false;
end

% message
tic;
fprintf('\r Start of loading the local training samples\r');
% agents
agent_names     = lower(fieldnames(odacasets.agents,'-full')); % agents that were defined or focused on
agent_codes     = struct2array(odacasets.agents); % get the value lists

%% training a iterated classification model
fprintf('\r Start of creating random forest classifier\r');
for iter = 0: iteration
    fprintf(' Iteration = %02d\r', iter);
    %% Open-sources training samples and their proportions
    if is_preload_model % if the model is preloaded, we will use the previous proportion to do 
        % convert to numbers of training samples
%         numbers = round(proportions.*total_number);
        % count of sample according to the usesage in the previous round
        numbers = zeros(length(agent_codes), 1);
        for icode = 1: length(agent_codes)
            numbers(icode) = length(find(agents_training_samples == agent_codes(icode)));
        end
        fprintf(' Previous samples:\r');
        displaySampleNumbers(agent_names, agent_codes, proportions, round(proportions.*total_number), agents_training_samples); % too fast to be displayed
        trainingsamples = []; % do not record
    else
        if iter == 0 % load the open-source data only at the first equal number model
            % Source #1: Load the open-source training data
            % load training samples, 30 mins in toal for the tile with heavy changes,
            % for example CA tile has too many climatic varibility changes
            fprintf('Open-source training sample:\r');
            trainingsamples = loadLocalTrainingSamplePixel(tile, agent_names, 'source', 'open', 'maxload', max_num_pertype, 'maxnum', maxnum);
            proportions = ones(length(agent_names), 1) ./ length(agent_names);
        else
            % control the minimum and maximum proportion of training samples
            proportions(proportions < min_proportion)       = min_proportion;
            proportions(proportions > max_proportion)       = max_proportion;
            proportions(ismember(agent_names, 'natural_hazard'))    = min_proportion; % minimum proportion for debris that can reduce commision of harvest A LOT
        end
    
        % convert to numbers of training samples
        numbers = round(proportions.*total_number);
        % Examine backup samples, if not enough, we will load it
        tic
        %% code of loading minimum proportion of samples from backup sample dataset
        % NOTE: this function will load the conus-wide samples if local samples are not enough. The values of the trainingsamples will not be changed.
        [inputs_training_samples, agents_training_samples, trainingsamples] = ...
            selectTrainingSamples(tiles, agent_names, agent_codes, numbers, trainingsamples, max_num_pertype, localratio, maxnum, ...
            'fill', iter > 0 & cfill); % update the 'trainingsamples' to consider loading backup samples to fill only for the second iteration, that is based on proportional samples
        displaySampleNumbers(agent_names, agent_codes, proportions, numbers, agents_training_samples); % too fast to be displayed
    end

    %% add new training samples for the last iteration and if we add new training samples
    if iter == iteration && (updaterate > 0 || numr > 0)
        % Source #2: Load the manual training data
        fprintf('Manually interpreted training sample:\r');
        % Option #1: The percentage of updating training pixels per agent
        if updaterate > 0  
            trainingsamples_manual = loadLocalTrainingSamplePixel(tile, agent_names, 'source', 'manual', 'maxload', max_num_pertype, 'maxnum', maxnum);
            fprintf('End of loading the manually interpreted training samples with %0.2f mins\r', toc/60);
            [inputs_training_samples_manual_replace, agents_training_samples_manual_replace] = ...
                selectTrainingSamples(tiles, agent_names, agent_codes, round(numbers.*updaterate), trainingsamples_manual, max_num_pertype, localratio, maxnum, ...
                'fill', false); % only local samples will be added to update maps (do not need CONUS-wide samples)
            % random sort the open-source training samples
            ids_random = randperm(length(agents_training_samples));
            inputs_training_samples = inputs_training_samples(ids_random, :);
            agents_training_samples = agents_training_samples(ids_random);
            clear ids_random; 
            % merge them, note that variable '_replace' MUST be placed at the first 
            inputs_training_samples = [inputs_training_samples_manual_replace; inputs_training_samples];
            clear inputs_training_samples_manual_replace;
            agents_training_samples = [agents_training_samples_manual_replace; agents_training_samples];
            clear agents_training_samples_manual_replace;
            % only remain the number of training samples that we really need
            ids_remain = [];
            for itype = 1: length(numbers)
                ids_agent = find(agents_training_samples == agent_codes(itype));
                if ~isempty(ids_agent)
                    ids_agent = ids_agent(1: min(length(ids_agent), numbers(itype)));
                    ids_remain = [ids_remain; ids_agent];
                end
            end
            clear ids_agent;
            inputs_training_samples = inputs_training_samples(ids_remain, :);
            agents_training_samples = agents_training_samples(ids_remain);
            clear ids_remain;
            
            fprintf('Updated the training sampeles with new manually interpreted training samples with %0.2f percent\r', updaterate.*100);
            displayUsedSampleNumbers(agent_names, agent_codes, agents_training_samples); % too fast to be displayed
        end
        % Option #2: Directly add training pixels
        if numr > 0 % if we need the manual training data to update the preliminary map
            % NOTE: this function will load the conus-wide samples if local samples are not enough. The values of the trainingsamples will not be changed.
            % The number of new training pixels per agent
            [inputs_training_samples_manual, agents_training_samples_manual] = ...
                loadLocalRefineTrainingPixels(tiles, 'maxnum', maxnum, 'random', randseed); % only local samples will be added to update maps (do not need CONUS-wide samples)
            
            [inputs_training_samples_manual, agents_training_samples_manual] = reselectSamples(inputs_training_samples_manual, agents_training_samples_manual, round(numbers.*numr), agent_codes);

            % merge them
            if ~isempty(inputs_training_samples_manual)
                inputs_training_samples = [inputs_training_samples; inputs_training_samples_manual];
                clear inputs_training_samples_manual_add;
                agents_training_samples = [agents_training_samples; agents_training_samples_manual];
                clear agents_training_samples_manual_add;
                fprintf('Used training samples after adding new manually interpreted samples:\r');
                add_sample = true;
            else
                % if we do not update the model, we just return it
                fprintf('Did not add new manually interpreted samples, and will skip update the classification results\r');
                add_sample = false;
                % return;
            end
            displayUsedSampleNumbers(agent_names, agent_codes, agents_training_samples); % too fast to be displayed
        end
        clear trainingsamples_manual;
    end


    %% training random forest classifier based on all available pixel samples
    % see matlab random forest at https://in.mathworks.com/help/stats/treebagger.html
    % training time: 25000 pixel samples in 500 seconds
    % exclude duplicated samples
    [~,ia,~] = unique(inputs_training_samples,'rows'); % returned as a column vector of indices to the first occurrence of repeated elements
    if length(inputs_training_samples) > length(ia)
        fprintf('%d samples duplicated\n', length(inputs_training_samples) - length(ia));
        inputs_training_samples = inputs_training_samples(ia, :);
        agents_training_samples = agents_training_samples(ia);
    else
        % when no new mannual data added/appended, and no duplicated
        % samples, we just use same model trianed in the previous round
        if numr > 0 && ~add_sample
            modelRF = [];
            return;
        end
    end

    modelRF = TreeBagger(ntrees, inputs_training_samples, agents_training_samples, 'Method', 'classification', 'NumPredictorsToSample', 'all'); % 'all' invokes Breiman's random forest algorithm
    fprintf(' Finished training random forest classifier with %d trees based on %d pixel samples with %0.2f mins\r', ntrees, length(agents_training_samples), toc/60);
    
    %% classify the sampled map for estimating proportion of each agent
    if iter < iteration
       tic
       proportions = updateProportionsPixel(tile, modelRF, agent_codes, num_mapsamples); % sampled records only within the central tile's folder
       clear modelRF;
       fprintf(' Finished updating the proportion of agents according to sampled map with %0.2f mins\r', toc/60);
    end
end
fprintf('\r* End of creating random forest classifier with %d iterations with %0.2f mins\r', iteration, toc(start_func_tic)/60);

end

function [inputs_training_samples, agents_training_samples, numbers] = reselectSamples(inputs_training_samples, agents_training_samples, numbers, agent_codes)
    % randomly sort the dataset
    ids_random = randperm(length(agents_training_samples));
    inputs_training_samples = inputs_training_samples(ids_random, :);
    agents_training_samples = agents_training_samples(ids_random);
    % reselect the trianing data according to new proportion from the
    % loaded dataset
    ids_remain = [];
    for itype = 1: length(numbers)
        ids_agent = find(agents_training_samples == agent_codes(itype));
        if ~isempty(ids_agent)
            ids_agent = ids_agent(1: min(length(ids_agent), numbers(itype)));
            ids_remain = [ids_remain; ids_agent];
            numbers(itype) = length(ids_agent); % update the number loaded for the agent
        end
    end
    inputs_training_samples = inputs_training_samples(ids_remain, :);
    agents_training_samples = agents_training_samples(ids_remain);
end

function proportions = updateProportionsPixel(tiles, modelRF, agent_codes, num_mapsamples)
% work on random pixels. no majority vote
    proportions = zeros(size(agent_codes)); % update the propotions for next iteration
    if ~iscell(tiles) % convert to cell array if only one tile inputed
        tiles = {tiles};
    end
    for it = 1: length(tiles)
        % The sampled data's path
        dir_downsampled_data_tile = fullfile(odacasets.pathResultODACA, tiles{it}, sprintf('%s_%d', odacasets.YearlyODACAInputsDownsampled, num_mapsamples) ); % format: xxx_xxx.mat
        dir_downsampled_data_tile_obj = dir_downsampled_data_tile;
        downsampled_data = dir(fullfile(dir_downsampled_data_tile_obj, sprintf('*record_objs_*.mat'))); % see more from function 'produceODACAInputDownsampling'

        for id = 1: length(downsampled_data)
            % loop each sample record
            load(fullfile(downsampled_data(id).folder, downsampled_data(id).name)); % load record_objs
            if ~isempty(record_objs)
                agent_predicted = modelPredict(modelRF, getClassificationInputs(record_objs), true); % true means score processing
                for iagent = 1: length(agent_predicted)
                    proportions(agent_codes==agent_predicted(iagent)) = proportions(agent_codes==agent_predicted(iagent)) + 1; % add one more sample to the agent
                end
            end
        end
    end
    proportions = proportions ./ sum(proportions);
end

function displaySampleNumbers(agent_names, agent_codes, proportions, numbers, agents_training_samples)
    for i = 1: length(agent_names)
        fprintf(' %s: ideal proportion = %0.2f percent, ideal number = %d, actual number = %d\r', agent_names{i}, proportions(i).*100, numbers(i), sum(agents_training_samples==agent_codes(i)));
    end
end
function displayUsedSampleNumbers(agent_names, agent_codes, agents_training_samples)
    for i = 1: length(agent_names)
        fprintf(' %s: actual number = %d\r', agent_names{i}, sum(agents_training_samples==agent_codes(i)));
    end
end