function out = majorityvote(agents, scores, varargin)
%MAJORITYVOTE is to apply a majority vote to determine the type of object
    p = inputParser;
    addParameter(p, 'target', []);
    parse(p,varargin{:});
    ids = p.Results.target;
    
    if isempty(ids)
        out = singlemajorityvote(agents, scores); % return only single result
    else
        ids_uniq = unique(ids); % for each object according to ID
        out = NaN(size(ids));
        for i = 1: length(ids_uniq)
            i_tmp = ids == ids_uniq(i);
            agents_tmp = agents(i_tmp);
            scores_tmp = scores(i_tmp);
            out_tmp = singlemajorityvote(agents_tmp, scores_tmp);
            out(i_tmp) = out_tmp;
        end
    end
end

function out = singlemajorityvote(in, in_score)
    %unique(y):Returns elements in an array with no repetitions.
    %count the number of times a element in an array occurs
    [count, values] = hist(in, unique(in));
    %Find the array index corresponding to  the value with the most occurrences
    [Vmax,argmax]=max(count);
    %Output function with most occurrences
    out = values(argmax);
    
    % if mutilple max values, the one with highest total classification score will be kept
    if sum(count==Vmax) > 1 
        max_values = values(count==Vmax); % the multiple maximum values
        max_values_score = zeros(size(max_values)); % corresponding scores
        for i = 1: length(max_values) % loop each of them to have the total score
            max_values_score(i) = sum(in_score(in == max_values(i))); % total score
        end
        [~,argmax]=max(max_values_score); % to keep the one with highest total score
        out = max_values(argmax);
    end
end
