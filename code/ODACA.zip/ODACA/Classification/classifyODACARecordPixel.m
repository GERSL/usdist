function classifyODACARecordPixel(tile, tilecenter, inpath, outpath, varargin)

% if isfile(outpath)
%     fprintf('Existing  %s\r', outpath);
%     return;
% end
tic
p = inputParser;
addParameter(p, 'mapround',  0); % 0: primlimary map; 1: 1st update using manual training samples
parse(p,varargin{:});
mapround = p.Results.mapround;

%% Add code paths
pathpackage = fileparts(fileparts(mfilename('fullpath'))); 
addpath(pathpackage); % add ODACA's parent folder
addpath(fullfile(pathpackage, 'Shared')); % add the <Shared>
addpath(fullfile(pathpackage, 'Classification')); % add the <Classification>

[outfolderpath] = fileparts(outpath);

if ~isfolder(outfolderpath)
    mkdir(outfolderpath);
end

path_model = fullfile(odacasets.pathResultODACA, tilecenter, odacasets.folderRandomForestModel, [odacasets.modelRFCName, sprintf('_v%02d.mat', mapround)]);
if ~isfile(path_model) % just copy the previous version's results if we do not update the model for this tile
    foldername_now=  [odacasets.YearlyODACAOutputs, sprintf('V%02d', mapround)];
    foldername_pr=  [odacasets.YearlyODACAOutputs, sprintf('V%02d', mapround - 1)];
    outpath_pre = strrep(outpath, foldername_now, foldername_pr);
    copyfile(outpath_pre, outpath);
else
    load(path_model); % modelRF
    
    load(inpath); % record_objs
    
    record_objs = predictDisturbanceAgent(modelRF, record_objs, 'map'); % replace as the classified structure
              
    save(outpath, 'record_objs');
            
    fprintf('Finished processing %s in %0.2f mins\r', outpath, toc/60);
end
end

