function [inputs_training_samples, agents_training_samples, trainingsamples] = selectTrainingSamples(tiles, agent_names, agent_codes, numbers, trainingsamples, max_num_pertype, localratio, maxnum, varargin)
%% This function is to assemble the trianing samples, in which local samples are at highest priorty, and the global backup samples will be used if not enough local samples
    p = inputParser;
    addParameter(p,'fill',      false); % fill training samples using CONUS-wide samples when the local samples are not enough, except of the firt iteration
    parse(p,varargin{:});
    fill = p.Results.fill;
    
    % also support the single number as the input
    if length(numbers) == 1
        numbers = numbers.*ones(length(agent_names), 1);
    end

    inputs_training_samples = [];
    agents_training_samples = [];
    for itype = 1: length(agent_names)
        isample = find(ismember({trainingsamples(:).agent}, agent_names{itype})); % index of the agent type
        num_local_samples = length(trainingsamples(isample).samples);
        
        numbers_local = round(numbers(itype)*localratio);
        % if local not enough, use global backup
        if num_local_samples < numbers_local
            numbers_local = num_local_samples;
        end
        % when 100% local samples, we will not load global backup samples
        if localratio == 1
            numbers_global = 0;
        else
            numbers_global = numbers(itype) - numbers_local;
        end
        % fill local samples using CONUS-wide samples
        if fill
            numbers_global = numbers(itype) - numbers_local;
        end
        
        % loading local samples
        if numbers_local > 0
            num_localsamples = length(trainingsamples(isample).samples);
            inputs_training_samples_type = trainingsamples(isample).samples(:, randperm(num_localsamples, min(numbers_local, num_localsamples)));
            inputs_training_samples = [inputs_training_samples, inputs_training_samples_type];
            agents_training_samples = [agents_training_samples; repmat(agent_codes(itype), length(inputs_training_samples_type), 1)];
            clear inputs_training_samples_type;
        end
        
        % loading global samples
        if numbers_global > 0
            if ~isfield(trainingsamples, 'backupsamples') || isempty(trainingsamples(isample).backupsamples) %  have not already loaded before
                tic
                trainingsamples(isample).backupsamples = loadGlobalTrainingSamplePixel(tiles, agent_names{itype}, 'maxload', max_num_pertype, 'maxnum', maxnum);
                fprintf('Finished loading %s global samples (%d pixels) with %0.2f mins\r', agent_names{itype}, length(trainingsamples(isample).backupsamples), toc/60);
            end
            if ~isempty(trainingsamples(isample).backupsamples)
                num_backupsamples = length(trainingsamples(isample).backupsamples);
                inputs_training_samples_type = trainingsamples(isample).backupsamples(:, randperm(num_backupsamples, min(numbers_global, num_backupsamples)));
                inputs_training_samples = [inputs_training_samples, inputs_training_samples_type];
                agents_training_samples = [agents_training_samples; repmat(agent_codes(itype), length(inputs_training_samples_type), 1)];
            end
            clear inputs_training_samples_type;
        end
    end
    if ~isempty(inputs_training_samples)
        inputs_training_samples = getClassificationInputs(inputs_training_samples);
    end
end