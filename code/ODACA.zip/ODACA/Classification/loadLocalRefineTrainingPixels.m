function   [inputs_training_samples_all, agents_training_samples_all] = loadLocalRefineTrainingPixels(tiles, varargin)
%% This function is to load the trianing samples
    p = inputParser;
    addParameter(p, 'maxnum',  1);         % maximum number of pixels per object sample
    addParameter(p, 'random',    'static'); % dynamic (for test) or static (for production) to select training pixels
    parse(p,varargin{:});
    maxnum=p.Results.maxnum;
    randseed        = p.Results.random;  % dynamic or static to select training pixels
    %% Set up the random's seed, and the MATLAB program will follow
    switch randseed % Set random method
        case 'static'
            rng(42); % static seed to re-generate same results
        case 'dynamic'
            rng('shuffle'); % If you want to avoid repeating the same random number arrays when MATLAB restarts, then execute the command,
    end
    agents_full = odacasets.agents;
    agents_name = fieldnames(agents_full);


    % force to use this directory
    dir_odaca = odacasets.pathResultODACA;
    foldernameSampleObject = sprintf('TrainingSampleObjectRefineV%02d', odacasets.refineSampleCollection);

    inputs_training_samples_all = [];
    agents_training_samples_all = [];
    for it = 1: length(tiles)
        tile = tiles{it};
        sample_records = dir(fullfile(dir_odaca, tile, odacasets.folderTrainingData, foldernameSampleObject, 'record_samples_*.mat'));
        

        inputs_training_samples_tile = [];
        agents_training_samples_tile = [];
        
        for m = 1: length(sample_records)

            % find the agent ID
            [~, filename_samp]=fileparts(sample_records(m).name);
            for iagent = 1: length(agents_name)
                if contains(sample_records(m).name, agents_name{iagent}, 'IgnoreCase',true)
                    agent_code = agents_full.(agents_name{iagent});
                    break;
                end
            end
 
            load(fullfile(sample_records(m).folder, sample_records(m).name)); % load record_objs_samples

            % process each of the object samples, aslo see batchMinimizeTrainingSampleObject.m
            totalnum_samples = length(record_objs_samples);
            num_pixelsamples = 0;

            for i = 1: totalnum_samples
                % find out overlaip
                idx = find(record_objs_samples(i).PixelIdxListSample == 1); 
                % randomly select sample pixels based on the maximum number of pixels per sample object
                if length(idx) > maxnum
                    idx = idx(randperm(length(idx), maxnum));
                    idx = sort(idx);
                end
                % update all the variables one by one
                record_objs_samples(i).PixelIdxList      = record_objs_samples(i).PixelIdxList(idx);
                record_objs_samples(i).DOY               = record_objs_samples(i).DOY(idx);
                record_objs_samples(i).CoeffsMag         = record_objs_samples(i).CoeffsMag(:,idx);
                record_objs_samples(i).CoeffsPre         = record_objs_samples(i).CoeffsPre(:,:,idx);
                record_objs_samples(i).TstartPre         = record_objs_samples(i).TstartPre(idx);
                record_objs_samples(i).TendPre           = record_objs_samples(i).TendPre(idx);
                record_objs_samples(i).RMSEPre           = record_objs_samples(i).RMSEPre(:,idx);
                record_objs_samples(i).CoeffsDurCha      = record_objs_samples(i).CoeffsDurCha(:,:,idx);
                record_objs_samples(i).CoeffsPost        = record_objs_samples(i).CoeffsPost(:,:,idx);
                record_objs_samples(i).TstartPost        = record_objs_samples(i).TstartPost(idx);
                record_objs_samples(i).TendPost          = record_objs_samples(i).TendPost(idx);
                record_objs_samples(i).RMSEPost          = record_objs_samples(i).RMSEPost(:,idx);
                record_objs_samples(i).Interval          = record_objs_samples(i).Interval(idx);
                % record_objs_samples(i).Frequency         = record_objs_samples(i).Frequency(idx);
                record_objs_samples(i).Elev              = record_objs_samples(i).Elev(idx);
                record_objs_samples(i).Slope             = record_objs_samples(i).Slope(idx);
                record_objs_samples(i).Aspect            = record_objs_samples(i).Aspect(idx);
                record_objs_samples(i).PixelIdxListSample= record_objs_samples(i).PixelIdxListSample(idx);
                num_pixelsamples = num_pixelsamples + length(idx);
            end

            % convert to training pixels
            record_pixels_samples = convertChangeObjects2Pixels(record_objs_samples, 'train', true); 
            clear record_objs_samples;
        
            inputs_training_samples_tile = [inputs_training_samples_tile, record_pixels_samples];
            agents_training_samples_tile = [agents_training_samples_tile; repmat(agent_code, length(record_pixels_samples), 1)];
        end

% % %         % filter out 50% construction samples because we selected too many
% % %         % consturction samples
% % %         ids_cons = find(agents_training_samples_tile==3);
% % %         if length(ids_cons) > 1
% % %             ids_more = ids_cons(randperm(length(ids_cons), round(length(ids_cons)*0.5))); % remove 50%
% % %         else
% % %             ids_more = [];
% % %         end
% % %         inputs_training_samples_tile(ids_more) = [];
% % %         agents_training_samples_tile(ids_more) = [];

        inputs_training_samples_all = [inputs_training_samples_all, inputs_training_samples_tile];
        agents_training_samples_all = [agents_training_samples_all; agents_training_samples_tile];
    end
    if isempty(inputs_training_samples_all)
        inputs_training_samples_all = [];
    else
        inputs_training_samples_all = getClassificationInputs(inputs_training_samples_all);
    end
end

