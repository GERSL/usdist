%% Submit classification jobs

%% CD to jobs
cd('Jobs/');

%% Submit jobs to train models
commandStr = sprintf('sbatch %s', 'jobs_train_ttu.sh');
[~, jobid] = system(commandStr);
jobid= split(jobid, ' ');
jobid = str2double(jobid{end});

%% Submit jobs to classify each record
commandStr = sprintf('sbatch --dependency=afterok:%d %s', jobid, 'jobs_classify_ttu.sh');
system(commandStr);

%% CD to be back
cd('../');