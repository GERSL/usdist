function trainingsamples = loadLocalTrainingSamplePixel(tiles, agent_types, varargin )
%% This function is to load the trianing samples
    p = inputParser;
    addParameter(p, 'source',  'open');     % data source: 'open' or 'manual'
    addParameter(p, 'maxload', []);         % number of object samples; unit: pixels per agent
    addParameter(p, 'years',   []);         % number of object samples
    addParameter(p, 'maxnum',  []);         % maximum number of pixels per object sample
    addParameter(p, 'refinesamplec',  odacasets.refineSampleCollection);  % refineSampleCollection
    parse(p,varargin{:});
    source=p.Results.source;
    max_num_pertype=p.Results.maxload;
    years=p.Results.years;
    maxnum=p.Results.maxnum;
    refinesamplec=p.Results.refinesamplec;


    if ~iscell(tiles) % also support single tile at char model
        tiles = {tiles};
    end
    if ~iscategorical(agent_types)
        agent_types = categorical(agent_types);
    end
    if ~isempty(max_num_pertype)
        agent_num_objsamples = countTotalNumSamples(tiles, agent_types); % number of object samples for each type within all study tiles, like 3 by 3 tiles
        agent_perct_objsamples = max_num_pertype./agent_num_objsamples;
        agent_perct_objsamples(agent_perct_objsamples > 1) = 1; % 100% load
    else
        agent_perct_objsamples = ones(size(agent_types)); % 100%
    end

    trainingsamples = [];        
    % loop each class
    for ia = 1: length(agent_types)
        record_pixels_samples_all = [];
        tic
        for it = 1: length(tiles)
            % search record_samples_merged_xxx.mat first
            switch source
                case 'open'
                    folderSamplePixel = odacasets.folderTrainingSamplePixel;
                case 'manual'
                    folderSamplePixel = sprintf('%sManualC%02d', odacasets.folderTrainingSamplePixel, refinesamplec);
            end

            if ~isempty(maxnum)
                folderSamplePixel = sprintf('%s_%04d', folderSamplePixel, maxnum); % append the maxnum
            end
            samples = dir(fullfile(odacasets.pathResultODACA, tiles{it}, odacasets.folderTrainingData, ...
                      folderSamplePixel, sprintf('record_samples_merged_%s_*.mat', lower(char(agent_types(ia))))));
            % search record_samples_xxx.mat if there are no merged sample pixels
            if isempty(samples)
                samples = dir(fullfile(odacasets.pathResultODACA, tiles{it}, odacasets.folderTrainingData, ...
                          folderSamplePixel, sprintf('record_samples_%s_*.mat', lower(char(agent_types(ia))))));
            end

            
            % iterate each of the sample
            for is = 1: length(samples)
                % remove extension
                [~, filename_samp]=fileparts(samples(is).name);
                % how many sample objects stored here?
                num_samples_char = split(filename_samp, '_');
                num_samples = str2double(num_samples_char{end});  
                if ~isempty(years) % force to filter out the datasets not within the defined years
                    year_sample = str2double(num_samples_char{end-6});
                    if ~ismember(year_sample, years)
                        continue;
                    end
                end
                if num_samples > 0
                    load(fullfile(samples(is).folder, samples(is).name)); % load record_objs_samples
                    if agent_perct_objsamples(ia) < 1 % downsampling according to the percentage
                        record_pixels_samples_all = [record_pixels_samples_all, ...
                            record_pixels_samples(randperm(length(record_pixels_samples), round(length(record_pixels_samples).*agent_perct_objsamples(ia))))];
                    else %load all samples
                        record_pixels_samples_all = [record_pixels_samples_all, record_pixels_samples];
                    end
                end
            end
        end

        if ~isempty(record_pixels_samples_all) && isfield(record_pixels_samples_all, 'Tile')
            record_pixels_samples_all = rmfield(record_pixels_samples_all, 'Tile'); % remove this field
        end
        trainingsamples(ia).agent = lower(char(agent_types(ia)));
        trainingsamples(ia).samples = record_pixels_samples_all;
        trainingsamples(ia).number = length(record_pixels_samples_all);
        clear record_pixels_samples_all;
        
        if agent_perct_objsamples(ia) < 1
            fprintf('Finished loading samples for %s (%d pixels) with %0.2f mins (downsampled owing to too many samples)\r', trainingsamples(ia).agent, length(trainingsamples(ia).samples), toc/60);
        else
            fprintf('Finished loading samples for %s (%d pixels) with %0.2f mins\r', trainingsamples(ia).agent, length(trainingsamples(ia).samples), toc/60);
        end
    end
        
end


function num_samples_pertype = countTotalNumSamples(ARDTiles, agent_types)
%% This is to count the total number of samples (objects), and then we can determine whether downsampling the cluster of samples
    % loop each class
    num_samples_pertype = zeros(length(agent_types), 1);
    for ia = 1: length(agent_types)
        total_num_samples_class = 0;
        for it = 1: length(ARDTiles)
            samples = dir(fullfile(odacasets.pathResultODACA, ARDTiles{it}, odacasets.folderTrainingData, ...
                odacasets.folderTrainingSampleModelReady, sprintf('record_samples_%s_*.mat', lower(char(agent_types(ia))))));
             for is = 1: length(samples)
                % remove extension
                [~, filename_samp]=fileparts(samples(is).name);
                % how many sample objects stored here?
                num_samples_char = split(filename_samp, '_');
                total_num_samples_class = total_num_samples_class + str2double(num_samples_char{end});
             end
        end
        num_samples_pertype(ia) = total_num_samples_class;
    end
end