function copyFolders(jobid, jobnum)
if ~exist('jobid', 'var')
    jobid = 1;
end
if ~exist('jobnum', 'var')
    jobnum = 1;
end
%% Add code paths
pathpackage = fileparts(fileparts(mfilename('fullpath'))); 
addpath(pathpackage); % add ODACA's parent folder
addpath(fullfile(pathpackage, 'Shared')); % add the <Shared>
addpath(fullfile(pathpackage, 'Other')); % add the <Other>


%% ARD tiles' list
ARDTiles = odacasets.ARDTiles; % to read central tiles
ARDTiles = getAdjacentARDTiles(ARDTiles); % to add neighbor tiles

%% Loop ARD tile
for iard = jobid: jobnum: length(ARDTiles)
    tic
    tile = ARDTiles{iard};
    folderpath_old = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Classification';
    % folderpath_old = fullfile(folderpath_old, tile, 'RandomForestModel', 'RFC_5000.mat');

%     folderpath_old = fullfile(folderpath_old, tile, odacasets.folderAuxilliaryData, 'DEM', sprintf('%s_DEM.tif',  tile));

%     folderpath_old = fullfile(folderpath_old, tile, odacasets.folderTrainingData, odacasets.folderReferenceLayerNLCD, sprintf('NLCD_%d_%s.tif', 2019, tile) ); % only land cover

    folderpath_old = fullfile(folderpath_old, tile, odacasets.folderAuxilliaryData, 'GSWO');

    if isfolder(folderpath_old) || isfile(folderpath_old)
        folderpath_new = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Classification';
        % folderpath_new = fullfile(folderpath_new, tile,  'RandomForestModel', 'RFC_5000.mat');
%         folderpath_new = fullfile(folderpath_new, tile, odacasets.folderAuxilliaryData, 'DEM', sprintf('%s_DEM.tif',  tile));
%         folderpath_new = fullfile(folderpath_new, tile, odacasets.folderTrainingData, odacasets.folderReferenceLayerNLCD, sprintf('NLCD_%d_%s.tif', 2019, tile) ); % only land cover

        folderpath_new = fullfile(folderpath_new, tile, odacasets.folderTrainingData, odacasets.folderReferenceLayerGSWO);
        
        if ~isfolder(fileparts(folderpath_new))
            mkdir(fileparts(folderpath_new));
        end

        copyfile(folderpath_old,folderpath_new);
        fprintf('Finished copying %s in %0.2f mins\r', folderpath_new, toc/60);
    else
        fprintf('Skipped copying %s in %0.2f mins\r', folderpath_old, toc/60);
    end
    
end