%% Add code paths
pathpackage = fileparts(fileparts(mfilename('fullpath'))); 
addpath(pathpackage); % add ODACA's parent folder
addpath(fullfile(pathpackage, 'Shared')); % add the <Shared>
addpath(fullfile(pathpackage, 'Other')); % add the <Other>


%% ARD tiles' list
ARDTiles = odacasets.ARDTiles; % to read central tiles
ARDTiles = getAdjacentARDTiles(ARDTiles); % to add neighbor tiles

%% Loop ARD tile
for iard = 1: length(ARDTiles)
    tile = ARDTiles{iard};
    
    folderpath = fullfile('/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Classification/', tile);
    % remove_folder(folderpath, 'ChangeObjectOutputV02');
    % remove_folder(folderpath, 'TrainingSampleObjectRefineV01');
    % remove_folder(folderpath, 'ReferenceLayerInterpreted');
    % folderpath = fullfile('/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/Classification/', tile, ...
    %     'TrainingData');
    % remove_folder(folderpath, 'RandomForestModel');
end

function remove_folder(folderpath, foldername)
    if isfolder(fullfile(folderpath, foldername))
        rmdir(fullfile(folderpath, foldername), 's');
        fprintf('Finished removing %s\r', fullfile(folderpath, foldername));
    end
end









