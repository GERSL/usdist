%% Add code paths
pathpackage = fileparts(fileparts(mfilename('fullpath'))); 
addpath(pathpackage); % add ODACA's parent folder
addpath(fullfile(pathpackage, 'Shared')); % add the <Shared>
addpath(fullfile(pathpackage, 'Other')); % add the <Other>


%% ARD tiles' list
ARDTiles = odacasets.ARDTiles; % to read central tiles
ARDTiles = getAdjacentARDTiles(ARDTiles); % to add neighbor tiles

%% Loop ARD tile
for iard = 1: length(ARDTiles)
    tile = ARDTiles{iard};
    try
        % Delete sample object
        folerpath_old = fullfile(odacasets.pathResultODACA, tile, ...
            'TrainingData', ...
            'TrainingSampleObject');
        rmdir(folerpath_old, 's');
        fprintf('Finished deleting %s\r', folerpath_old);

        % Delete sample object
        folerpath_old = fullfile(odacasets.pathResultODACA, tile, ...
            'TrainingData', ...
            'TrainingSamplePixel');
        rmdir(folerpath_old, 's');
        fprintf('Finished deleting %s\r', folerpath_old);
    catch
    end
end

% Delete backup sample
folerpath_old = odacasets.pathResultSampleBackup;
rmdir(folerpath_old, 's');
fprintf('Finished deleting %s\r', folerpath_old);