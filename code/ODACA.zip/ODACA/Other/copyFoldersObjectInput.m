function copyFoldersObjectInput(jobid, jobnum)
if ~exist('jobid', 'var')
    jobid = 1;
end
if ~exist('jobnum', 'var')
    jobnum = 1;
end
%% Add code paths
pathpackage = fileparts(fileparts(mfilename('fullpath'))); 
addpath(pathpackage); % add ODACA's parent folder
addpath(fullfile(pathpackage, 'Shared')); % add the <Shared>
addpath(fullfile(pathpackage, 'Other')); % add the <Other>


%% ARD tiles' list
ARDTiles = odacasets.ARDTiles; % to read central tiles
ARDTiles = getAdjacentARDTiles(ARDTiles); % to add neighbor tiles

%% Loop ARD tile
for iard = jobid: jobnum: length(ARDTiles)
    tic
    tile = ARDTiles{iard};
    folderpath_old = '/shared/cn452/Shi/ProjectCONUSDisturbanceAgent/CONUSProduct/';
    folderpath_old = fullfile(folderpath_old, tile, 'ChangeObjectInput');
    folderpath_new = '/shared/zhulab/Shi/ProjectCONUSDisturbanceAgent/CONUSProduct/';
    folderpath_new = fullfile(folderpath_new, tile, 'ChangeObjectInput');
    if ~isfolder(folderpath_new)
        mkdir(folderpath_new);
    end

    files_old = dir(fullfile(folderpath_old, '*.mat'));
    for ifile  = 1: length(files_old)
        file_old = fullfile(folderpath_old, files_old(ifile).name);


        file_new = fullfile(folderpath_new, files_old(ifile).name);
        if ~isfile(file_new)
   
            copyfile(file_old, file_new);
            fprintf('Finished copying %s in %0.2f mins\r', file_new, toc/60);
  
        end
    end
    
end