#!/bin/bash
#SBATCH -J copy
#SBATCH --partition=priority			# specify partition
#SBATCH --account=zhz18039			# specify the priority account 
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --array 1-20
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err

# Go back to <COLD_v2>
cd ../

module load matlab
matlab -nodisplay -singleCompThread -r "copyFolders($SLURM_ARRAY_TASK_ID, $SLURM_ARRAY_TASK_MAX); exit"


#SBATCH --partition=priority			# specify partition
#SBATCH --account=zhz18039			# specify the priority account 


#SBATCH --partition=general