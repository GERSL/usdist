function outputImagePath = warpRasterRIO(inputImagePath, imgPathLike, outputImagePath)
%CLIPRASTERRIOWARP is to use Python function to clip raster to same extent
%with same resolution
    try
        commandStr = sprintf('. $HOME/miniconda3/etc/profile.d/conda.sh; conda activate dist; rio warp %s %s --like %s --overwrite; conda deactivate;',...
            inputImagePath, outputImagePath, imgPathLike);
        system(commandStr);
    catch
        outputImagePath = [];
        warning('Error: Clipping raster for %s \n', inputImagePath);
    end

end

