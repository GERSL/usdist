function [overall_accuracy_mean, overall_accuracy_standard_error, overall_accuracy_max, overall_accuracy_min, agent_code_true_list, agent_code_primary_list, agent_code_secondary_list] = ...
    estimateAccuracy(tile, iteration, total_num_training_pixels, local_proportion, max_num_pixels_per_sample_object, new_num_training_pixels, new_percent_training_pixels, repeat)

    agent_lut = odacasets.agents;
    overall_accuracy_repeat = [];
    agent_code_true_list = [];
    agent_code_primary_list = [];
    agent_code_secondary_list = [];
    for repeatID = 1: repeat % iterate mutiple times
        agent_code_true = [];
        agent_code_primary = [];
        agent_code_secondary = [];
        for itile = 1: length(tile)   
            % load calibration results
            if isempty(max_num_pixels_per_sample_object)
                if new_percent_training_pixels > 0
                    filename_record = sprintf('record_calibration_%s_%02d_%05d_%03d_%04d_%05d_%03d_%02d.mat', tile{itile}, iteration, total_num_training_pixels, local_proportion*100,  9999, new_num_training_pixels, new_percent_training_pixels, repeatID);
                else % previous version that does not include the tag, new_percent_training_pixels
                    filename_record = sprintf('record_calibration_%s_%02d_%05d_%03d_%04d_%05d_%02d.mat', tile{itile}, iteration, total_num_training_pixels, local_proportion*100, 9999, new_num_training_pixels, repeatID);

                    % also support the newest version
                    if ~isfile( fullfile(testsets.folderpathCalibrationRecord, filename_record))
                        filename_record = sprintf('record_calibration_%s_%02d_%05d_%03d_%04d_%05d_%03d_%02d.mat', tile{itile}, iteration, total_num_training_pixels, local_proportion*100,  9999, new_num_training_pixels, new_percent_training_pixels, repeatID);
                    end
                end
            else
                if new_percent_training_pixels > 0
                    filename_record = sprintf('record_calibration_%s_%02d_%05d_%03d_%04d_%05d_%03d_%02d.mat', tile{itile}, iteration, total_num_training_pixels, local_proportion*100,  max_num_pixels_per_sample_object, new_num_training_pixels, new_percent_training_pixels, repeatID);
                else % previous version that does not include the tag, new_percent_training_pixels
                    filename_record = sprintf('record_calibration_%s_%02d_%05d_%03d_%04d_%05d_%02d.mat', tile{itile}, iteration, total_num_training_pixels, local_proportion*100, max_num_pixels_per_sample_object, new_num_training_pixels, repeatID);
                    
                    % also support the newest version
                    if ~isfile( fullfile(testsets.folderpathCalibrationRecord, filename_record))
                        filename_record = sprintf('record_calibration_%s_%02d_%05d_%03d_%04d_%05d_%03d_%02d.mat', tile{itile}, iteration, total_num_training_pixels, local_proportion*100,  max_num_pixels_per_sample_object, new_num_training_pixels, new_percent_training_pixels, repeatID);
                    end
                end
            end
            filepath_record = fullfile(testsets.folderpathCalibrationRecord, filename_record);
            if isfile(filepath_record)
                load(fullfile(testsets.folderpathCalibrationRecord, filename_record)); %#ok<LOAD> % calibration_samples
                for isamp = 1: length(calibration_samples)
                    agent_code_true         = [agent_code_true,      calibration_samples(isamp).agent_true];
                    agent_code_primary      = [agent_code_primary,   calibration_samples(isamp).agent_primary];
                    agent_code_secondary    = [agent_code_secondary, calibration_samples(isamp).agent_secondary];
                end
            else
                sprintf('Not found %s\n', filepath_record);
            end
        end
        % merge agri. and other into one group --- 'other'
        agent_code_true(agent_code_true==7) = 8;
        agent_code_primary(agent_code_primary==7) = 8;
        overall_accuracy_repeat = [overall_accuracy_repeat; 100*sum(agent_code_true == agent_code_primary)./length(agent_code_true)];

        agent_code_true_list = [agent_code_true_list, agent_code_true];
        agent_code_primary_list = [agent_code_primary_list, agent_code_primary];
        agent_code_secondary_list = [agent_code_secondary_list, agent_code_secondary];

    end
    
    fprintf('repeat times: %d\n', length(overall_accuracy_repeat))
    overall_accuracy_mean = mean(overall_accuracy_repeat);
    overall_accuracy_max = max(overall_accuracy_repeat)-overall_accuracy_mean;
    overall_accuracy_min = overall_accuracy_mean-min(overall_accuracy_repeat);
    overall_accuracy_standard_error = std(overall_accuracy_repeat)./sqrt(length(overall_accuracy_repeat)); %  standard error
end