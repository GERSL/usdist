classdef testsets
    %% sets for ODACA package
    % 
    % Author(s): Shi Qiu, UCONN
    % Last update on Nov 10, 2022

   properties (Constant)
          ARDTiles =  {'h029v005', ... % New England Area
                       'h021v015',... % Southeast
                       'h015v009',... % Great Plains
                       'h007v003', ... % Rocky Mountians
                       'h003v010'};  % Far west

        % Calibration samples
        folderpathCalibrationSample = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/CalibrationODACA/Sample';
        folderpathCalibrationRecord = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/CalibrationODACA/Record';
        folderpathCalibrationModel  = '/gpfs/sharedfs1/zhulab/Shi/ProjectCONUSDisturbanceAgent/CalibrationODACA/Model';
   end
   methods (Static)
        function [iteration, total_num_training_pixels, local_proportion, max_num_pixels_per_sample_object, new_num_training_pixels, new_percent_training_pixels, repeat] = test01()
            %% Test 01: Total number of training samples (unit: pixel) & Iteration times
            iteration                           = [0, 1];                               % total iteration time % only equal number to show out
            total_num_training_pixels           = [1000, 5000, 10000, 15000, 20000];                               % [1000, 2500, 5000, 10000, 15000, 20000]%, 25000]; % totalNumPixels = [10000]; % optimal
            local_proportion                    = [100];                                % 100% local training samples
            max_num_pixels_per_sample_object    = {200, 400, 600, 800, 1000, 1200, 1400, 1600, 1800};                                 % [] means do not trigger this option
            new_num_training_pixels             = [0];                                  % 0 training samples manually added
            new_percent_training_pixels         = [0];                                  % 0% open-source training samples can be replaced with the new training samples
            repeat                              = 10;                                   % how many times repeat to generate the variation
        end
        function [iteration, total_num_training_pixels, local_proportion, max_num_pixels_per_sample_object, new_num_training_pixels, new_percent_training_pixels, repeat] = test02()
            %% Test 02: Maximum number of training samples per object (unit: pixel)
            iteration                           = [1];                                  % total iteration time % only equal number to show out
            total_num_training_pixels           = [5000];                              % totalNumPixels = [10000]; % optimal
            local_proportion                    = [100];                                % 100% local training samples
            max_num_pixels_per_sample_object    = {200, 400, 600, 800, 1000, 1200, 1400, 1600, 1800};  % [] means do not trigger this option
%             max_num_pixels_per_sample_object    = {100, 200, 300, 400, 500, 600, 700, 800, 900, 1000};  % [] means do not trigger this option
%             max_num_pixels_per_sample_object    = {1100, 1200, 1300, 1400, 1500, 1600, 1700, 1800, 1900, 2000};  % [] means do not trigger this option
            new_num_training_pixels             = [0];                                  % 0 training samples manually added
            new_percent_training_pixels         = [0];                                  % 0% open-source training samples can be replaced with the new training samples
            repeat                              = 10;                                   % how many times repeat to generate the variation
        end
        function [iteration, total_num_training_pixels, local_proportion, max_num_pixels_per_sample_object, new_num_training_pixels, new_percent_training_pixels, repeat] = test03()
            %% Test 03: Percentage of local training samples (unit: pixel)
            iteration                           = [1];                                  % total iteration time % only equal number to show out
            total_num_training_pixels           = [10000];                              % totalNumPixels = [10000]; % optimal
            local_proportion                    = [0:10:90];                            % 100% local training samples
            max_num_pixels_per_sample_object    = {1000};                               % [] means do not trigger this option
            new_num_training_pixels             = [0];                                  % 0 training samples manually added
            new_percent_training_pixels         = [0];                                  % 0% open-source training samples can be replaced with the new training samples
            repeat                              = 20;                                   % how many times repeat to generate the variation
        end
        function [iteration, total_num_training_pixels, local_proportion, max_num_pixels_per_sample_object, new_num_training_pixels, new_percent_training_pixels, repeat] = test04()
            %% Test 04: Number of new training samples (unit: pixel)
            iteration                           = [1];                                  % total iteration time % only equal number to show out
            total_num_training_pixels           = [5000];                              % totalNumPixels = [10000]; % optimal
            local_proportion                    = [100];                                % 100% local training samples
            max_num_pixels_per_sample_object    = {[]};                                % [] means do not trigger this option
            new_num_training_pixels             = [1, 2, 3, 4, 5, 10, 20, 30, 40, 50];           % max number per object for the new refining samples
            new_percent_training_pixels         = [0];                                  % 0% open-source training samples can be replaced with the new training samples
            repeat                              = 10;                                   % how many times repeat to generate the variation
        end
        function [iteration, total_num_training_pixels, local_proportion, max_num_pixels_per_sample_object, new_num_training_pixels, new_percent_training_pixels, repeat] = test05()
            %% Test 05: Percentage of replacing the open-source samples with new training samples (unit: %)
            iteration                           = [1];                                  % total iteration time % only equal number to show out
            total_num_training_pixels           = [10000];                              % totalNumPixels = [10000]; % optimal
            local_proportion                    = [100];                                % 100% local training samples
            max_num_pixels_per_sample_object    = {1000};                               % [] means do not trigger this option
            new_num_training_pixels             = [0];                                  % 0 training samples
            new_percent_training_pixels         = [10, 20, 30, 40, 50, 60];             % 20% open-source training samples can be replaced with the new training samples
            repeat                              = 20;                                   % how many times repeat to generate the variation
        end
   end
end