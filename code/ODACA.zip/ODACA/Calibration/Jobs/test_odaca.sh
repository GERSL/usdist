#!/bin/bash
#SBATCH -J test
#SBATCH --partition=general
#SBATCH --constraint='epyc128' # Target the AMD Epyc node architecture 
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --array 1-399
#SBATCH --mem-per-cpu=30G
#SBATCH -o log/%x-out-%A_%4a.out
#SBATCH -e log/%x-err-%A_%4a.err



# cluster nocona quanah  #SBATCH --begin=now+3hours 
cd ../
module load matlab
matlab -nodisplay -singleCompThread -r "testODACA($SLURM_ARRAY_TASK_ID, $SLURM_ARRAY_TASK_MAX, 1); exit" #SBATCH --mem-per-cpu=30G % repeat 10 times, 6000 tasks in total
# matlab -nodisplay -singleCompThread -r "testODACA($SLURM_ARRAY_TASK_ID, $SLURM_ARRAY_TASK_MAX, 2); exit" #SBATCH --mem-per-cpu=30G % repeat 10 times, 450 tasks in total
# matlab -nodisplay -singleCompThread -r "testODACA($SLURM_ARRAY_TASK_ID, $SLURM_ARRAY_TASK_MAX, 4); exit" #SBATCH --mem-per-cpu=30G % repeat 10 times, 300 tasks in total
# matlab -nodisplay -singleCompThread -r "testODACA($SLURM_ARRAY_TASK_ID, $SLURM_ARRAY_TASK_MAX, 5); exit" #SBATCH --mem-per-cpu=30G % repeat 10 times, 600 tasks in total
