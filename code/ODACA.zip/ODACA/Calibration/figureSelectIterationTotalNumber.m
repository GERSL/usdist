
% restoredefaultpath;
% addpath(genpath(fileparts(fileparts(mfilename('fullpath'))))); 
% % Test 01: Total number of training samples & Iteration times
% [iteration, total_num_training_pixels, local_proportion, max_num_pixels_per_sample_object, new_num_training_pixels, new_percent_training_pixels, repeat] = testsets.test01();
% new_num_training_pixels = new_num_training_pixels(1); % only one value should be
% 
% filepath_fig = fullfile(fileparts(mfilename('fullpath')), 'figure', 'fig_select_total_number_samples.tif');
% 
% x_values        = total_num_training_pixels; % X-axis: total number of training samples (unit: pixels)
% 
% fig = figure('Name',  'Iteration and Total Number');
% set(gcf,'color','w');
% set(gcf,'Position',[500 500 350 250]);
% 
% colors = {'#e41a1c', '#377eb8', '#4daf4a', '#984ea3', '#ff7f00', '#ffff33'};
% for iTile = 1: length(testsets.ARDTiles)+ 1
%     
%     if iTile > length(testsets.ARDTiles)
%         tile = testsets.ARDTiles;
%     else
%         tile = testsets.ARDTiles{iTile};
%     end
%     tiles9 = getAdjacentARDTiles(tile); % to add neighbor tiles
%     for iID = iteration
%         y_values        = size(x_values);
%         y_values_stderr = size(x_values);
%         for ix = 1: length(x_values)
%             [y_values(ix), y_values_stderr(ix)] = ...
%                 estimateAccuracy(tiles9, iID, x_values(ix), local_proportion(1)./100, max_num_pixels_per_sample_object{1}, new_num_training_pixels, new_percent_training_pixels, repeat);
%         end
%         if iID == 0
%             [l0,p] = boundedline( ...
%                 x_values, y_values, y_values_stderr, '--ko', ...
%                 'alpha', ...
%                 'transparency', 0.3);
%             l0.DisplayName = 'Equal';
%             l0.LineWidth = 1.5;
%         end
%         if iID == 1
%             [l1,p] = boundedline( ...
%                 x_values, y_values, y_values_stderr, '-ro', ...
%                 'alpha', ...
%                 'transparency', 0.3);
%             l1.DisplayName = 'Proportional';
%             l1.LineWidth = 1.5;
%         end
%         hold on;
%     end
% end
% 
% legend([l0, l1], 'Location', 'southeast');
% xticks(x_values);
% xticklabels(x_values);
% xlabel('Number of Training Pixels');
% ytickformat('%.2f');
% ylabel('Overall Accuracy (%)');
% box on;
% exportgraphics(fig, filepath_fig, 'Resolution', 600);
% close(fig);


restoredefaultpath;
addpath(genpath(fileparts(fileparts(mfilename('fullpath'))))); 
% Test 01: Total number of training samples & Iteration times
[iteration, total_num_training_pixels, local_proportion, max_num_pixels_per_sample_object, new_num_training_pixels, new_percent_training_pixels, repeat] = testsets.test01();
new_num_training_pixels = new_num_training_pixels(1); % only one value should be

max_num_pixels_per_sample_object = { [] };

filepath_fig = fullfile(fileparts(mfilename('fullpath')), 'figure', 'fig_select_total_number_samples.svg');

x_values        = total_num_training_pixels; % X-axis: total number of training samples (unit: pixels)

fig = figure('Name',  'Iteration and Total Number');
set(gcf,'color','w');
set(gcf,'Position',[500 500 350 250]);
for iID = iteration
    y_values        = zeros(size(x_values));
    y_values_stderr = zeros(size(x_values));
    y_values_max_min = zeros(size(x_values, 2), 2);
    for ix = 1: length(x_values)
        [y_values(ix), y_values_stderr(ix), y_values_max_min(ix,1), y_values_max_min(ix,2)] = ...
            estimateAccuracy(testsets.ARDTiles, iID, x_values(ix), local_proportion(1)./100, max_num_pixels_per_sample_object{1}, new_num_training_pixels, new_percent_training_pixels, repeat);
    end
    if iID == 0
        [l0,p] = boundedline( ...
            x_values, y_values, y_values_max_min, '--ko', ...
            'alpha', ...
            'transparency', 0.3);
        l0.DisplayName = 'Equal';
        l0.LineWidth = 1.5;
    end
    if iID == 1
        [l1,p] = boundedline( ...
            x_values, y_values, y_values_max_min, '-ro', ...
            'alpha', ...
            'transparency', 0.3);
        l1.DisplayName = 'Proportional';
        l1.LineWidth = 1.5;
    end
    hold on;
end

legend([l0, l1], 'Location', 'southeast');
xticks(x_values);
xticklabels(x_values);
xlabel('Number of Training Pixels');
ytickformat('%.2f');
ylabel('Overall Accuracy (%)');
box on;
exportgraphics(fig, filepath_fig);
close(fig);