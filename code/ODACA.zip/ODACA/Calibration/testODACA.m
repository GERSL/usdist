function testODACA(taskid, ntasks, testid)
%%TESTODACA is to test ODACA algorithm
%% Setup parallel computing tasks
if ~exist('taskid', 'var') || ~exist('ntasks', 'var')|| ~exist('ntasks', 'var')
    taskid = 85; ntasks = 500; testid = 1;
end

%% Add code paths
restoredefaultpath;
pathparent = fileparts(fileparts(mfilename('fullpath')));
addpath(genpath(pathparent));

%% Test 
switch testid
    case 1 % Test 01: Total number of training samples (unit: pixel) & Iteration times
        [iteration, total_num_training_pixels, local_proportion, max_num_pixels_per_sample_object, new_num_training_pixels, new_percent_training_pixels, repeat] = testsets.test01();
    case 2 % Test 02: Maximum number of training samples per object (unit: pixel) for open data
        [iteration, total_num_training_pixels, local_proportion, max_num_pixels_per_sample_object, new_num_training_pixels, new_percent_training_pixels, repeat] = testsets.test02();
    case 3 % Test 03: Percentage of local training samples (unit: pixel)
        [iteration, total_num_training_pixels, local_proportion, max_num_pixels_per_sample_object, new_num_training_pixels, new_percent_training_pixels, repeat] = testsets.test03();
    case 4 % Test 04: Maximum number of training samples per object when adding interpreted samples (unit: pixel)
        [iteration, total_num_training_pixels, local_proportion, max_num_pixels_per_sample_object, new_num_training_pixels, new_percent_training_pixels, repeat] = testsets.test04();
    case 5 % Test 05: Percentage of replacing the open-source training samples with new samples (unit: %) This was under the maximum 1000 samples per object. Using this method, the disturbance with large area will dominate the training data.
        [iteration, total_num_training_pixels, local_proportion, max_num_pixels_per_sample_object, new_num_training_pixels, new_percent_training_pixels, repeat] = testsets.test05();
end

%% Assign testing tasks
objtasks = [];
centralTiles = testsets.ARDTiles;                                          % to read central tiles
for itile = 1: length(centralTiles)                                         % Five testing tiles
    for iter = 1: length(iteration)                                         % Layer 1
        for itotalnum = 1: length(total_num_training_pixels)                % Layer 2
            for iproport = 1: length(local_proportion)                      % Layer 3
                for imaxnum = 1: length(max_num_pixels_per_sample_object)   % Layer 4
                    for inew = 1: length(new_num_training_pixels)           % Layer 5
                        for inewprt = 1: length(new_percent_training_pixels)% Layer 6
                            for irepeat = 1: repeat                         % Layer 7
                                ic = length(objtasks) + 1;
                                objtasks(ic).tile = centralTiles{itile};
                                objtasks(ic).iteration = iteration(iter);
                                objtasks(ic).total_num_training_pixels = total_num_training_pixels(itotalnum);
                                objtasks(ic).local_proportion = local_proportion(iproport);
                                objtasks(ic).max_num_pixels_per_sample_object = max_num_pixels_per_sample_object{imaxnum};
                                objtasks(ic).new_num_training_pixels = new_num_training_pixels(inew);  % here we defined this as the max num pixels per object we can use
                                objtasks(ic).new_percent_training_pixels = new_percent_training_pixels(inewprt);
                                objtasks(ic).repeatID = irepeat;
                            end
                        end
                    end
                end 
            end     
        end
    end
end
rng(1);
objtasks = objtasks(randperm(length(objtasks)));

%% Run each task
calibration_sample_files = [];
for itask = taskid: ntasks: length(objtasks)
    tic
    %% Restrieve key information for the task assigned
    tile                             = objtasks(itask).tile;
    iteration                        = objtasks(itask).iteration;
    total_num_training_pixels        = objtasks(itask).total_num_training_pixels;
    local_proportion                 = objtasks(itask).local_proportion./100; % conver to 0.01
    max_num_pixels_per_sample_object = objtasks(itask).max_num_pixels_per_sample_object;
    new_num_training_pixels          = objtasks(itask).new_num_training_pixels;
    new_percent_training_pixels      = objtasks(itask).new_percent_training_pixels./100; % conver to 0.01
    repeatID                         = objtasks(itask).repeatID;

    %% Record file's name
    if isempty(max_num_pixels_per_sample_object)
        % filename_record = sprintf('record_calibration_%s_%02d_%05d_%03d_%04d_%02d.mat', tile, iteration, total_num_training_pixels, local_proportion*100, 9999, repeatID);
        % filename_record = sprintf('record_calibration_%s_%02d_%05d_%03d_%04d_%05d_%02d.mat', tile, iteration, total_num_training_pixels, local_proportion*100,  9999, new_num_training_pixels,repeatID);
        filename_record = sprintf('record_calibration_%s_%02d_%05d_%03d_%04d_%05d_%03d_%02d.mat', tile, iteration, total_num_training_pixels, local_proportion*100,  9999, new_num_training_pixels, new_percent_training_pixels*100, repeatID);
    else
        % filename_record = sprintf('record_calibration_%s_%02d_%05d_%03d_%04d_%02d.mat', tile, iteration, total_num_training_pixels, local_proportion*100, max_num_pixels_per_sample_object, repeatID);
        % filename_record = sprintf('record_calibration_%s_%02d_%05d_%03d_%04d_%05d_%02d.mat', tile, iteration, total_num_training_pixels, local_proportion*100,  max_num_pixels_per_sample_object, new_num_training_pixels,repeatID);
        filename_record = sprintf('record_calibration_%s_%02d_%05d_%03d_%04d_%05d_%03d_%02d.mat', tile, iteration, total_num_training_pixels, local_proportion*100,  max_num_pixels_per_sample_object, new_num_training_pixels, new_percent_training_pixels*100, repeatID);
    end

    filepath_record_save = fullfile(testsets.folderpathCalibrationRecord, filename_record);
    filepath_model_save = fullfile(testsets.folderpathCalibrationModel, filename_record);
    if isfile(filepath_record_save) && isfile(filepath_model_save)
        fprintf('\n Existing %s (9999 means infinite)\r', filename_record);
        continue;
    end

    fprintf('\n *********************************************************\r');
    fprintf('\n Processing %s (9999 means infinite)\r', filename_record);
    %% Train model for the central tile
    [modelRF, ~, proportion] = createPixelClassifier(tile, iteration, 'number', total_num_training_pixels, 'local', local_proportion, ...
        'maxnum', max_num_pixels_per_sample_object, 'numn', new_num_training_pixels, 'updaterate', new_percent_training_pixels, 'random', 'dynamic');
    
    %% Classify calibration sample one by one, because some of them are very large, to save memory
    %% NOTE 3-by-3 tiles
    % Find the sample files only one time.
    if isempty(calibration_sample_files)
        calibration_sample_files = dir(fullfile(testsets.folderpathCalibrationSample, 'record_calibration_sample_*.mat'));
    end
    tiles9 = getAdjacentARDTiles(tile); % to add neighbor tiles
    calibration_samples = [];
    for isamplefile = 1: length(calibration_sample_files)
        if contains(calibration_sample_files(isamplefile).name, tiles9) % only process the current tiles
            load(fullfile(calibration_sample_files(isamplefile).folder, calibration_sample_files(isamplefile).name)); %#ok<LOAD> % load sample_object
            for iobj = 1: length(sample_object) % iterate each of the sample objects
                % predict object's agent
                sample_object_predict = predictDisturbanceAgent(modelRF, sample_object(iobj));
                is = length(calibration_samples) + 1;
                % copy sample object's information
                calibration_samples(is).central_tile    = tile; % center tile
                calibration_samples(is).tile            = sample_object(iobj).tile;
                calibration_samples(is).object_id       = sample_object(iobj).ID; % Disturbance object's ID
                calibration_samples(is).year            = sample_object(iobj).year;
                calibration_samples(is).agent_true      = sample_object(iobj).agent;
                % add predicted agents
                calibration_samples(is).agent_primary   = sample_object_predict.agent_primary;
                calibration_samples(is).agent_secondary = sample_object_predict.agent_secondary;
                calibration_samples(is).score_primary   = sample_object_predict.score_primary;
                calibration_samples(is).score_secondary = sample_object_predict.score_secondary;
                clear sample_object_predict;
            end
        end
    end

    %% Save as local file for storing clibration samples
    if ~isfolder(testsets.folderpathCalibrationRecord)
        mkdir(testsets.folderpathCalibrationRecord);
    end
    filepath_save = filepath_record_save;
    save([filepath_save, '.part'], 'calibration_samples', 'proportion', '-v7.3');
    movefile([filepath_save, '.part'], filepath_save);

    %% Save as local file for storing clibration models
    if ~isfolder(testsets.folderpathCalibrationModel)
        mkdir(testsets.folderpathCalibrationModel);
    end
    filepath_save = filepath_model_save;
    save([filepath_save, '.part'], 'modelRF', 'proportion', '-v7.3');
    movefile([filepath_save, '.part'], filepath_save);
    fprintf('Processed %s with %0.2f mins\r', filename_record, toc/60);
end

end

