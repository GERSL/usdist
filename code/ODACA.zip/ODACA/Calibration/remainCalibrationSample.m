% remain calibration samples which still can be used further, based on the
% updated change maps



% Add search paths
restoredefaultpath;
folderpath_mfile = fileparts(mfilename('fullpath'));
addpath(genpath(fileparts(folderpath_mfile)));


% Read sample .csv
% the calibdation samples based on the change maps extracted by using all
% available Landsat single path data,
% here we will keep the samples that we still are able to use
filename_sample_csv = 'calibration_sample_coldv2_singlepath_alldata_createdate_20240426_v8.csv';
calisamples = readtable(fullfile(folderpath_mfile, 'Sample', filename_sample_csv));
calisamples.Agent = strrep(lower(calisamples.Agent),' ','_'); % convert to format to fit the defination in odacasets.m
agent_names = fieldnames(odacasets.agents);
calisamples = calisamples(ismember(calisamples.Agent, agent_names),:);

% ARD tiles that will be used to do the calibration
ARDTiles = testsets.ARDTiles;
ARDTiles = getAdjacentARDTiles(ARDTiles); % 3-by-3 Landsat ARD Tiles

samples_remain_all = [];

for ihv = 1: length(ARDTiles)
    hv_name = ARDTiles{ihv};
    samples = calisamples(ismember(calisamples.Tile, hv_name), :);
    samples = sortrows(samples, {'Year'});
    year_pre = 0;
    id_list_remain = [];
    for isam = 1: height(samples)
        sample = samples(isam,:);

        % Load annual disturbance map and find out the disturbance pixel
        if year_pre ~= sample.Year
            filepath_dist = fullfile(odacasets.pathResultODACA, hv_name, odacasets.folderYearlyCOLDDisturbanceMapObject, ['change_object_',num2str(sample.Year),'.tif']);
            [img_dist, R_dist, bbox] = geotiffread(filepath_dist);
            geoinfo = geotiffinfo(filepath_dist);
    
            img_dist = img_dist> 0 ; % pixel value is the object id
            
            img_dist = bwareaopen(img_dist, odacasets.minarea); % remove tiny objects with fewer than 4 pixels

        end
        % locate the sample over the disturbance map
        lat = sample.latitude;
        lon = sample.longitude;
        [x,y] = projfwd(geoinfo,lat,lon);
        [row, col] = map2pix(R_dist, x, y);
        row = int32(row);
        col = int32(col);
        ind = sub2ind(size(img_dist),row, col); % change row and col to match ID of records

        if img_dist(ind) > 0
            id_list_remain = [id_list_remain; isam];
        end

        % update the recording var
        year_pre = sample.Year;
    end
    samples_remain = samples(id_list_remain, :);
    samples_remain_all = [samples_remain_all; samples_remain];
end

writetable(samples_remain_all, fullfile(folderpath_mfile, 'Sample', 'calibration_sample_coldv2_singlepath_alldata_createdate_20240426_v8_remain_after_composite.csv'));


