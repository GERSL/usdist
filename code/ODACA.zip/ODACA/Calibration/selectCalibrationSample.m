% select the sample pixels based on the change object map which excluded
% the small objects


% Create sample pixels for the algorithem calibration
% 45 ARD tiles   by   20 pixels == 900 sample pixels
% Here we prepare 100 pixels to select 20 for interpretation


% Add search paths
restoredefaultpath;
folderpath_mfile = fileparts(mfilename('fullpath'));
addpath(genpath(fileparts(folderpath_mfile)));

% Number of samples per tile
n_sample_per_tile = 100; % per Tile

% ARD tiles that will be used to do the calibration
ARDTiles = testsets.ARDTiles;
ARDTiles = getAdjacentARDTiles(ARDTiles); % 3-by-3 Landsat ARD Tiles

% start and end years
start_year = odacasets.years(1);
end_year = odacasets.years(end);

% recording variables
lats_tile = [];
lons_tile = [];
years_tile = [];
tilenames = [];

for ihv = 1: length(ARDTiles)
    hv_name = ARDTiles{ihv};
    
    lats_all = [];
    lons_all = [];
    years_all = [];
    for i_year = start_year: end_year
        year = i_year; % e.g., 1985
        % Load annual disturbance map and find out the disturbance pixel
        filepath_dist = fullfile(odacasets.pathResultODACA, hv_name, odacasets.folderYearlyCOLDDisturbanceMapObject, ['change_object_',num2str(year),'.tif']);
        [img_dist, R_dist, bbox] = geotiffread(filepath_dist);
        geoinfo = geotiffinfo(filepath_dist);

        img_dist = img_dist> 0 ; % pixel value is the object id
        
        img_dist = bwareaopen(img_dist, odacasets.minarea); % remove tiny objects with fewer than 4 pixels
        
        IdsDisturb = find(img_dist == 1);

        randID = IdsDisturb(randperm(length(IdsDisturb),round(length(IdsDisturb)./1000)));
        if isempty(randID)
            continue;
        end

        [row, col]= ind2sub(size(img_dist), randID);
        [x, y] = pix2map(R_dist, row, col);
        [lat, lon] = projinv(geoinfo, x, y);

        year = repmat(year, [length(lat),1]);

        lats_all = [lats_all; lat];
        lons_all = [lons_all; lon];
        years_all = [years_all; year];
    end

    ids_random = randperm(length(lats_all), n_sample_per_tile);
    lats_tile = [lats_tile; lats_all(ids_random)];
    lons_tile = [lons_tile; lons_all(ids_random)];
    years_tile = [years_tile; years_all(ids_random)];
    tilenames = [tilenames; repmat(hv_name, n_sample_per_tile, 1)];
end

samplePixelMat = [];
for iPix = 1: length(lats_tile)
    samplePixelMat(iPix).Lat = lats_tile(iPix);
    samplePixelMat(iPix).Lon = lons_tile(iPix);
    samplePixelMat(iPix).Year = years_tile(iPix);
    samplePixelMat(iPix).Tile = tilenames(iPix,:);
end
samplePixelTable = struct2table(samplePixelMat);
writetable(samplePixelTable, fullfile(folderpath_mfile, 'Sample', 'calibration_sample_cold_composite_4500.csv'));
