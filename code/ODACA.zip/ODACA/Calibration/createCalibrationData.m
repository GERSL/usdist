function createCalibrationData(taskid, ntasks)
%CREATECALIBRATIONDATA is to generate change object for calibration, based
%on the calibration sample datasets, with .csv

if ~exist('taskid', 'var') || ~exist('ntasks', 'var')
    taskid = 1; ntasks = 1;
end

%% Add search paths
folderpath_mfile = fileparts(mfilename('fullpath'));
addpath(genpath(fileparts(folderpath_mfile)));

%% Read sample .csv
filename_sample_csv = 'calibration_sample_odaca_450_v1.xlsx';
table_sample = readtable(fullfile(folderpath_mfile, 'Sample', filename_sample_csv));
table_sample.VisualAgent = zeros(height(table_sample), 1);
% prepare the sample's agent according to the interpretation confidence
for i = 1: size(table_sample, 1)
    % define forest as the 1-th
    conf_score = table_sample(i, :).Forest;
    table_sample(i, :).VisualAgent = 1;

    if table_sample(i, :).Constr > conf_score % compared to the maximum value recorded
        table_sample(i, :).VisualAgent = 2; % update the code of disturbance agent
        conf_score = table_sample(i, :).Constr; % updated as to the maximum value
    end
    if table_sample(i, :).Stress > conf_score
        table_sample(i, :).VisualAgent = 3;   
        conf_score = table_sample(i, :).Stress;
    end
    if table_sample(i, :).Hazard > conf_score
        table_sample(i, :).VisualAgent = 4;   
        conf_score = table_sample(i, :).Hazard;
    end
    if table_sample(i, :).Water > conf_score
        table_sample(i, :).VisualAgent = 5;   
        conf_score = table_sample(i, :).Water;
    end
    if table_sample(i, :).Fire > conf_score
        table_sample(i, :).VisualAgent = 6;  
        conf_score = table_sample(i, :).Fire; 
    end
    if table_sample(i, :).Agriculture > conf_score
        table_sample(i, :).VisualAgent = 7;  
        conf_score = table_sample(i, :).Other; 
    end
    if table_sample(i, :).Other > conf_score
        table_sample(i, :).VisualAgent = 7;  
        conf_score = table_sample(i, :).Other; 
    end
end

%% ARD tiles
centralTiles = odacasets.ARDTiles; % to read central tiles
ARDTiles = getAdjacentARDTiles(centralTiles); % to add neighbor tiles


% ARDTiles = {'h021v016'};
%% Assign tasks first
objtasks = [];
for iARD = 1: length(ARDTiles)
    tile = ARDTiles{iARD};
    calisamples_tile = table_sample(ismember(table_sample.Tile, tile),:);
    yrs_uniq = unique(calisamples_tile.Year);
    for iyr = 1: length(yrs_uniq)
        ic = length(objtasks) + 1;
        objtasks(ic).tile = tile;
        objtasks(ic).year = yrs_uniq(iyr);
        objtasks(ic).samples = calisamples_tile(calisamples_tile.Year == yrs_uniq(iyr), :);
    end
end

%% Run each task, 366 tasks in total
for itask = taskid: ntasks: length(objtasks)
    tic
    %% Restrieve key information for the task assigned
    tile = objtasks(itask).tile;
    year = objtasks(itask).year;
    samples = objtasks(itask).samples;

    %% Read change object map
    filepath_dist_obj = fullfile(odacasets.pathResultODACA, tile, odacasets.folderYearlyCOLDDisturbanceMapObject, sprintf('change_object_%d.tif', year));
    [img_dist_obj, R_dist, bbox] = geotiffread(filepath_dist_obj);
    geoinfo = geotiffinfo(filepath_dist_obj);

    %% Restrieve the pixel location and agent for each sample points
    pixelsample = [];
    for isamp = 1: size(samples,1)
        lat = samples(isamp,: ).Latitude;
        lon = samples(isamp,: ).Longitude;
        [x,y] = projfwd(geoinfo,lat,lon);
        [row, col] = map2pix(R_dist, x, y);
        row = int32(row);
        col = int32(col);
        ind = sub2ind(size(img_dist_obj),col, row); % change row and col to match ID of records
        pixelsample(isamp).PixelIdx = ind; % Pixel's ID from the image map
        pixelsample(isamp).ObjectID = img_dist_obj(row, col); % normal row and col to obtain the obejct's id from the map.
        pixelsample(isamp).Agent = samples(isamp,: ).VisualAgent; % Pixel's Agent (interpreted)
    end
    % sort the pixel sample according to disturbance object's ID
    [~, ids_sorted] = sort([pixelsample.ObjectID]);
    pixelsample = pixelsample(ids_sorted);
    
    %% load .mat changes with inputting features  variable name: record_objs
    objectfiles = dir(fullfile(odacasets.pathResultODACA, tile, odacasets.YearlyODACAInputs, sprintf('record_objs_%d_*.mat', year)));

    %% iterate yearly dataset
    sample_object = [];
    for ifile = 1: length(objectfiles)
        [~, object_record_filename] = fileparts(objectfiles(ifile).name);
        filename_parts  = strsplit(object_record_filename, '_'); % e.g, record_objs_1985_0000000001_0000000561.mat
        object_id_start = str2double(filename_parts{end-1});
        object_id_end   = str2double(filename_parts{end});
        
        % continue only when the pixel smaples
        if sum(ismember([pixelsample.ObjectID], object_id_start: object_id_end)) > 0
            % load data
            load(fullfile(objectfiles(ifile).folder, objectfiles(ifile).name)); %#ok<LOAD>  %record_objs
            % restrieve the records with same object ID as the sample
            record_objs = record_objs(ismember([record_objs.ID], [pixelsample.ObjectID]));
            % each objec
            for iobj = 1 : length(record_objs)
                record_objs_sample = record_objs(iobj);

                % loop each sample pixel
                for ipixel = 1: length(pixelsample)
                    if ismember(pixelsample(ipixel).PixelIdx, record_objs_sample.PixelIdxList) % logical here since only one record is here
                        record_objs_sample.agent = pixelsample(ipixel).Agent;
                        record_objs_sample.tile = tile; % same Tile
                        record_objs_sample.year = year; % same Year
                        sample_object = [sample_object, record_objs_sample];
                    end
                end
            end
        end
    end

    if ~isfolder(testsets.folderpathCalibrationSample)
        mkdir(testsets.folderpathCalibrationSample);
    end

    save(fullfile(testsets.folderpathCalibrationSample, sprintf('record_calibration_sample_%s_%d.mat', tile, year)), ...
        'sample_object', '-v7.3');
    fprintf('Processed %s with %0.0f Object Samples for %d in %0.2f mins\r', tile, length(sample_object), year, toc/60);
end

end
