restoredefaultpath;
addpath(genpath(fileparts(fileparts(mfilename('fullpath'))))); 

%% Test sets
iteration                           = 1; % total iteration time % only equal number to show out
total_num_training_pixels           = 10000; % totalNumPixels = [10000]; % optimal
local_proportion                    = 100; % 100% local training samples
max_num_pixels_per_sample_object    = []; % [] means do not trigger this option
repeat                              = 1; % how many times repeat to generate the variation
new_percent_training_pixels         = 0;
new_num_training_pixels             = 0;


%% Load calibration data
tiles = testsets.ARDTiles;
% tiles = {'h003v010'};
for itile = 1: length(tiles)
    tile = tiles{itile};
    tile = {tile};

    [overall_accuracy_mean, overall_accuracy_standard_error, overall_accuracy_max, overall_accuracy_min, agent_code_true_list, agent_code_primary_list, agent_code_secondary_list] = ...
        estimateAccuracy(tile, iteration,  total_num_training_pixels, local_proportion./100, max_num_pixels_per_sample_object, new_num_training_pixels, new_percent_training_pixels, repeat);

    % Obtain all agent information
    agents_name = fieldnames(odacasets.agents); % convert to categorical array
    agents_code = cell2mat(struct2cell(odacasets.agents));  % convert to number array
    % Change agent's name to display (*Simplify agent names)
    agents_name{ismember(agents_name, 'forest_management')}     = 'Fo';
    agents_name{ismember(agents_name, 'agriculture_activity')}  = 'Ag';
    agents_name{ismember(agents_name, 'construction')}          = 'Co';
    agents_name{ismember(agents_name, 'stress')}                = 'St';
    agents_name{ismember(agents_name, 'natural_hazard')}        = 'Nh';
    agents_name{ismember(agents_name, 'water_dynamic')}         = 'Wa';
    agents_name{ismember(agents_name, 'fire')}                  = 'Fi';
    agents_name{ismember(agents_name, 'other')}                 = 'Ot';
    agents_name = categorical(agents_name);

    % Convert code to agent name
    [~, id_list] = ismember(agent_code_true_list, agents_code);
    agent_name_true_list = agents_name(id_list);
    [~, id_list] = ismember(agent_code_primary_list, agents_code);
    agent_name_primary_list = agents_name(id_list);
    clear id_list;


    figname = sprintf('Tile:%s | Total#:%d | Local:%d%%', tiles{itile}, total_num_training_pixels, local_proportion);
    fig = figure('Name',  figname);
    set(gcf,'color','w');
    cm = confusionmat(agent_name_primary_list , agent_name_true_list,  'Order', agents_name); % set true at the second input, to make x-axis is true
    cc = confusionchart(cm, agents_name, 'RowSummary','row-normalized','ColumnSummary','column-normalized');
    sortClasses(cc, agents_name);
    
    %% Custumize items
    title(figname);
    xlabel('Calibration');
    ylabel('Prediction');
end

function [overall_accuracy_mean, overall_accuracy_standard_error, agent_code_true_list, agent_code_primary_list, agent_code_secondary_list] = ...
    loadCalibrationSampleRecord(tile, iteration, total_num_training_pixels, local_proportion, max_num_pixels_per_sample_object, new_percent_training_pixels, repeat)
    agent_lut = odacasets.agents;
    overall_accuracy_repeat = [];
    agent_code_true_list = [];
    agent_code_primary_list = [];
    agent_code_secondary_list = [];
    for repeatID =1: repeat % iterate mutiple times
        agent_code_true = [];
        agent_code_primary = [];
        agent_code_secondary = [];
        for itile = 1: length(tile)
            % load calibration results
            if isempty(max_num_pixels_per_sample_object)
                if new_percent_training_pixels > 0
                    filename_record = sprintf('record_calibration_%s_%02d_%05d_%03d_%04d_%05d_%03d_%02d.mat', tile{itile}, iteration, total_num_training_pixels, local_proportion*100,  9999, new_num_training_pixels, new_percent_training_pixels, repeatID);
                else % previous version that does not include the tag, new_percent_training_pixels
                    filename_record = sprintf('record_calibration_%s_%02d_%05d_%03d_%04d_%05d_%02d.mat', tile{itile}, iteration, total_num_training_pixels, local_proportion*100, 9999, new_num_training_pixels, repeatID);

                    % also support the newest version
                    if ~isfile( fullfile(testsets.folderpathCalibrationRecord, filename_record))
                        filename_record = sprintf('record_calibration_%s_%02d_%05d_%03d_%04d_%05d_%03d_%02d.mat', tile{itile}, iteration, total_num_training_pixels, local_proportion*100,  9999, new_num_training_pixels, new_percent_training_pixels, repeatID);
                    end
                end
   
            else
                if new_percent_training_pixels > 0
                    filename_record = sprintf('record_calibration_%s_%02d_%05d_%03d_%04d_%05d_%03d_%02d.mat', tile{itile}, iteration, total_num_training_pixels, local_proportion*100,  max_num_pixels_per_sample_object, new_num_training_pixels, new_percent_training_pixels, repeatID);
                else % previous version that does not include the tag, new_percent_training_pixels
                    filename_record = sprintf('record_calibration_%s_%02d_%05d_%03d_%04d_%05d_%02d.mat', tile{itile}, iteration, total_num_training_pixels, local_proportion*100, max_num_pixels_per_sample_object, new_num_training_pixels, repeatID);
                    
                    % also support the newest version
                    if ~isfile( fullfile(testsets.folderpathCalibrationRecord, filename_record))
                        filename_record = sprintf('record_calibration_%s_%02d_%05d_%03d_%04d_%05d_%03d_%02d.mat', tile{itile}, iteration, total_num_training_pixels, local_proportion*100,  max_num_pixels_per_sample_object, new_num_training_pixels, new_percent_training_pixels, repeatID);
                    end
                end
   
            end

            load(fullfile(testsets.folderpathCalibrationRecord, filename_record)); %#ok<LOAD> % calibration_samples
            for isamp = 1: length(calibration_samples)
                agent_code_true         = [agent_code_true,      calibration_samples(isamp).agent_true];
                agent_code_primary      = [agent_code_primary,   calibration_samples(isamp).agent_primary];
                agent_code_secondary    = [agent_code_secondary, calibration_samples(isamp).agent_secondary];
            end
        end
        overall_accuracy_repeat = [overall_accuracy_repeat, 100*sum(agent_code_true == agent_code_primary)./length(agent_code_true)];
        agent_code_true_list = [agent_code_true_list, agent_code_true];
        agent_code_primary_list = [agent_code_primary_list, agent_code_primary];
        agent_code_secondary_list = [agent_code_secondary_list, agent_code_secondary];
    end
    
    overall_accuracy_mean = mean(overall_accuracy_repeat);
    overall_accuracy_standard_error = std(overall_accuracy_repeat)./sqrt(length(overall_accuracy_repeat)); %  standard error

end