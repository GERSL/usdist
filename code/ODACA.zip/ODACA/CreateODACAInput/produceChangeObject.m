function produceChangeObject(hv_name, yr)
    % This function is to segment change pixels as objects
    tic
    %% Pre-setted paras
    path_result_changemap_obj = fullfile( odacasets.pathResultODACA, hv_name, odacasets.folderYearlyCOLDDisturbanceMapObject);
    path_out = fullfile(path_result_changemap_obj, sprintf('change_object_%04d.tif', yr));
    if isfile(path_out)
        try % load the data to check
            geoinfo = geotiffinfo(path_out);
            fprintf('Exist %s\r', path_out);
            return;
        catch
        end
    end
    if ~isfolder(path_result_changemap_obj)
        mkdir(path_result_changemap_obj);
    end
    
    path_result_changemap = fullfile(odacasets.pathResultODACA, hv_name, odacasets.folderYearlyCOLDDisturbanceMap);
    img_dist = imread(fullfile(path_result_changemap, ['changemap_typedoy_',num2str(yr),'.tif']));
    % Pixel value: Type*1000 + DOY
    % All changes: 1 -> Regrowth   2 -> Afforestation   3 -> Disturbance
    img_dist = 0 < img_dist & img_dist < 9999;
    img_dist = img_dist'; % Note this!, which ensure the same ID as COLD outputs
    img_dist = bwareaopen(img_dist, odacasets.minarea); % remove tiny objects with fewer than 4 pixels
    obj_dist = bwlabel(img_dist); % 8-connected objects regionprops(img_dist,'PixelIdxList'); same as belabel's object IDs
    
    load(fullfile(odacasets.pathResultCOLD, hv_name, 'metadata.mat')); %#ok<LOAD>
    gridobj = metadata.GRIDobj;
    gridobj.Z = uint32(obj_dist'); % back to normal

    GRIDobj2geotiff(gridobj, path_out);
    fprintf('Finish creating %s with %0.2f mins\r', path_out, toc/60);
end
