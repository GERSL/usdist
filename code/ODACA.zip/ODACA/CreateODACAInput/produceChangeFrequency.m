function produceChangeFrequency(hv_name)
%PRODUCECHANGEFREQUENCY is to calcuale the frequency of land change
    % This function is to segment change pixels as objects
    tic
    %% Pre-setted paras
    years = odacasets.years;
    path_result_changefrequency = fullfile( odacasets.pathResultODACA, hv_name, odacasets.folderChangeFrequencyMap);
    path_out = fullfile(path_result_changefrequency, sprintf('change_frequency_%04d_%04d.tif', min(years), max(years)));
    if isfile(path_out)
        fprintf('Exist %s\r', path_out);
        return;
    end
    if ~isfolder(path_result_changefrequency)
        mkdir(path_result_changefrequency);
    end
    
    frequencymap = [];
    for i = 1: length(years)
        
        path_result_changemap = fullfile(odacasets.pathResultCOLD, hv_name, odacasets.folderYearlyCOLDDisturbanceMap);
        img_dist = imread(fullfile(path_result_changemap, ['changemap_typedoy_',num2str(years(i)),'.tif']));
        % Pixel value: Type*1000 + DOY
        % All changes: 1 -> Regrowth   2 -> Afforestation   3 -> Disturbance
        img_dist = 0 < img_dist & img_dist < 9999;
        img_dist = bwareaopen(img_dist, odacasets.minarea); % remove tiny objects with fewer than 4 pixels
        if isempty(frequencymap)
            frequencymap = double(img_dist);
        else
            frequencymap = frequencymap + double(img_dist);
        end
    end
    
    load(fullfile(odacasets.pathResultCOLD, hv_name, 'metadata.mat')); %#ok<LOAD>
    gridobj = metadata.GRIDobj;
    gridobj.Z = uint8(frequencymap); % 255 at max value

    GRIDobj2geotiff(gridobj, path_out);
    fprintf('Finish creating %s with %0.2f mins\r', path_out, toc/60);
end

