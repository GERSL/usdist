function batchCreateODACAInput(jobid, jobnum, process, ARDTiles)
%% This is to create the inputs of ODACA
%
% INPUT:
%
%   jobid:       Task ID of parallel computation
%
%   jobnum:      Total number of tasks of parallel computation
%
%
% RETURN:
%
%   null
%
% REFERENCE(S):
%
%   null
%
% EXAMPLE OF USE:
%
% 
% AUTHOR(s): Shi Qiu
% DATE: March 27, 2024
% COPYRIGHT @ GERSLab

%% Add code paths
restoredefaultpath;
pathpackage = fileparts(fileparts(mfilename('fullpath'))); 
addpath(genpath(pathpackage)); % add ODACA's parent folder

if ~exist('jobid', 'var')
    jobid = 6; % 25
end

if ~exist('jobnum', 'var')
    jobnum = 100;
end

%% Run defined cores
% jobid = 146; % 146, 159, 162
% jobnum = 162;

%% Define the datasets we will process
if ~exist('process', 'var')
    % process = {'dem', 'changeobject', 'changefrequency'}; % STEP 1 is to produce the DEM, slope, aspect, change object, changefrequency. Default memeory enough
    process = {'dem', 'changeobject'}; % STEP 1 is to produce the DEM, slope, aspect, change object, changefrequency. Default memeory enough
    process = {'changeobject'}; 
    process = {'odacainput'}; % STEP 2 is to produce the ODACA inputs. 20G per core works well for all tiles
    process = {'downsample'}; % STEP 3 is to produce the downsampled ODACA inputs for proportion estimation. 15G per core works well for all tiles
else
    process = {process}; % char to cell
end

%% ARD tiles
if ~exist('ARDTiles', 'var')
    ARDTiles = odacasets.ARDTiles; % to read central tiles
    % ARDTiles = odacasets.ARDTilesTest; % to read central tiles
end

%% Assign tasks first
objtasks = [];
for ipro = 1: length(process)
    % control not to adjacent tiles for downsampling for other processes except for downsampling which will do by itself
    ARDTilesProcess = ARDTiles;
    if ~strcmpi(process{ipro}, 'downsample')
        if odacasets.neighbor
            ARDTilesProcess = getAdjacentARDTiles(ARDTilesProcess); % to add neighbor tiles.
        end
    end
    ARDTilesProcess = unique(ARDTilesProcess);

    % control years
    switch lower(process{ipro})
        case {'dem', 'changefrequency'} % no year input; or, single year
            years = 0;
        otherwise % years to control
            years = odacasets.years;
    end

    % loop years and tiles
    for iyr = 1: length(years)
        for iARD = 1: length(ARDTilesProcess)
            hv_name = ARDTilesProcess{iARD};
            objtasks = [objtasks; ...
                struct('tile', hv_name, 'process', process{ipro}, 'year', years(iyr))];
        end
    end
end
rng(1);
objtasks = objtasks(randperm(length(objtasks)));

%% Process each task
for itask = jobid: jobnum: length(objtasks)
    taskobj = objtasks(itask);
    switch lower(taskobj.process)
        case 'dem'
            produceDEM(taskobj.tile);
        case 'changeobject'
            produceChangeObject(taskobj.tile, taskobj.year);
        case 'changefrequency'
            produceChangeFrequency(taskobj.tile);
        case 'odacainput'
            produceODACAInput(taskobj.tile, taskobj.year);
        case 'downsample'
            produceODACAInputDownsampling(taskobj.tile, taskobj.year, 'sample', 'pixel'); % for proportion estimation
    end
end

end

