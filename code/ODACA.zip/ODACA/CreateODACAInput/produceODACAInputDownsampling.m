function produceODACAInputDownsampling(tile, yr, varargin)
%PRODUCEODACAINPUTDOWNSAMPLING is to downsample the change maps based on
%the normal ODACA Inputs within CONUS region (NLCD 2019)
    p = inputParser;
    addParameter(p,'sample', 'pixel'); % save as pixels 'pixel' or 'object'
    parse(p,varargin{:});
    sample = p.Results.sample;

    tic_start = tic;
    fprintf('* START of downsampling ODACA inputs for %s in', tile);
    for i = 1: length(yr)
        fprintf(' %d', yr(i));
    end
    fprintf('\r');
    
    totalnum = odacasets.modelRFCNumberSamplesUpdateProportion;
    if odacasets.neighbor
        tiles = getAdjacentARDTiles(tile); % to add neighbor tiles
    elseif ~iscell(tile)
        tiles = {tile};
    end
    %% Pre-setted paras
    path_result_odaca = odacasets.pathResultODACA;
    path_obj_downsampled = fullfile(path_result_odaca, tile, sprintf('%s_%d', odacasets.YearlyODACAInputsDownsampled, totalnum));
    if ~isfolder(path_obj_downsampled)
        mkdir(path_obj_downsampled);
    end
    
    %% Load all change maps, ~6G in total for the tiles with heavy changes, such as h003v010
    tic;
    pixelIdxListAll = [];
    pixelYearListAll = []; % convert to [1, 35] from [1985, 2020]
    allyears = odacasets.years;
    pixelTileListAll = [];
    for i = 1: length(tiles) % each tile
        if contains(tiles{i}, 'h') &&  contains(tiles{i}, 'v')
            conus_region = getNLCDCONUSRegion(tiles{i}, 2021); % CONUS region's ROI
        else
            conus_region = [];
        end
        path_objmap = fullfile(path_result_odaca, tiles{i}, odacasets.folderYearlyCOLDDisturbanceMapObject);
        
        for j = 1: length(allyears)
            mapyear = allyears(j);
            changeobjmap = imread(fullfile(path_objmap, sprintf('change_object_%d.tif', mapyear))); % object ID in the map
            if ~isempty(conus_region)
                changeobjmap(~conus_region) = 0; % only analyze CONUS's region
            end
            changeobjmap = find(changeobjmap' > 0); % object ID in the map, same as COLD ID

            if ~isempty(changeobjmap)
                pixelIdxListAll = [pixelIdxListAll; changeobjmap];
                pixelYearListAll = [pixelYearListAll; repmat(uint8(j), size(changeobjmap))];
                pixelTileListAll = [pixelTileListAll; repmat(uint8(i), size(changeobjmap))];
            end
        end
        clear mapyear changeobjmap;
    end
    fprintf('Finish loading the list of pixel ID, Year, and Tile of all change object maps in %0.2f mins\r', toc/60);
    
    %% Randomly select certian number of pixels from change maps
    tic;
    rids = randpermStatic(length(pixelTileListAll), totalnum);
    pixelYearListAll = pixelYearListAll(rids);
    pixelTileListAll = pixelTileListAll(rids);
    pixelIdxListAll = pixelIdxListAll(rids);
    clear rids;
    % working on current tile with defined years
    [~, ids_year] = ismember(yr, allyears);
    ids_year = ismember(pixelYearListAll, ids_year);
    pixelYearListAll = pixelYearListAll(ids_year);
    pixelTileListAll = pixelTileListAll(ids_year);
    pixelIdxListAll = pixelIdxListAll(ids_year);
    clear ids_year;
    
    %% Pick up the change object's ID, according to the change object map. Here, we read it more time to save memory
    for i = 1: length(tiles) % each tile
        path_obj = fullfile(path_result_odaca, tiles{i}, odacasets.YearlyODACAInputs);
        tileyears_id = unique(pixelYearListAll(pixelTileListAll == i)); % years in the sampled map
        for j = 1: length(tileyears_id)
            tileyear = allyears(tileyears_id(j)); % year
            PixelIdxListDownSampled = pixelIdxListAll(pixelTileListAll == i & pixelYearListAll == tileyears_id(j));
            % check out the change object of .mat
            %% Process each of .mat files
            record_mats = dir(fullfile(path_obj, ['record_objs_', num2str(tileyear), '_*.mat']));
            fprintf('A total of %03d groups of change object for %s in %d below:\r', length(record_mats), tiles{i}, tileyear);
            for k = 1: length(record_mats)
                tic
                load(fullfile(record_mats(k).folder, record_mats(k).name));
                ids_valid = zeros(size(record_objs), 'logical'); % zeros at default
                for m = 1: length(record_objs)
                    ismem = ismember(record_objs(m).PixelIdxList, PixelIdxListDownSampled);
                    record_objs(m).PixelIdxListDownSampled = ismem;
                    if sum(ismem(:)) > 0 % sampled one
                        ids_valid(m) = 1;
                    end
                end
                record_objs(~ids_valid) = [];
                if ~isempty(record_objs)
                    if strcmpi(sample, 'pixel') % save as sample pixels, to save memory
                        record_objs = convertChangeObjects2Pixels(record_objs, 'proportion', true);
                        record_objs([record_objs.PixelIdxListDownSampled] == 0) = [];
                    end

                    % .part to avoid errors in saving large data
                    [~, recordname] = fileparts(record_mats(k).name);
                    pathout = fullfile(path_obj_downsampled, sprintf('%s_%s_%010d.mat',tiles{i}, recordname, length(record_objs))); % format: h003v010_record_objs_xxx_xxx.mat
                    save([pathout, '.part'], 'record_objs', '-v7.3');
                    movefile([pathout, '.part'], pathout);
                end
                fprintf('(%03d) Finished downsampling inputs for %s with %0.2f mins\r',k, record_mats(k).name, toc/60);
            end
        end
    end
    
    fprintf('END of downsampling ODACA inputs for %s with %0.2f mins in total\r\r', tile, toc(tic_start)/ 60);
end

function img_nlcd = getNLCDCONUSRegion(hv_name, nlcd_yr)
    nlcdImagePath = fullfile(odacasets.pathResultODACA, hv_name, odacasets.folderTrainingData, odacasets.folderReferenceLayerNLCD, sprintf('%s_nlcd_%d.tif', hv_name, nlcd_yr) ); % only land cover
    img_nlcd = readgeoraster(nlcdImagePath);
    img_nlcd = img_nlcd > 0;
end

