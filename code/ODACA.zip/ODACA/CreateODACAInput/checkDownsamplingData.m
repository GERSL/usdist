  
num_mapsamples = 50000;
tile = 'h003v010';
% The sampled data's path
dir_downsampled_data_tile = fullfile(odacasets.pathResultODACA, tile, ...
    sprintf('%s_%d', odacasets.YearlyODACAInputsDownsampled, num_mapsamples) ); % format: xxx_xxx.mat
downsampled_data = dir(fullfile(dir_downsampled_data_tile, sprintf('*record_objs_*.mat'))); % see more from function 'produceODACAInputDownsampling'
totlnum = 0;
for id = 1: length(downsampled_data)
    % loop each sample record
    load(fullfile(downsampled_data(id).folder, downsampled_data(id).name)); % load record_objs
    for i = 1: length(record_objs)
        totlnum = sum(record_objs(i).PixelIdxListDownSampled) + totlnum
    end
%     record_objs = convertChangeObjects2Median(record_objs, 'proportion', true);
end

% if ~isempty(record_objs)
%                 record_objs = convertChangeObjects2Median(record_objs, 'proportion', true);
%                 agent_predicted = modelPredict(modelRF, getClassificationInputs(record_objs), true); % true means score processing
%                 for iagent = 1: length(agent_predicted)
%                     proportions(agent_codes==agent_predicted(iagent)) = proportions(agent_codes==agent_predicted(iagent)) + record_objs(iagent).NumSamples; % add one more sample to the agent
%                 end
%             end