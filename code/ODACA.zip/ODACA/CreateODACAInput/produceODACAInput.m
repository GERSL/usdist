function produceODACAInput(hv_name, yr)
%PRODUCEODACAINPUT is to create the inputs of ODACA
    
    tic_start = tic;
    fprintf('* START of producing ODACA inputs for %s in %d\r', hv_name, yr);
    
    %% Pre-setted paras
    path_result_odaca = odacasets.pathResultODACA;

    % Path of outputing file
    path_obj = fullfile(path_result_odaca, hv_name, odacasets.YearlyODACAInputs);
    path_mat = fullfile(path_obj, ['record_objs_', num2str(yr), '_%010d_%010d.mat']);
    
    if ~isfolder(path_obj)
        mkdir(path_obj);
    end
    
    %% Load change map object first
    path_changemap_obj = fullfile( odacasets.pathResultODACA, hv_name, odacasets.folderYearlyCOLDDisturbanceMapObject);
    path_changemap_obj = fullfile(path_changemap_obj, sprintf('change_object_%04d.tif', yr));
    changemap_obj = imread(path_changemap_obj);
    
    if sum(sum(changemap_obj)) == 0
        fprintf('No change object!\r\r');
        fprintf('END of producing ODACA inputs for %s in %d with %0.2f mins in total\r\r', hv_name, yr, toc(tic_start)/ 60);
        return;
    end
    
    changemap_obj = changemap_obj'; % same as COLD output
   
    %% Compute fragstats for each change object
    tic
    obj_dist = fragstatsPatch(changemap_obj, 30, 'field', ...% 30 meters in Landsat data
        {'Area', 'PixelIdxList', 'area', 'cai', 'circle', 'contig', 'core', 'enn', 'frac', 'gyrate', 'ncore', 'para', 'perim', 'shape'}); % fields will be processed
    clear changemap_obj;
    fprintf('Finished computing FRAGSTATS with %0.2f mins\r', toc/60);
    
    % Seperate the list of change objects according to the ID of change object
    ids_split = 1;
    for i = 1: 100: length(obj_dist)
        if sum([obj_dist(ids_split(end):i).Area]) >= 200000 % 200, 000 pixels in total to split the objects
            ids_split = [ids_split; i];
        end
    end
    ids_split = [ids_split; length(obj_dist) + 1]; % sine we will substract -1
    
    fprintf('A total of %03d groups of change object below:\r', length(ids_split) - 1);
    % examine existing matlab files
    id_group = 1;
    ids_more = [];
    for i = 1: length(ids_split) - 1
        id_start = ids_split(i);
        id_end = ids_split(i + 1) - 1;
        if isfile(sprintf(path_mat, id_start, id_end))
            ids_more = [ids_more; id_start];
            fprintf('(%03d) Existing inputs for change objects from %09d to %09d\r',id_group, id_start, id_end);
            id_group = id_group + 1;
        end
    end
    ids_split(ismember(ids_split, ids_more)) = [];
    clear ids_more;

    %% Load auxiliary data
    if length(ids_split) > 1
        tic
        [img_dem, img_slope, img_aspect] = loadDEM(hv_name);
        fprintf('Finished loading DEM, slope, and aspect in %0.2f mins\r', toc/60);
        
        % tic
        % changefreqmap = imread(fullfile(path_result_odaca, hv_name, odacasets.folderChangeFrequencyMap, sprintf('change_frequency_%04d_%04d.tif', min(years), max(years))));
        % changefreqmap = double(changefreqmap)./length(years);
        % changefreqmap = changefreqmap';
        % fprintf('Finished loading change frequency in %0.2f mins\r', toc/60);
        
    end
    
    %% load part data to process
    id_group = 1;
    for i = 1: length(ids_split) - 1
        tic
        id_start = ids_split(i);
        id_end = ids_split(i + 1) - 1;
%         ids_list = vertcat(fragstats(id_start: id_end).PixelIdxList); % covnert to 1-d array
        Coeffs = loadCoeffs(hv_name, yr, vertcat(obj_dist(id_start: id_end).PixelIdxList));
        if isempty(Coeffs) % continue when Coeffs is null
            continue;
        end
        %% Process coeffs
        pos_list_coeffs = [Coeffs(:).POS];
        Coeffs = rmfield(Coeffs,{'POS', 'Year'}); % empty fields to save memery
        % Seg the map for the current year and calculate the Shape features
        record_objs = struct('ID', num2cell(id_start: id_end)); % initilize record using ID
        for i_obj = 1: id_end - id_start + 1
            
            id_obj = id_start + i_obj - 1;
            [~,loc]=ismember(obj_dist(id_obj).PixelIdxList, pos_list_coeffs); %  A is found in B.
            record_objs(i_obj).PixelIdxList = obj_dist(id_obj).PixelIdxList;

            % Pixel Value
            record_objs(i_obj).DOY = [Coeffs(loc).DOY];
            record_objs(i_obj).CoeffsMag = [Coeffs(loc).MagCoeffs]; 

            record_objs(i_obj).CoeffsPre = reshape([Coeffs(loc).PreChaCoeffs],[8, 7, length(loc)]);
            record_objs(i_obj).TstartPre = [Coeffs(loc).PreChaTstart]; 
            record_objs(i_obj).TendPre = [Coeffs(loc).PreChaTend]; 
            record_objs(i_obj).RMSEPre = [Coeffs(loc).PreChaRMSE];
            % adjust a0
            a0_tmp = record_objs(i_obj).CoeffsPre(1,:,:);
            a0_tmp = reshape(a0_tmp,[],size(a0_tmp,3),1);
            c_tmp = record_objs(i_obj).CoeffsPre(2,:,:);
            c_tmp = reshape(c_tmp,[],size(c_tmp,3),1);
%             dateAdjust = (record_objs(i_obj).TstartPre + record_objs(i_obj).TendPre)./2;
%             dateAdjustAll= repmat(dateAdjust,size(record_objs(i_obj).CoeffsPre,2),1);
            dateAdjustAll= repmat(record_objs(i_obj).TendPre, size(record_objs(i_obj).CoeffsPre,2),1); % date of the end of the pre-model
            record_objs(i_obj).CoeffsPre(1,:,:) = a0_tmp + c_tmp.*dateAdjustAll;
            clear a0_tmp c_tmp dateAdjust dateAdjustAll;

            % during change
            record_objs(i_obj).CoeffsDurCha = reshape([Coeffs(loc).DurCha],[2, 7, length(loc)]);
            record_objs(i_obj).CoeffsPost = reshape([Coeffs(loc).PostChaCoeffs],[8, 7, length(loc)]);
            record_objs(i_obj).TstartPost = [Coeffs(loc).PostChaTstart];
            record_objs(i_obj).TendPost = [Coeffs(loc).PostChaTend];
            record_objs(i_obj).RMSEPost = [Coeffs(loc).PostChaRMSE];
            % adjust a0
            a0_tmp = record_objs(i_obj).CoeffsPost(1,:,:);
            a0_tmp = reshape(a0_tmp,[],size(a0_tmp,3),1);
            c_tmp = record_objs(i_obj).CoeffsPost(2,:,:);
            c_tmp = reshape(c_tmp,[],size(c_tmp,3),1);
%             dateAdjust = (record_objs(i_obj).TstartPost + record_objs(i_obj).TendPost)./2;
%             dateAdjustAll= repmat(dateAdjust,size(record_objs(i_obj).CoeffsPost,2),1);
            dateAdjustAll= repmat(record_objs(i_obj).TstartPost,size(record_objs(i_obj).CoeffsPost,2),1);  % date of the start of the post-model
            record_objs(i_obj).CoeffsPost(1,:,:) = a0_tmp + c_tmp.*dateAdjustAll;
            clear a0_tmp c_tmp dateAdjust dateAdjustAll;

            record_objs(i_obj).Interval = record_objs(i_obj).TstartPost - record_objs(i_obj).TendPre;
            
            % record_objs(i_obj).Frequency = changefreqmap(obj_dist(id_obj).PixelIdxList);

            % DEM and DEM-drived
            record_objs(i_obj).Elev = img_dem(obj_dist(id_obj).PixelIdxList);
            record_objs(i_obj).Slope = img_slope(obj_dist(id_obj).PixelIdxList);
            record_objs(i_obj).Aspect = img_aspect(obj_dist(id_obj).PixelIdxList);
            record_objs(i_obj).RangElev = range(img_dem(obj_dist(id_obj).PixelIdxList)); % may be helpfull for debris

            % [Texture]
            record_objs(i_obj).StdDOY = std(record_objs(i_obj).DOY); % machanical disturbance may be done at different days (across some months), but natural disturbance such as wind and debris would occur at a same day.
            record_objs(i_obj).StdCoeffsMag = std(record_objs(i_obj).CoeffsMag, 0, 2); % homogenous change or not....
            record_objs(i_obj).StdInterval = std(record_objs(i_obj).Interval); % homogenous change or not....

            % [Shape]
            record_objs(i_obj).area = obj_dist(id_obj).area;
            record_objs(i_obj).cai = obj_dist(id_obj).cai;
            record_objs(i_obj).circle = obj_dist(id_obj).circle;
            record_objs(i_obj).contig = obj_dist(id_obj).contig;
            record_objs(i_obj).core = obj_dist(id_obj).core;
            record_objs(i_obj).enn = obj_dist(id_obj).enn;
            record_objs(i_obj).frac = obj_dist(id_obj).frac;
            record_objs(i_obj).gyrate = obj_dist(id_obj).gyrate;
            record_objs(i_obj).ncore = obj_dist(id_obj).ncore; 
            record_objs(i_obj).para = obj_dist(id_obj).para;
            record_objs(i_obj).perim = obj_dist(id_obj).perim; 
            record_objs(i_obj).shape = obj_dist(id_obj).shape; 
        end % end of collecting the record of objects
        
        % .part to avoid errors in saving large data
        save([sprintf(path_mat, id_start, id_end), '.part'], 'record_objs', '-v7.3');
        movefile([sprintf(path_mat, id_start, id_end), '.part'], sprintf(path_mat, id_start, id_end));
        
        fprintf('(%03d) Finished generating inputs for change objects from %09d to %09d with %0.2f mins\r', id_group, id_start, id_end, toc/60);
        id_group = id_group + 1;
    end % end of spliting

    fprintf('END of producing ODACA inputs for %s in %d with %0.2f mins in total\r\r', hv_name, yr, toc(tic_start)/ 60);
end


function Coeffs = loadCoeffs(hv_name, yr, ids_dist)
    files_coeffs = dir(fullfile(odacasets.pathResultODACA, hv_name, odacasets.folderYearlyCOLDDisturbanceCoeffs, ['rec_changecoeffs_*_',num2str(yr),'.mat'])); % i.e., rec_changecoeffs_1985_part001
    Coeffs = [];
    for i_c = 1: length(files_coeffs)
        load(fullfile(files_coeffs(i_c).folder, files_coeffs(i_c).name)); %#ok<LOAD>
        if ~isempty(rec_changecoeffs)
            rec_changecoeffs(~ismember([rec_changecoeffs.POS], ids_dist)) = []; % remove the pixel, which of object size less than 4 pixels
            if ~isempty(rec_changecoeffs)
                Coeffs = [Coeffs, rec_changecoeffs];
                if length(ids_dist) == length(Coeffs) % when loading done, return soon
                    return;
                end
            end
        end
    end
end

function [img_dem, img_slope, img_aspect] = loadDEM(hv_name)
%% LOADDEM is to load DEM, including elevation, slope, and aspect
% If not slope and aspect, this function will create them based on the
% existing DEM
    path_auxi = fullfile(odacasets.pathResultODACA, hv_name, odacasets.folderAuxilliaryData, odacasets.folderDEM);
    img_dem = GRIDobj(fullfile(path_auxi, sprintf('%s_dem.tif', hv_name)));
    
    path_slope = fullfile(path_auxi, sprintf('%s_slope.tif', hv_name));
    if isfile(path_slope)
        img_slope = imread(path_slope);
    else
        img_slope = arcslope(img_dem, 'deg');
        img_slope = 100.*img_slope.Z; % if we save it locally, we can reduce its volume. aspect_extent.Z = uint16(100.*aspect_extent.Z); % reduce volume 
    end
    path_aspect = fullfile(path_auxi, sprintf('%s_aspect.tif', hv_name));
    if isfile(path_aspect)
        img_aspect= imread(path_aspect);
    else
        img_aspect = aspect(img_dem);
        img_aspect = 100.*img_aspect.Z; % if we save it locally, we can reduce its volume. Which is same to test
    end
    
    img_dem = img_dem.Z';
    img_slope = img_slope';
    img_aspect = img_aspect';
end