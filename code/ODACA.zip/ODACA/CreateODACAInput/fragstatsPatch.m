function raster_patch = fragstatsPatch(raster_map, pixel_size, varargin)
%% fragstatsPatch computes the fragstats at patch level for logical raster
% data.
% 
%
% Description
%
%     This matlab version has been compared to the R package of
%     landscapemetrics at
%     https://r-spatialecology.github.io/landscapemetrics/index.html
%     Note the the shape index is some different to the R pacakge, but same
%     as McGarigal et al.
%
%
% Input arguments
%
%     raster_map       logical raster/ object raster created by the MATLAB
%                      function 'bwlabel'
%     pixel_size       pixel size at meters such Landsat image 30
%
% Output arguments
%
%     raster_patch     patch objects with fragstats
% 
%
% McGarigal, K., Cushman, S.A., and Ene E. 2012. FRAGSTATS v4: Spatial
% Pattern Analysis Program for Categorical and Continuous Maps. Computer
% software program produced by the authors at the University of
% Massachusetts, Amherst. Available at the following website:
% http://www.umass.edu/landeco/research/fragstats/fragstats.html
%
% Nowosad J., TF Stepinski. 2019. Information theory as a consistent
% framework for quantification and classification of landscape patterns.
% https://doi.org/10.1007/s10980-019-00830-x
%
% Author:  Shi Qiu (shi.qiu@uconn.edu)
% Last Date: Jan. 18, 2022
% Copyright @ GERS Lab, UCONN.
%

%% Optional inputs
p = inputParser;
addParameter(p,'field', []); % empty means all fields will be used
% request user's input
parse(p,varargin{:});
field = p.Results.field;

pixel_area = pixel_size.*pixel_size; % meters-squared
[height, width] = size(raster_map);

%% Segment objects
if islogical(raster_map)
    raster_patch_map = bwlabel(raster_map); % create patch object: 8-connected objects regionprops(img_dist,'PixelIdxList'); same as belabel's object IDs
else
    raster_patch_map = raster_map; % patch objects in the map
    raster_map = raster_map > 0; % convert logical raster
end
raster_patch = regionprops(bwconncomp(raster_map), 'Image',  'Area', 'Centroid', 'PixelIdxList', 'PixelList', 'Extrema', 'BoundingBox');

%% Calculate core area
% A cell is defined as core area if the cell has no neighbour with a different value than itself
edge_depth = 1;
raster_core = raster_map;
for idep = 1: edge_depth
    raster_core = imerode(raster_core, [0 1 0; 1 1 1; 0 1 0]); % cannot erode the boundary's pixels
    raster_core(1,:) = 0;
    raster_core(end,:) = 0;
    raster_core(:,1) = 0;
    raster_core(:,end) = 0;
end
raster_core = bwlabel(raster_core);

%% Calculate neighbours for contig
diagonal_neighbours =  imfilter(double(raster_map), [1,0,1; 0, 0, 0; 1, 0, 1], 'corr');
straigth_neighbours =  imfilter(double(raster_map), [0,1,0; 1, 0, 1; 0, 1, 0], 'corr').*2;

%% convert the number of pixels to area in ha
area = num2cell(pixel_area.*[raster_patch(:).Area]./10000);
[raster_patch(:).area] = area{:}; 
clear area;

%% Process each patch
for ipatch = 1: length(raster_patch)
    %% perimeter in meters 
    % PERIM is an 'Area and edge metric'. It equals the
    % perimeter of the patch including also the edge to the landscape
    % boundary. The metric describes patch area (larger perimeter for
    % larger patches), but also patch shape (large perimeter for irregular
    % shapes).
    raster_patch(ipatch).perim = pixel_size.*... % pixel's resolution
        (  sum(sum(     abs(raster_patch(ipatch).Image(2:end, :) - raster_patch(ipatch).Image(1:end-1, :) )  ))  +  sum(raster_patch(ipatch).Image(1, :)) +sum(raster_patch(ipatch).Image(end, :)) +... % remove the connected pixels along i-direction
           sum(sum(     abs(raster_patch(ipatch).Image(:,2: end) - raster_patch(ipatch).Image(:,1: end-1) )  ))  +  sum(raster_patch(ipatch).Image(:, 1)) +sum(raster_patch(ipatch).Image(:, end)) ); % remove the connected pixels along j-direction

    %% gyrate: Radius of Gyration (Area and edge metric)
    % GYRATE is an 'Area and edge metric'. The distance from each cell to
    % the patch centroid is based on cell center to centroid distances. The
    % metric characterises both the patch area and compactness.
    raster_patch(ipatch).gyrate = pixel_size.*sum((sqrt( (raster_patch(ipatch).Centroid(:,1) - [raster_patch(ipatch).PixelList(:,1)]).^2 + (raster_patch(ipatch).Centroid(:,2) - [raster_patch(ipatch).PixelList(:,2)]).^2 ) ))./raster_patch(ipatch).Area;
    
    %% Related Circumscribing Circle
    % circle is a 'Shape metric'. The metric is the ratio between the patch
    % area and the smallest circumscribing circle of the patch. The
    % diameter of the smallest circumscribing circle is the 'diameter' of
    % the patch connecting the opposing corner points of the two cells that
    % are the furthest away from each other. The metric characterises the
    % compactness of the patch and is comparable among patches with
    % different area.
    raster_patch(ipatch).circle = 1- (10000.*raster_patch(ipatch).area) ./ (pi.*(pixel_size.*ExactMinBoundCircle(raster_patch(ipatch).Extrema)).^2);
    
    %% Number of Core Areas
    % ncore is a 'Core area metric'. A cell is defined as core if the cell
    % has no neighbour with a different value than itself (rook's case).
    % The metric counts the disjunct core areas, whereby a core area is a
    % 'patch within the patch' containing only core cells. It describes
    % patch area and shape simultaneously (more core area when the patch is
    % large, however, the shape must allow disjunct core areas). Thereby, a
    % compact shape (e.g. a square) will contain less disjunct core areas
    % than a more irregular patch.
    raster_patch(ipatch).ncore = sum(unique( raster_core(raster_patch(ipatch).PixelIdxList)) > 0);

    %% core is a 'Core area metric' and equals the area within a patch that
    % is not on the edge of it. A cell is defined as core area if the cell
    % has no neighbour with a different value than itself (rook's case). It
    % describes patch area and shape simultaneously (more core area when
    % the patch is large and the shape is rather compact, i.e. a square).
    raster_patch(ipatch).core = pixel_area.*sum(raster_core(raster_patch(ipatch).PixelIdxList)>0)./10000; % in ha

    %%  Contiguity Index
    % contig is a 'Shape metric'. It asses the spatial connectedness (contiguity) of cells in patches.
    raster_patch(ipatch).contig = (( ...
        (sum(diagonal_neighbours(raster_patch(ipatch).PixelIdxList)) + sum(straigth_neighbours(raster_patch(ipatch).PixelIdxList)) + raster_patch(ipatch).Area )  ...
                            ./raster_patch(ipatch).Area) - 1) / 12;

    %% enn is an 'Aggregation metric'. The distance to the nearest
    % neighbouring patch of the same class i. The distance is measured from
    % edge-to-edge. The range is limited by the cell resolution on the
    % lower limit and the landscape extent on the upper limit. The metric
    % is a simple way to describe patch isolation.
    raster_patch(ipatch).enn = 999999; % at default max value = 30.* sqrt(5000*5000 + 5000*5000)
    for pixel_bufer = [50:150:20000] % loop 50 pixels to 20000 pixels, which speed up
        upper_left_pixel = raster_patch(ipatch).BoundingBox([2, 1]) + 0.5;
        lower_right_pixel = upper_left_pixel + raster_patch(ipatch).BoundingBox([4,3]) - 1;
        upper_left_pixel = upper_left_pixel - pixel_bufer;
        upper_left_pixel(upper_left_pixel < 1) = 1;
        lower_right_pixel = lower_right_pixel + pixel_bufer;
        lower_right_pixel(lower_right_pixel > height, 1) = height;
        lower_right_pixel(lower_right_pixel > width,  2) = width;
    
        patch_map_expand = raster_patch_map(upper_left_pixel(1): lower_right_pixel(1), upper_left_pixel(2): lower_right_pixel(2)); % ractangle of the patch with buffer of 100 pixels
    
        patch_map_expand_distance = patch_map_expand > 0;
        patch_map_expand_distance(patch_map_expand==ipatch) = 0; % remove itself patch
        
        if sum(patch_map_expand_distance(:)) == 0
            continue;
        end

        patch_map_expand_distance = bwdist(patch_map_expand_distance, 'euclidean');
    
        raster_patch(ipatch).enn = pixel_size.* min(patch_map_expand_distance(patch_map_expand==ipatch));
        if  ~isempty(raster_patch(ipatch).enn) || isequal(size(patch_map_expand_distance), size(raster_patch_map)) % reach maximum object
            break; % find minimum distance
        end
    end
end

%% Core Area Index
% cai is a 'Core area metric'. It equals the percentage of a patch that is
% core area. A cell is defined as core area if the cell has no neighbour
% with a different value than itself (rook's case). It describes patch area
% and shape simultaneously (more core area when the patch is large and the
% shape is rather compact, i.e. a square). Because the index is relative,
% it is comparable among patches with different area.
cai = num2cell(100.*[raster_patch(:).core]./[raster_patch(:).area]);
[raster_patch(:).cai] = cai{:};
clear cai;

%% Perimeter-Area Ratio
% para is a 'Shape metric'. It describes the patch complexity in a
% straightforward way. However, because it is not standarised to a certain
% shape (e.g. a square), it is not scale independent, meaning that
% increasing the patch size while not changing the patch form will change
% the ratio.
para = num2cell([raster_patch(:).perim]./(10000.*[raster_patch(:).area])); % in the unit of meter
[raster_patch(:).para] = para{:};
clear para;

%% Fractal Dimension Index
% Fractal is a 'Shape metric'. The index is based on the patch perimeter and
% the patch area and describes the patch complexity. Because it is
% standardized, it is scale independent, meaning that increasing the patch
% size while not changing the patch form will not change the ratio. frac:
frac = num2cell( 2.*log(0.25.*[raster_patch(:).perim])./log(10000.*[raster_patch(:).area]) ); % in the unit of meter
[raster_patch(:).frac] = frac{:};
clear frac;

%% Shape Index
% shape is a 'Shape metric'. It describes the ratio between the actual
% perimeter of the patch and the hypothetical minimum perimeter of the
% patch. The minimum perimeter equals the perimeter if the patch would be
% maximally compact.
shape = num2cell( 0.25.*[raster_patch(:).perim]./sqrt(10000.*[raster_patch(:).area]) ); % in the unit of meter
% shape = num2cell( [raster_patch(:).perim]./(2.*sqrt(pi.*10000.*[raster_patch(:).area])) ); % in the unit of meter
[raster_patch(:).shape] = shape{:};
clear shape;

%% Select fields
raster_patch = selectfields(raster_patch, field);
end

%% Below functions are to find the minium circle
% They are from https://in.mathworks.com/matlabcentral/fileexchange/48725-exact-minimum-bounding-spheres-and-circles
function [R,C,Xb]=ExactMinBoundCircle(X)
% Compute exact minimum bounding circle of a 2D point cloud using 
% Welzl's algorithm [1]. 
%
% INPUT:
%   - X     : M-by-2 list of point co-ordinates, where M is the total
%             number of points.
%
% OUTPUT:
%   - R     : radius of the minimum bounding circle of X.
%   - C     : 1-by-2 vector specifying centroid co-ordinates of the minimum
%             bounding circle of X.
%   - Xb    : subset of X, listing K-by-2 list of point co-ordinates from 
%             which R and C were computed. See function
%             'FitCircle2Points' for more info.
%
% REREFERENCES:
% [1] Welzl, E. (1991), 'Smallest enclosing disks (balls and ellipsoids)',
%     Lecture Notes in Computer Science, Vol. 555, pp. 359-370
%
% AUTHOR: Anton Semechko (a.semechko@gmail.com)
%
if nargin<1 || isempty(X) || ~isnumeric(X) || ~ismatrix(X) 
    error('Unrecognized format for 1st input argument (X)')
elseif size(X,2)~=2
    error('This function only works for 2D data')
elseif sum(~isfinite(X(:)))>0
    error('Point data contains NaN and/or Inf entries. Remove them and try again.')    
end
% Get minimum bounding circle
% -------------------------------------------------------------------------
if size(X,1)>2
    
    % Check points for collinearity
    Xo=mean(X,1);
    dX=bsxfun(@minus,X,Xo);
    [U,D]=svd((dX'*dX)/size(X,1),0);
    D=diag(D);
    if D(2)<1E-15
        dx=dX*U(:,1);
        [dx_min,id_min]=min(dx);
        [dx_max,id_max]=max(dx);
        R=(dx_max-dx_min)/2;
        C=U(:,1)'*(dx_max+dx_min)/2 + Xo;
        Xb=X([id_min;id_max],:);
        return
    end
    
    % Get convex hull of the point set
    F=convhull(X);
    F=unique(F(:));
    X=X(F,:);
    
end
try
    % Remove duplicates
    X=uniquetol(X,eps,'ByRows',true);
catch
    % older version of Matlab; 'uniquetol' is unavailable
end
if size(X,1)<3
    [R,C]=FitCircle2Points(X); 
    Xb=X;   
    return
end
% Randomly permute the point set
idx=randperm(size(X,1));
X=X(idx(:),:);
if size(X,1)<1E3
    try
        
        % Center and radius of the circle
        [R,C]=B_MinCircle(X,[]);
        
        % Co-ordinates of the points used to compute parameters of the 
        % minimum bounding circle
        D=sum(bsxfun(@minus,X,C).^2,2);
        [D,idx]=sort(abs(D-R^2));
        Xb=X(idx(1:4),:);
        D=D(1:4);
        Xb=Xb(D<1E-6,:);
        [~,idx]=sort(Xb(:,1));
        Xb=Xb(idx,:);
        return
    catch
    end
end
    
% If we got to this point, then either size(X,1)>=1E3 or recursion depth 
% limit was reached. So need to break-up point-set into smaller sets and 
% then recombine the results.
M=size(X,1);
dM=max(min(floor(M/4),300),3);
res=mod(M,dM);
n=ceil(M/dM);  
idx=dM*ones(1,n);
if res>0
    idx(end)=res;
end
 
if res<0.25*dM && res>0
    idx(n-1)=idx(n-1)+idx(n);
    idx(n)=[];
    n=n-1;
end
X=mat2cell(X,idx,2);
Xb=[];
for i=1:n
    
    % Center and radius of the circle
    [R,C,Xi]=B_MinCircle([Xb;X{i}],[]);    
    
    % 40 points closest to the circle
    if i<1
        D=abs(sum(bsxfun(@minus,Xi,C).^2,2)-R^2);
    else
        D=abs(sqrt(sum(bsxfun(@minus,Xi,C).^2,2))-R);
    end
    [D,idx]=sort(D);
    Xb=Xi(idx(1:min(40,numel(D))),:);
    
end
D=D(1:3);
Xb=Xb(D/R*100<1E-3,:);
[~,idx]=sort(Xb(:,1));
Xb=Xb(idx,:);
    function [R,C,P]=B_MinCircle(P,B)
        
    if size(B,1)==3 || isempty(P)
        [R,C]=FitCircle2Points(B); % fit circle to boundary points
        return
    end
    
    % Remove the last (i.e., end) point, p, from the list
    P_new=P;
    P_new(end,:)=[];
    p=P(end,:);
        
    % Check if p is on or inside the bounding circle. If not, it must be
    % part of the new boundary.
    [R,C,P_new]=B_MinCircle(P_new,B); 
    if isnan(R) || isinf(R) || R<=eps
        chk=true;
    else
        chk=norm(p-C)>(R+eps);
    end
    
    if chk
        B=[p;B];
        [R,C]=B_MinCircle(P_new,B);
        P=[p;P_new];
    end
        
    end
end

function [R,C]=FitCircle2Points(X)
% Fit a circle to a set of 2 or at most 3 points in 3D space. Note that
% point configurations with 3 collinear points do not have well-defined 
% solutions (i.e., they lie on circles with infinite radius).
%
% INPUT:
%   - X     : M-by-2 array of point coordinates, where M<=3.
%
% OUTPUT:
%   - R     : radius of the circle. R=Inf when the circle is undefined, as 
%             specified above.
%   - C     : coordinates of the circle centroid. C=nan(1,2) when the 
%             circle is undefined, as specified above.
%
% AUTHOR: Anton Semechko (a.semechko@gmail.com)
%
N=size(X,1);
if N>3
    error('Input must a N-by-2 array of point coordinates, with N<=3')
end
% Empty set
if isempty(X)
    C=nan(1,2);
    R=nan; 
    return
end
% A single point
if N==1
    C=X;
    R=0;
    return
end
% Line segment
if N==2
    C=mean(X,1);
    R=norm(X(2,:)-X(1,:))/2;
    return
end
% Remove duplicate vertices, if there are any
D=bsxfun(@minus,permute(X,[1 3 2]),permute(X,[3 1 2]));
D=sqrt(sum(D.^2,3));
D(1:(N+1):end)=Inf;
chk=D<=1E-12;
if sum(chk(:))>0
    for i=1:(N-1)
        if size(X,1)<=i, break; end
        idx=chk(i,:);
        idx(1:i)=false;
        idx=find(idx);
        chk(idx,:)=[];
        chk(:,idx)=[];
        X(idx,:)=[];
    end
    [R,C]=FitCircle2Points(X);
    return
end
% Three unique, though possibly collinear points
tol=1E-2; % collinearity threshold (in degrees)
   
% Check for collinearity
D12=X(2,:)-X(1,:); D12=D12/norm(D12);
D13=X(3,:)-X(1,:); D13=D13/norm(D13);
chk=abs(D12*D13(:));
chk(chk>1)=1;
if acos(chk)*(180/pi)<tol
    R=inf;
    C=nan(1,2);
    return
end
% Circle centroid
A=2*bsxfun(@minus,X(2:3,:),X(1,:));
b=sum(bsxfun(@minus,X(2:3,:).^2,X(1,:).^2),2);
C=(A\b)';
% Circle radius
R=sqrt(sum((X(1,:)-C).^2,2));
end

function out = selectfields(inp, req, noerr) 
% selectfields  Select fields from struct with optional noerror 
%  2017-07-09  Matlab2006+  Copyright (c) 2017, W J Whiten  BSD License
%  2019-03-12  Updated for struct arrays, thanks Jos, Stephen
%  2019-03-13  Code replaced by tidier code from Stephen Cobeldick & Jos
%
% s2=selectfields(s1,names,noerror)
%  inp      Input struct or cell array of pairs
%  req      Cell array of field names to be copied
%  noerr    If present no error message if any name not a struct field
%
%  out      Struct giving selected fields from struct1
%
% Examples:
% t1=selectfields(struct('a',[1,2,3],'b',2,'c',3),{'a','c'})
% t1 = 
%   struct with fields:
% 
%     a: [1 2 3]
%     c: 3
%
% selectfields(struct('a',1,'c',3,'aa',11),{'a','b','c'},true)
% ans = 
%   struct with fields:
% 
%     a: 1
%     c: 3

% see https://in.mathworks.com/matlabcentral/fileexchange/63774-selectfields-select-specified-field-names-from-a-struct
if(~isstruct(inp))
    error('selectfields: first input must be a struct')
end
% check for invalid req names
idx = ~isfield(inp,req ); 
if( (nargin<3||~noerr) && any(idx) )
    str = sprintf(' %s,',req{idx }); 
    error('selectfields: Fieldnames not in structure:%s',str ) 
end
% remove fields not needed
out = rmfield(inp,setdiff(fieldnames(inp),req )); 
end

%% Backup 
% % %     TO CALCUALTE THE ENN WITH CENTROIDS
% % %     centroids  = reshape([raster_patch([1: ipatch-1 , ipatch+1: end]).Centroid], [2, length(raster_patch) - 1])'; % covnert to list of points with i, and j
% % %     centroids_near = abs(centroids-raster_patch(ipatch).Centroid);
% % %     centroids_near = centroids_near(:,1) < 100 & centroids_near(:,2) < 100;
% % %     centroids = centroids(centroids_near,:);
% % %     [~, enn ] = knnsearch( centroids, raster_patch(ipatch).Centroid, 'K', 1, 'Distance', 'euclidean');
% % %     if isempty(enn) % no other remaining points
% % %          raster_patch(ipatch).enn = 999999; % unlimited distance will indicate a isolated patch, that will be processed in the unit of meters
% % %     else
% % %          raster_patch(ipatch).enn = pixel_size.*enn; % in the unit of meters
% % %     end



%% In R package 
% library(landscapemetrics)
% library(raster)
% landscape <- raster('../changeobjectmap_1985_oneobj.tif')
%
% https://r-spatialecology.github.io/landscapemetrics/reference/index.html
% test = lsm_p_area(landscape) % done to comapred to R version
% test = lsm_p_cai(landscape) % done to comapred to R version
% test = lsm_p_circle(landscape) % done to comapred to R version
% test = lsm_p_contig(landscape) % done to comapred to R version
% test = lsm_p_core(landscape) % done to comapred to R version
% test = lsm_p_enn(landscape) % same as the McGarigal, K., Cushman, S.A., and Ene E. 2012. 
% test = lsm_p_frac(landscape) % done to comapred to R version
% test = lsm_p_gyrate(landscape) % done to comapred to R version
% test = lsm_p_ncore(landscape) % done to comapred to R version
% test = lsm_p_para(landscape) % done to comapred to R version
% test = lsm_p_perim(landscape) % done to comapred to R version
% test = lsm_p_shape(landscape) % done to comapred to R version