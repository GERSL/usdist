function produceDEM(hv_name, isupdate)

%% Add search paths
folderpath_mfile = fileparts(mfilename('fullpath'));
folderpath_parent = fileparts(folderpath_mfile);
addpath(folderpath_parent);
addpath(folderpath_mfile);
clear folderpath_mfile folderpath_parent;

if ~exist('isupdate', 'var')
    isupdate = 0; % label for updating the existing file
end

global pathResultODACA;

% out
if ~isempty(pathResultODACA)
    folderpath_auxi = fullfile(pathResultODACA, hv_name, odacasets.folderAuxilliaryData, odacasets.folderDEM);
else
    folderpath_auxi = fullfile(odacasets.pathResultODACA, hv_name, odacasets.folderAuxilliaryData, odacasets.folderDEM);
end
if ~isfolder(folderpath_auxi)
    mkdir(folderpath_auxi);
end

% Find out the tile extent
load(fullfile(odacasets.pathResultCOLD, hv_name, 'metadata.mat')); %#ok<LOAD>
extent_gridobj = metadata.GRIDobj;

path_dem_saving = fullfile(folderpath_auxi, sprintf('%s_dem.tif', hv_name));
path_slope_saving = fullfile(folderpath_auxi, sprintf('%s_slope.tif', hv_name));
path_aspect_saving = fullfile(folderpath_auxi, sprintf('%s_aspect.tif', hv_name));
    
%% DEM
if ~isupdate && isfile(path_dem_saving) % do not update the file and it has existed
    fprintf('Exist: %s\n', path_dem_saving);
else 
    if isempty(extent_gridobj)
        extent_gridobj = GRIDobj(filepath_hv_extent);
    end
    DEM_extent = readopentopo('extent',extent_gridobj, 'demtype', 'SRTMGL1',...
        'verbose',false, 'apikey', odacasets.openTopoAPIKey);
    DEM_extent = reproject2utm(DEM_extent,extent_gridobj);
    DEM_extent.Z = int16(DEM_extent.Z); % reduce volume
    GRIDobj2geotiff(DEM_extent, path_dem_saving);
    fprintf('Created: %s\n', path_dem_saving);
end

%% To save disk, we do not save the slope and aspect data locally
% % % %% Slope
% % % if ~isupdate && isfile(path_slope_saving) % do not update the file and it has existed
% % %     fprintf('Exist: %s\n', path_slope_saving);
% % % else
% % %     slope_extent = arcslope(DEM_extent, 'deg');
% % %     slope_extent.Z = uint16(100.*slope_extent.Z); % reduce volume 
% % %     GRIDobj2geotiff(slope_extent, path_slope_saving);
% % %     fprintf('Created: %s\n', path_slope_saving);
% % % end
% % % 
% % % %% Aspect
% % % if ~isupdate && isfile(path_aspect_saving) % do not update the file and it has existed
% % %     fprintf('Exist: %s\n', path_aspect_saving);
% % % else
% % %     aspect_extent = aspect(DEM_extent);
% % %     aspect_extent.Z = uint16(100.*aspect_extent.Z); % reduce volume 
% % %     GRIDobj2geotiff(aspect_extent, path_aspect_saving);
% % %     fprintf('Created: %s\n', path_aspect_saving);
% % % end
