function DEM = uminus(DEM)
DEM.Z = uminus(DEM.Z);