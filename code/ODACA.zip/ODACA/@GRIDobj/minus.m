function OUT = minus(varargin)

funname = 'minus';
narginchk(2,2)
OUT = builtincaller(funname,varargin{:});